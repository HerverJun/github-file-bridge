# 引子：一九五六年七月 | PROLOGUE: JULY 1956

达林顿府
Darlington Hall

看来，这些天来一直在我心头盘桓的那次远行计划越来越像是真的要成行了。
It seems increasingly likely that I really will undertake the expedition that has been preoccupying my imagination now for some days.

我应该说明的是，这是一次叨光法拉戴先生的福特轿车的舒适旅行；一次依我看来将带我穿越英格兰众多最优美的乡村盛景，去往西南诸郡的远行，而且会让我离开达林顿府的时间长达五六天之久。
An expedition, I should say, which I will undertake alone, in the comfort of Mr Farraday's Ford; an expedition which, as I foresee it, will take me through much of the finest countryside of England to the West Country, and may keep me away from Darlington Hall for as much as five or six days.

之所以有此旅行的念头，我应该特意指出，是源自差不多两个礼拜前的一个下午，由法拉戴先生本人主动向我提出的一个最为慷慨的建议。
The idea of such a journey came about, I should point out, from a most kind suggestion put to me by Mr Farraday himself one afternoon almost a fortnight ago, when I had been dusting the portraits in the library.

当时我正在藏书室里为那些肖像掸尘，准确地说，我记得是站在梯凳上为韦瑟比子爵的肖像掸尘，我的雇主拿着几本书进来，大概是准备放回书架上。
In fact, as I recall, I was up on the step-ladder dusting the portrait of Viscount Wetherby when my employer had entered carrying a few volumes which he presumably wished returned to the shelves.

看到我在那儿，他就趁便通知我，他刚刚确定下来，要在八月和九月间返回美国，为期五周时间。
On seeing my person, he took the opportunity to inform me that he had just that moment finalized plans to return to the United States for a period of five weeks between August and September.

说完正事之后，我的雇主将那几本书放到书桌上，往chaise-longue上一躺，两腿一伸。
Having made this announcement, my employer put his volumes down on a table, seated himself on the chaise-longue, and stretched out his legs.

就是在那个时候，他抬头看着我，跟我说道：
It was then, gazing up at me, that he said.

“你该知道，史蒂文斯，我可不希望你在我离开的这段时间里就一直被闭锁在这幢房子里。
‘You realize, Stevens, I don't expect you to be locked up here in this house all the time I'm away.

你何不开着那辆轿车，到某个地方消遣几天呢？
Why don't you take the car and drive off somewhere for a few days?

你看起来是该好好享受一次休假了。”
You look like you could make good use of a break.’

这个建议突如其来，我一时间不知该如何应答才好。
Coming out of the blue as it did, I did not quite know how to reply to such a suggestion.

我记得我对于他的体恤下情表达了谢意，不过很有可能并没有做出任何明确的表态，因为我的雇主又接着道：
I recall thanking him for his consideration, but quite probably I said nothing very definite for my employer went on:

“我这话是认真的，史蒂文斯。
‘I'm serious, Stevens.

我真的认为你应该休个假了。
I really think you should take a break.

汽油的花费由我来承担。
I'll foot the bill for the gas.

你们这帮家伙，你们总是把自己闭锁在这些深宅大院里忙这忙那，干吗不出去四处走走，看看你们这个美丽的国家呢？”
You fellows, you're always locked up in these big houses helping out, how do you ever get to see around this beautiful country of yours?’

这不是我的雇主第一次提出这样一个问题了；看来，这倒确实是让他大为费心的一件事。
This was not the first time my employer had raised such a question; indeed, it seems to be something which genuinely troubles him.

在这种情况下，当我站在那个梯凳上的时候，我脑子里倒是浮现出了一个回答；大意是：虽然从旅行观光、游览乡村盛景的角度上来说，我们确实对这个国家所知甚少，但是干我们这一行的，对于英格兰的“见识”却实际上比大多数人都更胜一筹，因为我们就身处这个国家名流显贵云集的显赫府第当中。
On this occasion, in fact, a reply of sorts did occur to me as I stood up there on the ladder; a reply to the effect that those of our profession, although we did not see a great deal of the country in the sense of touring the countryside and visiting picturesque sites, did actually ‘see’ more of England than most, placed as we were in houses where the greatest ladies and gentlemen of the land gathered.

当然了，我在向法拉戴先生表达这一观点的时候，却又不太可能不给人一种自以为是的冒昧感觉。
Of course, I could not have expressed this view to Mr Farraday without embarking upon what might have seemed a presumptuous speech.

所以我也只能满足于简单地如此答复：
I thus contented myself by saying simply:

“这些年来，就在这幢府第当中，我已经尽享饱览英格兰的无限精华之特权了，先生。”
‘It has been my privilege to see the best of England over the years, sir, within these very walls.’

法拉戴先生似乎不太明白我的言下之意，因为他仍旧只是继续道：“我是认真的，史蒂文斯。
Mr Farraday did not seem to understand this statement, for he merely went on: ‘I mean it, Stevens.

一个人不能到处走走，见识一下自己的国家，这是大不应该的。
It's wrong that a man can't get to see around his own country.

接受我的建议，到外面去待上个几天吧。”
Take my advice, get out of the house for a few days.’

你也能预料得到，那天下午我根本就没把法拉戴先生的建议当真，只是把它当作一位美国绅士不太熟悉在英格兰通常哪些事该做、哪些事又不该做的又一例证。
As you might expect, I did not take Mr Farraday's suggestion at all seriously that afternoon, regarding it as just another instance of an American gentleman's unfamiliarity with what was and what was not commonly done in England.

而我在接下来的几天里对这一建议的态度之所以发生了改变—的确，前往西南诸郡一游的打算在我的思绪中越来越挥之不去—无疑实质上应该归因于—我又何必隐瞒呢？—肯顿小姐的来信，如果不算圣诞贺卡的话，这是几乎七年来她写给我的第一封信。
The fact that my attitude to this same suggestion underwent a change over the following days – indeed, that the notion of a trip to the West Country took an ever-increasing hold on my thoughts – is no doubt substantially attributable to – and why should I hide it? – the arrival of Miss Kenton's letter, her first in almost seven years if one discounts the Christmas cards.

但还是让我马上讲清楚我这话是什么意思吧；我想说的是，肯顿小姐的来信引发了我一连串与达林顿府的管理事务相关的想法，我需要强调指出的是，正是由于府第的管理事务已经成为眼下的当务之急，才促使我重新考虑我的雇主那完全出自好意的建议。不过，还是让我进一步作一番解释吧。
But let me make it immediately clear what I mean by this; what I mean to say is that Miss Kenton's letter set off a certain chain of ideas to do with professional matters here at Darlington Hall, and I would underline that it was a preoccupation with these very same professional matters that led me to consider anew my employer's kindly meant suggestion. But let me explain further.

事实上，在过去这几个月里，我在履行自己的职责方面犯下了一系列小小的差池。
The fact is, over the past few months, I have been responsible for a series of small errors in the carrying out of my duties.

我应该说明，这些差池毫无例外，本身都是非常微不足道的。
I should say that these errors have all been without exception quite trivial in themselves.

尽管如此，我想您也能理解，对于一个不习惯于犯下此类差池的人而言，这一发展趋势还是令我备感不安的，实际上，针对其源头，我也确实已经开始认真考虑各种防微杜渐的措施了。
Nevertheless, I think you will understand that to one not accustomed to committing such errors, this development was rather disturbing, and I did in fact begin to entertain all sorts of alarmist theories as to their cause.

正如在这种情况下屡见不鲜的，之前我对于最显而易见的事实竟然一直都视而不见—也就是说，一直到我开始反复咂摸肯顿小姐来信的个中深意，我才终于豁然开朗，看清楚了那个简单的事实：最近几个月来的那些小小不言的差池也确实没什么大不了的，全都源自人员配置上的先天缺陷。
As so often occurs in these situations, I had become blind to the obvious – that is, until my pondering over the implications of Miss Kenton's letter finally opened my eyes to the simple truth: that these small errors of recent months have derived from nothing more sinister than a faulty staff plan.

当然了，尽最大的努力做好府第中的人员配置规划本就是每一位管家的职责和本分。
It is, of course, the responsibility of every butler to devote his utmost care in the devising of a staff plan.

谁知道到底有多少的口角争执、诬告栽赃和完全没有必要的解雇，有多少原本大有前途的职业生涯却半途而废，实际上应归咎于一位管家在人员配备规划阶段的马虎和疏懒呢？
Who knows how many quarrels, false accusations, unnecessary dismissals, how many promising careers cut short can be attributed to a butler's slovenliness at the stage of drawing up the staff plan?

有人说，制订一套良好的人员配置规划是任何一位称职的管家所有技能的基础和柱石，的确，我可以说是同意这种说法的。
Indeed, I can say I am in agreement with those who say that the ability to draw up a good staff plan is the cornerstone of any decent butler's skills.

在过去这些年中，我已经亲自设计过很多的人员配备规划，如果说这些规划当中极少有需要调整和改进之处的话，我相信我也并没有过分地自我吹嘘。
I have myself devised many staff plans over the years, and I do not believe I am being unduly boastful if I say that very few ever needed amendment. And if in the present case the staff plan is at fault, blame can be laid at no one's door but my own.

同时我也该特别指出，这一次的状况的确是异乎寻常地困难才算是公道。
At the same time, it is only fair to point out that my task in this instance had been of an unusually difficult order.

具体的情况是这样的。
What had occurred was this.

房产交易一旦结束—这次交易使达林顿家族在长达两个世纪之后，失去了对这座府第的所有权—法拉戴先生就知会我们，他不会马上入住这里，而是将再花四个月的时间对美国的事务做一个了结。
Once the transactions were over – transactions which had taken this house out of the hands of the Darlington family after two centuries – Mr Farraday let it be known that he would not be taking up immediate residence here, but would spend a further four months concluding matters in the United States.

不过与此同时，他又最殷切地希望前任东家的员工—他已经听说这批雇员具有极佳的声誉—能够继续留任达林顿府。
In the meantime, however, he was most keen that the staff of his predecessor – a staff of which he had heard high praise – be retained at Darlington Hall.

当然，他所指的这批“员工”，仅是达林顿勋爵的几位亲属在房产交易期间临时照管这幢宅第时所留用的那六位骨干人员；但我很遗憾地向新雇主汇报，交易一旦完成，除了克莱门茨太太以外，对于其他员工另寻其他工作的情况我实在是无能为力。
This ‘staff’ he referred to was, of course, nothing more than the skeleton team of six kept on by Lord Darlington's relatives to administer to the house up to and throughout the transactions; and I regret to report that once the purchase had been completed, there was little I could do for Mr Farraday to prevent all but Mrs Clements leaving for other employment.

当我向法拉戴先生写信表达我对此种状况的遗憾时，我接到来自美国的答复，指示我去招募一批“配得上一座堂皇的古老英国府第”的新员工。
When I wrote to my new employer conveying my regrets at the situation, I received by reply from America instructions to recruit a new staff ‘worthy of a grand old English house’.

我立刻着手尽力满足法拉戴先生的愿望，但您也知道，在现在这个时候要想招募到一批令人满意的高标准员工实在殊非易事，尽管经由克莱门茨太太的推荐，我很高兴地雇用了罗斯玛丽和阿格尼丝，但是直到去年春天法拉戴先生短暂地先期探访达林顿府，我跟他进行第一次事务性会晤之时，招聘工作并无更大的进展。
I immediately set about trying to fulfil Mr Farraday's wishes, but as you know, finding recruits of a satisfactory standard is no easy task nowadays, and although I was pleased to hire Rosemary and Agnes on Mrs Clements's recommendation, I had got no further by the time I came to have my first business meeting with Mr Farraday during the short preliminary visit he made to our shores in the spring of last year.

也正是在那个场合下—在达林顿府那个显得异常空旷的书房里—法拉戴先生第一次跟我握了手，不过，在那之前我们相互之间也已经算不上是陌生人了；除了招聘雇员这一事务之外，我的新雇主在好几个其他方面也发现有必要求助于那些我也许只是因为走运才拥有的才能和品质，并且发现它们—我不妨冒昧地直言—是值得信赖和托付的。
It was on that occasion – in the strangely bare study of Darlington Hall – that Mr Farraday shook my hand for the first time, but by then we were hardly strangers to each other; quite aside from the matter of the staff, my new employer in several other instances had had occasion to call upon such qualities as it may be my good fortune to possess and found them to be, I would venture, dependable.

因此，我认为，他马上就感觉可以跟我以一种讲求实际、充分信任的方式坦诚地交谈，在这次会面结束前，他留给我一笔不算不可观的资金由我全权掌管，为他不久之后入住达林顿府进行各个方面的准备之用。
So it was, I assume, that he felt immediately able to talk to me in a businesslike and trusting way, and by the end of our meeting, he had left me with the administration of a not inconsiderable sum to meet the costs of a wide range of preparations for his coming residency.

别的方面姑且不论，我想说的是，正是在这次面谈的过程中，当我提出在现在这种时候招聘到合格员工的难处时，法拉戴先生在经过片刻沉吟后，向我提出了他的要求：我应尽力拟定出一个人员配置规划—用他话说就是“某种仆佣的轮值表”—按照这一规划，这座府第或许可以就依靠目前的这四位员工正常地运转起来—也就说克莱门茨太太、那两位年轻的姑娘，外加我自己。
In any case, my point is that it was during the course of this interview, when I raised the question of the difficulty of recruiting suitable staff in these times, that Mr Farraday, after a moment's reflection, made his request of me; that I do my best to draw up a staff plan – ‘some sort of servants’ rota’ as he put it – by which this house might be run on the present staff of four – that is to say, Mrs Clements, the two young girls, and myself.

他充分地理解，这样也许意味着要将这座府第中的好些部分“深藏密闭”起来，但我能否充分调动我所有的经验和专长，尽我之所能确保将此类损失控制在最低限度之内？
This might, he appreciated, mean putting sections of the house ‘under wraps’, but would I bring all my experience and expertise to bear to ensure such losses were kept to a minimum?

回想过去，我手下曾有过十七名员工可供调度，而且就在不久前，达林顿府雇用的员工人数甚至达到过二十八位，相形之下，希望依靠设计出一个完善的人员配置规划，仅用四个人就能将这么大的府第管理得井井有条，这种想法往轻里说，至少也是令人望而却步的。
Recalling a time when I had had a staff of seventeen under me, and knowing how not so long ago a staff of twenty-eight had been employed here at Darlington Hall, the idea of devising a staff plan by which the same house would be run on a staff of four seemed, to say the least, daunting.

尽管我竭力不把自己的想法表露出来，我那深表怀疑的态度想必还是遮掩不住的，于是法拉戴先生又补充了一句，似乎是为了消除我的顾虑，说如果证明确属必要，也可以再增加一位雇员。
Although I did my best not to, something of my scepticism must have betrayed itself, for Mr Farraday then added, as though for reassurance, that were it to prove necessary, then an additional member of staff could be hired.

但他又重复道，如果我能“试一下就用四个人”的话，他将感激不尽。
But he would be much obliged, he repeated, if I could ‘give it a go with four’.

说起来，就像我们当中的很多人一样，我自然也不太情愿对旧有的方式做出太多的变更。
Now naturally, like many of us, I have a reluctance to change too much of the old ways.

但像某些人那样仅仅是为了传统而固守传统的话，却也并无任何益处。
But there is no virtue at all in clinging as some do to tradition merely for its own sake.

在这个电气和现代化供暖系统的时代，确实也没有必要再雇用甚至只是上一代人所必需的那么多种类的员工了。
In this age of electricity and modern heating systems, there is no need at all to employ the sorts of numbers necessary even a generation ago.

说实在的，实际上长久以来我已经形成了这样一种想法，即只是为了传统的缘故而维持不必要的冗员—结果造成雇员们拥有了大量不但无益反而有害的空闲时间—这正是造成职业水准急剧下降的重要原因。
Indeed, it has actually been an idea of mine for some time that the retaining of unnecessary numbers simply for tradition's sake – resulting in employees having an unhealthy amount of time on their hands – has been an important factor in the sharp decline of professional standards.

再者说，法拉戴先生已经明确表示，他难得会举办过去达林顿府所司空见惯的那种盛大的社交活动。
Furthermore, Mr Farraday had made it clear that he planned to hold only very rarely the sort of large social occasions Darlington Hall had seen frequently in the past.

在这之后，我就全身心地投入到法拉戴先生所交付给我的这个任务当中；我花费了大量的时间拟定人员配置规划，而且在我从事其他的工作以及就寝以后尚未睡着的时候，又花费了至少同样多的时间反复斟酌推敲。
I did then go about the task Mr Farraday had set me with some dedication; I spent many hours working on the staff plan, and at least as many hours again thinking about it as I went about other duties or as I lay awake after retiring.

只要是我感觉又有了什么新的想法，我都会反复探究它是否还有任何纰漏，从所有的角度对它一一进行检视。
Whenever I believed I had come up with something, I probed it for every sort of oversight, tested it through from all angles.

最后我终于拟出了一个规划，也许还并不完全符合法拉戴先生所提出的要求，但我确信这已经是人力所及的范围之内的最好结果了。
Finally, I came up with a plan which, while perhaps not exactly as Mr Farraday had requested, was the best, I felt sure, that was humanly possible.

这座府第中几乎所有富有魅力的部分都能继续保持正常运转；而庞大的仆佣生活区—包括后廊、那两间茶点整备室，还有那间老式的洗衣房—以及三楼上的客房都将关闭，不再使用，保留一楼的所有主要的房间以及相当数量的客房。
Almost all the attractive parts of the house could remain operative: the extensive servants’ quarters – including the back corridor, the two still rooms and the old laundry – and the guest corridor up on the second floor would be dust-sheeted, leaving all the main ground-floor rooms and a generous number of guest rooms.

平心而论，以我们现在这四人团队的力量，也只有再借助一些临时工的增援才能胜任这一安排；因此，我的人员配置规划当中也已经加入了临时工的服务内容：一位园丁每周来一次，夏季则增加为两次；两位清洁工每周来两次。
Admittedly, our present team of four would manage this programme only with reinforcement from some daily workers; my staff plan therefore took in the services of a gardener, to visit once a week, twice in the summer, and two cleaners, each to visit twice a week.

除此之外，我的人员配置规划意味着我们四位常驻员工每个人各自的常规职责也要进行根本性的调整。
The staff plan would, furthermore, for each of the four resident employees mean a radical altering of our respective customary duties.

以我的预期，那两位年轻姑娘并不会感觉这些调整和改变非常难以适应，而我尽最大的可能确保将克莱门茨太太需要承受的调整幅度降至最低限度，结果我自己也就肩负起了许多您可能认为唯有思想最为开通的管家才会去承担的工作职责。
The two young girls, I predicted, would not find such changes so difficult to accommodate, but I did all I could to see that Mrs Clements suffered the least adjustments, to the extent that I undertook for myself a number of duties which you may consider most broad-minded of a butler to do.

时至今日，我也不至于会说这是个糟糕的人员配置规划；毕竟，它可以使得只有四个人的团队能够承担起这么多其范围远远超乎预料的职责。
Even now, I would not go so far as to say it is a bad staff plan; after all, it enables a staff of four to cover an unexpected amount of ground.

不过，您无疑也会同意，最好的员工规划是能够留出清楚的误差范围的那一种，万一某位雇员生了病或是出于这样那样的原因而状态欠佳，也好留出余地。
But you will no doubt agree that the very best staff plans are those which give clear margins of error to allow for those days when an employee is ill or for one reason or another below par.

如果碰到这样的特殊情况，我当然就将面对一个稍稍异乎寻常的棘手的任务，不过，即便如此，我都一直并没有忽视，只要是有可能，就把预留这样的“余地”也体现在规划当中。
In this particular case, of course, I had been set a slightly extraordinary task, but I had nevertheless not been neglectful to incorporate ‘margins’ wherever possible.

我尤其注意克莱门茨太太或者那两位姑娘可能产生的任何抗拒心理，因为她们承担了超出传统界限之外的职责，她们可能会认为她们的工作量也已经大为增加。
I was especially conscious that any resistance there may be on the part of Mrs Clements, or the two girls, to the taking on of duties beyond their traditional boundaries would be compounded by any notion that their workloads had greatly increased.

在反复斟酌、不断完善员工规划的那些日子里，我也已经特别为此而大费思量，以确保她们一旦克服了因承担这些“五花八门的”额外角色而产生的反感，她们就会发现这样的职责分配其实是饶有兴味的，而且也并不会成为很大的负担。
I had then, over those days of struggling with the staff plan, expended a significant amount of thought to ensuring that Mrs Clements and the girls, once they had got over their aversion to adopting these more ‘eclectic’ roles, would find the division of duties stimulating and unburden-some.

然而，我担心在我急于赢得克莱门茨太太和两位姑娘支持的同时，我也许并没有对于我自己的局限做出非常严格的评估；尽管我在此类事务上的经验以及习惯性的审慎，使我不至于冒失地承担超出我实际能力所及的任务，但我也许疏忽了给我自己留出足够的余地。
I fear, however, that in my anxiety to win the support of Mrs Clements and the girls, I did not perhaps assess quite as stringently my own limitations; and although my experience and customary caution in such matters prevented my giving myself more than I could actually carry out, I was perhaps negligent over this question of allowing myself a margin.

如果在几个月的实际应用当中，这种失察会以一种很不起眼却又相当显著的方式表现出来的话，我丝毫都不会感到吃惊。
It is not surprising then, if over several months, this oversight should reveal itself in these small but telling ways.

归根结底，我相信这个问题一句话就能说清：我给自己分派的工作实在是太多了。
In the end, I believe the matter to be no more complicated than this: I had given myself too much to do.

人员配置规划中这样一个明显的缺点居然一直都未能引起我的注意，您可能会为此而感到吃惊，但您也会同意，一个人如果在一段时间内持久不断地沉湎于某种想法中无法自拔，是会经常出现这种当局者迷的问题的；直到相当意外地受到某种外部事件的激发，才会憬然醒悟到事情的真相。
You may be amazed that such an obvious shortcoming to a staff plan should have continued to escape my notice, but then you will agree that such is often the way with matters one has given abiding thought to over a period of time; one is not struck by the truth until prompted quite accidentally by some external event.

所以正是在这样的情况下，也就是说，我收到肯顿小姐的来信，她在这封长信中以深藏不露的笔触表达出对于达林顿府无可置疑的怀旧之情，而且—对此我相当肯定—还明确地暗示了她重返故地的强烈愿望，这不禁迫使我重新审视已经拟定的员工规划。
So it was in this instance; that is to say, my receiving the letter from Miss Kenton, containing as it did, along with its long, rather unrevealing passages, an unmistakable nostalgia for Darlington Hall, and – I am quite sure of this – distinct hints of her desire to return here, obliged me to see my staff plan afresh.

直到这时，我才醒悟到达林顿府确实还需要另一位员工来扮演一个至关重要的角色；实际上，也正是因为缺少了这样的一个角色，才是我近来麻烦不断的关键的中枢。
Only then did it strike me that there was indeed a role that a further staff member could crucially play here; that it was, in fact, this very shortage that had been at the heart of all my recent troubles.

我越是认真地考虑，事情也就越发清楚明了：以其对于这座府第的衷心挚爱，以其堪为典范楷模的职业水准—这种素质如今几乎已经是无处寻觅了—肯顿小姐正是能使我为达林顿府完成一个完全令人满意的员工规划所需要的关键要素。
And the more I considered it, the more obvious it became that Miss Kenton, with her great affection for this house, with her exemplary professionalism – the sort almost impossible to find nowadays – was just the factor needed to enable me to complete a fully satisfactory staff plan for Darlington Hall.

对目前的局面做出如此分析之后，没过多久我就觉得应该重新考虑一下几天前法拉戴先生主动提出的那个慷慨的建议了。
Having made such an analysis of the situation, it was not long before I found myself reconsidering Mr Farraday's kind suggestion of some days ago.

因为我想到，那驱车远行的计划可以在工作方面很好地派上用处；也就是说，我可以在驱车前往西南诸郡的过程中，顺道拜访一下肯顿小姐，这样就可以当面探查一下她希望重返达林顿府工作的虚实。
For it had occurred to me that the proposed trip in the car could be put to good professional use; that is to say, I could drive to the West Country and call on Miss Kenton in passing, thus exploring at first hand the substance of her wish to return to employment here at Darlington Hall.

我应该说明的是，我已经把肯顿小姐最近的那封来信反复阅读了好几次，她那方面有重返达林顿的这种暗示，绝对不可能只是出诸我的想象。
I have, I should make clear, reread Miss Kenton's recent letter several times, and there is no possibility I am merely imagining the presence of these hints on her part.

尽管如此，我有好几天却无法鼓起勇气向法拉戴先生再次提起此事。
For all that, I could not for some days quite bring myself to raise the matter again with Mr Farraday.

在这件事上，不管怎么说，有好几个方面我感觉需要自己先行厘清之后才能采取进一步的行动。
There were, in any case, various aspects to the matter I felt I needed to clarify to myself before proceeding further.

比如说，这里面就有费用的问题。
There was, for instance, the question of cost.

因为，即便我的雇主慷慨地主动表示“承担汽油的花费”，考虑到还有诸如住宿、用餐以及在旅途中可能消耗的各种小零食的开销，这样一次旅行的总花费仍旧可能会达到一个惊人的数目。
For even taking into account my employer's generous offer to ‘foot the bill for the gas’, the costs of such a trip might still come to a surprising amount considering such matters as accommodation, meals, and any small snacks I might partake of on my way.

此外还有什么样的服装适合这样一次旅行的问题，以及是否值得专门为此添置一套新衣服的问题。
Then there was the question of what sorts of costume were appropriate on such a journey, and whether or not it was worth my while to invest in a new set of clothes.

我已经拥有好多套顶级的礼服正装，有的是过去这些年间达林顿勋爵本人好心送给我的，有些则是曾在府里做客，因为有理由对于这里的服务水准深感满意的各位客人送的。
I am in the possession of a number of splendid suits, kindly passed on to me over the years by Lord Darlington himself, and by various guests who have stayed in this house and had reason to be pleased with the standard of service here.

很多套正装或许对于计划中的这次旅行来说太过正式了些，要不然就是以现在的眼光看来太过老式了些。
Many of these suits are, perhaps, too formal for the purposes of the proposed trip, or else rather old-fashioned these days.

不过我还有一套非正式场合穿的休闲套装，是一九三一或者三二年爱德华·布莱尔爵士送给我的—在当时实际上是全新的，而且差不多完全合身—这套服装应该很合适在我可能宿夜的任何宾馆旅店的客厅或是餐室穿着。
But then there is one lounge suit, passed on to me in 1931 or 1932 by Sir Edward Blair – practically brand new at the time and almost a perfect fit – which might well be appropriate for evenings in the lounge or dining room of any guest houses where I might lodge.

不过，适合旅行时穿的衣服我却一套都没有—也就是我开车时穿的衣服—除非是我打算穿年轻的查默斯勋爵在大战期间送给我的那套服装，如果不计较对我来说明显太小了一些，也可以认为是适合这一场合的理想之选了。
What I do not possess, however, is any suitable travelling clothes – that is to say, clothes in which I might be seen driving the car – unless I were to don the suit passed on by the young Lord Chalmers during the war, which despite being clearly too small for me, might be considered ideal in terms of tone.

最后我自己计算了一下，我的积蓄应该能应付所有可能的花销，此外也许还足可以添置一套新衣。
I calculated finally that my savings would be able to meet all the costs I might incur, and in addition, might stretch to the purchase of a new costume.

我希望您不要因为我在服装上面的盘算就认为我过于虚荣了；我这么计较只是因为谁都不知道在什么情况下你将不得不承认你是达林顿府里的人，如果碰到这样的情况，你的穿着装扮是否与你的地位相称就显得至关重要了。
I hope you do not think me unduly vain with regard to this latter matter; it is just that one never knows when one might be obliged to give out that one is from Darlington Hall, and it is important that one be attired at such times in a manner worthy of one's position.

在这段时间里，我也花了不少时间去查阅道路交通地图，还细读了简·西蒙斯太太撰写的《英格兰奇景》的相关卷帙。
During this time, I also spent many minutes examining the road atlas, and perusing also the relevant volumes of Mrs Jane Symons's The Wonder of England.

如果您对于西蒙斯太太的这套著作还有所不知—这套系列丛书多达七卷，每一卷集中描写英伦诸岛的一个地区—我衷心地向您推荐它们。
If you are not familiar with Mrs Symons's books – a series running to seven volumes, each one concentrating on one region of the British Isles – I heartily recommend them.

这套书是三十年代写的，不过大部分内容都还并不过时—再者说了，我也不相信德国人的炸弹已经对我们的乡村面貌造成了如此大的改观。
They were written during the thirties, but much of it would still be up to date – after all, I do not imagine German bombs have altered our countryside so significantly.

事实上，西蒙斯太太在战前就是我们这府上的常客；而且她确实也是最受员工们喜欢的客人之一，因为她从不吝惜对我们服务工作的热情赞赏。
Mrs Symons was, as a matter of fact, a frequent visitor to this house before the war; indeed, she was among the most popular as far as the staff were concerned due to the kind appreciation she never shied from showing.

也正是在那个时候，出于我对这位女士由衷的仰慕之情，只要有一点点空闲时间我就跑到藏书室里，第一次开始细读她的大著。
It was in those days, then, prompted by my natural admiration for the lady, that I had first taken to perusing her volumes in the library whenever I had an odd moment.

我记得一九三六年肯顿小姐离开达林顿府前往康沃尔郡以后，我因为从未去过那个地方，我确实还经常翻阅一下西蒙斯太太著作的第三卷，那一卷向读者描述的正是德文和康沃尔两郡的怡人美景，并且配有大量的照片以及—更能使我产生情感共鸣的是—画家们描绘那一地区各种景致的很多素描作品。
Indeed, I recall that shortly after Miss Kenton's departure to Cornwall in 1936, myself never having been to that part of the country, I would often glance through Volume III of Mrs Symons's work, the volume which describes to readers the delights of Devon and Cornwall, complete with photographs and – to my mind even more evocative – a variety of artists’ sketches of that region.

我是由此才能对于肯顿小姐婚后定居之地获得了些许认识的。
It was thus that I had been able to gain some sense of the sort of place Miss Kenton had gone to live her married life.

不过正如我已经说过的，那是三十年代的情况了，据我所知，西蒙斯太太的著作那个时候在全国都是家喻户晓的。
But this was, as I say, back in the thirties, when as I understand, Mrs Symons's books were being admired in houses up and down the country.

我已经有好多年未曾翻阅这套丛书了，直到最近的情势发展，才又使我重新把描写德文和康沃尔两郡的那一卷从书架上取下来。
I had not looked through those volumes for many years, until these recent developments led me to get down from the shelf the Devon and Cornwall volume once more.

我又从头至尾认真研读了一遍那些精彩的描述和插图，您也许能够理解，一想到现在也许终于可以开着车到那个区域去亲眼看看了，我就按捺不住万分激动的心情。
I studied all over again those marvellous descriptions and illustrations, and you can perhaps understand my growing excitement at the notion that I might now actually undertake a motoring trip myself around that same part of the country.

事已至此，看来除了主动再跟法拉戴先生提出这次旅行以外，也别无他法了。
It seemed in the end there was little else to do but actually to raise the matter again with Mr Farraday.

当然，也有可能他半个月前的建议只不过是突发奇想，说过即忘，他已经不会再对这个想法表示赞同了。
There was always the possibility, of course, that his suggestion of a fortnight ago may have been a whim of the moment, and he would no longer be approving of the idea.

不过，通过这几个月来我对法拉戴先生的观察，他并非那种反复无常的绅士，而在一位雇主身上再没有比这种出尔反尔的品性更让人恼火的了。
But from my observation of Mr Farraday over these months, he is not one of those gentlemen prone to that most irritating of traits in an employer – inconsistency.

没有理由怀疑他会对之前自己热情提议的驾车远游计划表现得前后不一—他肯定不会再主动重提“承担汽油的花费”这一最为慷慨的承诺了。
There was no reason to believe he would not be as enthusiastic as before about my proposed motoring trip – indeed, that he would not repeat his most kind offer to ‘foot the bill for the gas’.

尽管如此，我还是要非常谨慎小心地选择一个向他重提这件事的最佳时机；因为，虽然如我所言，我从未有一时一刻怀疑过法拉戴先生会是个出尔反尔之辈，不过，如果专拣他心事重重或者心烦意乱的时候去提，那可就非常不智了。
Nevertheless, I considered most carefully what might be the most opportune occasion to bring the matter up with him; for although I would not for one moment, as I say, suspect Mr Farraday of inconsistency, it nevertheless made sense not to broach the topic when he was preoccupied or distracted.

如果在这种情况下贸然拒绝了我的请求，其实并不能反映出我的雇主在这件事上的真实意图，可是否决的话一旦说出了口，我也就很难再把它提出来了。
A refusal in such circumstances may well not reflect my employer's true feelings on the matter, but once having sustained such a dismissal, I could not easily bring it up again.

因此，显而易见，我必须明智地选择合适的时机。
It was clear, then, that I had to choose my moment wisely.

最后，我认定一天当中最明智审慎的时刻应该是我在客厅里摆好下午茶的时候。
In the end, I decided the most prudent moment in the day would be as I served afternoon tea in the drawing room.

在那个时候，法拉戴先生通常外出去高地上散了一会儿步刚刚回来，所以他的思绪极少会沉浸在傍晚时分经常从事的阅读和写作当中。
Mr Farraday will usually have just returned from his short walk on the downs at that point, so he is rarely engrossed in his reading or writing as he tends to be in the evenings.

事实上，当我把下午茶端进来的时候，法拉戴先生总是会把之前正在阅读的图书或是杂志合上，站起身来在窗前伸展一下双臂，似乎预先就准备要跟我聊上几句。
In fact, when I bring in the afternoon tea, Mr Farraday is inclined to close any book or periodical he has been reading, rise and stretch out his arms in front of the windows, as though in anticipation of conversation with me.

如上所述，我相信我在时机选择这个问题上的判断是合情合理的；但实际情况的非我所愿则应完全归咎于我在另一个方向上的判断失误。
As it was, I believe my judgement proved quite sound on the question of timing; the fact that things turned out as they did is entirely attributable to an error of judgement in another direction altogether.

换句话说，我并没有充分考虑到这样一个事实，即在一天当中的那个时刻，法拉戴先生想要进行的是那种轻松愉快、诙谐幽默的闲谈。
That is to say, I did not take sufficient account of the fact that at that time of the day, what Mr Farraday enjoys is a conversation of a light-hearted, humorous sort.

如果昨天下午我把茶点端进来的时候知道他是这样一种心情，如果我当时能意识到他在那种时候会倾向于用一种揶揄谈笑的口吻跟我闲谈的话，更明智的做法当然就是压根儿都不提肯顿小姐的名字了。
Knowing this to be his likely mood when I brought in the tea yesterday afternoon, and being aware of his general propensity to talk with me in a bantering tone at such moments, it would certainly have been wiser not to have mentioned Miss Kenton at all.

但您也许能够理解，在请求我的雇主的某种慷慨的恩赐时，我这方面总会有一种天然的倾向，竭力暗示在我的请求背后还隐藏着某种良好的职业动机。
But you will perhaps understand that there was a natural tendency on my part, in asking what was after all a generous favour from my employer, to hint that there was a good professional motive behind my request.

所以我在陈述自己很想开车前往西南诸郡一游的原因时，并没有提及西蒙斯太太那卷著作当中所描述的那些个迷人的细节，反而错误地宣称达林顿府的一位前任的女管家就居住在那个区域。
So it was that in indicating my reasons for preferring the West Country for my motoring, instead of leaving it at mentioning several of the alluring details as conveyed by Mrs Symons's volume, I made the error of declaring that a former housekeeper of Darlington Hall was resident in that region.

我的本意原是打算向法拉戴先生解释一下，我为什么会认为这不失一种可能的选项，借此也许可以成为解决目前这座府第的管理当中现存的一些小问题的理想方案。
I suppose I must have been intending to explain to Mr Farraday how I would thus be able to explore an option which might prove the ideal solution to our present small problems here in this house.

一直等到我已提到肯顿小姐的名字以后，我才突然意识到我如果继续讲下去将是多么不妥的冒昧之举。
It was only after I had mentioned Miss Kenton that I suddenly realized how entirely inappropriate it would be for me to continue.

不仅是因为我尚不能确定肯顿小姐重新回到这里的意愿是否是真，除此以外，当然还有自从一年多以前我跟法拉戴先生第一次会面以来，我甚至都还没有跟他讨论过增加员工的这个问题。
Not only was I unable to be certain of Miss Kenton's desire to rejoin the staff here, I had not, of course, even discussed the question of additional staff with Mr Farraday since that first preliminary meeting over a year ago.

如果继续大声地宣布我对于达林顿府未来的考虑，退一万步讲，也是非常冒昧和唐突的。
To have continued pronouncing aloud my thoughts on the future of Darlington Hall would have been, to say the very least, presumptuous.

想到这一点，我当时相当突然地停住了话头，我猜想，我的表情应该是有点尴尬的。
I suspect, then, that I paused rather abruptly and looked a little awkward.

总之，法拉戴先生抓住这个机会，冲我眉开眼笑，并别有一番深意地说道：
In any case, Mr Farraday seized the opportunity to grin broadly at me and say with some deliberation.

“哎呀，哎呀，史蒂文斯。
‘My, my, Stevens.

一位女性朋友。
A lady-friend.

而且是在你这个岁数。”
And at your age.’

这场面真是再难堪不过了，达林顿勋爵是绝不会置一位雇员于这样的境地的。
This was a most embarrassing situation, one in which Lord Darlington would never have placed an employee.

不过我这么说也并非对法拉戴先生有任何贬损之意；他毕竟是一位美国绅士，他的行为举止经常是大为不同的。
But then I do not mean to imply anything derogatory about Mr Farraday; he is, after all, an American gentleman and his ways are often very different.

他并没有任何恶意，这一点是毫无疑问的；但您无疑也能理解，这处境对我而言是多么不自在。
There is no question at all that he meant any harm; but you will no doubt appreciate how uncomfortable a situation this was for me.

“我还从没想到你居然是这样一位大受女性欢迎的男人啊，史蒂文斯，”他继续道。
‘I’d never have figured you for such a lady's man, Stevens,’ he went on.

“这肯定能让你在精神上永葆青春，我猜想。
‘Keeps the spirit young, I guess.

但如此一来，我就真的不知道帮你去赴如此暧昧的约会对我而言是不是应该啦。”
But then I really don't know it's right for me to be helping you with such dubious assignations.’

自然，我忍不住想立刻而又毫不含糊地坚决否认我的雇主强加在我头上的这种不实的动机，但我及时地察觉到，我这么做的话无疑等于一口吞下了法拉戴先生的钓饵，那局面只会变得越发令人难堪。
Naturally, I felt the temptation to deny immediately and unambiguously such motivations as my employer was imputing to me, but saw in time that to do so would be to rise to Mr Farraday's bait, and the situation would only become increasingly embarrassing.

于是我只得继续尴尬地站在那儿，等着我的雇主允许我进行这次驾车的旅行。
I therefore continued to stand there awkwardly, waiting for my employer to give me permission to undertake the motoring trip.

尽管这个场面对我来说备感难堪，我却丝毫不希望暗示我在任何方面有可以埋怨法拉戴先生的地方，他的为人绝没有丝毫刻薄之处；我敢肯定，他这么做只不过是在享受那种善意地揶揄取笑的乐趣，在美国这无疑是雇主和雇员间关系良好、友善的一种表现，他们将其当作一种亲切友好的游戏而乐在其中。
Embarrassing as those moments were for me, I would not wish to imply that I in any way blame Mr Farraday, who is in no sense an unkind person; he was, I am sure, merely enjoying the sort of bantering which in the United States, no doubt, is a sign of a good, friendly understanding between employer and employee, indulged in as a kind of affectionate sport.

的确，站在适当的角度上来看，我应该指出的是，恰恰是这种在我的新雇主身上体现出来的善意的逗趣儿，才真正体现出这几个月来我们主仆关系的融洽—尽管我必须承认，对此应该如何回应我仍旧很没有把握。
Indeed, to put things into a proper perspective, I should point out that just such bantering on my new employer's part has characterized much of our relationship over these months – though I must confess, I remain rather unsure as to how I should respond.

事实上，在我刚开始为法拉戴先生工作的那些日子里，有一两次我真是为他对我所说的话大感震惊。
In fact, during my first days under Mr Farraday, I was once or twice quite astounded by some of the things he would say to me.

比方说，我有一次曾请示他，如果我们邀请到我们府上来做客的某位绅士希望带夫人同来，我们该怎么办。
For instance, I once had occasion to ask him if a certain gentleman expected at the house was likely to be accompanied by his wife.

“她要是真的来了，那就只能求上帝保佑啦，”法拉戴先生回答道。
‘God help us if she does come,’ Mr Farraday replied.

“也许你能让她尽量离我们远一点，史蒂文斯。
‘Maybe you could keep her off our hands, Stevens.

也许你能把她带到摩根先生农场上的某个马厩里去。
Maybe you could take her out to one of those stables around Mr Morgan's farm.

就用那些干草来招待她吧。
Keep her entertained in all that hay.

她也许正是你的绝配呢。”
She may be just your type.’

有好一会儿，我都不知道我的雇主到底在说些什么。
For a moment or two, I had not an idea what my employer was saying.

然后我才意识到他是在开玩笑，我便竭力展露出恰如其分的微笑，不过我怀疑在我的表情当中应该能觉察得出一丝困惑，如果还算不上是震惊的话。
Then I realized he was making some sort of joke and endeavoured to smile appropriately, though I suspect some residue of my bewilderment, not to say shock, remained detectable in my expression.

不过在接下来的日子里，我渐渐学会了对于我雇主的类似言语不再表示诧异，而且只要察觉到他声音中有这种揶揄打趣的语气，我就会还以恰如其分的微笑。
Over the following days, however, I came to learn not to be surprised by such remarks from my employer, and would smile in the correct manner whenever I detected the bantering tone in his voice.

话虽如此，我却又从来都不能肯定在这种场合之下我确切地应该做些什么。
Nevertheless, I could never be sure exactly what was required of me on these occasions.

也许我应该开怀大笑；或者报以自己的看法。
Perhaps I was expected to laugh heartily; or indeed, reciprocate with some remark of my own.

这后一种可能性这几个月来都快成了我的心病了，而且对此我仍旧还没拿定主意。
This last possibility is one that has given me some concern over these months, and is something about which I still feel undecided.

因为在美国很有可能是这样的：一位雇员提供的良好的专业服务当中应该包括有令其雇主开怀解颐的玩笑和戏谑。
For it may well be that in America, it is all part of what is considered good professional service that an employee provide entertaining banter.

“庄稼汉的纹章”酒馆的店主有一次说过，他要是个美国酒保的话才不会以那种友好然而永远谦恭有礼的方式跟我们聊天呢，相反，他会粗鲁地指责我们的恶习和缺点，直接骂我们酒鬼以及所有诸如此类的名号，因为他的顾客就期望他如此扮演他的角色。
In fact, I remember Mr Simpson, the landlord of the Ploughman's Arms, saying once that were he an American bartender, he would not be chatting to us in that friendly, but ever-courteous manner of his, but instead would be assaulting us with crude references to our vices and failings, calling us drunks and all manner of such names, in his attempt to fulfil the role expected of him by his customers.

我还记得几年前，作为贴身男仆陪侍雷金纳德·梅维斯爵士前往美国旅行的雷恩先生曾经说过，纽约的出租车司机惯常跟乘客说话的方式要是在伦敦重复一遍的话，结果即便是这个家伙不会被反剪着双臂扭送就近的警局，也八成会引发一场骚乱的。
And I recall also some years ago, Mr Rayne, who travelled to America as valet to Sir Reginald Mauvis, remarking that a taxi driver in New York regularly addressed his fare in a manner which if repeated in London would end in some sort of fracas, if not in the fellow being frogmarched to the nearest police station.

如此说来，我的雇主极有可能满心期望我也能以相仿的方式去回应他善意的揶揄打趣了，我如果不予回应的话反而会被认为是一种疏忽和失职了。
It is quite possible, then, that my employer fully expects me to respond to his bantering in a like manner, and considers my failure to do so a form of negligence.

这一点，如我之前所说，简直成了我的一块心病。
This is, as I say, a matter which has given me much concern.

但我又必须承认，我感觉这种揶揄打趣的事务并非我能以满腔的热情去履行的职责。
But I must say this business of bantering is not a duty I feel I can ever discharge with enthusiasm.

在现如今这个瞬息万变的时代中，调整自己以适应那些传统上来说并非自己分内工作的职责，固然是非常好的；但是揶揄打趣就完全是另外一个范畴的事情了。
It is all very well, in these changing times, to adapt one's work to take in duties not traditionally within one's realm; but bantering is of another dimension altogether.

别的且不说，首先第一点，你怎么能确定，在某个特定的场合哪一种对于此类揶揄打趣的回应才是雇主所真正期待的呢？
For one thing, how would one know for sure that at any given moment a response of the bantering sort is truly what is expected?

如果你贸然回出一句意在打趣的调侃，结果却发现完全驴唇不对马嘴，那种灾难性的后果简直想都不太敢想。
One need hardly dwell on the catastrophic possibility of uttering a bantering remark only to discover it wholly inappropriate.

不过，不久前我倒是确实有一次鼓足勇气尝试了一下那种戏谑的回答方式。
I did though on one occasion not long ago, pluck up the courage to attempt the required sort of reply.

当时我正在早餐室里伺候法拉戴先生喝早上的咖啡，这时他对我道：
I was serving Mr Farraday morning coffee in the breakfast room when he had said to me:

“我猜想今天早上那公鸡打鸣一样的声音应该不是你弄出来的吧，史蒂文斯？”
‘I suppose it wasn't you making that crowing noise this morning, Stevens?’

我意识到，我雇主指的是一对收废铜烂铁的吉卜赛夫妇一早从这儿经过时那惯常的吆喝声。
My employer was referring, I realized, to a pair of gypsies gathering unwanted iron who had passed by earlier making their customary calls.

碰巧，那天早上我也正在琢磨我的雇主是否期望我去回应他的揶揄打趣这个进退失据的难题，而且一直都很担心他会如何看待我对他意在逗乐的开场屡屡都毫无反应这个问题。
As it happened, I had that same morning been giving thought to the dilemma of whether or not I was expected to reciprocate my employer's bantering, and had been seriously worried at how he might be viewing my repeated failure to respond to such openings.

因此我就开始思考该如何机智地应对；我的回答应该是在万一对情况做出了误判也仍旧是安全稳妥、不会造成丝毫冒犯才对。
I therefore set about thinking of some witty reply; some statement which would still be safely inoffensive in the event of my having misjudged the situation.

过了有一会儿，我才说：
After a moment or two, I said:

“依我看，与其说是鸡打鸣，不如说是燕子叫，先生。
‘More like swallows than crows, I would have said, sir.

从流浪迁徙的角度来看。”
From the migratory aspect.’

说完后我继之以恰如其分的谦恭的微笑，以便以毫无歧义的方式表明我说的是句俏皮话，因为我可不希望法拉戴先生出于不必要的故作尊重而强忍住自发的笑意。
And I followed this with a suitably modest smile to indicate without ambiguity that I had made a witticism, since I did not wish Mr Farraday to restrain any spontaneous mirth he felt out of a misplaced respectfulness.

可是结果法拉戴先生却只是抬头看着我道：“你说什么，史蒂文斯？”
Mr Farraday, however, simply looked up at me and said: ‘I beg your pardon, Stevens?’

只有到了这时我才想到，我的俏皮话对于并不知道是吉卜赛人从我们这里经过的人来说，自然是不容易领会和理解的。
Only then did it occur to me that, of course, my witticism would not be easily appreciated by someone who was not aware that it was gypsies who had passed by.

到了这时，我就不知道到底该如何将这场戏谑的逗趣继续下去了；事实上，我决定最好是就此打住，假装想起某件需要我马上去处理的急事，就此告退，留下我的雇主大惑不解地坐在原地。
I could not see, then, how I might press on with this bantering; in fact, I decided it best to call a halt to the matter and, pretending to remember something I had urgently to attend to, excused myself, leaving my employer looking rather bemused.

对于要求我去履行的这么一桩实际上是全新的职责而言，这个开端实在是再令人气馁不过了；令人气馁的程度之深，使我必须承认，在这方面我再也没有进行过进一步的尝试。
It was, then, a most discouraging start to what may in fact be an entirely new sort of duty required of me; so discouraging that I must admit I have not really made further attempts along these lines.

不过与此同时，我也无法逃避这样一种感觉，即法拉戴先生并不满意我对于他形形色色的揶揄打趣所做出的回应。
But at the same time, I cannot escape the feeling that Mr Farraday is not satisfied with my responses to his various banterings.

确实，他近来甚至愈发频繁地坚持跟我逗乐打趣，应该就是加倍鼓励我以趣味相投的兴致予以积极的回应。
Indeed, his increased persistence of late may even be my employer's way of urging me all the more to respond in a like-minded spirit.

可是即便如此，自打我那第一次说的关于吉卜赛人的俏皮话以来，我就再也没能当场就想出其他类似的俏皮话。
Be that as it may, since that first witticism concerning the gypsies, I have not been able to think of other such witticisms quickly enough.

现如今，碰到类似的困难尤其会让人忧心忡忡，因为你已经不能像过去那样去跟同行们讨教以后再做决定了。在不久以前，如果你在工作上产生了任何类似职责不清的困扰，你都不会过于心焦，因为你知道，要不了多久，你的某位其见解颇受人尊重的同行就将陪同他的雇主前来做客，如此一来，你就有充裕的时间跟他讨教这个问题了。
Such difficulties as these tend to be all the more preoccupying nowadays because one does not have the means to discuss and corroborate views with one's fellow professionals in the way one once did. Not so long ago, if any such points of ambiguity arose regarding one's duties, one had the comfort of knowing that before long some fellow professional whose opinion one respected would be accompanying his employer to the house, and there would be ample opportunity to discuss the matter.

当然啦，在达林顿勋爵的时代，因为贵妇和士绅们经常一连多日在府里做客，你也很容易能跟随侍来访的同行们发展出一种相互理解的良好关系。
And of course, in Lord Darlington's days, when ladies and gentlemen would often visit for many days on end, it was possible to develop a good understanding with visiting colleagues.

确实，在那些繁忙的日子里，我们的仆役大厅里经常荟萃了一大批英格兰最优秀的专业同行，我们经常围坐在温暖的炉火旁边一直聊到深夜。
Indeed, in those busy days, our servants’ hall would often witness a gathering of some of the finest professionals in England talking late into the night by the warmth of the fire.

而且不瞒你说，如果你在那样的任何一个夜晚走进我们的仆役大厅，你听到的将不只是各种闲言碎语和小道消息；你更有可能会见证我们针对占据了楼上我们雇主们全副精力的那些重大事件，或者报上刊载的那些重大新闻所展开的激烈辩论。当然了，正如来自各行各业的同行们聚在一起的时候惯常都会做的那样，你也会发现我们正在讨论我们这个职业的方方面面。
And let me tell you, if you were to have come into our servants’ hall on any of those evenings, you would not have heard mere gossip; more likely, you would have witnessed debates over the great affairs preoccupying our employers upstairs, or else over matters of import reported in the newspapers; and of course, as fellow professionals from all walks of life are wont to do when gathered together, we could be found discussing every aspect of our vocation.

有时候，我们中间自然也会产生严重的分歧，大家争得个面红耳赤，但更常见的是，那里充满了互敬互谅的友好气氛。如果我报出几位常客的姓名的话，也许可以使您对于那些夜晚的格调气氛具有更直观的概念；我们的常客中包括了像是詹姆斯·钱伯斯爵士的贴身管家哈里·格雷厄姆先生，以及悉尼·狄金森先生的贴身男仆约翰·唐纳兹先生这样的人物。
Sometimes, naturally, there would be strong disagreements, but more often than not, the atmosphere was dominated by a feeling of mutual respect. Perhaps I will convey a better idea of the tone of those evenings if I say that regular visitors included the likes of Mr Harry Graham, valet-butler to Sir James Chambers, and Mr John Donalds, valet to Mr Sydney Dickenson.

也有很多或许没那么著名的同行，但他们现场那生动活泼的表现使得他们的每一次造访都令人难忘；比如说约翰·坎贝尔先生的贴身管家威尔金森先生就以善于模仿知名人士而大名鼎鼎；又如伊斯特利府的戴维森先生，他在为某一观点辩论时表现出来的澎湃激情有时真会让陌生人惊骇万分，而在其他时刻的表现则唯有最为讨人喜欢的单纯善良；再如约翰·亨利·彼得斯先生的贴身管家赫尔曼先生，他那过激的观点无论是谁听到都不可能处之淡然，但他那与众不同的纵情大笑以及约克郡人特有的魅力又使得他备受所有人的喜爱。
And there were others less distinguished, perhaps, but whose lively presence made any visit memorable; for instance, Mr Wilkinson, valet-butler to Mr John Campbell, with his well-known repertoire of impersonations of prominent gentlemen; Mr Davidson from Easterly House, whose passion in debating a point could at times be as alarming to a stranger as his simple kindness at all other times was endearing; Mr Herman, valet to Mr John Henry Peters, whose extreme views no one could listen to passively, but whose distinctive belly-laugh and Yorkshire charm made him impossible to dislike. I could go on.

这类人物真是不胜枚举。尽管我们在处理问题的方式方法上难免有些小小的分歧，但在当初那些岁月里，在我们这个行业当中是存在着一种真正的同志情谊的。
There existed in those days a true camaraderie in our profession, whatever the small differences in our approach. We were all essentially cut from the same cloth, so to speak.

打个比方说，我们本质上都是从同一块布料上剪下来的布头和布尾。可是现在的情况已经是大为不同了，就算难得碰到某位雇员陪侍主人到我们这儿来做客，他也更像是个完全的陌生人，除了英式足球以外就再也没有什么话可说，而且宁肯去“庄稼汉的纹章”喝几杯，也不愿在仆役大厅里围坐着炉火消磨那个夜晚—而且照现如今的风尚，他可能更愿意光顾明星酒馆。
Not the way it is today, when on the rare occasion an employee accompanies a guest here, he is likely to be some newcomer who has little to say about anything other than Association Football and who prefers to pass the evening not by the fire of the servants’ hall, but drinking at the Ploughman's Arms – or indeed, as seems increasingly likely nowadays, at the Star Inn.

刚才我曾提到詹姆斯·钱伯斯爵士的贴身管家格雷厄姆先生。
I mentioned a moment ago Mr Graham, the valet-butler to Sir James Chambers.

事实上，两个月前我就高兴地得知詹姆斯爵士要来达林顿府做客的消息。
In fact, some two months ago, I was most happy to learn that Sir James was to visit Darlington Hall.

我期待这次来访，不仅是因为达林顿勋爵时代的客人们现在已经极为少见了—法拉戴先生交往的圈子自然是跟爵爷大为不同的—而且还因为我想当然地以为格雷厄姆先生也会像往常那样陪侍詹姆斯爵士一同前来，这样的话我就可以就调侃打趣的这个问题征求一下他的意见了。
I looked forward to the visit not only because visitors from Lord Darlington's days are most rare now – Mr Farraday's circle, naturally, being quite different from his lordship's – but also because I presumed Mr Graham would accompany Sir James as of old, and I would thus be able to get his opinion on this question of bantering.

当我在詹姆斯爵士来访前一天才得知他将一个人过来的时候，我真是既诧异又失望。
I was, then, both surprised and disappointed to discover a day before the visit that Sir James would be coming alone.

而且，在詹姆斯爵士逗留期间，我又获悉格雷厄姆先生已经不再为爵士服务了；事实上詹姆斯爵士已经根本就不再雇用任何一位全职的雇员了。
Furthermore, during Sir James's subsequent stay, I gathered that Mr Graham was no longer in Sir James's employ; indeed that Sir James no longer employed any full-time staff at all.

我很想知道格雷厄姆先生的现状，因为我们之间虽然相知并不算深，至少在我们碰面的场合我们都一直相处甚欢。
I would like to have discovered what had become of Mr Graham, for although we had not known each other well, I would say we had got on on those occasions we had met.

但结果我却没有碰到任何合适的机会能获知相关的信息。
As it was, however, no suitable opportunity arose for me to gain such information.

不得不说，我真是大失所望，因为我原本很希望能向他讨教一下调侃打趣的这个问题的。
I must say, I was rather disappointed, for I would like to have discussed the bantering question with him.

不过，还是让我回到原来的话题吧。
However, let me return to my original thread.

正如之前所说，昨天下午在法拉戴先生对我进行他的调侃打趣的过程中，我不得不站在客厅里度过那颇不自在的几分钟时间。
I was obliged, as I was saying, to spend some uncomfortable minutes standing in the drawing room yesterday afternoon while Mr Farraday went about his bantering.

我只能像往常一样以微笑来应答—至少借以表明我也在某种程度上以愉快的心情参与了他正在进行的打趣和调侃—一边等着看我的雇主是否会兑现有关我外出旅行的承诺。
I responded as usual by smiling slightly – sufficient at least to indicate that I was participating in some way with the good-humouredness with which he was carrying on – and waited to see if my employer's permission regarding the trip would be forthcoming.

正如我所期盼的那样，他没经过多少耽搁就好意地照准了，不仅如此，法拉戴先生竟然还记得并重申了他之前“承担汽油的花费”的慷慨提议。
As I had anticipated, he gave his kind permission after not too great a delay, and furthermore, Mr Farraday was good enough to remember and reiterate his generous offer to ‘foot the bill for the gas’.

事已至此，我似乎也就再没什么理由不正式启动我前往西南诸郡的驾车出游计划了。
So then, there seems little reason why I should not undertake my motoring trip to the West Country.

我当然必须给肯顿小姐写封信告诉她我有可能从她那儿路过；我还需要安排好旅行中的穿着问题。
I would of course have to write to Miss Kenton to tell her I might be passing by; I would also need to see to the matter of the costumes.

我外出期间有关达林顿府里工作安排的其他各种问题也需要安排好。
Various other questions concerning arrangements here in the house during my absence will need to be settled.

总之一句话，我已经找不到任何真正的理由不进行这次计划中的远行了。
But all in all, I can see no genuine reason why I should not undertake this trip.

# 第一天—傍晚 | DAY ONE–EVENING

索尔兹伯里
Salisbury

今晚，我入住索尔兹伯里市的一家宾馆。
Tonight, I find myself here in a guest house in the city of Salisbury.

我旅途的第一天已经结束，总的说来，我不得不说我是相当满意的。
The first day of my trip is now completed, and all in all, I must say I am quite satisfied.

我早上出发的时间比原本计划的要晚了几乎一个钟头，尽管在八点前我就已经整理好了行装，把一应用品全都装进了那辆福特车。
This expedition began this morning almost an hour later than I had planned, despite my having completed my packing and loaded the Ford with all the necessary items well before eight o'clock.

由于克莱门茨太太和那两位姑娘本周也不在，我想我是非常强烈地意识到这样一个事实：我一旦离开，达林顿府有可能就在本世纪里头一次空无一人了—自从它建成之日起这可能也是头一次。
What with Mrs Clements and the girls also gone for the week, I suppose I was very conscious of the fact that once I departed, Darlington Hall would stand empty for probably the first time this century – perhaps for the first time since the day it was built.

这种感觉非常怪异，也许正是为此我才耽搁了这么长时间，我在整个大宅里数度逡巡，最后再检查一次，确认是否一切都已安置妥当。
It was an odd feeling and perhaps accounts for why I delayed my departure so long, wandering around the house many times over, checking one last time that all was in order.

当我终于把车子开动的时候，复杂的情感实在难以言喻。
It is hard to explain my feelings once I did finally set off.

在起初二十分钟的车程中，我很难说曾感受到丝毫的兴奋或是期待之情。
For the first twenty minutes or so of motoring, I cannot say I was seized by any excitement or anticipation at all.

这无疑是由于，尽管我距离大宅越来越远，周遭的景物却并不陌生，至少还都是我曾经涉足的地方。
This was due, no doubt, to the fact that though I motored further and further from the house, I continued to find myself in surroundings with which I had at least a passing acquaintance.

我因为被我的职责禁锢在这座大宅里，在此之前我一直都感觉自己极少外出旅行，不过这些年来，因为这种或是那种工作上的原因，我当然也难免会有各种各样的短途出行，所以看来我对于周边这些区域要远比我臆想中熟悉得多。
Now I had always supposed I had travelled very little, restricted as I am by my responsibilities in the house, but of course, over time, one does make various excursions for one professional reason or another, and it would seem I have become much more acquainted with those neighbouring districts than I had realized.

也正如我说的，当我迎着明媚的阳光朝伯克郡的边界开去时，我对于沿途乡村景色的熟悉一再地出乎我的意料之外。
For as I say, as I motored on in the sunshine towards the Berkshire border, I continued to be surprised by the familiarity of the country around me.

不过，周围的景物终于变得无法辨识了，我知道我已经跨出了之前所有的边界。
But then eventually the surroundings grew unrecognizable and I knew I had gone beyond all previous boundaries.

我曾听人描述过这一时刻，当扬帆起航，当终于看不见陆地的轮廓时的心情。
I have heard people describe the moment, when setting sail in a ship, when one finally loses sight of the land.

我想，人们经常描绘的有关这一刻内心当中不安与兴奋混杂在一起的情感经验，应该跟我开着福特车渐渐驶入陌生区域的心情非常相近吧。
I imagine the experience of unease mixed with exhilaration often described in connection with this moment is very similar to what I felt in the Ford as the surroundings grew strange around me.

这种心情就是在我转过一个弯道，发现自己驶上了一条环绕一座小山的盘山公路时袭上心头的。
This occurred just after I took a turning and found myself on a road curving around the edge of a hill.

我能感觉到我左侧是壁立的陡坡，只不过由于路边树木丛生，繁茂的枝叶使我没办法看清罢了。
I could sense the steep drop to my left, though I could not see it due to the trees and thick foliage that lined the roadside.

那种我确实已经将达林顿府远远抛在后面的感觉陡然间涌上心头，我得承认我还当真感到了一阵轻微的恐慌—这种感觉又因为担心自己也许完全走错了路而变本加厉，唯恐自己正南辕北辙地朝荒郊野外飞驰而去。
The feeling swept over me that I had truly left Darlington Hall behind, and I must confess I did feel a slight sense of alarm – a sense aggravated by the feeling that I was perhaps not on the correct road at all, but speeding off in totally the wrong direction into a wilderness.

这种恐慌只不过一闪而过，但却让我放慢了车速。
It was only the feeling of a moment, but it caused me to slow down.

即使在我已经确认自己并没有走错路以后，我仍旧感觉必须先将车子暂停一会儿，等把情况完全探明以后才能安心。
And even when I had assured myself I was on the right road, I felt compelled to stop the car a moment to take stock, as it were.

我决定从车上下来，伸展一下腿脚，刚来到车外，那种正位于半山腰的感觉就更其强烈了。
I decided to step out and stretch my legs a little and when I did so, I received a stronger impression than ever of being perched on the side of a hill.

在道路的一侧，灌木丛和矮小的树木陡直地上升，而在另一侧，透过扶疏的枝叶，我能看到远处的乡野。
On one side of the road, thickets and small trees rose steeply, while on the other I could now glimpse through the foliage the distant countryside.

我相信自己已经沿着路边走了一小段，不时透过林木的缝隙窥视，希望能找到一个更好的视野，正在这时，我听到背后传来一个人的声音。
I believe I had walked a little way along the roadside, peering through the foliage hoping to get a better view, when I heard a voice behind me.

到此为止，我想当然地以为就我一个人的，所以有些诧异地转过身去。
Until this point, of course, I had believed myself quite alone and I turned in some surprise.

就在不远处的公路对过，我能看到有一条人行小径的入口，小道沿山势向上，消失在灌木丛中。
A little way further up the road on the opposite side, I could see the start of a footpath, which disappeared steeply up into the thickets.

标志着小径入口的一块大石头上，坐着个白头发的瘦削男人，戴着顶布帽，正在抽一支烟斗。
Sitting on the large stone that marked this spot was a thin, white-haired man in a cloth cap, smoking his pipe.

他又冲我喊了一声，我虽然听不清楚他说了些什么，但能看出他正向我招手示意我过去。
He called to me again and though I could not quite make out his words, I could see him gesturing for me to join him.

我一时间还以为他是个流浪汉，然后才看清楚他就是个本地人，正在享受清新的空气和夏日的阳光，我也就恭敬不如从命了。
For a moment, I took him for a vagrant, but then I saw he was just some local fellow enjoying the fresh air and summer sunshine, and saw no reason not to comply.

“我只是有些好奇，先生，”他在我走近时说道，“你的腿脚到底有多硬朗。”
‘Just wondering, sir,’ he said, as I approached, ‘how fit your legs were.’

“你说什么？”
‘I beg your pardon?’

那人指了指上山的小径。
The fellow gestured up the footpath.

“你的腿脚一定得非常硬朗，肺活量也得够大，才能到那上面去。
‘You got to have a good pair of legs and a good pair of lungs to go up there.

我呢，两样条件都不具备，所以我只能待在这儿。
Me, I haven't got neither, so I stay down here.

但如果我的身体条件再好一点的话，我就会爬到上面去坐着啦。
But if I was in better shape, I'd be sitting up there.

那儿有一块很不错的小地方，还有一条长凳什么的。
There's a nice little spot up there, a bench and everything.

在整个英格兰，你都甭想找到一处比那儿风景更好的地方啦。”
And you won't get a better view anywhere in the whole of England.’

“如果你所言非虚，”我说，“我想我还是宁肯待在这儿。
‘If what you say is true,’ I said, ‘I think I'd rather stay here.

我碰巧正要进行一次驾车的远游，期间有望欣赏到诸多绝佳的胜景。
I happen to be embarking on a motoring trip during the course of which I hope to see many splendid views.

倘若还没正式踏上旅途就已经见识到了最美的景色，那岂不是有些过于草率了吗？”
To see the best before I have properly begun would be somewhat premature.’

那人似乎没明白我的意思，因为他仍旧重复道：“你在整个英格兰都甭想找到更美的景色啦。
The fellow did not seem to understand me, for he simply said again: ‘You won't see a better view in the whole of England.

不过我告诉你，你的腿脚一定得非常硬朗，肺活量也得够大才上得去。”
But I tell you, you need a good pair of legs and a good pair of lungs.’

然后他又补充道：“我看，以你的年纪来说你的身体状况还是很不错的，先生。
Then he added: ‘I can see you're in good shape for your age, sir.

我得说，你是完全能爬上去的，没有问题。
I'd say you could make your way up there, no trouble.

我是说，就连我这样的，碰到天气好的时候都能上得去。”
I mean, even I can manage on a good day.’

我抬头看了看那条小径，确实很陡，而且高低不平。
I glanced up the path, which did look steep and rather rough.

“我跟你说，先生，你要是不上去看看，肯定会后悔的。
‘I'm telling you, sir, you'll be sorry if you don't take a walk up there.

再者说了，谁知道呢，也许再过上个一两年就太晚了呢。”
And you never know.

—他相当粗鄙地哈哈一乐—“最好趁你还行的时候上去看看。”
A couple more years and it might be too late’ – he gave a rather vulgar laugh – ‘Better go on up while you still can.’

直到现在我才突然想到，那人当时这么说很有可能只不过是一种幽默的表达方式；也就是说，那只是一种善意的调侃。
It occurs to me now that the man might just possibly have meant this in a humorous sort of way; that is to say, he intended it as a bantering remark.

可我必须说，今天早上我只感觉他的表现实在是很无礼，不过也正是为了证明他那番暗示是多么愚蠢无稽，我才会赌气登上那羊肠小径的。
But this morning, I must say, I found it quite offensive and it may well have been the urge to demonstrate just how foolish his insinuation had been that caused me to set off up the footpath.

不管怎么说，我都非常高兴我这么做了。
In any case, I am very glad I did so.

当然，那段山路走得确是相当费力—不过我可以夸口的是，这并没有真正难倒我—小径沿着山势曲曲折折地向上延伸了一百码左右。
Certainly, it was quite a strenuous walk – though I can say it failed to cause me any real difficulty – the path rising in zigzags up the hillside for a hundred yards or so.

随后就到达了一小片空旷地，那个人说的无疑就是这个地方了。
I then reached a small clearing, undoubtedly the spot the man had referred to.

迎面摆了一条长凳—确实，展现在面前是绵延数英里、最令人叹为观止的乡村胜景。
Here one was met by a bench – and indeed, by a most marvellous view over miles of the surrounding countryside.

映入我眼帘的基本上就是一片片层层叠叠的田野，绵延不绝直到天际。
What I saw was principally field upon field rolling off into the far distance.

地势起伏平缓，每一块田地都以树篱和树木为界。
The land rose and fell gently, and the fields were bordered by hedges and trees.

远处的田野中有一些小点点，我猜想那应该是绵羊。
There were dots in some of the distant fields which I assumed to be sheep.

在我右手边，几乎就在地平线上，我想我能看到一座教堂的方塔。
To my right, almost on the horizon, I thought I could see the square tower of a church.

似那般站在那里感觉确是妙不可言，周遭夏日的天籁将你笼罩，和煦的微风轻拂你的面颊。
It was a fine feeling indeed to be standing up there like that, with the sound of summer all around one and a light breeze on one's face.

我相信正是那时，看着那片风景的时候，我才第一次萌生了一种跟展现我面前的旅途相契合的心境。
And I believe it was then, looking on that view, that I began for the first time to adopt a frame of mind appropriate for the journey before me.

因为也正是在那时，对于我明知未来几天即将展现在我面前让我去尽情体验的诸多有趣的经验，我才第一次产生了一种健康合理的兴奋和期盼。
For it was then that I felt the first healthy flush of anticipation for the many interesting experiences I know these days ahead hold in store for me.

而且确实，也正是在那时，我才下定决心，决不再为这趟旅途我交托给自己的工作任务而畏缩气馁；我有信心处理好有关肯顿小姐和我们目前在人员配置规划上所面临的难题。
And indeed, it was then that I felt a new resolve not to be daunted in respect to the one professional task I have entrusted myself with on this trip; that is to say, regarding Miss Kenton and our present staffing problems.

不过这都是今天早上的事儿了。
But that was this morning.

今天傍晚，我在这家舒适的宾馆里安顿下来，位置就在距索尔兹伯里市中心不远的一条街上。
This evening I found myself settled here in this comfortable guest house in a street not far from the centre of Salisbury.

据我看这是家相对简朴的旅店，不过非常干净，完全符合我的要求。
It is, I suppose, a relatively modest establishment, but very clean and perfectly adequate for my needs.

老板娘大约四十岁出头，由于法拉戴先生的那辆福特车，再加上我那身高品质的行头，显然把我当成了一位非常尊贵的上宾。
The landlady, a woman of around forty or so, appears to regard me as a rather grand visitor on account of Mr Farraday's Ford and the high quality of my suit.

今天下午—我是大约三点半到达索尔兹伯里的—当我在她的登记簿上填写我的住址“达林顿府”时，我觉察到她看我的眼神中带上了一丝惶恐，显然是把我当成了某位住惯了里兹和多切斯特那类豪华饭店的士绅，担心我一旦看到这里的客房就会怒冲冲地离开她的宾馆。
This afternoon – I arrived in Salisbury at around three thirty – when I entered my address in her register as ‘Darlington Hall’, I could see her look at me with some trepidation, assuming no doubt that I was some gentleman used to such places as the Ritz or the Dorchester and that I would storm out of the guest house on being shown my room.

她告诉我前排朝向的客房中还有一间双人房空着，不过她欢迎我以单人房的房价入住这间客房。
She informed me that a double room at the front was available, though I was welcome to it for the price of a single.

接着我就被领到了这个房间，在一天当中的那个时候，阳光正好将壁纸上的花卉纹样照亮，看着让人赏心悦目。
I was then brought up to this room, in which, at that point of the day, the sun was lighting up the floral patterns of the wallpaper quite agreeably.

房间里有两张单人床，还有两扇可以俯瞰街景的大窗。
There were twin beds and a pair of good-sized windows overlooking the street.

当我询问浴室在哪里的时候，老板娘以胆怯的声音回答说浴室就在我房间的对面，但要等晚餐过后才有热水供应。
On inquiring where the bathroom was, the woman told me in a timid voice that although it was the door facing mine, there would be no hot water available until after supper.

我请她为我送一壶茶上来，她离开后，我又进一步检查了一下这个房间。
I asked her to bring me up a pot of tea, and when she had gone, inspected the room further.

床很干净，铺得很齐整。
The beds were perfectly clean and had been well made.

屋角的洗脸池也很干净。
The basin in the corner was also very clean.

朝窗外望去，可以看到街道对面有一家面包店，橱窗里陈列着各色糕点，还有一家药店和理发店。
On looking out of the windows, one saw on the opposite side of the street a bakery displaying a variety of pastries, a chemist's shop and a barber's.

再往前，还能看到这条街跨过了一座小小的圆拱桥，再往下延伸就是相对郊区的地段了。
Further along, one could see where the street passed over a round-backed bridge and on into more rural surroundings.

我在洗脸池里用冷水洗了洗脸和手，提提精神，然后就在靠窗的一把硬背椅子上坐下，等我要的茶送上来。
I refreshed my face and hands with cold water at the basin, then seated myself on a hard-backed chair left near one of the windows to await my tea.

我想应该是在四点刚过不久的时候，我离开宾馆，到索尔兹伯里的大街上去探个究竟。
I would suppose it was shortly after four o'clock that I left the guest house and ventured out into the streets of Salisbury.

这里的街道宽阔而又通畅，赋予这个城市一种不可思议的开阔感，让人真想就在温暖和煦的阳光下，在大街上闲逛几个钟头。
The wide, airy nature of the streets here give the city a marvellously spacious feel, so that I found it most easy to spend some hours just strolling in the gently warm sunshine.

此外，我还发现这个城市拥有很多迷人之处；我屡次发现自己漫步经过一排排可爱的旧圆木门脸儿的住房，或是翻过某一座架在流经这个城市的众多溪流上面的步行小石桥。
Moreover, I discovered the city to be one of many charms; time and again, I found myself wandering past delightful rows of old timber-fronted houses, or crossing some little stone footbridge over one of the many streams that flow through the city.

当然了，我并没有忘记去参观那座优美的大教堂，西蒙斯太太在她的著作中对这座大教堂可是赞誉有加。
And of course, I did not fail to visit the fine cathedral, much praised by Mrs Symons in her volume.

这座庄严的建筑并不难找，无论置身索尔兹伯里的什么地方，它那高耸的尖顶都清晰可见。
This august building was hardly difficult for me to locate, its looming spire being ever-visible wherever one goes in Salisbury.

确实，我在傍晚时分返回宾馆的途中，好几次扭头回顾，而每一次都会欣赏到灿烂的夕阳在那巍峨的尖顶后面逐渐西沉的景象。
Indeed, as I was making my way back to this guest house this evening, I glanced back over my shoulder on a number of occasions and was met each time by a view of the sun setting behind that great spire.

然而今夜一个人待在安静的房间里，我发现这第一天的旅程真正在我脑海中留下深刻印记的并不是索尔兹伯里大教堂，也不是这座城市任何其他的迷人景色，反倒是今天早上意外所见的那一片延绵起伏、美丽绝伦的英格兰乡村胜景。现在，我很乐于相信其他的国家能够奉献出更为雄伟壮观的景色。
And yet tonight, in the quiet of this room, I find that what really remains with me from this first day's travel is not Salisbury Cathedral, nor any of the other charming sights of this city, but rather that marvellous view encountered this morning of the rolling English countryside. Now I am quite prepared to believe that other countries can offer more obviously spectacular scenery.

的确，我也在百科全书和《国家地理杂志》上看到过全球各个角落那令人屏息赞叹的风光照片：气势磅礴的峡谷和瀑布，粗犷壮丽的崇山峻岭。
Indeed, I have seen in encyclopedias and the National Geographic Magazine breath-taking photographs of sights from various corners of the globe; magnificent canyons and waterfalls, raggedly beautiful mountains.

我当然从来都无缘亲眼目睹这些奇景，但我还是有充分的信心不揣冒昧地断言：英国那些最优美的风景—就像我今晨所见—拥有一种其他国家的风景所付之阙如的特质，尽管它们表面上看来或许更加具有戏剧性。我相信，这样的一种特质会使英国的风景在任何客观的观察者眼中，都成为世界上给人印象最深、最令人满意的景色，这种特质或许以“伟大”这个字眼来形容是最为贴切的。
It has never, of course, been my privilege to have seen such things at first hand, but I will nevertheless hazard this with some confidence: the English landscape at its finest – such as I saw it this morning – possesses a quality that the landscapes of other nations, however more superficially dramatic, inevitably fail to possess. It is, I believe, a quality that will mark out the English landscape to any objective observer as the most deeply satisfying in the world, and this quality is probably best summed up by the term ‘greatness’.

因为千真万确，今天早上当我站在那个高崖上饱览我面前的那片土地时，我真真切切地体会到了那种极为罕有却又确定无疑的情感—那种只有置身于“伟大”面前才会产生的情感。
For it is true, when I stood on that high ledge this morning and viewed the land before me, I distinctly felt that rare, yet unmistakable feeling – the feeling that one is in the presence of greatness.

我们将这片土地称为我们的大不列颠，也许还有些人觉得这未免有些妄自尊大，但我却敢于冒昧地直言，唯有我们国家的风景才配得上使用这个崇高的形容词。
We call this land of ours Great Britain, and there may be those who believe this a somewhat immodest practice. Yet I would venture that the landscape of our country alone would justify the use of this lofty adjective.

然而，这个“伟大”的确切含义到底是什么呢？
And yet what precisely is this ‘greatness’?

它到底在哪里，或者体现在什么当中呢？
Just where, or in what, does it lie?

我知道，这样一个问题是要远比我更为聪明的头脑才能回答的，但如果一定要我斗胆一猜的话，我会说，使我们的国土之美显得如此与众不同的正在于它欠缺那种明显的戏剧性或者奇崛的壮观色彩。
I am quite aware it would take a far wiser head than mine to answer such a question, but if I were forced to hazard a guess, I would say that it is the very lack of obvious drama or spectacle that sets the beauty of our land apart.

个中的关键就在于那种静穆的优美，那种高贵的克制。
What is pertinent is the calmness of that beauty, its sense of restraint.

就仿佛这片土地明知道自己的优美，知道自己的伟大，又感觉无须去彰显，去招摇。
It is as though the land knows of its own beauty, of its own greatness, and feels no need to shout it.

相形之下，像非洲和美洲这样的地方所呈现的景观，虽然无疑是令人赞叹激赏的，我敢肯定，正是因为它们这种毫无节制的自我标榜，在态度客观的观察者看来反倒会相形见绌。
In comparison, the sorts of sights offered in such places as Africa and America, though undoubtedly very exciting, would, I am sure, strike the objective viewer as inferior on account of their unseemly demonstrativeness.

这整个问题倒是跟这些年来在我们这个行当中曾引发诸多争议的那个问题非常相似：怎样才算得上一个“伟大的”管家？
The whole question is very akin to the question that has caused much debate in our profession over the years: what is a ‘great’ butler?

我还清楚地记得一天的工作结束后，我们围坐在仆役大厅的炉火旁，针对这个话题长时间展开的那些愉快的讨论。
I can recall many hours of enjoyable discussion on this topic around the fire of the servants’ hall at the end of a day.

您应该注意到我说的是“怎样”才算是一个伟大的管家，而不是“谁”：因为对于在我们这代人中是谁确立了本行业的标准，其实是没有什么严重分歧的，也就是说，像沙勒维尔府的马歇尔先生或是布莱德伍德的莱恩先生就是个中翘楚。
You will notice I say ‘what’ rather than ‘who’ is a great butler; for there was actually no serious dispute as to the identity of the men who set the standards amongst our generation. That is to say, I am talking of the likes of Mr Marshall of Charleville House, or Mr Lane of Bridewood.

如果您有幸得识这样的人物，您无疑就会知道我所指的他们所拥有的特质到底是什么了。
If you have ever had the privilege of meeting such men, you will no doubt know of the quality they possess to which I refer.

但您无疑也会明白，我为什么会说要对这种特质下一个确切的定义殊非易事了。
But you will no doubt also understand what I mean when I say it is not at all easy to define just what this quality is.

捎带说一句，由于对此我又有了深一层的思考，恐怕也不能说在谁算得上是伟大的管家这一点上是毫无疑义的。
Incidentally, now that I come to think further about it, it is not quite true to say there was no dispute as to who were the great butlers.

更严密的说法应该是：至少在那些对此类问题具有真知灼见的专业人士中间，对这一点是没有太大争议的。
What I should have said was that there was no serious dispute among professionals of quality who had any discernment in such matters.

当然啦，达林顿府的仆役大厅就像任何地方的仆役大厅一样，必然要接受不同智力层次和认知水平的雇员，所以我记得曾有好多次我不得不紧咬嘴唇，才能容忍有些雇员—我不得不很遗憾地说，有时甚至是我自己属下的员工—兴奋不已地为比如说杰克·内伯斯之流的人物大唱赞歌。
Of course, the servants’ hall at Darlington Hall, like any servants’ hall anywhere, was obliged to receive employees of varying degrees of intellect and perception, and I recall many a time having to bite my lip while some employee – and at times, I regret to say, members of my own staff – excitedly eulogized the likes of, say, Mr Jack Neighbours.

我对于杰克·内伯斯先生并无任何成见，据我了解，他已在大战中不幸阵亡。
I have nothing against Mr Jack Neighbours, who sadly, I understand, was killed in the war.

我提到他只是因为他是个典型的实例而已。
I mention him simply because his was a typical case.

在三十年代中期有那么两三年的时间，内伯斯先生的大名似乎成为全国每一个仆役大厅里谈论的热门话题。
For two or three years in the mid-thirties, Mr Neighbours's name seemed to dominate conversations in every servants’ hall in the land.

如我之前所言，在达林顿府中亦复如此，许多随侍主人来访的雇员都会带来内伯斯先生最新成就的传闻，于是，我和格雷厄姆先生这样的人也就只能万般无奈地被迫听着一则又一则有关他的趣闻轶事了。
As I say, at Darlington Hall too, many a visiting employee would bring the latest tales of Mr Neighbours's achievements, so that I and the likes of Mr Graham would have to share the frustrating experience of hearing anecdote after anecdote relating to him.

而这其中最令人懊恼的无过于，不得不亲眼见证那些在其他方面堪称正派得体的雇员们在讲完每一段轶事之后，都要叹赞不已地摇头晃脑，发出这样由衷的感叹：“那位内伯斯先生，他可真是最棒的。”
And most frustrating of all would be having to witness at the conclusion of each such anecdote otherwise decent employees shaking their heads in wonder and uttering phrases like: ‘That Mr Neighbours, he really is the best.’

说起来，我并不怀疑内伯斯先生拥有良好的组织才能；据我理解，他的确以引人瞩目的方式主持、策划过好几次重大的社交盛会。
Now I do not doubt that Mr Neighbours had good organizational skills; he did, I understand, mastermind a number of large occasions with conspicuous style.

但是在任何阶段，他就从未曾达到过一位伟大管家的境界。
But at no stage did he ever approach the status of a great butler.

我本该在他声誉最隆之时说这番话的，正如我早该预料到的，他在出尽风头不过短短的几年之内很快就声名扫地了。
I could have told you this at the height of his reputation, just as I could have predicted his downfall after a few short years in the limelight.

一位一度曾是他那一代口中交相赞誉的业内翘楚，短短的几年之内却又被确切地证明他其实一无是处，这样的翻覆多长时间会出现一次？
How often have you known it for the butler who is on everyone's lips one day as the greatest of his generation to be proved demonstrably within a few years to have been nothing of the sort?

然而，当初曾对他不吝溢美之词的同样那些雇员，又将忙着对某一新角色赞颂不已了，他们从来不知道适可而止，检讨一下自己的判断能力。
And yet those very same employees who once heaped praise on him will be too busy eulogizing some new figure to stop and examine their sense of judgement.

这些仆役大厅里的话题人物总是集中于某个豪门巨室的管家，可能因为成功地筹办过两三次重大的社交盛会而一下子声名鹊起，成为众所瞩目的焦点人物的。
The object of this sort of servants’ hall talk is invariably some butler who has come to the fore quite suddenly through having been appointed by a prominent house, and who has perhaps managed to pull off two or three large occasions with some success.

随后，全英格兰上上下下的各个仆役大厅里就会谣诼纷起，其大意不过是某某要员或是显贵已经向他伸出了橄榄枝，或者全国至尊至贵的几户门庭正以堪称天价的高薪竞相对他进行延揽。
There will then be all sorts of rumours buzzing through servants’ halls up and down the country to the effect that he has been approached by this or that personage or that several of the highest houses are competing for his services with wildly high wages.

但不过短短的几年之后，情况又复如何呢？
And what has happened before a few years have passed?

同样是这位所向披靡的人物对于某桩大错却负有了不可推卸的责任，要么就是由于其他的原因而失去了雇主的宠幸，已经离开了他当初建功立业的门庭，就此不知所终了。
This same invincible figure has been held responsible for some blunder, or has for some other reason fallen out of favour with his employers, leaves the house where he came to fame and is never heard of again.

与此同时，那同一批飞短流长的传播者们已经又找到了另一位后起之秀，继续津津乐道他的丰功伟绩了。
Meanwhile, those same gossipers will have found yet some other newcomer about whom to enthuse.

我发现，那些来访的贴身男仆往往就是罪魁祸首，因为他们通常总是急不可耐地一心觊觎着管家的职位。
Visiting valets, I have found, are often the worst offenders, aspiring as they usually do to the position of butler with some urgency.

就是他们这批人，总是一口咬定这位或是那位人物是最值得我辈效仿的榜样，要么就像是应声虫一样，热衷于一遍遍地传播某位特别的英雄人物据说已经就我们的专业问题所发表的卓识高见。
They it is who tend to be always insisting this or that figure is the one to emulate, or repeating what some particular hero is said to have pronounced upon professional matters.

不过话说到这儿，我得赶紧补充一句，也有很多贴身男仆是从来都不会沉迷于这种蠢行的—他们事实上是具有最高鉴识能力的专业人士。
But then, of course, I hasten to add, there are many valets who would never dream of indulging in this sort of folly – who are, in fact, professionals of the highest discernment.

当两三位这样的人士齐聚在我们的仆役大厅时—我指的是比如说像格雷厄姆先生这种水准的有识之士，只可惜我现在似乎已经跟他失去了联系—我们能针对我们这个行业的方方面面进行某些最饶有兴味、最才华横溢的辩论和探讨。
When two or three such persons were gathered together at our servants’ hall – I mean of the calibre of, say, Mr Graham, with whom now, sadly, I seem to have lost touch – we would have some of the most stimulating and intelligent debates on every aspect of our vocation.

的的确确，时至今日，那些夜晚都算得那个时代留给我的最美好的记忆。
Indeed, today, those evenings rank amongst my fondest memories from those times.

话休絮烦，还是让我们回到那个让我们真正备感兴趣的问题吧，当年我们在仆役大厅度过的那些夜晚，若是没有被对这个行业缺乏任何基本认识的无知之徒的喋喋不休所毁掉的话，我们最热衷于讨论的问题便是：“怎样才算是一位伟大的管家？”
But let me return to the question that is of genuine interest, this question we so enjoyed debating when our evenings were not spoilt by chatter from those who lacked any fundamental understanding of the profession; that is to say, the question ‘what is a great butler?’

据我所知，这些年来这个问题虽然引发了无数的讨论，我们业内却鲜有制定出一项官方答案的尝试。
To the best of my knowledge, for all the talk this question has engendered over the years, there have been very few attempts within the profession to formulate an official answer.

我能想到唯一可以援以为例的便是海斯协会所设立的入会标准。
The only instance that comes to mind is the attempt of the Hayes Society to devise criteria for membership.

您也许对海斯协会不甚了了，因为近些年来已极少为人谈及。
You may not be aware of the Hayes Society, for few talk of it these days.

不过在二十年代及三十年代早期，该协会却曾在伦敦及周边各郡产生过相当大的影响。
But in the twenties and the early thirties, it exerted a considerable influence over much of London and the Home Counties.

事实上，已经有人觉得它的势力过于强大了，所以当它最终被迫关闭时，很多人认为这并非一件坏事，我想那是一九三二或者一九三三年的事儿。
In fact, many felt its power had become too great and thought it no bad thing when it was forced to close, I believe in 1932 or 1933.

海斯协会号称，“唯有第一流”的管家他们才接受入会。
The Hayes Society claimed to admit butlers of ‘only the very first rank’.

它的势力与威望的日渐增长，大部分源自它与其他那些昙花一现的组织的不同诉求，它始终将它的会员人数控制在极低的范围之内，这就使得它的入会宗旨具有了一定的信誉度。
Much of the power and prestige it went on to gain derived from the fact that unlike other such organizations which have come and gone, it managed to keep its numbers extremely low, thus giving this claim some credibility.

据称，它的会员人数从未超过三十名，大部分时间都仅仅保持在九到十位。
Membership, it was said, never at any point rose above thirty and much of the time remained closer to nine or ten.

这一点，再加上海斯协会颇有些类似于秘密社团的事实，一度为它蒙上了不小的神秘色彩，由此也使得它偶尔针对职业问题所发表的见解会被众人视如圭臬、奉若神明。
This, and the fact that the Hayes Society tended to be a rather secretive body, lent it much mystique for a time, ensuring that the pronouncements it occasionally issued on professional matters were received as though hewn on tablets of stone.

不过，这个协会一度拒不公之于众的内容之一就是它自家的入会标准。
But one matter the Society resisted pronouncing on for some time was the question of its own criteria for membership.

随着公众要求其公布入会标准的压力与日俱增，也是为了答复《士绅男仆季刊》上刊登的一系列询问的信函，这个协会终于承认，他们接受会员入会的先决条件是“申请者须服务于显赫门庭”。
Pressure to have these announced steadily mounted, and in response to a series of letters published in A Quarterly for the Gentleman's Gentleman, the Society admitted that a prerequisite for membership was that ‘an applicant be attached to a distinguished household’.

“不过，当然了，”这个协会又继续解释道，“仅此一条尚远不足以满足入会之要求”。
‘Though of course,’ the Society went on, ‘this by itself is far from sufficient to satisfy requirements.’

除此之外，该协会还明确表示，他们并不将商贾之家或是“新贵”阶层视作“显赫门庭”，而依我看来，单单这一食古不化的过时观点就已经严重削弱了该协会在我们的行业标准方面原本可能享有的任何严肃的权威性。
It was made clear, furthermore, that the Society did not regard the houses of businessmen or the ‘newly rich’ as ‘distinguished’, and in my opinion this piece of out-dated thinking crucially undermined any serious authority the Society may have achieved to arbitrate on standards in our profession.

在回应《季刊》后续刊发的来函时，该协会为它的立场作了辩护，声称他们虽愿意接受部分来函的观点，承认在商贾之家确实也有素质极佳的管家之存在，但“前提必须是纯正的淑女士绅之家不久即将前来礼聘延揽”，他们才会给以最终的认可。
In response to further letters in A Quarterly, the Society justified its stance by saying that while it accepted some correspondents’ views that certain butlers of excellent quality were to be found in the houses of businessmen, ‘the assumption had to be that the houses of true ladies and gentlemen would not refrain long from acquiring the services of any such persons’.

“纯正的淑女士绅”的标准必须作为最终判断的依据，该协会辩称，否则的话“我们差不多等于是遵行了苏俄布尔什维克的仪轨”了。
One had to be guided by the judgement of ‘the true ladies and gentlemen’, argued the Society, or else ‘we may as well adopt the proprieties of Bolshevik Russia’.

此番言辞引发了更激烈的论战，读者来函的压力与日俱增，力促该协会明确全面地公布其会员入会之标准。
This provoked further controversy, and the pressure of letters continued to build up urging the Society to declare more fully its membership criteria.

最终，在写给《季刊》的一封短函中该协会算是公开表了态—我将凭记忆尽量精确地引用其原文—“入会标准之首要条件是申请人须拥有与其职位相称之高尚尊严。
In the end, it was revealed in a brief letter to A Quarterly that in the view of the Society – and I will try and quote accurately from memory – ‘the most crucial criterion is that the applicant be possessed of a dignity in keeping with his position.

申请人无论有何等光耀之成就，倘若被确认在这一方面不符合标准，则将不能满足入会之要求”。
No applicant will satisfy requirements, whatever his level of accomplishments otherwise, if seen to fall short in this respect.’

尽管我对海斯协会向来都缺乏热情，我却认为它这一特别的声明倒至少是建立在一个重要的事实之上的。
For all my lack of enthusiasm for the Hayes Society, it is my belief that this particular pronouncement at least was founded on a significant truth.

如果我们来审视一下那些我们公认为“伟大的”管家，如果我们来审视一下比如说马歇尔先生或者莱恩先生，那么那个看起来将他们与那些只不过是极有能力的管家区别开来的因素，最切近的描述也确实只有“尊严”这个词差堪承当了。
If one looks at these persons we agree are ‘great’ butlers, if one looks at, say, Mr Marshall or Mr Lane, it does seem to be that the factor which distinguishes them from those butlers who are merely extremely competent is most closely captured by this word ‘dignity’.

当然，这只会引发进一步的争议：这个“尊严”又包含何种内容呢？
Of course, this merely begs the further question: of what is ‘dignity’ comprised?

也正是在这一点上，我跟格雷厄姆先生这样业内的翘楚人物进行过几次饶有兴味的辩论。
And it was on this point that the likes of Mr Graham and I had some of our most interesting debates.

格雷厄姆先生是一直都认为这个“尊严”是有点类似于女性之美的，因此试图去对它分而析之是无甚意义的。
Mr Graham would always take the view that this ‘dignity’ was something like a woman's beauty and it was thus pointless to attempt to analyse it.

我则认为这样的比拟有贬低马歇尔先生之辈所拥有的“尊严”之嫌。
I, on the other hand, held the opinion that to draw such a parallel tended to demean the ‘dignity’ of the likes of Mr Marshall.

不仅如此，我之反对格雷厄姆先生的这一类比的原因主要还在于，它暗示一个人是否拥有这种“尊严”纯粹出自造化的侥幸；如果某人并没有不证自明地先天就拥有了它，那么出自主观的奋力争取也就像是东施效颦般徒劳无益了。
Moreover, my main objection to Mr Graham's analogy was the implication that this ‘dignity’ was something one possessed or did not by a fluke of nature; and if one did not self-evidently have it, to strive after it would be as futile as an ugly woman trying to make herself beautiful.

尽管我也承认，管家中的绝大多数最终都会清楚地认识到他们并无获得此种素质的能力，但我仍然坚信，这种“尊严”正是我辈应该终其一生在职业生涯中有意识地去努力追求的标的。
Now while I would accept that the majority of butlers may well discover ultimately that they do not have the capacity for it, I believe strongly that this ‘dignity’ is something one can meaningfully strive for throughout one's career.

那些像马歇尔先生这样“伟大的”管家们，我相信，也都是经过多年艰苦的自我训练和认真地吸取经验才终于拥有了这一素质的。
Those ‘great’ butlers like Mr Marshall who have it, I am sure, acquired it over many years of self-training and the careful absorbing of experience.

所以，依我看来，如果站在职业的立场上接受格雷厄姆先生的观点的话，那可就无异于失败主义者的论调了。
In my view, then, it was rather defeatist from a vocational standpoint to adopt a stance like Mr Graham's.

不管怎么说，尽管格雷厄姆先生对此一直秉持怀疑主义的态度，我犹记得曾经有好多个夜晚，我跟他一起深入地交换意见，试图厘清这种“尊严”具体内涵的情景。
In any case, for all Mr Graham's scepticism, I can remember he and I spending many evenings trying to put our fingers on the constitution of this ‘dignity’.

我们从来都未曾达成任何共识，不过我可以说，至少在我这方面，在我们深入探讨的过程中就此问题我已经形成了相当坚定的看法，而且大体而言，这些信念我迄今仍信奉不渝。
We never came to any agreement, but I can say for my part that I developed fairly firm ideas of my own on the matter during the course of such discussions, and they are by and large the beliefs I still hold today.

如果可以的话，我想就在这儿试着谈谈我对这个“尊严”究为何物的看法。
I would like, if I may, to try and say here what I think this ‘dignity’ to be.

如果说沙勒维尔府的马歇尔先生和布莱德伍德的莱恩先生是当代世所公认的两位伟大的管家，我料想应该不会有什么争议。
You will not dispute, I presume, that Mr Marshall of Charleville House and Mr Lane of Bridewood have been the two great butlers of recent times.

或许您也会认可，布兰伯里堡的亨德森先生同样隶属这个凤毛麟角的范畴。
Perhaps you might be persuaded that Mr Henderson of Branbury Castle also falls into this rare category.

但如果我说家父在很多方面也足堪与这些人物并驾齐驱，我一直将他的职业生涯当作我细究“尊严”这一定义的样板，您或许就会认为我这只是出于偏私的小见识了。
But you may think me merely biased if I say that my own father could in many ways be considered to rank with such men, and that his career is the one I have always scrutinized for a definition of ‘dignity’.

不过我坚信，家父在拉夫伯勒府服务时的事业巅峰期的确就是“尊严”这个词的鲜活化身。
Yet it is my firm conviction that at the peak of his career at Loughborough House, my father was indeed the embodiment of ‘dignity’.

我也明白，若是客观地看待此事，我们不得不承认在家父身上是缺少通常人们会期望一位伟大的管家所具备的某些特质的。
I realize that if one looks at the matter objectively, one has to concede my father lacked various attributes one may normally expect in a great butler.

不过，我必须据理力争的是，他所缺少的这些特质毫无例外的都是那些肤浅和装饰性的东西，虽然无疑都是很有魅力的特质，就像蛋糕上的糖霜一样，却又都是跟真正的本质并无实际的相关性的。
But those same absent attributes, I would argue, are every time those of a superficial and decorative order, attributes that are attractive, no doubt, as icing on the cake, but are not pertaining to what is really essential.

我指的是诸如标准的口音、对语言的驾驭能力，以及对于诸如驯鹰术或是蝾螈交配这类包罗万象的话题的无所不知—这一类的特质没有一样是家父可以引为自夸的。
I refer to things such as good accent and command of language, general knowledge on wide-ranging topics such as falconing or newt-mating – attributes none of which my father could have boasted.

再者说了，不要忘记家父是上一辈的管家，在他开始起职业生涯的时候，这些特质并不被认为是合宜得体的，更不用说是一位管家值得拥有的了。
Furthermore, it must be remembered that my father was a butler of an earlier generation who began his career at a time when such attributes were not considered proper, let alone desirable in a butler.

对于雄辩的口才与广阔的知识的执迷似乎是在我们这一代才兴起的，也许就正是大力效仿马歇尔先生的结果，那些等而下之的同行在努力效仿他的伟大之时错将表面文章当作了精髓和本质。
The obsessions with eloquence and general knowledge would appear to be ones that emerged with our generation, probably in the wake of Mr Marshall, when lesser men trying to emulate his greatness mistook the superficial for the essence.

依我看来，我们这一代人未免过于专注于这些“花色配菜”了；天晓得，为了训练标准的口音和对语言的娴熟驾驭我们到底花费了多少时间和精力，我们花费了多少个钟头去学习各种百科全书以及各类知识测试，而这些时间原本应该花费在熟练地掌握本行业的基本原理之上的。
It is my view that our generation has been much too preoccupied with the ‘trimmings’; goodness knows how much time and energy has gone into the practising of accent and command of language, how many hours spent studying encyclopedias and volumes of ‘Test Your Knowledge’, when the time should have been spent mastering the basic fundamentals.

虽说我们必须时刻小心，不要试图去推卸那些从根源上讲需要我们自己去承担的责任，不过我也必须指出，某些雇主在鼓励这类潮流上也确实起到了推波助澜的巨大作用。
Though we must be careful not to attempt to deny the responsibility which ultimately lies with ourselves, it has to be said that certain employers have done much to encourage these sorts of trends.

这话说来未免令人遗憾，不过看来近些年来颇有些府第，有些还是至尊至贵的显赫门庭，都倾向于采取一种相互攀比的态度，并不耻于向宾朋们“炫耀”他们的管家对于这类鸡毛蒜皮的本事的掌握是何等娴熟。
I am sorry to say this, but there would appear to have been a number of houses in recent times, some of the highest pedigree, which have tended to take a competitive attitude towards each other and have not been above ‘showing off’ to guests a butler's mastery of such trivial accomplishments.

我听到过各种各样的例子，府里的管家在盛大的招待会上被当作玩杂耍的猴子一样展示给一众宾朋。
I have heard of various instances of a butler being displayed as a kind of performing monkey at a house party.

我本人就曾亲眼目睹过一次非常令人遗憾的例子，在那府上已经成了一项保留节目，那便是由宾朋们打铃把管家唤来，要他回答各种随机的提问，比如说某某年的德比马赛中是谁赢得了桂冠，那场景活像是在杂耍戏院里向表演节目的“记忆达人”连珠发问。
In one regrettable case, which I myself witnessed, it had become an established sport in the house for guests to ring for the butler and put to him random questions of the order of, say, who had won the Derby in such and such a year, rather as one might to a Memory Man at the music hall.

如我所言，家父那一代管家幸好还没有那些有关我们的职业价值的缠杂不清。
My father, as I say, came of a generation mercifully free of such confusions of our professional values.

我还是要再强调一遍：尽管他对英语的掌握和他的知识面都相对有限，他不仅通晓管理一幢宅第所需的所有知识和窍门，而且在他事业的全盛时期，他已经具备了海斯协会所谓的“与其职位相称之高尚尊严”。
And I would maintain that for all his limited command of English and his limited general knowledge, he not only knew all there was to know about how to run a house, he did in his prime come to acquire that ‘dignity in keeping with his position’, as the Hayes Society puts it.

如此，如果我试图向诸位描述清楚我认为使得家父如此出类拔萃的原因到底是什么，那么在这一过程中或许也就能讲清楚我对于“尊严”究为何物的看法了。
If I try, then, to describe to you what I believe made my father thus distinguished, I may in this way convey my idea of what ‘dignity’ is.

多年以来，有一个故事是家父总喜欢反反复复多次讲述的。
There was a certain story my father was fond of repeating over the years.

我记得我还是个孩子以及后来在他的督导之下开始做一个男仆的时候，都曾听他向客人们讲过这个故事。
I recall listening to him tell it to visitors when I was a child, and then later, when I was starting out as a footman under his supervision.

我记得我在得到我第一个管家的职位后—那是在牛津郡奥尔肖特的一幢相对朴素的住宅，为马格里奇先生和太太服务—第一次回去探望他时，他又把这个故事给我讲了一遍。
I remember him relating it again the first time I returned to see him after gaining my first post as butler – to a Mr and Mrs Muggeridge in their relatively modest house in Allshot, Oxfordshire.

很显然，这个故事对他来说意义重大。
Clearly the story meant much to him.

家父那辈人并不像我们这代人那样习惯于喋喋不休地讨论和分析事理，我相信，讲述以及反复地讲述这个故事对于家父而言就等于是他对自己所从事的这个职业所进行的批判性的省思。
My father's generation was not one accustomed to discussing and analysing in the way ours is and I believe the telling and retelling of this story was as close as my father ever came to reflecting critically on the profession he practised.

果如此，则这个故事也就提供了解他的所思所想的关键线索。
As such, it gives a vital clue to his thinking.

这显然是个真实的故事，内容大致是有位管家随侍雇主远赴印度，多年服务于斯，在只能雇用当地仆佣的情况下仍能始终维持跟英国国内同样高的专业服务水准。
The story was an apparently true one concerning a certain butler who had travelled with his employer to India and served there for many years maintaining amongst the native staff the same high standards he had commanded in England.

话说有一天下午，这位管家走进餐厅去检查晚餐的准备工作是否已经全部就绪，结果却发现有一只老虎正懒洋洋地趴在餐桌底下。
One afternoon, evidently, this butler had entered the dining room to make sure all was well for dinner, when he noticed a tiger languishing beneath the dining table.

那位管家不动声色地离开餐厅，小心地把门关好，然后镇定自若地来到客厅，他的雇主正和几位客人在那儿喝茶。
The butler had left the dining room quietly, taking care to close the doors behind him, and proceeded calmly to the drawing room where his employer was taking tea with a number of visitors.

他礼貌地轻咳了一声，引起了雇主的注意，然后凑近主人的耳边悄声禀道：“非常抱歉，先生，有只老虎此刻正在餐厅里。
There he attracted his employer's attention with a polite cough, then whispered in the latter's ear: ‘I'm very sorry, sir, but there appears to be a tiger in the dining room.

也许您能许我使用十二号口径的猎枪？”
Perhaps you will permit the twelve-bores to be used?’

据传说，几分钟后，主人和客人听到了三声枪响。
And according to legend, a few minutes later, the employer and his guests heard three gun shots.

之后不久，当这位管家再度出现在客厅里更换新茶的时候，雇主问他是否一切顺利。
When the butler reappeared in the drawing room some time afterwards to refresh the teapots, the employer had inquired if all was well.

“非常顺利，谢谢您，先生，”他回答道。
‘Perfectly fine, thank you, sir,’ had come the reply.

“晚餐的时间将一如既往，而且容我高兴地回禀，届时，刚刚发生的意外将不会留下任何可见的痕迹。”
‘Dinner will be served at the usual time and I am pleased to say there will be no discernible traces left of the recent occurrence by that time.’

最后这句话—“届时，刚刚发生的意外将不会留下任何可见的痕迹”—家父总会呵呵带笑地重复一遍，并且赞赏不已地摇摇头。
This last phrase – ‘no discernible traces left of the recent occurrence by that time’ – my father would repeat with a laugh and shake his head admiringly.

他从未声称知道这位管家的尊姓大名，也从未说起还有人认识他，但他总是坚持事件的过程就跟他的讲述不差分毫。
He neither claimed to know the butler's name, nor anyone who had known him, but he would always insist the event occurred just as he told it.

不管怎么说，这个故事是真是假其实并不重要；重要的，当然是它透露了家父心目中理想的典范是什么样子。
In any case, it is of little importance whether or not this story is true; the significant thing is, of course, what it reveals concerning my father's ideals.

因为，当我回顾他的职业生涯时，我以后见之明能够看得出来，他有生之年都在努力成为他故事里的那个管家。
For when I look back over his career, I can see with hindsight that he must have striven throughout his years somehow to become that butler of his story.

而在我看来，在他事业的巅峰时期，家父已经实现了他的雄心壮志，夙愿得偿。
And in my view, at the peak of his career, my father achieved his ambition.

因为尽管我可以肯定他绝对不会有在餐桌底下邂逅一只老虎的机会，当我将我所知道或者听人说起的他的事迹细细掂量之后，我至少能想起好几个实例，足以显示出他已完全具备了故事中他钦敬不已的那位管家的素质。
For although I am sure he never had the chance to encounter a tiger beneath the dining table, when I think over all that I know or have heard concerning him, I can think of at least several instances of his displaying in abundance that very quality he so admired in the butler of his story.

这其中有一个例证是由查尔斯与雷丁公司的大卫·查尔斯先生讲给我听的，他在达林顿勋爵的时代不时会造访达林顿府。
One such instance was related to me by Mr David Charles, of the Charles and Redding Company, who visited Darlington Hall from time to time during Lord Darlington's days.

事有凑巧，有天晚上由我临时充当他的贴身男仆，查尔斯先生就跟我说起，多年前他造访拉夫伯勒府时跟家父曾有过一面之雅。拉夫伯勒府是实业家约翰·西尔弗斯先生的宅第，家父在其事业的巅峰时期曾在那里服务了十五年之久。
It was one evening when I happened to be valeting him, Mr Charles told me he had come across my father some years earlier while a guest at Loughborough House – the home of Mr John Silvers, the industrialist, where my father served for fifteen years at the height of his career.

他对家父真是没齿难忘，查尔斯先生对我说，就因为在他那次造访期间发生的一个小小的插曲。
He had never been quite able to forget my father, Mr Charles told me, owing to an incident that occurred during that visit.

令查尔斯先生愧悔不已的是有天下午，他居然纵容自己跟另外两位客人一起喝得酩酊大醉—我姑且只将这两位绅士称呼为史密斯先生和琼斯先生，因为在某些社交圈子里很有可能有人还记得他们。
One afternoon, Mr Charles to his shame and regret had allowed himself to become inebriated in the company of two fellow guests – gentlemen I shall merely call Mr Smith and Mr Jones since they are likely to be still remembered in certain circles.

在喝了一个多钟头以后，这两位绅士临时起意，想开车前往周边的几个村子兜兜风—那个时候汽车还是一样挺新奇的玩意儿。
After an hour or so of drinking, these two gentlemen decided they wished to go for an afternoon drive around the local villages – a motor car around this time still being something of a novelty.

他们劝说查尔斯先生跟他们一起去，由于司机不巧正在休假，于是就请家父暂代司机之职。
They persuaded Mr Charles to accompany them, and since the chauffeur was on leave at that point, enlisted my father to drive the car.

一旦上路之后，史密斯和琼斯先生尽管都已是十足的中年人了，其行为举止却像是学童般轻佻幼稚，一路上高唱粗鄙俚俗的小曲儿，对沿途所见之事物风景所发的评论更是粗鄙不堪。
Once they had set off, Mr Smith and Mr Jones, for all their being well into their middle years, proceeded to behave like schoolboys, singing coarse songs and making even coarser comments on all they saw from the window.

尤有甚者，这两位绅士在当地的地图上注意到附近有三个村庄，名字分别叫作莫菲、萨尔塔什和布里戈恩。
Furthermore, these gentlemen had noticed on the local map three villages in the vicinity called Morphy, Saltash and Brigoon.

现在我已经不能完全肯定确切的村名了，但重点是它们让史密斯和琼斯先生想起了杂耍剧场里的一出表演，叫作“墨菲、萨尔特曼和布里吉德猫”，您也许也听说过。
Now I am not entirely sure these were the exact names, but the point was they reminded Mr Smith and Mr Jones of the music hall act, Murphy, Saltman and Brigid the Cat, of which you may have heard.

在注意到这一奇妙的巧合后，这两位绅士就燃起了去这三个村子一探究竟的雄心—权当是为了向这三位艺人致敬。
Upon noticing this curious coincidence, the gentlemen then gained an ambition to visit the three villages in question – in honour, as it were, of the music hall artistes.

照查尔斯先生的说法，家父在已经遵命带他们去过了一个村子，正要进入第二个的时候，史密斯或是琼斯先生注意到这个村子是布里戈恩—也就是说，照艺人姓氏顺序的话这应该是第三个，而非第二个。
According to Mr Charles, my father had duly driven to one village and was on the point of entering a second when either Mr Smith or Mr Jones noticed the village was Brigoon – that is to say the third, not the second, name of the sequence.

于是他们愤怒地要求家父马上掉转车头，以便“以正确的顺序”依次参观这几个村子。
They demanded angrily that my father turned the car immediately so that the villages could be visited ‘in the correct order’.

这样一次折返势必大大增加行车的里程，不过，查尔斯先生向我保证，家父将其当作完全合情合理的要求，毫无异议地接受下来，而且之后的表现也几乎是一如既往地彬彬有礼、无可挑剔。
It so happened that this entailed doubling back a considerable way of the route, but, so Mr Charles assures me, my father accepted the request as though it were a perfectly reasonable one, and in general, continued to behave with immaculate courtesy.

可是史密斯和琼斯先生的注意力现在已经被吸引到家父身上，而且无疑已经对车窗外的景物感到相当厌烦了，于是就继之以对家父的“错误”大声嘲骂以自娱。
But Mr Smith's and Mr Jones's attention had now been drawn to my father and no doubt rather bored with what the view outside had to offer, they proceeded to amuse themselves by shouting out unflattering remarks concerning my father's ‘mistake’.

查尔斯先生犹记得他对于家父的表现大为惊叹，因为家父没有流露出一丝一毫不安或是恼怒的迹象，仍旧镇定自若地继续开车，其表情既充满个人尊严，又随时乐于效力帮忙。
Mr Charles remembered marvelling at how my father showed not one hint of discomfort or anger, but continued to drive with an expression balanced perfectly between personal dignity and readiness to oblige.

然而家父的沉着镇定却没有办法再持续下去了。
My father's equanimity was not, however, allowed to last.

因为那两位绅士在厌倦了对家父的肆意辱骂之后，居然开始议论起了招待他们的主人—也就是家父的雇主约翰·西尔弗斯先生。
For when they had wearied of hurling insults at my father's back, the two gentlemen began to discuss their host – that is to say, my father's employer, Mr John Silvers.

而且其措辞越来越卑劣和恶毒，就连查尔斯先生都听不下去了—至少他是这样声称的—不得不出言制止，暗示这样的议论是颇为失礼的。
The remarks grew even more debased and treacherous so that Mr Charles – at least so he claimed – was obliged to intervene with the suggestion that such talk was bad form.

可是这番劝说却招致了极为激烈的反驳，以至于查尔斯先生不但要担心他将成为那两位绅士接下来辱骂的对象，甚至真的害怕自己有遭到人身伤害的危险了。
This view was contradicted with such energy that Mr Charles, quite aside from worrying he would become the next focus of the gentlemen's attention, actually thought himself in danger of physical assault.

可是正在这时，就在他们针对家父的雇主爆出了一句特别恶毒的含沙射影的攻击之后，家父突然间来了个急刹车。
But then suddenly, following a particularly heinous insinuation against his employer, my father brought the car to an abrupt halt.

正是接下来发生的那一幕给查尔斯先生留下了不可磨灭的深刻印象。
It was what happened next that had made such an indelible impression upon Mr Charles.

后车门被打开了，家父就站在车门外，距离汽车几步之遥，目光紧盯着车内。
The rear door of the car opened and my father was observed to be standing there, a few steps back from the vehicle, gazing steadily into the interior.

据查尔斯先生的描述，他们三位乘客似乎这才意识到家父的体魄是何等威风凛凛，不约而同地全被震慑住了。
As Mr Charles described it, all three passengers seemed to be overcome as one by the realization of what an imposing physical force my father was.

确实，他的身高足有六英尺三英寸，而他的表情，虽然当你知道他在乐于听命效劳的时候是让人感觉安心可靠的，但在某些特定的情境之下却着实也会是令人望而生畏的。
Indeed, he was a man of some six feet three inches, and his countenance, though reassuring while one knew he was intent on obliging, could seem extremely forbidding viewed in certain other contexts.

按照查尔斯先生的说法，家父并没有表现出任何明显的怒气。
According to Mr Charles, my father did not display any obvious anger.

他似乎只不过是拉开了后车门。
He had, it seemed, merely opened the door.

然而他却有一种不怒自威的力量，不必开口就胜似正言厉色的训斥，再加上他那赫然耸立的魁伟身躯稳如泰山般坚不可摧，一见之下，查尔斯先生那两位醉醺醺的同伴马上就俯首帖耳地畏葸不前了，活像是偷苹果的小男孩被农夫抓了个现行一般。
And yet there was something so powerfully rebuking, and at the same time so unassailable about his figure looming over them that Mr Charles's two drunken companions seemed to cower back like small boys caught by the farmer in the act of stealing apples.

家父就这样在那儿站了一段时间，一句话不说，只是用手拉着敞开的车门。
My father had proceeded to stand there for some moments, saying nothing, merely holding open the door.

最后，不知是史密斯还是琼斯先生说了一句：“我们不再继续走了吗？”
Eventually, either Mr Smith or Mr Jones had remarked: ‘Are we not going on with the journey?’

家父没有搭腔，而是继续默不作声地站在那里，既没有要求他们下车，也没有流露任何愿望或者意图。
My father did not reply, but continued to stand there silently, neither demanding disembarkation nor offering any clue as to his desires or intentions.

我很可以想象得出他那天的那副模样：在车门构成的那个方框里，他那威严的黑色身影几乎完全挡住了他身后那柔美的赫特福德郡风光。
I can well imagine how he must have looked that day, framed by the doorway of the vehicle, his dark, severe presence quite blotting out the effect of the gentle Hertfordshire scenery behind him.

查尔斯先生回忆说，那短短一段时间真是不可思议地令人怔忪不安，在此期间，尽管并没有参与方才两个人的不良言行，他仍旧感觉愧疚不已，罪责难逃。
Those were, Mr Charles recalls, strangely unnerving moments during which he too, despite not having participated in the preceding behaviour, felt engulfed with guilt.

这种沉默的局面仿佛要无休无止地持续下去，一直等到史密斯或者琼斯先生终于鼓起勇气嗫嚅道：“我想我们刚才确实有些放肆鲁莽了。
The silence seemed to go on interminably, before either Mr Smith or Mr Jones found it in him to mutter: ‘I suppose we were talking a little out of turn there.

我们保证不会再这样了。”
It won't happen again.’

家父沉吟了片刻，然后轻轻地把车门关上，回到驾驶座，继续那三个村庄的环游之旅—查尔斯先生肯定地对我说，剩余的游程几乎就是在一片沉默中完成的。
A moment to consider this, then my father had closed the door gently, returned to the wheel and had proceeded to continue the tour of the three villages – a tour, Mr Charles assured me, that was completed thereafter in near silence.

既然已经回忆了这个插曲，我便也想起了同样发生在家父职业生涯那段时间的另一件事，而这件事也许更能清楚地展现出他所拥有的特殊的职业素养。
Now that I have recalled this episode, another event from around that time in my father's career comes to mind which demonstrates perhaps even more impressively this special quality he came to possess.

在此我应该先解释一下，我们家一共是兄弟两个—我哥哥伦纳德在我还是个孩子的时候就在南非战争中阵亡了。
I should explain here that I am one of two brothers – and that my elder brother, Leonard, was killed during the South African War while I was still a boy.

家父自然是深感丧子之痛；而使这件大不幸雪上加霜的是，一位父亲在这种情况下唯一能够得到的安慰—即坚信自己的儿子是为了英王和国家光荣捐躯的—又由于家兄是在一次特别声名狼藉的机动行动中丧生的这一事实而受到玷污。
Naturally, my father would have felt this loss keenly; but to make matters worse the usual comfort a father has in these situations – that is, the notion that his son gave his life gloriously for king and country – was sullied by the fact that my brother had perished in a particularly infamous manoeuvre.

那次行动被指控为非但是针对布尔人的平民聚居区发动的一次最不符合英军荣誉的军事袭击，而且更有确凿的铁证证实，此次行动的指挥极端不负责任，数度违反了基本的军事预防原则，因此阵亡的兵士—包括家兄在内—死得可以说是毫无意义的。
Not only was it alleged that the manoeuvre had been a most un-British attack on civilian Boer settlements, overwhelming evidence emerged that it had been irresponsibly commanded with several floutings of elementary military precautions, so that the men who had died – my brother among them – had died quite needlessly.

有鉴于接下来我要讲述的内容，我不宜再对那次机动行动做更为精确的指认了，不过如果我说那次行动曾在当时引发轩然大波，控辩双方针锋相对的冲突本身使得那场争论更加引人瞩目的话，那么您也许已经猜到我具体的所指了。
In view of what I am about to relate, it would not be proper of me to identify the manoeuvre any more precisely, though you may well guess which one I am alluding to if I say that it caused something of an uproar at the time, adding significantly to the controversy the conflict as a whole was attracting.

当时曾有舆论呼吁将涉事的将领就地免职，甚至移交军事法庭审判，但军方出面力保该将领，并许其继续履职，打完那场战役。
There had been calls for the removal, even the court-martialling, of the general concerned, but the army had defended the latter and he had been allowed to complete the campaign.

而鲜为人知的是，在南非冲突临近结末之时，这位将领主动选择悄然引退，然后进入商界，专营往来南非的货运生意。
What is less known is that at the close of the Southern African conflict, this same general had been discreetly retired, and he had then entered business, dealing in shipments from Southern Africa.

我之所以提到这些是因为在战争结束大约十年后，也就是说当丧子的创伤仅只在表面上已经愈合的时候，约翰·西尔弗斯先生将家父叫进书房，告诉他这位要人—我姑且简单地称他为“将军”吧—即将前来府上做客几日，参加府里举行的宴会，家父的雇主希望借此机会为一桩获利颇丰的商业交易打下基础。
I relate this because some ten years after the conflict, that is to say when the wounds of bereavement had only superficially healed, my father was called into Mr John Silvers's study to be told that this very same personage – I will call him simply ‘the General’ – was due to visit for a number of days to attend a house party, during which my father's employer hoped to lay the foundations of a lucrative business transaction.

不过，西尔弗斯先生也想到了这次造访将对家父造成的重大影响，所以特意叫他进来，主动提出在将军逗留期间他不妨休假几天。
Mr Silvers, however, had remembered the significance the visit would have for my father, and had thus called him in to offer him the option of taking several days’ leave for the duration of the General's stay.

毋庸讳言，家父对这位将军自然是憎恶已极；不过他同样也认识到雇主目前生意上的前景全系于此次乡宅宴会能否成功举办—预计将有十八位客人莅临，这样的规模可绝非是小事一桩。
My father's feelings towards the General were, naturally, those of utmost loathing; but he realized too that his employer's present business aspirations hung on the smooth running of the house party – which with some eighteen or so people expected would be no trifling affair.

于是家父做出了这样的答复，大意是他由衷地感激他个人的情感深得主人的体恤，但他可以向西尔弗斯先生保证，举办乡宅宴会期间所提供的一切服务都将符合应有的水准。
My father thus replied to the effect that while he was most grateful that his feelings had been taken into account, Mr Silvers could be assured that service would be provided to the usual standards.

结果，家父所承受的磨难甚至比原本的预期还要严酷得多。
As things turned out, my father's ordeal proved even worse than might have been predicted.

一则，家父原本或许还抱有一线期望，以为在亲自见到这位将军以后也许能心生些许尊敬或是同情，从而缓解他对此人怀有的憎恶之情，而事实证明，这根本就是毫无来由的一厢情愿。
For one thing, any hopes my father may have had that to meet the General in person would arouse a sense of respect or sympathy to leaven his feelings against him proved without foundation.

这位将军身材痴肥、相貌丑陋，其仪态举止毫无教养，言谈话语粗鲁不文，不论说到什么都往军事术语上硬套。
The General was a portly, ugly man, his manners were not refined, and his talk was conspicuous for an eagerness to apply military similes to a very wide variety of matters.

尤有甚者，这位绅士的贴身男仆并没有随侍前来，因为平常伺候他的男仆不巧病倒了。
Worse was to come with the news that the gentleman had brought no valet, his usual man having fallen ill.

这就带来了一个微妙的难题，因为另有一位客人也没有带他的贴身男仆，于是乎府上的管家将亲自担任哪位客人的贴身男仆，哪位客人的贴身男仆只能由府上的普通男仆临时充当就成了一个问题。
This presented a delicate problem, another of the house guests being also without his valet, raising the question as to which guest should be allocated the butler as valet and who the footman.

家父因为体贴雇主的处境，当即主动接下了为将军做贴身男仆的差事，这么一来就不得不跟他厌恶的那个人亲密相处长达四天之久了。
My father, appreciating his employer's position, volunteered immediately to take the General, and thus was obliged to suffer intimate proximity for four days with the man he detested.

与此同时，那位将军因为浑然不知家父的感受，还利用一切机会大讲特讲他那丰功伟绩的从军历史—当然了，许多从过军的绅士都喜欢在房间里私底下面对贴身男仆大肆夸耀当年的神勇。
Meanwhile, the General, having no idea of my father's feelings, took full opportunity to relate anecdotes of his military accomplishments – as of course many military gentlemen are wont to do to their valets in the privacy of their rooms.

然而家父居然一丝不漏地隐藏了自己的情感，完美无瑕地履行了他的专业职责，以至于将军在离别之际由衷地向约翰·西尔弗斯先生盛赞他的管家是何等优秀，并留下一笔可观的小费以示谢意—家父毫不犹豫地请雇主将其捐献给了慈善机构。
Yet so well did my father hide his feelings, so professionally did he carry out his duties, that on his departure the General had actually complimented Mr John Silvers on the excellence of his butler and had left an unusually large tip in appreciation – which my father without hesitation asked his employer to donate to a charity.

通过从家父的职业生涯中援引的这两个实例—两者我都曾经过确证，相信其确凿无疑—我希望您会同意，家父不但是证实了，他几乎就是海斯协会所谓的“与其职位相称之高尚尊严”的化身。
I hope you will agree that in these two instances I have cited from his career – both of which I have had corroborated and believe to be accurate – my father not only manifests, but comes close to being the personification itself, of what the Hayes Society terms ‘dignity in keeping with his position’.

若是有人将这种时刻下的家父与某位即便拥有杰克·内伯斯那类最高等级花式技巧的管家做一番对比，我相信他或许就能够初步分辨得出“伟大的”管家与只不过颇有能力的管家之间的不同了。
If one considers the difference between my father at such moments and a figure such as Mr Jack Neighbours even with the best of his technical flourishes, I believe one may begin to distinguish what it is that separates a ‘great’ butler from a merely competent one.

至此，我们或许也就更能够理解家父为什么那么喜欢在餐桌底下发现了一只老虎却丝毫都不惊惶失措的那个管家的故事了；那是因为他本能地知道在这个故事当中就隐含着“尊严”的真谛。
We may now understand better, too, why my father was so fond of the story of the butler who failed to panic on discovering a tiger under the dining table; it was because he knew instinctively that somewhere in this story lay the kernel of what true ‘dignity’ is.

言已至此，就容我这样地假定吧：“尊严”云云，其至关紧要的一点即在于一位管家无论何时何地都能坚守其职业生命的能力。
And let me now posit this: ‘dignity’ has to do crucially with a butler's ability not to abandon the professional being he inhabits.

那些等而下之的管家只要稍遇刺激就会放弃其职业生命，回复原形。
Lesser butlers will abandon their professional being for the private one at the least provocation.

对于这样的人来说，身为管家就好比扮演某个哑剧里的角色；轻轻一推，稍一趔趄，那个假面就会跌落，露出底下的真身。
For such persons, being a butler is like playing some pantomime role; a small push, a slight stumble, and the façade will drop off to reveal the actor underneath.

伟大的管家之所以伟大，是由于他们能够化入他们的职业角色，并且是全身心地化入；他们绝不会为外部事件所动摇，不管这些事件是何等出人意料、令人恐慌或是惹人烦恼。
The great butlers are great by virtue of their ability to inhabit their professional role and inhabit it to the utmost; they will not be shaken out by external events, however surprising, alarming or vexing.

他们呈现出的职业精神和专业风范就好比一位体面的绅士坚持穿着正式的套装：他绝不会容许自己因为宵小无赖的干扰或任何意外状况而在大庭广众之下宽衣解带；他在，也只有在他主动要这样做时才会将正装脱下，而且也毫无例外地是在他完全独处的情况下才会这么做。
They wear their professionalism as a decent gentleman will wear his suit: he will not let ruffians or circumstances tear it off him in the public gaze; he will discard it when, and only when, he wills to do so, and this will invariably be when he is entirely alone.

如我所言，这是关乎“尊严”的大计。
It is, as I say, a matter of ‘dignity’.

常听人说，真正的管家只存在于英国。
It is sometimes said that butlers only truly exist in England.

在其他国家，无论实际上冠以什么样的头衔，有的只是男仆。
Other countries, whatever title is actually used, have only manservants.

我倒是认为此言不虚。
I tend to believe this is true.

欧陆民族无法造就管家，是因为他们从人种上说就不擅长克制情绪，极端的情绪自控是只有英国人才做得到的。
Continentals are unable to be butlers because they are as a breed incapable of the emotional restraint which only the English race is capable of.

欧陆民族—总的说来凯尔特人亦然，我想您无疑也会赞同—通常在情绪强烈的时刻难以自控，所以除非是在那种丝毫都不会有刺激和挑战的场合下，他们是无法保持其专业风范的。
Continentals – and by and large the Celts, as you will no doubt agree – are as a rule unable to control themselves in moments of strong emotion, and are thus unable to maintain a professional demeanour other than in the least challenging of situations.

如果允许我再次沿用先前的那个比喻—请原谅我表述得如此粗俗—他们就像是一个受到一点最轻微的刺激就会把正装和衬衣一把扯下，尖声喊叫四处乱跑的人。
If I may return to my earlier metaphor – you will excuse my putting it so coarsely – they are like a man who will, at the slightest provocation, tear off his suit and his shirt and run about screaming.

一句话，“尊严”可不是这种人力所能及的。
In a word, ‘dignity’ is beyond such persons.

我们英国人在这方面比外国人具有重要的优势，也正是为此，当你想到某位伟大的管家时，他几乎理所当然地注定就是个英国人。
We English have an important advantage over foreigners in this respect and it is for this reason that when you think of a great butler, he is bound, almost by definition, to be an Englishman.

当然了，对此您也许会不以为然，就像当初开心惬意地围炉夜话时，每当我阐述这样的见解格雷厄姆先生都会进行反驳一样：就算是我所言非虚，你也只能在亲眼目睹他在严峻的考验下的所作所为之后才有定论。
Of course, you may retort, as did Mr Graham whenever I expounded such a line during those enjoyable discussions by the fire, that if I am correct in what I am saying, one could recognize a great butler as such only after one had seen him perform under some severe test.

然而事实上，我们都会承认像马歇尔或者莱恩先生等人都在伟大的管家之列，而究其实我们当中的绝大多数都无法声称已经在这样的环境下考察过他们的实际作为。
And yet the truth is, we accept persons such as Mr Marshall or Mr Lane to be great, though most of us cannot claim to have ever scrutinized them under such conditions.

我不得不承认格雷厄姆先生的话自有其道理，但我只能这么说，当一个人在这个行业内干了足够长的时间以后，他只需凭直觉就能判断出某个人职业素养的深浅，无须亲眼目睹他在压力下的表现。
I have to admit Mr Graham has a point here, but all I can say is that after one has been in the profession as long as one has, one is able to judge intuitively the depth of a man's professionalism without having to see it under pressure.

确实，一旦能有幸亲炙一位真正伟大的管家，你非但不会对其有所怀疑，一心只想要“考验”一下他的含金量，你反而会觉得根本无法想象这样一位威信如此之高的人物会在任何情况下背弃其与生俱有的职业素养。
Indeed, on the occasion one is fortunate enough to meet a great butler, far from experiencing any sceptical urge to demand a ‘test’, one is at a loss to imagine any situation which could ever dislodge a professionalism borne with such authority.

事实上，多年前那个周日的午后，也正是这样的一种体悟，才能穿透酒精所造成的重度思维混沌，使得家父的那两位乘客陷入愧疚的沉默。
In fact, I am sure it was an apprehension of this sort, penetrating even the thick haze created by alcohol, which reduced my father's passengers into a shamed silence that Sunday afternoon many years ago.

面对这样的人物，就如同今天上午面对那最优美的英格兰风光一样：一见之下，你自然会知道你就站在了伟大的面前。
It is with such men as it is with the English landscape seen at its best as I did this morning: when one encounters them, one simply knows one is in the presence of greatness.

我知道，总会有人断言任何像我这样试图去对“伟大”条分缕析的行为都是徒劳。
There will always be, I realize, those who would claim that any attempt to analyse greatness as I have been doing is quite futile.

“有些人就是有，有些人就是没有，清楚明白，”格雷厄姆先生总会这么说。
‘You know when somebody's got it and you know when somebody hasn't,’ Mr Graham's argument would always be.

“除此以外，就没什么好说的了。”
‘Beyond that there's nothing much you can say.’

可我认为，在这个问题上我们有责任去对抗失败主义的论调。
But I believe we have a duty not to be so defeatist in this matter.

对所有我们这样的从业者而言，对这些问题进行深入的思考就更是一种职业责任了，唯其如此，我们每个人才可能为我们自己赢得“尊严”而更好地努力。
It is surely a professional responsibility for all of us to think deeply about these things so that each of us may better strive towards attaining ‘dignity’ for ourselves.

# 第二天—上午 | DAY TWO–MORNING

索尔兹伯里
Salisbury

我生性择床，换个地方总是睡不着，很不安稳地勉强浅睡了不长时间以后，我在大约一个钟头前就醒了。
Strange beds have rarely agreed with me, and after only a short spell of somewhat troubled slumber, I awoke an hour or so ago.

那时天还很黑，知道自己还要开整整一天的车，我努力想再多睡一会儿。
It was then still dark, and knowing I had a full day's motoring ahead of me, I made an attempt to return to sleep.

结果证明是徒劳以后，我最终决定干脆起来算了，那时候还很黑，为了去屋角的洗脸池那儿刮脸我不得不打开了电灯。
This proved futile, and when I decided eventually to rise, it was still so dark that I was obliged to turn on the electric light in order to shave at the sink in the corner.

不过等我刮完脸以后我又把灯关了，我能看到晨光已经从窗帘的边沿透了进来。
But when having finished I switched it off again, I could see early daylight at the edges of the curtains.

就在刚才我把窗帘拉开的时候，外面的光线仍旧非常暗淡，还有一层类似薄雾的东西影响了我的视线，就连街对面的面包店和药房都影影绰绰的。
When I parted them just a moment ago, the light outside was still very pale and something of a mist was affecting my view of the baker's shop and chemist's shop opposite.

确实，顺着街道朝远处望去，在街道跨上那座小圆拱桥的地方，能看到薄雾从河面上升起，有一根桥柱子都几乎完全看不见了。
Indeed, following the street further along to where it runs over the little round-backed bridge, I could see the mist rising from the river, obscuring almost entirely one of the bridge-posts.

外面阒无人迹，除了远处传来的某种锤击敲打的回声，以及这家旅店后侧的一个房间偶尔的咳嗽声以外，四下里仍旧悄无声息。
There was not a soul to be seen, and apart from a hammering noise echoing from somewhere distant, and an occasional coughing in a room to the back of the house, there is still no sound to be heard.

老板娘显然还没有起床走动，看来要想在她宣布的七点半以前就吃上早饭是绝无可能了。
The landlady is clearly not yet up and about, suggesting there is little chance of her serving breakfast earlier than her declared time of seven thirty.

眼下，在我等待这个世界醒来的安静时刻里，我发现自己又在心底里温习起了肯顿小姐那封来信的内容。
Now, in these quiet moments as I wait for the world about to awake, I find myself going over in my mind again passages from Miss Kenton's letter.

说起来了，我其实早就该解释一下我为什么还称呼她为“肯顿小姐”的。
Incidentally, I should before now have explained myself as regards my referring to ‘Miss Kenton’.

“肯顿小姐”其实应该被称呼为“本恩太太”才对，而且这已经有二十个年头了。
‘Miss Kenton’ is properly speaking ‘Mrs Benn’ and has been for twenty years.

可是因为我跟她认识并共事的时段仅限于她的少女时期，自从她去了英格兰西南成为“本恩太太”以后就再也没有见过她，您也许会原谅我仍旧使用我认识她时那已经不合礼俗的方式称呼她，而且这么多年来我在心里一直都是这样称呼她的。
However, because I knew her at close quarters only during her maiden years and have not seen her once since she went to the West Country to become ‘Mrs Benn’, you will perhaps excuse my impropriety in referring to her as I knew her, and in my mind have continued to call her throughout these years.

当然了，她的来信也给了我额外的理由可以继续把她当作“肯顿小姐”，因为她的婚姻不幸最终还是就要走向终点了。
Of course, her letter has given me extra cause to continue thinking of her as ‘Miss Kenton’, since it would seem, sadly, that her marriage is finally to come to an end.

信里并没有细讲这方面的情况，这当然也是意料中的事，不过肯顿小姐已经明确无误地谈到，她事实上已经搬出本恩先生那位于赫尔斯顿的住宅，目前寓居在小康普顿村附近的一位熟人家里。
The letter does not make specific the details of the matter, as one would hardly expect it to do, but Miss Kenton states unambiguously that she has now, in fact, taken the step of moving out of Mr Benn's house in Helston and is presently lodging with an acquaintance in the nearby village of Little Compton.

她的婚姻以失败告终当然是个悲剧。
It is of course tragic that her marriage is now ending in failure.

此时此刻，她想必正在抱憾地思量多年前做出的那个决定是如何使得她在中年的后期落得如此孤独凄凉的。
At this very moment, no doubt, she is pondering with regret decisions made in the far-off past that have now left her, deep in middle age, so alone and desolate.

不难看出，处在这样的一种心绪之下，想到能重返达林顿府对她而言将是个不小的安慰。
And it is easy to see how in such a frame of mind, the thought of returning to Darlington Hall would be a great comfort to her.

诚然，她在信中并没有一字一句明确地表示故园重返的意愿；但遣词造句的种种委婉幽微之处在在传递出这一明白无误的讯息，字里行间深深地浸透着对于她在达林顿府度过的那些岁月的怀恋之情。
Admittedly, she does not at any point in her letter state explicitly her desire to return; but that is the unmistakable message conveyed by the general nuance of many of the passages, imbued as they are with a deep nostalgia for her days at Darlington Hall.

当然了，肯顿小姐是无法期望在这个时候旧地重返就能重拾那些已经失去的岁月的，我们见面时我的首要责任就要提醒她这一点。
Of course, Miss Kenton cannot hope by returning at this stage ever to retrieve those lost years, and it will be my first duty to impress this upon her when we meet.

我将不得不向她指出，现在的情况已经跟当初判若云泥—那种有一大帮仆从任凭差遣的日子恐怕在我们的有生之年都是一去不返了。
I will have to point out how different things are now – that the days of working with a grand staff at one's beck and call will probably never return within our lifetime.

不过再怎么说肯顿小姐也是一位聪颖的女性，不须我多嘴她应该也已经意识到了世事的变迁。
But then Miss Kenton is an intelligent woman and she will have already realized these things.

确实，头等重要的一点是，只要肯顿小姐愿意重返达林顿府并在那里一直工作到退休，我看这样的选择没有理由不会为她那已经充满了光阴虚掷、岁月蹉跎况味的人生带来一份真正的慰藉。
Indeed, all in all, I cannot see why the option of her returning to Darlington Hall and seeing out her working years there should not offer a very genuine consolation to a life that has come to be so dominated by a sense of waste.

当然了，从我本人的专业角度来看，尽管肯顿小姐不再工作已经有了这么多年的时间，她显然仍将被证实是解决达林顿府目前困扰我们的最大难题的最佳解决方案。
And of course, from my own professional viewpoint, it is clear that even after a break of so many years, Miss Kenton would prove the perfect solution to the problem at present besetting us at Darlington Hall.

事实上，将其称之为“难题”，我或许都已经言过其实了。
In fact, by terming it a ‘problem’, I perhaps overstate the matter.

我所指的毕竟只是由我自身所造成的一系列微不足道的小差池，而我现在所力求的也不过是一种防患于未然的预防措施。
I am referring, after all, to a series of very minor errors on my part and the course I am now pursuing is merely a means of pre-empting any ‘problems’ before one arises.

诚然，这些小小不言的疏失一开始也确实让我大伤脑筋，不过一旦我腾出手来对这些病患进行一番正确的诊断，发现它们不过就是由明显的人手短缺所引发的表面症状以后，我也就不再为此而忧心忡忡了。
It is true, these same trivial problems did cause me some anxiety at first, but once I had had time to diagnose them correctly as symptoms of nothing more than a straightforward staff shortage, I have refrained from giving them much thought.

正如我之前所言，肯顿小姐的到来就将彻底解决这些问题。
Miss Kenton's arrival, as I say, will put a permanent end to them.

不过还是回到她的信上。
But to return to her letter.

里面有时的确透露出她对当前现状的某种绝望的情绪—这一点还是挺让人揪心的。
It does at times reveal a certain despair over her present situation – a fact that is rather concerning.

她有一段话是这样开始的：“虽然我还不知道该如何有效地将我的余生填满……”在另一处，她又这样写道：“我的余生在我面前伸展为一片虚空。”
She begins one sentence: ‘Although I have no idea how I shall usefully fill the remainder of my life …’ And again, elsewhere, she writes: ‘The rest of my life stretches out as an emptiness before me.’

不过正如我已经说过的，信中大部分的语气都透露出一种怀旧的乡愁。
For the most part, though, as I have said, the tone is one of nostalgia.

有一处，比如说，她写道：
At one point, for instance, she writes:

“这整个插曲不禁让我想起了艾丽丝·怀特。
‘This whole incident put me in mind of Alice White.

你还记得她吗？
Do you remember her?

事实上，我很难想象你会忘记她。
In fact, I hardly imagine you could forget her.

就我而言，我仍旧时常想起她那些元音的发音方式以及只有她才能造得出来的、完全不合文法的独特的句子！
For myself, I am still haunted by those vowel sounds and those uniquely ungrammatical sentences only she could dream up!

你可知道她后来的下落如何？”
Have you any idea what became of her?’

事实上我并不知道她后来的归宿，不过我不得不说，一想到那个恼人的女仆，的确给我带来了不少的乐趣—她最后成了我们恪尽职守的员工之一。
I have not, as a matter of fact, though I must say it rather amused me to remember that exasperating housemaid – who in the end turned out to be one of the most devoted.

在她信里的另外一处，肯顿小姐写道：
At another point in her letter, Miss Kenton writes:

“当时我是多么喜欢从三楼的那几间卧室俯瞰大草坪以及远处那绿草如茵的开阔高地。
‘I was so fond of that view from the second-floor bedrooms overlooking the lawn with the downs visible in the distance.

那景色是否一如往昔，别来无恙？
Is it still like that?

夏日的傍晚，那景色中总带有某种神奇的魔力，现在我要向你坦白，想当初我不知浪费了多少宝贵的时间，就站在一扇窗前，直看得心醉神迷。”
On summer evenings there was a sort of magical quality to that view and I will confess to you now I used to waste many precious minutes standing at one of those windows just enchanted by it.’

然后她又继续写道：
Then she goes on to add:

“如果这回忆令人痛苦，敬请谅解。
‘If this is a painful memory, forgive me.

但我永远都不会忘记那一次我们俩一起望见令尊在凉亭前来回徘徊的情景，他低头看着地上，就仿佛一心想找回他失落在那里的某样珍宝。”
But I will never forget that time we both watched your father walking back and forth in front of the summerhouse, looking down at the ground as though he hoped to find some precious jewel he had dropped there.’

三十多年前的那个情景居然也如此鲜活地留在了肯顿小姐的记忆中，真让人又惊又喜。
It is something of a revelation that this memory from over thirty years ago should have remained with Miss Kenton as it had done with me.

的确，那肯定是发生在她上文提到某个夏日的傍晚，我还清楚地记得爬到三楼的平台，但见一道道橘红色的夕照穿过每一扇半掩的卧室房门刺破了走廊上的昏沉。
Indeed, it must have occurred on just one of those summer evenings she mentions, for I can recall distinctly climbing to the second landing and seeing before me a series of orange shafts from the sunset breaking the gloom of the corridor where each bedroom door stood ajar.

当我走过那一间间卧室时，透过其中的一扇门看到了肯顿小姐映在窗前的侧影，她转过身柔声叫道：“史蒂文斯先生，您有空吗？”
And as I made my way past those bedrooms, I had seen through a doorway Miss Kenton's figure, silhouetted against a window, turn and call softly: ‘Mr Stevens, if you have a moment.’

我走进去的时候，肯顿小姐已经又回头望着窗外了。
As I entered, Miss Kenton had turned back to the window.

下面，白杨的树影横陈在大草坪上。
Down below, the shadows of the poplars were falling across the lawn.

在我们视野的右侧是缓缓隆起的草坡，一直延伸到凉亭前，家父的身影就出现在那里，全神贯注地在那儿来回踱步—肯顿小姐形容得确实很形象，“就仿佛一心想找回他失落在那里的某样珍宝”。
To the right of our view, the lawn sloped up a gentle embankment to where the summerhouse stood, and it was there my father's figure could be seen, pacing slowly with an air of preoccupation – indeed, as Miss Kenton puts it so well, ‘as though he hoped to find some precious jewel he had dropped there’.

我对这一幕情景一直永志不忘是有非常充分的理由的，我希望能解释清楚。
There are some very pertinent reasons why this memory has remained with me, as I wish to explain.

此外，现在想来，考虑到初到达林顿府时她与家父之间关系的某些方面，那么这幕情景会给肯顿小姐留下同样深刻的印象，或许也就并不那么令人惊奇了。
Moreover, now that I come to think of it, it is perhaps not so surprising that it should also have made a deep impression on Miss Kenton given certain aspects of her relationship with my father during her early days at Darlington Hall.

肯顿小姐和家父差不多是同时来到达林顿府的—也就是说，在一九二二年的春天—因为当时我一下子失去了女管家和副管家两位得力干将。原因是我这两位干将决定结婚并且辞职不干了。
Miss Kenton and my father had arrived at the house at more or less the same time – that is to say, the spring of 1922 – as a consequence of my losing at one stroke the previous housekeeper and under-butler.

我一直都认为，这一类的男女关系对于整幢宅第里的秩序是一种严重的威胁。
This had occurred due to these latter two persons deciding to marry one another and leave the profession.

从那时算起，我又因为同样的原因失去了好几位雇员。
I have always found such liaisons a serious threat to the order in a house.

当然了，在女仆和男仆中间发生这样的事情是完全可以预期的，而一个优秀的管家在进行人员配置时是一直都应该将这一因素考虑在内的；但是这样的婚配如果发生在高级职位的雇员当中，则将会对工作造成极具破坏性的影响。
Since that time, I have lost numerous more employees in such circumstances. Of course, one has to expect such things to occur amongst maids and footmen, and a good butler should always take this into account in his planning; but such marrying amongst more senior employees can have an extremely disruptive effect on work.

当然，如果两位员工碰巧相爱并决定结婚，那要进行问责就未免失礼之至了；但我发现真正让人着恼的是对本职工作并无真正的奉献热忱，频频更换工作岗位主要就是为了寻求罗曼司的那些人—女管家们就尤其难逃其咎。
Of course, if two members of staff happen to fall in love and decide to marry, it would be churlish to be apportioning blame; but what I find a major irritation are those persons – and housekeepers are particularly guilty here – who have no genuine commitment to their profession and who are essentially going from post to post looking for romance. This sort of person is a blight on good professionalism.

不过得容我立刻补充一句，我说这话时脑子想的可绝非肯顿小姐。
But let me say immediately I do not have Miss Kenton in mind at all when I say this.

她当然最后也离了职并且结了婚，但我可以担保，她在我手下担任女管家期间绝对恪尽职守，从不允许任何外务干扰到她的职业操守。
Of course, she too eventually left my staff to get married, but I can vouch that during the time she worked as a housekeeper under me, she was nothing less than dedicated and never allowed her professional priorities to be distracted.

不过我扯得太远了。
But I am digressing.

我方才讲到我们同时需要招聘一位女管家和一位副管家，而肯顿小姐正是在这时来到达林顿府接任了女管家一职—我记得她带来的推荐信对她的评价非常之高。
I was explaining that we had fallen in need of a housekeeper and an under-butler at one and the same time and Miss Kenton had arrived – with unusually good references, I recall – to take up the former post.

事有凑巧，家父也正好在这个时候因为雇主约翰·西尔弗斯先生的去世，行将结束他在拉夫伯勒府杰出的服务工作，等于是既失去了工作，又没有了栖身之地。
As it happened, my father had around this time come to the end of his distinguished service at Loughborough House with the death of his employer, Mr John Silvers, and had been at something of a loss for work and accommodation.

他当然仍旧是第一流的专业管家，但当时已经是七十几岁的高龄，并且饱受关节炎和其他病痛之苦。
Although he was still, of course, a professional of the highest class, he was now in his seventies and much ravaged by arthritis and other ailments.

如此一来，若是要他跟那些高度职业化的年轻一辈管家竞争同一职位恐怕也难操胜算。
It was not at all certain, then, how he would fare against the younger breed of highly professionalized butlers looking for posts.

有鉴于此，延请家父以其丰富的经验和卓著的声誉来达林顿府继续服务，将不失为一个合情合理的解决办法。
In view of this, it seemed a reasonable solution to ask my father to bring his great experience and distinction to Darlington Hall.

我记得那是家父和肯顿小姐加入我们的工作团队不久以后的一个早上，我正在餐具室里坐在桌前审阅文书账目，听到有一记敲门声。
As I remember it was one morning a little while after my father and Miss Kenton had joined the staff, I had been in my pantry, sitting at the table going through my paperwork, when I heard a knock on my door.

我还没说“请进”，肯顿小姐就推门走了进来，我记得当时我还有些错愕。
I recall I was a little taken aback when Miss Kenton opened the door and entered before I had bidden her to do so.

她捧着一大瓶鲜花，笑吟吟地道：
She came in holding a large vase of flowers and said with a smile:

“史蒂文斯先生，我想这些花能让您的餐具室显得明亮一点。”
‘Mr Stevens, I thought these would brighten your parlour a little.’

“您说什么，肯顿小姐？”
‘I beg your pardon, Miss Kenton?’

“您的房间竟然如此阴暗冰冷，这实在太可惜了，史蒂文斯先生，您看外面是多么阳光明媚。
‘It seemed such a pity your room should be so dark and cold, Mr Stevens, when it's such bright sunshine outside.

我想这些花能给这里带来一点生气。”
I thought these would enliven things a little.’

“非常感谢您的好意，肯顿小姐。”
‘That's very kind of you, Miss Kenton.’

“不能让更多的阳光照进来真是太罪过了。
‘It's a shame more sun doesn't get in here.

墙面甚至都有点潮湿呢，您说是不是，史蒂文斯先生？”
The walls are even a little damp, are they not, Mr Stevens?’

我重新回到自己的账目上，说：“不过是水汽凝结罢了，我想，肯顿小姐。”
I turned back to my accounts, saying: ‘Merely condensation, I believe, Miss Kenton.’

她把花瓶放到我面前的桌子上，然后又环顾了一下我的餐具室，说道：“如果您愿意的话，史蒂文斯先生，我以后可以给您多剪一些花送来。”
She put her vase down on the table in front of me, then glancing around my pantry again said: ‘If you wish, Mr Stevens, I might bring in some more cuttings for you.’

“肯顿小姐，我很感激您的好意。
‘Miss Kenton, I appreciate your kindness.

但这不是一间娱乐室。
But this is not a room of entertainment.

我倒宁肯将分心的因素保持在最低限度。”
I am happy to have distractions kept to a minimum.’

“可也没有必要把您的房间弄得这么光秃秃的，而且全然没有色彩啊，史蒂文斯先生。”
‘But surely, Mr Stevens, there is no need to keep your room so stark and bereft of colour.’

“它现在这个样子就完全符合我的需要，肯顿小姐，不过还是非常感激您的好心。
‘It has served me perfectly well this far as it is, Miss Kenton, though I appreciate your thoughts.

事实上，既然您正好在这儿，我倒确实有个具体的问题想跟您提一下。”
In fact, since you are here, there was a certain matter I wished to raise with you.’

“哦，真的吗，史蒂文斯先生？”
‘Oh, really, Mr Stevens.’

“是的，肯顿小姐，只不过小事一桩。
‘Yes, Miss Kenton, just a small matter.

昨天我碰巧经过厨房，听到您在呼唤某个名叫威廉的人。”
I happened to be walking past the kitchen yesterday when I heard you calling to someone named William.’

“是吗，史蒂文斯先生？”
‘Is that so, Mr Stevens?’

“确实，肯顿小姐。
‘Indeed, Miss Kenton.

我听到您喊了好几遍‘威廉’这个名字。
I did hear you call several times for “William”.

我能问一下您那是在跟谁说话吗？”
May I ask who it was you were addressing by that name?’

“哎呀，史蒂文斯先生，我想我当时应该是在跟令尊说话。
‘Why, Mr Stevens, I should think I was addressing your father.

这幢房子里再也没有第二个人叫威廉了，据我所知。”
There are no other Williams in this house, I take it.’

“这是个很容易犯的小错误，”我面带浅笑道。
‘It's an easy enough error to have made,’ I said with a small smile.

“肯顿小姐，我能否请您以后称呼家父为‘史蒂文斯先生’呢？
‘May I ask you in future, Miss Kenton, to address my father as “Mr Stevens”?

如果您是在向第三者提到他，那么您也许可以称他为‘老史蒂文斯先生’，以便于将家父跟在下区分开来。
If you are referring to him to a third party, then you may wish to call him “Mr Stevens senior” to distinguish him from myself.

为此我将感激不尽，肯顿小姐。”
I'm most grateful, Miss Kenton.’

话说完之后我就又回到我的文书工作上来。
With that I turned back to my papers.

可是让我感到惊讶的是，肯顿小姐并没有就此告退。
But to my surprise, Miss Kenton did not take her leave.

“请原谅我打搅您了，史蒂文斯先生，”过了一会儿她说道。
‘Excuse me, Mr Stevens,’ she said after a moment.

“喔，肯顿小姐。”
‘Yes, Miss Kenton.’

“恐怕我不太明白您到底什么意思。
‘I am afraid I am not quite clear what you are saying.

我过去一直都习惯于直呼下属的教名，我并没有看出到了这里就有需要改弦更张的理由。”
I have in the past been accustomed to addressing under-servants by their Christian names and saw no reason to do otherwise in this house.’

“一个最可以理解的小差错，肯顿小姐。
‘A most understandable error, Miss Kenton.

不过，如果您愿意稍稍考虑一下具体的情况，您可能就会看得出来，像您这样的人以对待‘下属’的方式跟家父这样的人说话，是不太妥当的。”
However, if you will consider the situation for a moment, you may come to see the inappropriateness of someone such as yourself talking “down” to one such as my father.’

“我还是不太明白您的意思，史蒂文斯先生。
‘I am still not clear what you are getting at, Mr Stevens.

您说像我这样的人，可是照我的理解，我是这里的女管家，而令尊则是副管家。”
You say someone such as myself, but I am as far as I understand the housekeeper of this house, while your father is the under-butler.’

“他的职位当然是副管家，如您所言。
‘He is of course in title the under-butler, as you say.

可是令我感到意外的是，以您的观察能力，您居然没有发现他实际上不止是个男管家。
But I am surprised your powers of observation have not already made it clear to you that he is in reality more than that.

远远不止。”
A great deal more.’

“我的观察能力无疑已经差到了极点，史蒂文斯先生。
‘No doubt I have been extremely unobservant, Mr Stevens.

我只观察到令尊是位很有能力的副管家，并以其相应的职位来称呼他。
I had only observed that your father was an able under-butler and addressed him accordingly.

而照您的说法，令尊居然被像我这样的人直呼其名，他一定会感觉屈辱已极的。”
It must indeed have been most galling for him to be so addressed by one such as I.’

“肯顿小姐，听您的口气，您显然是根本就没有观察过家父。
‘Miss Kenton, it is clear from your tone you simply have not observed my father.

否则您就会明白，以您这样的年龄和资历是不该直呼他‘威廉’的，这本该是显而易见的。”
If you had done so, the inappropriateness of someone of your age and standing addressing him as “William” should have been self-evident to you.’

“史蒂文斯先生，我担任女管家的时间或许不长，不过应该说至少在我担任这个职务期间，我的能力还是得到过不少相当慷慨的评价的。”
‘Mr Stevens, I may not have been a housekeeper for long, but I would say that in the time I have been, my abilities have attracted some very generous remarks.’

“我一刻都没有怀疑过您的能力，肯顿小姐。
‘I do not doubt your competence for one moment, Miss Kenton.

但是只要您愿意多加观察的话，有成百上千的事例会使您意识到家父是位多么非同寻常、鹤立鸡群的人物，您必定可以从他身上获益良多的。”
But a hundred things should have indicated to you that my father is a figure of unusual distinction from whom you may learn a wealth of things were you prepared to be more observant.’

“那我真是太感激您的忠告了，史蒂文斯先生。
‘I am most indebted to you for your advice, Mr Stevens.

那就再请您不吝赐教，我到底能从观察令尊这上面学到哪些了不起的本领呢？”
So do please tell me, just what marvellous things might I learn from observing your father?’

“我还以为这对任何一个长眼睛的人来说都是不言而喻的呢，肯顿小姐。”
‘I would have thought it obvious to anyone with eyes, Miss Kenton.’

“但我们已经达成了共识，我在这方面的能力特别欠缺，不是吗？”
‘But we have already established, have we not, that I am particularly deficient in that respect.’

“肯顿小姐，如果您觉得以您现在的年纪来说您已经尽善尽美了的话，您将永远都无法提升到以您的能力无疑可以达到的高度。
‘Miss Kenton, if you are under the impression you have already at your age perfected yourself, you will never rise to the heights you are no doubt capable of.

如果容我直言不讳的话，比如说，到现在您仍然经常不太确定哪样东西究竟放到了哪里以及哪样东西到底是哪样。”
I might point out, for instance, you are still often unsure of what goes where and which item is which.’

这一下似乎挫了肯顿小姐的锐气，让她有些下不来台。
This seemed to take the wind out of Miss Kenton's sails somewhat.

她一度甚至看起来有点心烦意乱。
Indeed, for a moment, she looked a little upset.

然后她说：
Then she said:

“我初来乍到，是有一点手足无措，可这也是完全正常的吧。”
‘I had a little difficulty on first arriving, but that is surely only normal.’

“啊，您这话算是说到了点子上，肯顿小姐。
‘Ah, there you are, Miss Kenton.

您要是观察过家父的话，就会看出他对府里的大事小情真是了如指掌，而且几乎从他踏入达林顿府的那一刻起就是这样的，而他还比您晚到了一个礼拜。”
If you had observed my father who arrived in this house a week after you did, you will have seen that his house knowledge is perfect and was so almost from the time he set foot in Darlington Hall.’

肯顿小姐似乎思考了一下我这番话，然后才有点愠怒地道：
Miss Kenton seemed to think about this before saying a little sulkily:

“我敢肯定老史蒂文斯先生对他的工作是非常擅长的，不过我向您保证，史蒂文斯先生，我也同样能把自己的工作做得很好。
‘I am sure Mr Stevens senior is very good at his job, but I assure you, Mr Stevens, I am very good at mine.

我会记住以后用他的全称来称呼令尊的。
I will remember to address your father by his full title in future.

现在，如果您没有别的事了，就请容许我告退了。”
Now, if you would please excuse me.’

在这次遭遇之后，肯顿小姐就不再试图把花往我的餐具室里送了，而且总的说来，我很高兴地观察到她的工作很快就步入了正轨。
After this encounter, Miss Kenton did not attempt to introduce further flowers into my pantry, and in general, I was pleased to observe, she went about settling in impressively.

不仅如此，她显然是位对待工作非常严肃认真的女管家，而且年纪虽轻，却似乎毫不费力地就赢得了她属下各位员工的尊敬。
It was clear, furthermore, she was a housekeeper who took her work very seriously and in spite of her youth, she seemed to have no difficulty gaining the respect of her staff.

我还注意到，此后她的确开始以“史蒂文斯先生”来称呼家父。
I noticed too that she was indeed proceeding to address my father as ‘Mr Stevens’.

不过，我们在餐具室里的那段谈话过去两周以后的一个下午，我正在藏书室里做着点什么，这时肯顿小姐走进来对我说：
However, one afternoon perhaps two weeks after our conversation in my pantry, I was doing something in the library when Miss Kenton came in and said:

“打搅您了，史蒂文斯先生。
‘Excuse me, Mr Stevens.

不过如果您在寻找您的簸箕的话，我看到它就在外面的门厅里呢。”
But if you are searching for your dust-pan, it is out in the hall.’

“您说什么，肯顿小姐？”
‘I beg your pardon, Miss Kenton?’

“您的簸箕，史蒂文斯先生。
‘Your dust-pan, Mr Stevens.

您把它放在外面了。
You've left it out here.

要我替您把它拿进来吗？”
Shall I bring it in for you?’

“肯顿小姐，我刚才并没有用过簸箕。”
‘Miss Kenton, I have not been using a dust-pan.’

“啊，呃，那就请您原谅吧，史蒂文斯先生。
‘Ah, well, then forgive me, Mr Stevens.

我想当然地以为刚才是您使用过簸箕，并且把它放在了门厅里。
I naturally assumed you were using your dust-pan and had left it out in the hall.

很抱歉平白打搅了您。”
I am sorry to have disturbed you.’

她已经准备离开了，又在门口转过身来说：
She started to leave, but then turned at the doorway and said:

“哦，史蒂文斯先生。
‘Oh, Mr Stevens.

我本想自己把它放归原位的，可是现在必须先上楼一趟。
I would return it myself but I have to go upstairs just now.

不知道能否请您记得把它还回去呢？”
I wonder if you will remember it?’

“当然了，肯顿小姐。
‘Of course, Miss Kenton.

多谢您留心和提醒。”
Thank you for drawing attention to it.’

“这是我应该做的，史蒂文斯先生。”
‘It is quite all right, Mr Stevens.’

我听着她的脚步声穿过门厅，开始上了主楼梯，然后我才朝门口走去。
I listened to her footsteps cross the hall and start up the great staircase, then proceeded to the doorway myself.

透过藏书室的两扇大门，可以一览无遗地将门厅和宅第的大门尽收眼底。
From the library doors, one has an unbroken view right across the entrance hall to the main doors of the house.

肯顿小姐提到的那个簸箕就最为惹人注目地矗立在那空荡荡的、擦洗得光洁如镜的地板中央。
Most conspicuously, in virtually the central spot of the otherwise empty and highly polished floor, lay the dust-pan Miss Kenton had alluded to.

那是个虽说微不足道，但却令人恼火的疏失；那个簸箕不但从底层开向门厅的那五道房门那儿看去极为惹人注目，而且从楼梯和二楼的那几个露台上也可以看得一清二楚。
It struck me as a trivial, but irritating error; the dust-pan would have been conspicuous not only from the five ground-floor doorways opening on to the hall, but also from the staircase and the first-floor balconies.

我穿过门厅，把那个碍眼的物事拿起来，而直到这时我才意识到这次疏失的全部内涵：我突然想起，约莫半个钟头前，正是家父在擦洗门厅的地板来着。
I crossed the hall and had actually picked up the offending item before realizing its full implication; my father, I recalled, had been brushing the entrance hall a half-hour or so earlier.

起先，我简直都不敢相信家父会犯下这样的错误，不过我马上就提醒自己，这种小小不言的疏忽是每个人都难免偶尔会出现的，于是我的恼怒马上就转到了肯顿小姐头上，怪她居然如此毫无道理地小题大做。
At first, I found it hard to credit such an error to my father. But I soon reminded myself that such trivial slips are liable to befall anyone from time to time, and my irritation soon turned to Miss Kenton for attempting to create such unwarranted fuss over the incident.

然后，最多又过了一个礼拜，我正从厨房来到后廊上的时候，肯顿小姐从她的起坐间里出来，跟我说了一通显然是经过了一番排练的话；大意是尽管她因为让我注意到我的下属所犯的错误而深感不安，不过她和我本来就是一个团队，不得不通力合作，所以她希望我如果注意到女员工出了什么差错，请我务必也像她那样直言相告。
Then, not more than a week later, I was coming down the back corridor from the kitchen when Miss Kenton came out of her parlour and uttered a statement she had clearly been rehearsing; this was something to the effect that although she felt most uncomfortable drawing my attention to errors made by my staff, she and I had to work as a team, and she hoped I would not feel inhibited to do similarly should I notice errors made by female staff.

说完这番话后，她接着又指出，餐厅里有几件已经摆上餐桌的银餐具上有明显的擦拭剂的残留。
She then went on to point out that several pieces of silver had been laid out for the dining room which bore clear remains of polish.

有一把餐叉的齿尖简直就是黑色的。
The end of one fork had been practically black.

我谢了她，她就又退回到了自己的起坐间。
I thanked her and she withdrew back into her parlour.

当然，她根本就没有必要特地来提醒我，银器正是家父的主要职责所在，而且是他深感自豪的一项工作。
It had been unnecessary, of course, for her to mention that the silver was one of my father's main responsibilities and one he took great pride in.

很有可能还有不少其他这类的事例，我现在已经不记得了。
It is very possible there were a number of other instances of this sort which I have now forgotten.

反正在我记忆中，事态在某种程度上达到了高潮是在一个细雨蒙蒙的阴沉的午后，当时我正在弹子房里护理达林顿勋爵的各种运动奖牌和奖杯。
In any case, I recall things reaching something of a climax one grey and drizzly afternoon when I was in the billiard room attending to Lord Darlington's sporting trophies.

肯顿小姐走了进来，站在门口说：
Miss Kenton had entered and said from the door:

“史蒂文斯先生，我刚注意到这门外有样东西令我百思不得其解。”
‘Mr Stevens, I have just noticed something outside which puzzles me.’

“那是什么呢，肯顿小姐？”
‘What is that, Miss Kenton?’

“是爵爷的意思，要把楼梯平台上的那尊中国佬跟弹子房门外的这尊调换位置吗？”
‘Was it his lordship's wish that the Chinaman on the upstairs landing should be exchanged with the one outside this door?’

“中国佬，肯顿小姐？”
‘The Chinaman, Miss Kenton?’

“是的，史蒂文斯先生。
‘Yes, Mr Stevens.

原本一直摆在楼梯平台上的那尊中国佬的塑像，现在就在这扇门外面。”
The Chinaman normally on the landing you will now find outside this door.’

“我恐怕，肯顿小姐，是您有点搞错了吧？”
‘I fear, Miss Kenton, that you are a little confused.’

“我不认为是我搞错了，史蒂文斯先生。
‘I do not believe I am confused at all, Mr Stevens.

我特别要求自己要熟悉府内所有物品的摆放位置。
I make it my business to acquaint myself with where objects properly belong in a house.

那尊中国佬，我猜想，是被某个人擦拭过以后摆错位置了。
The Chinamen, I would suppose, were polished by someone then replaced incorrectly.

如果您不相信的话，史蒂文斯先生，也许您可以移步出来自己看一下。”
If you are sceptical, Mr Stevens, perhaps you will care to step out here and observe for yourself.’

“肯顿小姐，我现在手头还有事。”
‘Miss Kenton, I am occupied at present.’

“可是，史蒂文斯先生，您似乎并不相信我的话。
‘But, Mr Stevens, you do not appear to believe what I am saying.

既然如此，我想还是请您移步出来亲自看一下。”
I am thus asking you to step outside this door and see for yourself.’

“肯顿小姐，我现在正忙着，过会儿我再处理这件事吧。
‘Miss Kenton, I am busy just now and will attend to the matter shortly.

说起来这也算不上什么急务。”
It is hardly one of urgency.’

“如此说来，史蒂文斯先生，您是认可我在这件事上并没有弄错喽。”
‘You accept then, Mr Stevens, that I am not in error on this point.’

“肯顿小姐，在我腾出手来处理这件事之前，我是不会贸然认可任何结论的。
‘I will accept nothing of the sort, Miss Kenton, until I have had the chance to deal with the matter.

可是我现在手头上还有事。”
However, I am occupied at present.’

我转身继续做我的事，可是肯顿小姐仍旧站在门口观察我。
I turned back to my business, but Miss Kenton remained in the doorway observing me.

最后她又道：
Eventually, she said:

“看得出来您手头的事很快就会做完了，史蒂文斯先生。
‘I can see you will be finished very shortly, Mr Stevens.

我就在门外等您，等您一出来，这件事就可以最后定案了。”
I will await you outside so that this matter may be finalized when you come out.’

“肯顿小姐，我想您是有些小题大做了。”
‘Miss Kenton, I believe you are according this matter an urgency it hardly merits.’

可是肯顿小姐已经离开了门口，而且果不其然，我在继续自己工作的时候，偶尔的脚步声以及其他的声响都会提醒我，她仍旧在门外等着。
But Miss Kenton had departed, and sure enough, as I continued with my work, an occasional footstep or some other sound would serve to remind me she was still there outside the door.

于是我就决定在弹子房里再多找些工作来做，寄希望于过一会儿以后她能意识到自己的位置是多么荒谬可笑，就此识时务地走开。
I decided therefore to occupy myself with some further tasks in the billiard room, assuming she would after a while see the ludicrousness of her position and leave.

然而，又过了一段时间以后，我已经把利用手边的工具能做的工作全都干完了，肯顿小姐却显然仍旧待在外面。
However, after some time had passed, and I had exhausted the tasks which could usefully be achieved with the implements I happened to have at hand, Miss Kenton was evidently still outside.

我决定不再在这种幼稚的事情上浪费时间，于是考虑通过法式落地窗脱身。
Resolved not to waste further time on account of this childish affair, I contemplated departure via the french windows.

然而天公不作美—说白了，放眼一望，外面就有好几个大水坑和一块块烂泥地—再者说，还得有人再重新回到弹子房，从里面把落地窗闩好。
A drawback to this plan was the weather – that is to say, several large puddles and patches of mud were in evidence – and the fact that one would need to return to the billiard room again at some point to bolt the french windows from the inside.

最后，我认定最好的办法就是出其不意地冲出门去，怒气冲冲地大踏步离开。
Eventually, then, I decided the best strategy would be simply to stride out of the room very suddenly at a furious pace.

我于是尽可能悄无声息地先来到一个最佳的位置，从那儿可以发动这样的一次急行军，我紧握自己的清洁工具，一鼓作气地冲出门去，还没等大吃一惊的肯顿小姐醒过神来，我已经沿着走廊迈出去好几步了。
I thus made my way as quietly as possible to a position from which I could execute such a march, and clutching my implements firmly about me, succeeded in propelling myself through the doorway and several paces down the corridor before a somewhat astonished Miss Kenton could recover her wits.

可是她很快就回过味儿来，眨眼工夫已经抢到我的前头，挡住了我的去路。
This she did, however, rather rapidly and the next moment I found she had overtaken me and was standing before me, effectively barring my way.

“史蒂文斯先生，这尊中国佬摆错了地方，您不会不同意吧？”
‘Mr Stevens, this is the incorrect Chinaman, would you not agree?’

“肯顿小姐，我忙得很。
‘Miss Kenton, I am very busy.

我很奇怪您除了一整天都在走廊里站着，居然就没有更好的事情可做了。”
I am surprised you have nothing better to do than stand in corridors all day.’

“史蒂文斯先生，这尊中国佬摆放的位置到底是对还是不对？”
‘Mr Stevens, is that the correct Chinaman or is it not?’

“肯顿小姐，我想请您把嗓门压低一点。”
‘Miss Kenton, I would ask you to keep your voice down.’

“我只是想请您，史蒂文斯先生，转过身去看一看那尊中国佬。”
‘And I would ask you, Mr Stevens, to turn around and look at that Chinaman.’

“肯顿小姐，请您把嗓门压低点。
‘Miss Kenton, please keep your voice down.

如果下属们听到我们扯着嗓门争论中国佬是否摆错了地方，那成何体统？”
What would employees below think to hear us shouting at the top of our voices about what is and what is not the correct Chinaman?’

“事实是，史蒂文斯先生，府里所有的中国佬塑像都已经脏了有一段时间啦！
‘The fact is, Mr Stevens, all the Chinamen in this house have been dirty for some time!

而现在，居然又摆错了地方！”
And now, they are in incorrect positions!’

“肯顿小姐，您实在是莫名其妙。
‘Miss Kenton, you are being quite ridiculous.

现在能否请您行个好放我过去？”
Now if you will be so good as to let me pass.’

“史蒂文斯先生，劳您驾看看您身后的那尊中国佬好吗？”
‘Mr Stevens, will you kindly look at the Chinaman behind you?’

“如果这对您来说如此重要，肯顿小姐，我可以认可，我后面的那尊中国佬或许是摆错了地方。
‘If it is so important to you, Miss Kenton, I will allow that the Chinaman behind me may well be incorrectly situated.

可我必须要说，我实在有些搞不明白，您为什么会对这些最微不足道的疏失如此地关切备至。”
But I must say I am at some loss as to why you should be so concerned with these most trivial of errors.’

“这些疏失本身或许微不足道，史蒂文斯先生，但您自己却要认识到那其中隐含的更重大的意义。”
‘These errors may be trivial in themselves, Mr Stevens, but you must yourself realize their larger significance.’

“肯顿小姐，我不明白您的意思。
‘Miss Kenton, I do not understand you.

现在能否请您好心让我过去。”
Now if you would kindly allow me to pass.’

“那事实就是，史蒂文斯先生，您交托给令尊的工作已经远非他这个年纪的人所能承担得了啦。”
‘The fact is, Mr Stevens, your father is entrusted with far more than a man of his age can cope with.’

“肯顿小姐，您显然并不清楚您暗示的是什么。”
‘Miss Kenton, you clearly have little idea of what you are suggesting.’

“不管令尊曾有过怎样的辉煌，史蒂文斯先生，他现在的能力都已经严重衰退了。
‘Whatever your father was once, Mr Stevens, his powers are now greatly diminished.

这就是您所谓的这些‘微不足道的疏失’所暗含的真正意义，而如果您对此掉以轻心，那么要不了多久，令尊就将铸成大错。”
This is what these “trivial errors” as you call them really signify and if you do not heed them, it will not be long before your father commits an error of major proportions.’

“肯顿小姐，您这只不过是在给自己出洋相。”
‘Miss Kenton, you are merely making yourself look foolish.’

“我很抱歉，史蒂文斯先生，可我必须把话说完。
‘I am sorry, Mr Stevens, but I must go on.

我认为令尊身上的很多职责都该被卸下来了。
I believe there are many duties your father should now be relieved of.

比如说，不应该让他再继续端那些沉重的托盘了。
He should not, for one, be asked to go on carrying heavily laden trays.

他端着它们走进餐厅的时候，他那两只手抖得实在令人心惊。
The way his hands tremble as he carries them into dinner is nothing short of alarming.

他迟早肯定会失手将托盘砸到某位夫人或是士绅的大腿上，就只是个时间问题罢了。
It is surely only a matter of time before a tray falls from his hands on to a lady or gentleman's lap.

不仅如此，史蒂文斯先生，这话我说出来很是冒昧，但我已经注意到了令尊的鼻子。”
And furthermore, Mr Stevens, and I am very sorry to say this, I have noticed your father's nose.’

“真的吗，肯顿小姐？”
‘Have you indeed, Miss Kenton?’

“很遗憾是真的，史蒂文斯先生。
‘I regret to say I have, Mr Stevens.

前天傍晚，我眼看着令尊端着托盘脚步非常迟缓地朝餐厅走去，恐怕我很清楚地看到他的鼻尖上拖着长长的一条鼻涕，就在那些汤碗上面摇摇欲坠。
The evening before last I watched your father proceeding very slowly towards the dining room with his tray, and I am afraid I observed clearly a large drop on the end of his nose dangling over the soup bowls.

我恐怕这样的上菜方式是很难令人食欲大开的。”
I would not have thought such a style of waiting a great stimulant to appetite.’

不过这会子经过细想以后，我倒不能肯定肯顿小姐那天当真把话说得如此毫无顾忌了。
But now that I think further about it, I am not sure Miss Kenton spoke quite so boldly that day.

在我们多年密切共事的过程中，我们诚然越来越坦诚地交换意见，可是眼下我正在回忆的那个午后尚属我们订交的初始阶段，我觉得即便是肯顿小姐也不会如此直言不讳的。
We did, of course, over the years of working closely together come to have some very frank exchanges, but the afternoon I am recalling was still early in our relationship and I cannot see even Miss Kenton having been so forward.

我不敢肯定她当真会冒昧到说出像是“这些疏失本身或许微不足道，可你自己却要认识到那其中隐含的更重大的意义”这样的话来。
I am not sure she could actually have gone so far as to say things like: ‘these errors may be trivial in themselves, but you must yourself realize their larger significance’.

事实上，经过一番仔细的回想以后，我感觉应该是达林顿勋爵亲自跟我说这番话的，那是我跟肯顿小姐在弹子房门外那番交锋过后的大约两个月后，爵爷将我叫进了他的书房。
In fact, now that I come to think of it, I have a feeling it may have been Lord Darlington himself who made that particular remark to me that time he called me into his study some two months after that exchange with Miss Kenton outside the billiard room.

那时，家父的境况在他摔倒以后已经有了重大的变化。
By that time, the situation as regards my father had changed significantly following his fall.

书房的两扇大门正对着从主楼梯上下来的每个人。
The study doors are those that face one as one comes down the great staircase.

现在的书房门外放了一个陈设法拉戴先生各种小摆设的玻璃柜子，不过在达林顿勋爵的时代，那个位置一直都立着一个书架，专用来摆放卷帙浩繁的百科全书，包括一整套的《不列颠百科全书》。
There is outside the study today a glass cabinet displaying various of Mr Farraday's ornaments, but throughout Lord Darlington's days, there stood at that spot a bookshelf containing many volumes of encyclopedia, including a complete set of the Britannica.

达林顿勋爵一个惯用的策略就是在我从楼梯上下来的时候装作在这个书架前检索百科全书各卷的书脊，有时候为了增加偶遇的效果，他还会真的从书架上抽出某一卷来，在我走完最后几级楼梯的时候佯装专心致志埋头阅读的样子。
It was a ploy of Lord Darlington's to stand at this shelf studying the spines of the encyclopedias as I came down the staircase, and sometimes, to increase the effect of an accidental meeting, he would actually pull out a volume and pretend to be engrossed as I completed my descent.

然后，在我从他身边走过以后，他才会说：“哦，史蒂文斯，有件事我想跟你说一下。”
Then, as I passed him, he would say: ‘Oh, Stevens, there was something I meant to say to you.’

说完后，他就会漫步走回书房，表面上仍旧埋头于他拿在手里的那卷大书当中。
And with that, he would wander back into his study, to all appearances still thoroughly engrossed in the volume held open in his hands.

达林顿勋爵在采取这种方式的时候，总是因为他要谈的事情让他感到有些为难，甚至在书房的门已经在他身后关好以后，他仍旧经常会站在窗户跟前，在整个谈话过程中一直做出查阅百科全书的样子。
It was invariably embarrassment at what he was about to impart which made Lord Darlington adopt such an approach, and even once the study door was closed behind us, he would often stand by the window and make a show of consulting the encyclopedia throughout our conversation.

我在这里顺带描述的这一事件，不过是众多事例当中的一桩，而这些事例无不鲜明地表现出达林顿勋爵那羞涩而又谦逊的天性。
What I am now describing, incidentally, is one of many instances I could relate to you to underline Lord Darlington's essentially shy and modest nature.

近些年来，有关爵爷本人以及他在诸多重大事件当中所扮演的重要角色，坊间出现了大量不实之词，有些口耳相传，有些则付诸笔墨；更有甚者，有些极端无知的报道居然指鹿为马，断言爵爷的行为是由自我中心，要不然就是傲慢自负所驱使的。
A great deal of nonsense has been spoken and written in recent years concerning his lordship and the prominent role he came to play in great affairs, and some utterly ignorant reports have had it that he was motivated by egotism or else arrogance.

请容我在此说上一句，再也没有比这种论调更加悖乎常理、罔顾事实的了。
Let me say here that nothing could be further from the truth.

爵爷后来所坚守的那些公开立场是与他的本能和天性完全背道而驰的，而我敢断言，爵爷之所以能够勉为其难地克服他那远为恬淡退隐的一面，纯粹是出于深厚的道德责任感。
It was completely contrary to Lord Darlington's natural tendencies to take such public stances as he came to do and I can say with conviction that his lordship was persuaded to overcome his more retiring side only through a deep sense of moral duty.

无论近年来对达林顿勋爵的功过如何评说—如我之前所言，这其中的大部分纯粹是无稽之谈—我都该为爵爷说句公道话：他本质上是个真正的好人，一个彻头彻尾的绅士，时至今日，我都为自己能将最好的年华奉献给为这样一个人服务上而深感自豪。
Whatever may be said about his lordship these days – and the great majority of it is, as I say, utter nonsense – I can declare that he was a truly good man at heart, a gentleman through and through, and one I am today proud to have given my best years of service to.

在我说起的那个特别的午后，爵爷的年纪应该还在五十四五岁上；不过据我的回忆，他的头发已经完全灰白，他那瘦高的身形已经出现了在他的晚年变得异常显著的驼背的迹象。
On the particular afternoon to which I am referring, his lordship would still have been in his mid-fifties; but as I recall, his hair had greyed entirely and his tall slender figure already bore signs of the stoop that was to become so pronounced in his last years.

他几乎是在说话时，眼睛才会从那卷百科全书上抬一抬：
He barely glanced up from his volume as he asked:

“令尊身体感觉好些了吧，史蒂文斯？”
‘Your father feeling better now, Stevens?’

“我可以很高兴地说，他已经完全康复了，先生。”
‘I'm glad to say he has made a full recovery, sir.’

“听到这个消息真让人高兴。
‘Jolly pleased to hear that.

非常高兴。”
Jolly pleased.’

“谢谢您，先生。”
‘Thank you, sir.’

“听我说，史蒂文斯，令尊那边有任何—呃—迹象没有？
‘Look here, Stevens, have there been any – well – signs at all?

我的意思是，有没有任何迹象显示令尊也许希望他的工作负担稍许减轻一些？
I means signs to tell us your father may be wishing his burden lightened somewhat?

撇开这次摔倒的事故不谈，我的意思是。”
Apart from this business of him falling, I mean.’

“正如我所说的，先生，家父看来已经完全康复了，我相信他仍旧是个堪当重任之人。
‘As I say, sir, my father appears to have made a full recovery and I believe he is still a person of considerable dependability.

诚然，他最近在履行职责时确实出过一两个明显的差错，但在性质上无论如何都是微不足道的。”
It is true one or two errors have been noticeable recently in the discharging of his duties, but these are in every case very trivial in nature.’

“不过，我们谁都不希望任何类似的事情再度发生，是不是？
‘But none of us wish to see anything of that sort happen ever again, do we?

我的意思是，令尊不小心跌倒这类的意外。”
I mean, your father collapsing and all that.’

“那是自然，先生。”
‘Indeed not, sir.’

“而且当然啦，这种意外既然会发生在草坪上，那也就可能发生在任何地方。
‘And of course, if it can happen out on the lawn, it could happen anywhere.

而且在任何时候。”
And at any time.’

“是的，先生。”
‘Yes, sir.’

“有可能发生在，比如说，令尊正在侍餐的晚宴当中。”
‘It could happen, say, during dinner while your father was waiting at table.’

“是有可能，先生。”
‘It is possible, sir.’

“你听我说，史蒂文斯，不出半个月，那些代表当中的第一批就会来到这里了。”
‘Look here, Stevens, the first of the delegates will be arriving here in less than a fortnight.’

“我们都已做好了充分的准备，先生。”
‘We are well prepared, sir.’

“在那之后，这幢房子里发生的所有事情都可能产生非同小可的结果。”
‘What happens within this house after that may have considerable repercussions.’

“是的，先生。”
‘Yes, sir.’

“我的意思是说非同小可的结果。
‘I mean considerable repercussions.

对于欧洲的发展全局而言都是如此。
On the whole course Europe is taking.

只要看看将要出席的人员名单，我认为这么说一点都不算夸张。”
In view of the persons who will be present, I do not think I exaggerate.’

“是的，先生。”
‘No, sir.’

“这种时候可容不得有半点差池。”
‘Hardly the time for taking on avoidable hazards.’

“的确如此，先生。”
‘Indeed not, sir.’

“你听我说，史蒂文斯，我的意思绝非是要令尊离开这个岗位。
‘Look here, Stevens, there's no question of your father leaving us.

我只是请你重新考虑一下他所承担的职责范围。”
You're simply being asked to reconsider his duties.’

我相信，说到这里的时候，爵爷再次低下头去假装看书，并局促不安地用手指比画着一个条目：“这些疏失本身或许微不足道，史蒂文斯，可你自己却必须要认识到那其中隐含的更重大的意义。
And it was then, I believe, that his lordship said as he looked down again into his volume and awkwardly fingered an entry: ‘These errors may be trivial in themselves, Stevens, but you must yourself realize their larger significance.

令尊堪当重任的时代正在成为过去。
Your father's days of dependability are now passing.

在那种任何一个疏失都可能危及会议成功的工作领域，请切莫再派给他任何任务了。”
He must not be asked to perform tasks in any area where an error might jeopardize the success of our forthcoming conference.’

“绝对不会了，先生。
‘Indeed not, sir.

对此我完全理解。”
I fully understand.’

“很好。
‘Good.

那我就把此事交给你去斟酌办理了，史蒂文斯。”
I'll leave you to think about it then, Stevens.’

应该说明的是，大约在一个礼拜以前，达林顿勋爵是亲眼看到家父意外跌倒的过程的。爵爷当时正在凉亭里招待两位客人，一位年轻的女士和一位绅士，眼看着家父端着一大托盘大受欢迎的茶点穿过草坪朝他们走来。
Lord Darlington, I should say, had actually witnessed my father's fall of a week or so earlier. His lordship had been entertaining two guests, a young lady and gentleman, in the summerhouse, and had watched my father's approach across the lawn bearing a much welcome tray of refreshments.

草坪和凉亭之间有一段长约几码的小缓坡，那时候跟现在一样，有四块石板嵌入草中充当进阶的梯级。家父就是在走到这几块石板附近时摔倒的，托盘上所有的东西—茶壶、茶杯、茶托、三明治、蛋糕—在石板上方的草皮上撒得到处都是。
The lawn climbs a slope several yards in front of the summerhouse, and in those days, as today, four flagstones embedded into the grass served as steps by which to negotiate this climb. It was in the vicinity of these steps that my father fell, scattering the load on his tray – teapot, cups, saucers, sandwiches, cakes – across the area of grass at the top of the steps.

等我接到警报赶过去的时候，爵爷和他那两位客人已经让家父面向一侧躺好，从凉亭里拿来的靠垫和小地毯权充枕头和毯子。
By the time I had received the alarm and gone out, his lordship and his guests had laid my father on his side, a cushion and a rug from the summerhouse serving as pillow and blanket.

家父已经神志不清，面色呈现出一种古怪的灰色。
My father was unconscious and his face looked an oddly grey colour.

已经派人去请梅雷迪思大夫了，不过爵爷认为等大夫赶到之前应该先把家父从太阳地里转移出来；结果是让人搬来了一把带篷的轮椅，费了不少劲儿把家父转移到了室内。
Dr Meredith had already been sent for, but his lordship was of the view that my father should be moved out of the sun before the doctor's arrival; consequently, a bath-chair arrived and with not a little difficulty, my father was transported into the house.

梅雷迪思大夫赶到的时候，家父已经苏醒过来，感觉好多了。大夫并没有待多久，临走前只模棱两可地交代了几句，大意是家父也许是“工作过于劳累”了。
By the time Dr Meredith arrived, he had revived considerably and the doctor soon left again making only vague statements to the effect that my father had perhaps been ‘over-working’.

这整个意外的发生显然让家父感觉非常难堪，到我们在达林顿勋爵的书房里谈话的时候，他早已经跟之前一样继续忙碌地工作了。
The whole episode was clearly a great embarrassment to my father, and by the time of that conversation in Lord Darlington's study, he had long since returned to busying himself as much as ever.

于是，怎么才能提出这个减免其工作职责的话题可就殊非易事了。
The question of how one could broach the topic of reducing his responsibilities was not, then, an easy one.

对我来说尤其麻烦的还在于这些年来家父跟我之间的交流越来越少，其原因我从来也没有真正搞清楚。
My difficulty was further compounded by the fact that for some years my father and I had tended – for some reason I have never really fathomed – to converse less and less.

以至于在他来到达林顿府以后，即便是针对工作进行一些简单的必要沟通时，那气氛也让双方都很是尴尬。
So much so that after his arrival at Darlington Hall, even the brief exchanges necessary to communicate information relating to work took place in an atmosphere of mutual embarrassment.

思之再三，我认定最好还是选在家父的寝室里跟他私下谈这件事，这样的话等我走后他也可以不受打扰地仔细考虑一下他所面临的新处境。
In the end, I judged the best option to be to talk in the privacy of his room, thus giving him the opportunity to ponder his new situation in solitude once I took my leave.

能在寝室里找到家父的时间只有他刚起床的一大早和临睡前的深夜里。
The only times my father could be found in his room were first thing in the morning and last thing at night.

我选择了前者，于是在某一天的清晨，我爬上仆役厢房的楼顶来到他居住的小阁楼外，轻轻敲了敲门。
Choosing the former, I climbed up to his small attic room at the top of the servants’ wing early one morning and knocked gently.

在此之前，我极少有理由进入家父的寝室，一见之下我深为那个房间的逼仄和简陋而吃惊。
I had rarely had reason to enter my father's room prior to this occasion and I was newly struck by the smallness and starkness of it.

确实，我记得当时的印象是跨入了一间牢房，后来想来，这种感觉或许跟天刚破晓时那苍白的光线以及空间的局促或者四壁的萧然也不无关系。
Indeed, I recall my impression at the time was of having stepped into a prison cell, but then this might have had as much to do with the pale early light as with the size of the room or the bareness of its walls.

因为家父已经拉开了窗帘，脸已经刮好，穿好全套制服坐在床沿上，显然他就一直坐在那里观看着天色的变化，等待黎明的到来。
For my father had opened his curtains and was sitting, shaved and in full uniform, on the edge of his bed from where evidently he had been watching the sky turn to dawn.

至少揣测起来他应该是在观看天空的，毕竟从他那个小小的窗口望去，只能看到屋瓦和雨水槽。
At least one assumed he had been watching the sky, there being little else to view from his small window other than roof-tiles and guttering.

他床头的那盏油灯已经捻灭，当我发现家父不以为然地瞥了一眼我手里的油灯—那是我特意带了来给摇摇晃晃的楼梯照个亮的—我就赶紧捻灭了它。
The oil lamp beside his bed had been extinguished, and when I saw my father glance disapprovingly at the lamp I had brought to guide me up the rickety staircase, I quickly lowered the wick.

油灯捻灭以后，我才更加清楚地注意到那照进房间的苍白光线的效果，以及它是如何照亮了家父那皱纹堆垒、棱角分明、仍旧令人敬畏不已的面容轮廓的。
Having done this, I noticed all the more the effect of the pale light coming into the room and the way it lit up the edges of my father's craggy, lined, still awesome features.

“啊，”我说，短促地一笑，“我就知道父亲肯定已经起了床，而且为白天的工作做好了准备。”
‘Ah,’ I said, and gave a short laugh, ‘I might have known Father would be up and ready for the day.’

“我起来已经三个钟头啦，”他说，颇为冷淡地上下打量了我一番。
‘I’ve been up for the past three hours,’ he said, looking me up and down rather coldly.

“希望父亲不是因为关节炎的困扰才睡不好觉的。”
‘I hope Father is not being kept awake by his arthritic troubles.’

“我的睡眠已经尽够了。”
‘I get all the sleep I need.’

父亲朝屋内唯一的那把椅子靠过去，那是把小小的木椅子，他把两只手全都撑在椅背上，借此站起身来。
My father reached forward to the only chair in the room, a small wooden one, and placing both hands on its back brought himself to his feet.

当我看到他站立在我面前的时候，我真不知道他的腰弯背驼在多大程度上是因为年老体衰，又在多大程度上应归咎于为了适应这个小阁楼那陡斜的天花板而养成的习惯。
When I saw him stood upright before me, I could not be sure to what extent he was hunched over due to infirmity and what extent due to the habit of accommodating the steeply sloped ceilings of the room.

“我来是要跟您谈一件事，父亲。”
‘I have come here to relate something to you, Father.’

“那就简明扼要地说。
‘Then relate it briefly and concisely.

我不能整个上午都听你瞎叨叨。”
I haven't all morning to listen to you chatter.’

“既然如此，父亲，那我就直奔主题了。”
‘In that case, Father, I will come straight to the point.’

“那就直奔主题，说完了事。
‘Come to the point then and be done with it.

我们这里还有人有工作要做呢。”
Some of us have work to be getting on with.’

“很好。
‘Very well.

既然您希望我长话短说，我就恭敬不如从命了。
Since you wish me to be brief, I will do my best to comply.

事实是，父亲已经是越来越年老体衰。
The fact is, Father has become increasingly infirm.

以至于现在就连履行副管家的日常职责也已经是心有余而力不足了。
So much so that even the duties of an under-butler are now beyond his capabilities.

爵爷认为，我自己也有同感，如果允许父亲继续承担目前的职责，他随时都可能危及府内日常事务的正常运转，尤其是下周即将举行的国际盛会。”
His lordship is of the view, as indeed I am myself, that while Father is allowed to continue with his present round of duties, he represents an ever-present threat to the smooth running of this household, and in particular to next week's important international gathering.’

父亲的面容，在那半明半暗的光线之下，没有丝毫的情绪波动。
My father's face, in the half-light, betrayed no emotion whatsoever.

“重点在于，”我继续道，“我们感觉父亲不应该再承担伺候用餐的工作了，不论席间是否有宾客在场。”
‘Principally,’ I continued, ‘it has been felt that Father should no longer be asked to wait at table, whether or not guests are present.’

“在过去的五十四年间，我每天都负责伺候用餐，”家父说道，话音不疾不徐。
‘I have waited at table every day for the last fifty-four years,’ my father remarked, his voice perfectly unhurried.

“除此以外，也已经决定父亲不该再端送盛放任何物品的托盘，不管需要走动的距离有多近。
‘Furthermore, it has been decided that Father should not carry laden trays of any sort for even the shortest distances.

有鉴于已经做出的这些限制，也知道父亲尤其看重简洁明了，我已经在此列出了经过修正的日常职责的清单，切盼父亲自今日起就遵照执行。”
In view of these limitations, and knowing Father's esteem for conciseness, I have listed here the revised round of duties he will from now on be expected to perform.’

我自己都感觉不太情愿将我手里的那张清单直接递给他，于是就放在了他的床尾上。
I felt disinclined actually to hand to him the piece of paper I was holding, and so put it down on the end of his bed.

家父瞥了它一眼，然后就转过目光凝视着我。
My father glanced at it then returned his gaze to me.

他的表情仍没有丝毫情绪变化的蛛丝马迹，他那双扶在椅背上的手却似乎完全放松了下来。
There was still no trace of emotion discernible in his expression, and his hands on the back of the chair appeared perfectly relaxed.

不管是否已经弯腰驼背，他那威严的身形所造成的绝对影响仍旧不容小觑—正是那同样的影响力使得后座上两位烂醉的绅士恢复了清醒。
Hunched over or not, it was impossible not to be reminded of the sheer impact of his physical presence – the very same that had once reduced two drunken gentlemen to sobriety in the back of a car.

最后，他说道：
Eventually, he said:

“我上次摔倒纯粹是因为那几级石阶的缘故。
‘I only fell that time because of those steps.

都已经歪歪扭扭了。
They're crooked.

应该吩咐谢默斯赶快去把它们挪挪正，以免别的人也在那儿摔倒喽。”
Seamus should be told to put those right before someone else does the same thing.’

“的确。
‘Indeed.

总之，父亲能答应我务必细看一下那份清单吗？”
In any case, may I be assured Father will study that sheet?’

“应该吩咐谢默斯赶紧去把那几级台阶修理好。
‘Seamus should be told to put those steps right.

绝对要在那些绅士们从欧洲来到之前就弄好。”
Certainly before these gentlemen start arriving from Europe.’

“的确。
‘Indeed.

那么，父亲，祝您早安。”
Well, Father, good morning.’

肯顿小姐在信中提到的那个夏日傍晚就在这次短暂会晤的不久后—当然，也可能就是那同一天的傍晚。
That summer evening referred to by Miss Kenton in her letter came very soon after that encounter – indeed, it may have been the evening of that same day.

我记不清到底是为了什么爬到宅第的最高层，来到一侧全都是一间间客房的那条走廊上了。
I cannot remember just what purpose had taken me up on to the top floor of the house to where the row of guest bedrooms line the corridor.

但我想正如此前已经说过的那样，我仍生动地记得当时那最后的斜阳穿过每扇敞开的房门，一道道橘红色的光线投射到走廊上的情景。
But as I think I have said already, I can recall vividly the way the last of the daylight was coming through each open doorway and falling across the corridor in orange shafts.

当我从那一间间无人使用的卧房门前走过时，肯顿小姐的侧影就映衬在其中一间卧室的窗户前，她看到我之后就喊我过去。
As I walked on past those unused bedrooms, Miss Kenton's figure, a silhouette against a window within one of them, had called to me.

当你细想此事，当你想起肯顿小姐在初到达林顿府时曾如何反复地讲起家父的所作所为，那天傍晚的情形何以会长久地留在她的记忆中，历经这么多年而不衰，恐怕也就不足为奇了。
When one thinks about it, when one remembers the way Miss Kenton had repeatedly spoken to me of my father during those early days of her time at Darlington Hall, it is little wonder that the memory of that evening should have stayed with her all of these years.

当我们俩从窗口望着楼下家父的身影时，她无疑是感觉到一定程度的负疚感的。
No doubt, she was feeling a certain sense of guilt as the two of us watched from our window my father's figure down below.

白杨树的树影占据了大半块草坪，不过落照仍旧照亮了远处通向凉亭的那段草坡。
The shadows of the poplar trees had fallen across much of the lawn, but the sun was still lighting up the far corner where the grass sloped up to the summerhouse.

我们望见家父就站在那四级石头台阶前，陷入了沉思。
My father could be seen standing by those four stone steps, deep in thought.

一阵微风轻轻地拂乱了他的头发。
A breeze was slightly disturbing his hair.

然后，我们看见他非常缓慢地走上了那几级石阶。
Then, as we watched, he walked very slowly up the steps.

上到坡顶以后，他转身又走了下来，比上去的时候步幅稍快。
At the top, he turned and came back down, a little faster.

再度转身之后，家父又一次凝神伫立了几秒钟，仔细端详着他眼前的石阶。
Turning once more, my father became still again for several seconds, contemplating the steps before him.

最后，他第二次拾阶而上，异常郑重其事。
Eventually, he climbed them a second time, very deliberately.

这一次他朝前走，越过草坪，几乎走到了凉亭边上，然后转过身又慢慢地走回来，眼睛一刻都没有离开过地面。
This time he continued on across the grass until he had almost reached the summerhouse, then turned and came walking slowly back, his eyes never leaving the ground.

事实上，要描述他当时的行为举止，我再也想不出比肯顿小姐在信中打的那个比方更为形象的了；的的确确，他“就仿佛一心想找回他失落在那里的某样珍宝”。
In fact, I can describe his manner at that moment no better than the way Miss Kenton puts it in her letter; it was indeed ‘as though he hoped to find some precious jewel he had dropped there’.

不过我看我是越来越沉溺于这些回忆当中了，这或许有点蠢吧。
But I see I am becoming preoccupied with these memories and this is perhaps a little foolish.

毕竟，目前的这次旅行是我千载难逢的一个机会，可以尽情品味英格兰乡村的众多绝胜佳景，我要是任由自己这么过度分心的话，以后我肯定会后悔不迭的。
This present trip represents, after all, a rare opportunity for me to savour to the full the many splendours of the English countryside, and I know I shall greatly regret it later if I allow myself to become unduly diverted.

事实上，我注意到自己还没有在此记下来到这座城市途中的任何见闻—只约略提到一开始那在山坡上的短暂停留。
In fact, I notice I have yet to record here anything of my journey to this city – aside from mentioning briefly that halt on the hillside road at the very start of it.

考虑到我其实非常享受昨天的旅程，这真算得上一个不小的纰漏。
This is an omission indeed, given how much I enjoyed yesterday's motoring.

我相当仔细地规划过前往索尔兹伯里的这趟旅程，避开了几乎所有的主干道；在有些人看来这次行车路线像是在不必要地绕圈子，不过这样一来我就能欣赏到简·西蒙斯太太在其佳著中推荐的好多处美景了，我必须说，对此我是相当满意的。
I had planned the journey here to Salisbury with considerable care, avoiding almost entirely the major roads; the route might have seemed unnecessarily circuitous to some, but then it was one that enabled me to take in a fair number of the sights recommended by Mrs J. Symons in her excellent volumes, and I must say I was well pleased with it.

大部分的时间我都行驶在农田牧地间，置身于绿草萋萋的怡人芳香中，而且我经常会不由自主地放慢车速，缓缓徐行，为的是更好地欣赏途经的一条溪流或是一道山谷的美景。
For much of the time it took me through farmland, amidst the pleasant aroma of meadows, and often I found myself slowing the Ford to a crawl to better appreciate a stream or a valley I was passing.

不过据我的记忆，一直到已经行将接近索尔兹伯里的时候，我才真正又从车上下来了一次。
But as I recall, I did not actually disembark again until I was quite near Salisbury.

当时我正行驶在一条长长的直路上，道路两旁都是开阔的草甸。
On that occasion, I was moving down a long, straight road with wide meadows on either side of me.

事实上，到了这里土地已经变得非常广袤而又平坦，四面都可以看得很远，索尔兹伯里大教堂的尖塔已经在前方的天际线上清晰可见。
In fact, the land had become very open and flat at that point, enabling one to see a considerable distance in all directions, and the spire of Salisbury Cathedral had become visible on the skyline up ahead.

一种宁静的心绪涌上心头，因为这个原因我想我又一次把车子开得非常慢了—可能时速不会超过十五英里。
A tranquil mood had come over me, and for this reason I believe I was again motoring very slowly – probably at no more than fifteen miles per hour.

也是幸好如此，因为开得这么慢我才及时发现有一只母鸡正以最悠闲不过的步态横穿我前方的道路。
This was just as well, for I saw only just in time a hen crossing my path in the most leisurely manner.

我赶紧把福特车停下来，离那只母鸡只剩下一两英尺的距离，这么一来它倒也停下不走了，就站在我车前的路当间。
I brought the Ford to a halt only a foot or two from the fowl, which in turn ceased its journey, pausing there in the road in front of me.

过了一会儿，我见它仍旧一动不动，就按响了汽车喇叭，但这并没有什么用，只使得那只母鸡开始在地上啄起什么东西来了。
When after a moment it had not moved, I resorted to the car horn, but this had no effect other than to make the creature commence pecking at something on the ground.

恼怒之下，我打开车门开始下车，一只脚刚刚踩到踏脚板上的时候，我听到一个女人的声音喊道：
Rather exasperated, I began to get out and had one foot still on the running board when I heard a woman's voice call:

“哦，我真是太抱歉啦，先生。”
‘Oh, I do beg your pardon, sir.’

往周围一瞧，我才发现自己刚刚经过了路边的一幢农舍—一个系着围裙的年轻女人从里面跑了出来，想必是汽车喇叭惊动了她。
Glancing round, I saw I had just passed on the roadside a farm cottage – from which a young woman in an apron, her attention no doubt aroused by the horn, had come running.

她从我身边走过去，一个突然袭击把那只母鸡抓住，她把它抱小孩一样抱在怀里，一边再次向我道歉。
Passing me, she swooped up the hen in her arms and proceeded to cradle it as she apologized to me again.

我请她但放宽心，这对我并没有造成什么妨碍，她说道：
When I assured her no harm had been done, she said:

“真是非常感谢您特意停下车来，没有从内莉身上轧过去。
‘I do thank you for stopping and not running poor Nellie over.

她是个好姑娘，总是给我们生出最大的鸡蛋。
She's a good girl, provides us with the largest eggs you've ever seen.

您特意把车停下来真是菩萨心肠。
It's so good of you to stop.

而且您可能还急着赶路吧？”
And you were probably in a hurry too.’

“哦，我一点儿都不着急赶路，”我微笑道。
‘Oh, I'm not in a hurry at all,’ I said with a smile.

“这么多年以来，我这是头一回能这么消消停停地享受一下，我得承认，这真是一种相当愉快的经历。
‘For the first time in many a year, I'm able to take my time and I must say, it's rather an enjoyable experience.

您看，我这纯是在享受驾车出游的乐趣呢。”
I'm just motoring for the pleasure of it, you see.’

“哦，那敢情好，先生。
‘Oh, that's nice, sir.

您是要去索尔兹伯里吧，我估摸着。”
And you're on your way to Salisbury, I expect.’

“确实。
‘I am indeed.

事实上，前面我们能看到的就是那座大教堂吧？
In fact, that's the cathedral we can see over there, isn't it?

听说那是一座恢宏壮丽的建筑。”
I'm told it's a splendid building.’

“哦，可不是嘛，先生，是很漂亮。
‘Oh, it is, sir, it's very nice.

呃，跟您说实话吧，我自己都还没去过索尔兹伯里呢，所以也讲不清楚它近看是个什么样子。
Well, to tell you the truth, I hardly go to Salisbury myself, so I couldn't really say what it's like at close quarters.

不过我跟您说，先生，我们从这儿天天都能看到那个尖塔。
But I tell you, sir, day in day out we have a view of the steeple from here.

有些日子雾太大了，它就仿佛完全消失了似的。
Some days, it's too misty and it's like it's vanished altogether.

可是您自己也看得出来，像今天这样的好天气，它看上去有多漂亮啊。”
But you can see for yourself, on a fine day like this, it's a nice sight.’

“赏心悦目。”
‘Delightful.’

“您没有从我们内莉的身上轧过去，我真是感激不尽，先生。
‘I'm so grateful you didn't run over our Nellie, sir.

三年前，我们的乌龟就是这么被轧死的，也就在这个地方。
Three years ago a tortoise of ours got killed like that and on just about this very spot.

为此我们全都非常伤心来着。”
We were all very upset over that.’

“真是太惨了，”我说，面色非常沉重。
‘How very tragic,’ I said, sombrely.

“哦，可不是嘛，先生。有人说我们庄稼人早就习惯了家畜伤亡了，才不是那么回事呢。
‘Oh, it was, sir. Some people say we farm people get used to animals being hurt or killed, but that's just not true.

我的小儿子一连哭了好几天。
My little boy cried for days.

您肯为了内莉停车真是菩萨心肠，先生。
It's so good you stopped for Nellie, sir.

既然您都已经下了车了，何不进屋喝杯茶呢？我们欢迎之至。
If you'd care to come in for a cup of tea, now that you've got out and everything, you'd be most welcome.

这会给您在路上提提神的。”
It would set you on your way.’

“您太客气了，不过说实话，我觉得应该继续赶路了。
‘That's most kind, but really, I feel I should continue.

我希望能适时地赶到索尔兹伯里，好有时间去看看那个城市的众多胜景呢。”
I'd like to reach Salisbury in good time to take a look at the city's many charms.’

“说得也是，先生。
‘Indeed, sir.

那好吧，再次感谢您。”
Well, thank you again.’

我又上了路，出于某种原因—也许是因为我觉得还会有更多的家畜悠闲地横穿马路吧—我仍旧保持着刚才的缓慢车速。
I set off again, maintaining for some reason – perhaps because I expected further farm creatures to wander across my path – my slow speed of before.

我必须得说，刚才的这桩小小的遭遇不禁使我的精神为之大好；我因为一念之善受到感激，又得到淳朴的善意回报，不禁使我对于未来几天里吉凶莫测的旅行计划感到一种特别的振奋之情。
I must say, something about this small encounter had put me in very good spirits; the simple kindness I had been thanked for, and the simple kindness I had been offered in return, caused me somehow to feel exceedingly uplifted about the whole enterprise facing me over these coming days.

也就是怀着这样昂扬的情绪，我来到了索尔兹伯里。
It was in such a mood, then, that I proceeded here to Salisbury.

不过我觉得还是应该暂时回头再说两句家父的事；因为我突然想到，在处理有关家父能力衰退这个问题上，给大家的印象可能是我的态度太过生硬，有些操之过急了。
But I feel I should return just a moment to the matter of my father; for it strikes me I may have given the impression earlier that I treated him rather bluntly over his declining abilities.

事实上，除了采取那样的方式以外，我当时也是别无选择的—一旦我把当时的整个大背景解释清楚，您肯定也会认同我这种说法的。
The fact is, there was little choice but to approach the matter as I did – as I am sure you will agree once I have explained the full context of those days.

概括说来，将在达林顿府召开的重要的国际会议已经迫在眉睫，处理问题已经容不得有任何放任姑息或是“转弯抹角”的余地了。
That is to say, the important international conference to take place at Darlington Hall was by then looming ahead of us, leaving little room for indulgence or ‘beating about the bush’.

还需提醒诸位一句的是，尽管在此后的大约十五年间，达林顿府确曾见证了诸多具有同等分量的重大事件的发生，但别忘了，一九二三年三月的那次会议正是这些重大事件中的第一桩；可以想象，正因为相对来说缺乏经验，大家也就更不敢马虎大意了。
It is important to be reminded, moreover, that although Darlington Hall was to witness many more events of equal gravity over the fifteen or so years that followed, that conference of March 1923 was the first of them; one was, one supposes, relatively inexperienced, and inclined to leave little to chance.

事实上，直到今天我仍然会经常回顾那次会议，出于不止一个原因，我将其视作我整个一生的转折点。
In fact, I often look back to that conference and, for more than one reason, regard it as a turning point in my life.

首先，我想我的确把它看作我真正成长为一名成熟的管家的重大时刻。
For one thing, I suppose I do regard it as the moment in my career when I truly came of age as a butler.

这并不代表说我认为自己已经必然地成了一位“伟大的”管家；不管怎么说，这样的评判都是不应该由我来论定的。
That is not to say I consider I became necessarily, a ‘great’ butler; it is hardly for me, in any case, to make judgements of this sort.

不过，如果有人愿意假定在我的整个职业生涯中至少已经具备了一丁点“尊严”的核心素质，那么此人应该也会希望将一九二三年三月的那次会议当作一个代表性的时刻，在那其中我也许显示出我已经具备了那种素质所要求的能力。
But should it be that anyone ever wished to posit that I have attained at least a little of that crucial quality of ‘dignity’ in the course of my career, such a person may wish to be directed towards that conference of March 1923 as representing the moment when I demonstrated I might have a capacity for such a quality.

那次会议无疑属于那样的重大事件之一：如果它在某个人发展过程的关键阶段不期而至，必将会挑战并且拓展其个人能力的极限，所以自那以后，此人便会以全新的标准来检视和要求自己了。
It was one of those events which at a crucial stage in one's development arrive to challenge and stretch one to the limit of one's ability and beyond, so that thereafter one has new standards by which to judge oneself.

当然了，那次会议之所以令人难忘亦有其他颇为不同的原因，在此我愿详细解释一下。
That conference was also memorable, of course, for other quite separate reasons, as I would like now to explain.

一九二三年的那次会议可以说是达林顿勋爵长期擘画的最终成果；的确，现在回顾起来，可以清楚地看到爵爷是如何从会议的大约三年前就开始朝着这个目标努力的。
The conference of 1923 was the culmination of long planning on the part of Lord Darlington; indeed, in retrospect, one can see clearly how his lordship had been moving towards this point from three years or so before.

我记得，在大战结束合约起草的时候，他对此还并没有这么全神贯注，我想，公平合理地说来，他对合约的兴趣与其说是源自对于其内容的关注，还不如说是由于他跟卡尔—海因茨·布雷曼先生的友谊。
As I recall, he had not been initially so preoccupied with the peace treaty when it was drawn up at the end of the Great War, and I think it is fair to say that his interest was prompted not so much by an analysis of the treaty, but by his friendship with Herr Karl-Heinz Bremann.

大战结束不久后，布雷曼先生初次造访达林顿府，那时他还是一身戎装，任何人都看得出来，他跟达林顿勋爵之间已经建立起了深厚的友谊。
Herr Bremann first visited Darlington Hall very shortly after the war while still in his officer's uniform, and it was evident to any observer that he and Lord Darlington had struck up a close friendship.

这并没有让我感到吃惊，因为任何人只要一瞥之下就看得出布雷曼先生是位高尚正派的士绅君子。
This did not surprise me, since one could see at a glance that Herr Bremann was a gentleman of great decency.

从德国陆军退役以后，他在之后的两年间每隔一段时间都会再次造访，而你忍不住会有些震惊地注意到，他的境况已经是每况愈下了。
He returned again, having left the German army, at fairly regular intervals during the following two years, and one could not help noticing with some alarm the deterioration he underwent from one visit to the next.

他的衣着越来越敝旧，他的身形越来越单薄；他的眼睛里现出一种惊恐不安的神色，在他最后的几次造访中，他会长时间地凝视着虚空，忘记了爵爷就在他身旁，有时甚至在爵爷跟他说话时都茫然不觉。
His clothes became increasingly impoverished, his frame thinner; a hunted look appeared in his eyes, and on his last visits, he would spend long periods staring into space, oblivious of his lordship's presence or, sometimes, even of having been addressed.

我本以为布雷曼先生是罹患了什么严重的疾病，可是听了爵爷当时的一番话，我才明白情况并非如此。
I would have concluded Herr Bremann was suffering from some serious illness, but for certain remarks his lordship made at that time assuring me this was not so.

应该是临近一九二〇年末的时候，达林顿勋爵踏上了他数度柏林之行的首次旅程，我还记得那次初访对他造成的深刻影响。
It must have been towards the end of 1920 that Lord Darlington made the first of a number of trips to Berlin himself, and I can remember the profound effect it had on him.

他回来以后一连好几天都心事重重，我还记得我有一次问他柏林之行是否愉快时，他的回答是：“令人不安，史蒂文斯。
A heavy air of preoccupation hung over him for days after his return, and I recall once, in reply to my inquiring how he had enjoyed his trip, his remarking: ‘Disturbing, Stevens.

令人甚为不安。
Deeply disturbing.

如此对待战败的敌人对我们而言实在是名誉扫地。
It does us great discredit to treat a defeated foe like this.

这完全背离了我们国家的传统。”
A complete break with the traditions of this country.’

不过，还有与此有关的另一件事一直生动地留在我的记忆当中。
But there is another memory that has remained with me very vividly in relation to this matter.

如今，原来的宴会厅已经不再摆放餐桌，那个宽敞的大厅由于其天花极高且非常华美，法拉戴先生就将其派作了类似画廊的用场。
Today, the old banqueting hall no longer contains a table and that spacious room, with its high and magnificent ceiling, serves Mr Farraday well as a sort of gallery.

但是在爵爷的时代，宴会厅还是经常使用的，常设的长餐桌可供三十位或更多的客人就座用餐；实际上，那个宴会厅是如此宽敞，只要在常设的长餐桌一头再加设几张小餐桌，就能供差不多五十位客人就座用餐。
But in his lordship's day, that room was regularly required, as was the long table that occupied it, to seat thirty or more guests for dinner; in fact, the banqueting hall is so spacious that when necessity demanded it, further tables were added to the existing one to enable almost fifty to be seated.

当然，在寻常的日子里，达林顿勋爵就跟如今的法拉戴先生一样，是在气氛更加亲切的餐厅里用餐的，那是招待十二位客人用餐的理想场所。
On normal days, of course, Lord Darlington took his meals, as does Mr Farraday today, in the more intimate atmosphere of the dining room, which is ideal for accommodating up to a dozen.

不过我记得在那个特别的冬夜里，餐厅因为某种原因无法使用，达林顿勋爵只得跟唯一的一位客人—我想应该是爵爷任职外交部时期的同僚理查德·福克斯爵士—在那空旷的宴会厅里共进晚餐。
But on that particular winter's night I am recollecting the dining room was for some reason out of use, and Lord Darlington was dining with a solitary guest – I believe it was Sir Richard Fox, a colleague from his lordship's Foreign Office days – in the vastness of the banqueting hall.

您无疑也会同意，在侍餐的时候，最困难的情况就莫过于只有两个人用餐了。
You will no doubt agree that the hardest of situations as regards dinner-waiting is when there are just two diners present.

我本人是宁肯只伺候一位用餐者用餐的，哪怕他是个素不相识的陌生人。
I would myself much prefer to wait on just one diner, even if he were a total stranger.

在有两个人一起用餐的情况下，就算其中一位是自己的主人，你也会发现最大的难题就在于很难做到既要全意殷勤又须完全不引起注意这一优质侍餐服务的核心要义；在这种情况下，你难免会有这样的怀疑，即你的在场是否妨碍了两位用餐者的谈话。
It is when there are two diners present, even when one of them is one's own employer, that one finds it most difficult to achieve that balance between attentiveness and the illusion of absence that is essential to good waiting; it is in this situation that one is rarely free of the suspicion that one's presence is inhibiting the conversation.

那天晚上，宴会厅里的大部分空间都处在黑暗中，两位绅士肩并肩坐在长餐桌的中间位置—因为餐桌过于宽大，不宜于对坐—照明只有餐桌上的烛台以及对面噼啪作响的炉火。
On that occasion, much of the room was in darkness, and the two gentlemen were sitting side by side midway down the table – it being much too broad to allow them to sit facing one another – within the pool of light cast by the candles on the table and the crackling hearth opposite.

为了将我的存在感减到最低，我决定站在比平常距离餐桌远得多的暗处。
I decided to minimize my presence by standing in the shadows much further away from table than I might usually have done.

当然了，这一策略也有其明显的不利之处，每次我走向光亮处侍餐的时候，还没等我走到餐桌前，我前进的脚步就会产生又长又响的回声，以最招摇的方式让用餐者注意到我的到来；不过也确有一大优点，可以使我站在一旁待命时几乎不会被人注意到。
Of course, this strategy had a distinct disadvantage in that each time I moved towards the light to serve the gentlemen, my advancing footsteps would echo long and loud before I reached the table, drawing attention to my impending arrival in the most ostentatious manner; but it did have the great merit of making my person only partially visible while I remained stationary.

正是在我这样侍立于离开两位绅士有一段距离的暗处的时候，我听到坐在两排空椅子中间的达林顿勋爵谈起了布雷曼先生，他的声音一如既往地平静而又温文，然而却在高大的四壁间产生了强烈的回响。
And it was as I was standing like that, in the shadows some distance from where the two gentlemen sat amidst those rows of empty chairs, that I heard Lord Darlington talk about Herr Bremann, his voice as calm and gentle as usual, somehow resounding with intensity around those great walls.

“他曾是我的敌人，”爵爷说道，“可是一直都表现得像个绅士。
‘He was my enemy,’ he was saying, ‘but he always behaved like a gentleman.

在我们两国相互炮击的六个月期间，我们彼此都能以礼相待。
We treated each other decently over six months of shelling each other.

他是位绅士，必须恪尽职守，我对他本人并无丝毫怨恨。
He was a gentleman doing his job and I bore him no malice.

我曾对他说：‘听我说，我们现在是敌人，我会不惜一切跟你战斗到底。
I said to him: “Look here, we're enemies now and I'll fight you with all I've got.

但是在这一可悲的事务结束之后，等我们之间不必再相互为敌的时候，我们一定要一起喝一杯。’
But when this wretched business is over, we shan't have to be enemies any more and we'll have a drink together.”

但可悲的是，这一君子协定却让我成了一个骗子。
Wretched thing is, this treaty is making a liar out of me.

我的意思是，我跟他说过一旦战争结束以后我们就不再相互为敌了。
I mean to say, I told him we wouldn't be enemies once it was all over.

如今我有何面目再去见他，跟他说我所言不虚呢？”
But how can I look him in the face and tell him that's turned out to be true?’

就在那同一个夜晚的稍后时段，爵爷一边摇着头，一边语气沉重地说：“我是为了维护世界的正义才打那场战争的。
And it was a little later that same night that his lordship said with some gravity, shaking his head: ‘I fought that war to preserve justice in this world.

据我的理解，我并没有参加到针对日耳曼种族的仇杀当中。”
As far as I understood, I wasn't taking part in a vendetta against the German race.’

时至今日，每当听到针对爵爷的各种说法，每当听到这些日子里甚嚣尘上的有关他的行事动机的那些愚蠢的诛心之论，我就会高兴地回忆起他在那间空荡荡的宴会厅里说出的那番肺腑之言。
And when today one hears talk about his lordship, when one hears the sort of foolish speculations concerning his motives as one does all too frequently these days, I am pleased to recall the memory of that moment as he spoke those heartfelt words in the near-empty banqueting hall.

在以后的这些岁月当中，针对爵爷的所作所为无论曾有过如何纷纭复杂的说法，至少我个人从未怀疑过，他所有的言行无不源自他内心深处渴望伸张“世界的正义”的终极愿望。
Whatever complications arose in his lordship's course over subsequent years, I for one will never doubt that a desire to see ‘justice in this world’ lay at the heart of all his actions.

那个夜晚过后没多久，就传来了布雷曼先生在汉堡至柏林的一列火车上开枪自杀的噩耗。
It was not long after that evening there came the sad news that Herr Bremann had shot himself in a train between Hamburg and Berlin.

爵爷自然是非常难过，并马上制订计划，对布雷曼夫人致以哀悼之情并予以经济援助。
Naturally, his lordship was greatly distressed and immediately made plans to dispatch funds and commiserations to Frau Bremann.

然而，在经过好几天的努力之后—其间我本人亦曾竭尽所能给以协助—爵爷都寻觅不到布雷曼先生家人的任何行踪。
However, after several days of endeavour, in which I myself did my best to assist, his lordship was not able to discover the whereabouts of any of Herr Bremann's family.

看来，他已经有挺长一段时间无家可归、妻离子散了。
He had, it seemed, been homeless for some time and his family dispersed.

我相信，即使没有这个不幸的消息，达林顿勋爵也会开始他日后的那些作为的；他那唯愿终结不义与苦难的渴望就深深地根植于他的本性中，他是不可能改弦更张的。
It is my belief that even without this tragic news, Lord Darlington would have set upon the course he took; his desire to see an end to injustice and suffering was too deeply ingrained in his nature for him to have done otherwise.

事实上，布雷曼先生死后不过几个礼拜，爵爷就开始花费更多的精力和时间致力于解决德国的危机。
As it was, in the weeks that followed Herr Bremann's death, his lordship began to devote more and more hours to the matter of the crisis in Germany.

众多政府的权贵与社会上的名流都成为府里的常客—我记得，这其中就包括了丹尼尔斯勋爵、约翰·梅纳德·凯恩斯先生和H·G·威尔斯先生，那位著名的作家，以及其他很多“不宜公开”的人士，在此我也就姑隐其名了—这些来宾经常和爵爷一连好几个钟头闭门密商。
Powerful and famous gentlemen became regular visitors to the house – including, I remember, figures such as Lord Daniels, Mr John Maynard Keynes, and Mr H. G. Wells, the renowned author, as well as others who, because they came ‘off the record’, I should not name here – and they and his lordship were often to be found locked in discussion for hours on end.

有些来宾事实上是绝对“不宜公开”的，我得到指示要确保不能让仆佣们得悉他们的身份，有时甚至都不能让人看到他们。
Some of the visitors were, in fact, so ‘off the record’ that I was instructed to make sure the staff did not learn their identities, or in some cases, even glimpse them.

不过—我可以自豪而又感激地说一句—达林顿勋爵从来都未曾试图避过我的耳目；我还记得有好几次，某位大人物一句话说到一半就停下来，警惕地瞥上我一眼，而爵爷无一例外地都会保证说：“哦，但说无妨。
However – and I say this with some pride and gratitude – Lord Darlington never made any efforts to conceal things from my own eyes and ears; I can recall on numerous occasions, some personage breaking off in mid-sentence to glance warily towards my person, only for his lordship to say: ‘Oh, that's all right.

在史蒂文斯面前您什么话都可以讲，这一点我可以向您保证。”
You can say anything in front of Stevens, I can assure you.’

于是，在布雷曼先生去世后的大约两年间，在爵爷与那段时间已成为其最亲密盟友的大卫·卡迪纳尔爵士的不懈努力下，已成功地聚集起一个由重要人士组成的广泛联盟，其共同的信念是德国的现状已经不能再这样持续下去了。
Steadily, then, over the two years or so following Herr Bremann's death, his lordship, together with Sir David Cardinal, who became his closest ally during that time, succeeded in gathering together a broad alliance of figures who shared the conviction that the situation in Germany should not be allowed to persist.

这其中不但有英国人和德国人，还有比利时人、法国人、意大利人和瑞士人；他们的身份则是高级外交官和政要、杰出的神职人员、退役的军方士绅、作家与思想家。
These were not only Britons and Germans, but also Belgians, French, Italians, Swiss; they were diplomats and political persons of high rank; distinguished clergymen; retired military gentlemen; writers and thinkers.

其中的有些绅士是因为跟爵爷的见解一致，深切地感觉到在凡尔赛签订的和约远非光明磊落，为了一场已经结束了的战争而继续惩罚一个战败国是不道德的行径。
Some were gentlemen who felt strongly, like his lordship himself, that fair play had not been done at Versailles and that it was immoral to go on punishing a nation for a war that was now over.

其他人显然对于德国或是她的子民并不这么关心，但他们认为该国的经济乱象若不得到遏止，则极有可能以惊人之势蔓延至全世界。
Others, evidently, showed less concern for Germany or her inhabitants, but were of the opinion that the economic chaos of that country, if not halted, might spread with alarming rapidity to the world at large.

等到一九二二年初的时候，爵爷已经开始为心中一个明确的目标而努力了。
By the turn of 1922, his lordship was working with a clear goal in mind.

这就是将这群同道中那些最有影响力的人物齐集达林顿府，举办一场“非官方的”国际会议—会议将集中讨论《凡尔赛和约》中最为苛刻的几个条款的修订办法。
This was to gather under the very roof of Darlington Hall the most influential of the gentlemen whose support had been won with a view to conducting an ‘unofficial’ international conference – a conference that would discuss the means by which the harshest terms of the Versailles treaty could be revised.

为了使他们的努力不至于付诸东流，任何此类的会议都必须具有足够的分量，如此方能对于“官方的”国际会议产生决定性的影响—专为重新检讨和约的内容这一目的已经正式召开过几次会议，但其结果却只是徒增混乱和怨愤。
To be worthwhile, any such conference would have to be of sufficient weight so that it could have a decisive effect on the ‘official’ international conferences – several of which had already taken place with the express purpose of reviewing the treaty, but which had succeeded in producing only confusion and bitterness.

我们当时的首相劳合·乔治先生已经呼吁于一九二二年春在意大利再次召开一次大型会议，爵爷最初的打算就是在达林顿府组织一次聚会以便确保意大利的会议能取得令人满意的结果。
Our Prime Minister of that time, Mr Lloyd George, had called for another great conference to be held in Italy in the spring of 1922, and initially his lordship's aim was to organize a gathering at Darlington Hall with a view to ensuring a satisfactory outcome to this event.

虽然爵爷和大卫爵士不遗余力地辛苦工作，但这一时限确实还是过于紧迫了；但随着乔治先生倡议举行的会议再度无疾而终，爵爷于是着眼于计划来年将于瑞士举行的下一次大型会议。
For all the hard work on his and Sir David's part, however, this proved too harsh a deadline; but then with Mr George's conference ending yet again in indecision, his lordship set his sights on a further great conference scheduled to take place in Switzerland that following year.

我还记得那段时期里的一天早上，我在早餐室里为达林顿勋爵端上咖啡的时候，他有点愤愤地把手里的《泰晤士报》折起来，说道：“这些法国人。
I can remember one morning around this time bringing Lord Darlington coffee in the breakfast room, and his saying to me as he folded The Times with some disgust: ‘Frenchmen.

我真是，说实话，史蒂文斯，有点受不了这些法国人。”
Really, I mean to say, Stevens. Frenchmen.’

“是的，先生。”
‘Yes, sir.’

“而且想想看我们还必须得在全世界面前跟他们手挽着手，肩并着肩。
‘And to think we have to be seen by the world to be arm in arm with them.

一旦被人提醒到这一点，你就巴不得好好去洗个澡。”
One wishes for a good bath at the mere reminder.’

“是的，先生。”
‘Yes, sir.’

“上次我在柏林的时候，史蒂文斯，奥费拉特男爵，家父的老朋友，走上前来跟我说：‘你们为什么要这样对待我们？
‘Last time I was in Berlin, Stevens, Baron Overath, old friend of my father, came up and said: “Why do you do this to us?

难道你们看不出来再这样下去我们就承受不了了吗？’我真是很想直接告诉他，这全是那些可鄙的法国人干的。
Don't you see we can't go on like this?” I was jolly well tempted to tell him it's those wretched Frenchmen.

这么胡闹可绝非英国人的行事风格，我想跟他说。
It's not the English way of carrying on, I wanted to say.

可我转念一想还是不能这么做：绝对不应该诋毁我们亲爱的盟国。”
But I suppose one can't do things like that. Mustn't speak ill of our dear allies.’

可是事实上，正是由于法国人在解除德国人免受《凡尔赛和约》苛酷条款的限制方面最不肯通融，也就更为迫切地需要在达林顿府举行的聚会上至少请到一位对于本国的外交政策拥有明确影响力的法国绅士与会。
But the very fact that the French were the most intransigent as regards releasing Germany from the cruelties of the Versailles treaty made all the more imperative the need to bring to the gathering at Darlington Hall at least one French gentleman with unambiguous influence over his country's foreign policy.

的确，我就听到爵爷数度表达过这样的观点：如果没有这样的一位人士出席，则任何关于德国问题的讨论都不过是自娱自乐。
Indeed, I heard several times his lordship express the view that without the participation of such a personage, any discussion on the topic of Germany would be little more than an indulgence.

于是，爵爷就和大卫爵士开始着手解决筹备工作的这一至关重要的环节，在此期间，我亲眼目睹他们迭遭挫败仍不屈不挠的精神境界，真是令我感佩不已，五体投地。他们发出了无数信函和电报，而且在短短两个月内爵爷就三度亲赴巴黎斡旋。
He and Sir David accordingly set upon this final crucial lap of their preparations and to witness the unswerving determination with which they persevered in the face of repeated frustrations was a humbling experience; countless letters and telegrams were dispatched and his lordship himself made three separate trips to Paris within the space of two months.

最后终于征得一位声名显赫的法国人的承诺—我将只称呼他为“杜邦先生”—同意在严格地“不宜公开”的基础上参加此次聚会，会议的日期也由此得以确定。
Finally, having secured the agreement of a certain extremely illustrious Frenchman – I will merely call him ‘M. Dupont’ – to attend the gathering on a very strict ‘off the record’ basis, the date for the conference was set.

也就是一九二三年那个令人难忘的三月。
That is to say, for that memorable March of 1923.

随着会期越来越近，我所承受的压力在性质上虽远不如爵爷肩负的那么巨大，但也绝非是微不足道的。
As this date grew ever nearer, the pressures on myself, though of an altogether more humble nature than those mounting on his lordship, were nevertheless not inconsequential.

我非常清楚地意识到，如果有任何一位客人在达林顿府逗留期间稍感些微地不够舒适，就有可能造成无法想象的严重后果。
I was only too aware of the possibility that if any guest were to find his stay at Darlington Hall less than comfortable, this might have repercussions of unimaginable largeness.

不仅如此，由于与会人数的不确定性，我事先的准备工作也就格外复杂化了。
Moreover, my planning for the event was complicated by the uncertainty as to the numbers involved.

这次会议的级别极高，正式的与会者仅限于十八位位高权重的绅士和两位女士—一位德国的伯爵夫人以及那令人敬畏的埃莉诺·奥斯汀太太，她当时还住在柏林；不过由于每位与会者都有充分的理由携秘书、贴身男仆和翻译一同前来，要想确知这些随同人员的人数几乎是不可能的。
The conference being of a very high level, the participants had been limited to just eighteen very distinguished gentlemen and two ladies – a German countess and the formidable Mrs Eleanor Austin, at that time still resident in Berlin; but each of these might reasonably bring secretaries, valets and interpreters, and there proved no way of ascertaining the precise number of such persons to expect.

再者说来，有一部分与会者肯定会在三天的会期之前提早到来，以便为自己留出充足的时间做好准备工作并估定其他客人的具体心态；然而他们提前抵达的准确日期仍属未定之数。
Furthermore, it became clear that a number of the parties would be arriving some time before the three days set aside for the conference, thus giving themselves time to prepare their ground and gauge the mood of fellow guests, though their exact arrival dates were, again, uncertain.

我能够确定的只有府里所有的仆役员工不仅需要不遗余力地努力工作，需要随时保持最为警觉的待命状态，而且还得具有非同寻常的灵活和变通性。
It was clear then that the staff would not only have to work extremely hard, and be at their most alert, they would also have to be unusually flexible.

事实上，我一度曾经认为如果不从府外引进更多人手帮忙的话，我们面临的这一巨大的挑战恐怕难以顺利完成。
In fact, I was for some time of the opinion that this huge challenge ahead of us could not be surmounted without my bringing in additional staff from outside.

但如此一来，不但是爵爷肯定担心会引起外界的谣诼蜂起，也会使得我在承担不起任何失误的情势下，出现不得不仰赖完全不知底细的外人的窘境。
However, this option, quite aside from the misgivings his lordship was bound to have as regards gossip travelling, entailed my having to rely on unknown quantities just when a mistake could prove most costly.

于是，我开始着手以一种，在我想象中，一位将军为一场战役做准备的态度来为即将到来的重大日子做好准备：我以无以复加的谨慎态度拟定了一份特别的员工配置规划，预先考虑到各种可能发生的意外和不测；我仔细分析了我们最薄弱的环节所在，为此专门制订了若干应急计划，以便在果然出现问题时即可施行补救措施；我甚至对全体员工做了一次军队里惯用的“鼓气讲话”，让大家认识到，尽管他们必须拼力工作到精疲力竭的程度，但能在未来的那几天里克尽厥职，他们必将感到莫大的自豪。
I thus set about preparing for the days ahead as, I imagine, a general might prepare for a battle: I devised with utmost care a special staff plan anticipating all sorts of eventualities; I analysed where our weakest points lay and set about making contingency plans to fall back upon in the event of these points giving way; I even gave the staff a military-style ‘pep-talk’, impressing upon them that, for all their having to work at an exhausting rate, they could feel great pride in discharging their duties over the days that lay ahead.

“历史极有可能就在我们这个屋檐下创造出来，”我这样告诉他们。
‘History could well be made under this roof,’ I told them.

而他们因为深知我绝非那种夸大其词之辈，也就都能清楚地认识到某件意义重大的事件即将在我们府里上演了。
And they, knowing me to be one not prone to exaggerated statements, well understood that something of an extraordinary nature was impending.

这样您或许就能理解，家父不巧在凉亭前摔倒时整个达林顿府里所笼罩的紧张气氛—那一意外就发生在第一批与会客人可能会到达的两周前—而且也该明白我为什么要说我们已经没有什么“转弯抹角”的余地了吧？
You will understand then something of the climate prevailing around Darlington Hall by the time of my father's fall in front of the summerhouse – this occurring as it did just two weeks before the first of the conference guests were likely to arrive – and what I mean when I say there was little room for any ‘beating about the bush’.

可不管怎么说，家父居然很快就找到了办法，巧妙地规避了由不许他再端托盘的禁令对他的工作效能所造成的限制。
My father did, in any case, rapidly discover a way to circumvent the limitations on his effectiveness implied by the stricture that he should carry no laden trays.

一时间，大家经常看到他推着一辆手推车在府里到处走动的身影，车上满载着清洁用具、拖把、刷子，虽总是摆放得整整齐齐，旁边却又极不协调出现了茶壶、茶杯和茶碟，有时候看起来活像是街头小贩的卖货车。
The sight of his figure pushing a trolley loaded with cleaning utensils, mops, brushes arranged incongruously, though always tidily, around teapots, cups and saucers, so that it at times resembled a street-hawker's barrow, became a familiar one around the house.

显然，他仍旧无可避免地只得放弃他在餐厅里侍餐的职责，但除此以外，拜那辆手推车之赐，他却完成了惊人的工作量。
Obviously he still could not avoid relinquishing his waiting duties in the dining room, but otherwise the trolley enabled him to accomplish a surprising amount.

事实上，随着国际会议的巨大挑战日益迫近，家父身上似乎也发生了令人惊讶的变化。
In fact, as the great challenge of the conference drew nearer, an astonishing change seemed to come over my father.

给人感觉简直就像是他被某种超自然的力量附了体，让他一下子年轻了二十岁；前些日子他脸上那种意气消沉的神色几乎一扫而光，他在府里各处工作起来简直浑身洋溢着青春的活力，在外人看来几乎要以为不是只有一个，而是有好几个这样的身影推着手推车在达林顿府里的各个走廊上奔忙呢。
It was almost as though some supernatural force possessed him, causing him to shed twenty years; his face lost much of the sunken look of recent times, and he went about his work with such youthful vigour that a stranger might have believed there were not one but several such figures pushing trolleys about the corridors of Darlington Hall.

至于肯顿小姐呢，我记得那些日子里日益增加的压力似乎也对她产生了明显的影响。
As for Miss Kenton, I seem to remember the mounting tension of those days having a noticeable effect upon her.

举例说来，我记得那段时间里我有一次在后廊上跟她偶遇时的情形。
I recall, for instance, the occasion around that time I happened to encounter her in the back corridor.

对于达林顿府来说，后廊在整个仆役区域起到了主干的作用，由于进深过长，阳光无法照射进来，走廊里总是一副阴沉沉的场景。
The back corridor, which serves as a sort of backbone to the staff's quarters of Darlington Hall, was always a rather cheerless affair due to the lack of daylight penetrating its considerable length.

就算是在大晴天，后廊上也是一片昏暗，从那儿走过就像是穿过一条隧道一样。
Even on a fine day, the corridor could be so dark that the effect was like walking through a tunnel.

在我说起的那一次，如果我未曾从她朝我走来时鞋子踩在地板上的脚步声中认出她来，那就只能通过她的轮廓来辨认了。
On that particular occasion, had I not recognized Miss Kenton's footsteps on the boards as she came towards me, I would have been able to identify her only from her outline.

我在木地板上少数几处有道光线透进来的地方选了一处停下脚步，待她走近以后叫了一声：“啊，肯顿小姐。”
I paused at one of the few spots where a bright streak of light fell across the boards and, as she approached, said: ‘Ah, Miss Kenton.’

“有事吗，史蒂文斯先生？”
‘Yes, Mr Stevens?’

“肯顿小姐，不知道可否提醒您留意一下，楼上的床单需要在后天之前准备妥当。”
‘Miss Kenton, I wonder if I may draw your attention to the fact that the bed linen for the upper floor will need to be ready by the day after tomorrow.’

“床单已经全都准备好了，史蒂文斯先生。”
‘The matter is perfectly under control, Mr Stevens.’

“啊，很高兴听您这么说。
‘Ah, I'm very glad to hear it.

我不过是突然想到了而已，没什么别的意思。”
It just struck me as a thought, that's all.’

我正要起步往前走的时候，肯顿小姐却站在了原地。
I was about to continue on my way, but Miss Kenton did not move.

然后她朝我走近一步，一道光纹刚好落在她的脸上，我这才看清楚她那愤怒的表情。
Then she took one step more towards me so that a bar of light fell across her face and I could see the angry expression on it.

“非常不幸，史蒂文斯先生，我真是忙得不可开交，我发现我几乎连一刻都不得闲。
‘Unfortunately, Mr Stevens, I am extremely busy now and I am finding I have barely a single moment to spare.

而您却明显地闲得很，我要是有您那么多闲工夫的话，我也会很高兴在府里四处溜达溜达，然后再同样地提醒您去特别注意一下那些你早就已经做好的工作的。”
If only I had as much spare time as you evidently do, then I would happily reciprocate by wandering about this house reminding you of tasks you have perfectly well in hand.’

“喔，肯顿小姐，根本没必要发那么大的火。
‘Now, Miss Kenton, there is no need to become so bad-tempered.

我只是觉得有必要提醒您一声，您并没有因为太忙而疏忽了……”
I merely felt the need to satisfy myself that it had not escaped your attention …’

“史蒂文斯先生，这已经是在过去的两天当中您第四或第五次感觉有此必要了。
‘Mr Stevens, this is the fourth or fifth time in the past two days you have felt such a need.

您居然有这么多时间在府里上上下下地闲逛，并且以您那毫无必要的指责无端地去打搅别人，这实在是让人感觉匪夷所思。”
It is most curious to see that you have so much time on your hands that you are able to simply wander about this house bothering others with gratuitous comments.’

“肯顿小姐，如果您居然有那么一时一刻认为我还有空闲时间的话，那就比以往任何时候都更清楚地显示出您是多么地缺乏经验了。
‘Miss Kenton, if you for one moment believe I have time on my hands, that displays more clearly than ever your great inexperience.

我相信假以时日，再过几年，您对于在这样一幢府第里到底有多少大事小情需要操心，是会获得一些更为清楚的概念的。”
I trust that in years to come, you will gain a clearer picture of what occurs in a house like this.’

“您总是没完没了地提到我有‘多么缺乏经验’，史蒂文斯先生，然而您却显然无法指出我的工作中有任何疏失。
‘You are perpetually talking of my “great inexperience”, Mr Stevens, and yet you appear quite unable to point out any defect in my work.

否则，我确信您老早就不厌其烦地不吝赐教了。
Otherwise I have no doubt you would have done so long ago and at some length.

行了，我手头上还有很多工作要做，如果您不再这样跟在我屁股后面指手画脚，妨碍我做事，我将会感激不尽的。
Now, I have much to be getting on with and would appreciate your not following me about and interrupting me like this.

如果您实在是有太多的闲暇需要消磨，那我建议您不如到外面去呼吸点新鲜空气，倒是更为有益一些。”
If you have so much time to spare, I suggest it might be more profitably spent taking some fresh air.’

她咚咚地踩着地板从我身边走过，朝走廊那头走去。
She stamped past me and on down the corridor.

我决定最好还是到此为止，不要再深究下去，于是也就继续走我的路了。
Deciding it best to let the matter go no further, I continued on my way.

我就要来到厨房门口的时候，忽听得她怒冲冲的脚步声再次尾随而至。
I had almost reached the kitchen doorway when I heard the furious sounds of her footsteps coming back towards me again.

“事实上，史蒂文斯先生，”她大声叫道，“我想请您从今往后不要再直接跟我说话了。”
‘In fact, Mr Stevens,’ she called, ‘I would ask you from now on not to speak to me directly at all.’

“肯顿小姐，您这话到底是什么意思？”
‘Miss Kenton, whatever are you talking about?’

“如果有必要传递什么信息的话，那就请您通过一位信使来传达。
‘If it is necessary to convey a message, I would ask you to do so through a messenger.

或者您也可以写一张字条，派人给我送来。
Or else you may like to write a note and have it sent to me.

这样的话，我们之间的工作关系，我肯定，将会融洽很多。”
Our working relationship, I am sure, would be made a great deal easier.’

“肯顿小姐……”
‘Miss Kenton …’

“我实在是太忙了，史蒂文斯先生。
‘I am extremely busy, Mr Stevens.

如果信息太复杂怕说不清楚的话，就请写张字条。
A written note if the message is at all complicated.

或者您愿意的话，也可以跟玛莎或多萝西讲，要不然就跟您认为值得信赖的某位男性员工讲。
Otherwise you may like to speak to Martha or Dorothy, or any members of the male staff you deem sufficiently trustworthy.

我现在必须得回去忙我的工作，只能留您一个人继续闲逛下去了。”
Now I must return to my work and leave you to your wanderings.’

肯顿小姐的行径固然令人恼怒，可我也实在无暇多想，因为那时第一批客人已经到了。
Irritating as Miss Kenton's behaviour was, I could not afford to give it much thought, for by then the first of the guests had arrived.

国外的代表预计还要两三天后才会陆续到达，不过被爵爷称作“主场团队”的三位绅士—外交部两位绝对“不宜公开”身份的公使和大卫·卡迪纳尔爵士—为了尽可能把准备工作做到位已经提早来到。
The representatives from abroad were not expected for a further two or three days, but the three gentlemen referred to by his lordship as his ‘home team’ – two Foreign Office ministers attending very much ‘off the record’ and Sir David Cardinal – had come early to prepare the ground as thoroughly as possible.

一如既往，我在出入几位绅士正坐而论道，进行深入讨论的不同房间时，他们几乎不会对我有任何避讳，于是我不免对于进展到这一阶段的整体氛围多多少少也有了一定的印象。
As ever, little was done to conceal anything from me as I went in and out of the various rooms in which these gentlemen sat deep in discussion, and I thus could not avoid gaining a certain impression of the general mood at this stage of the proceedings.

当然，爵爷和他的同僚们着重对于每一位即将与会的代表的基本情况相互间都尽可能精准地做了简要介绍；不过，他们关注的焦点都不可避免地集中在了一个人身上—也就是杜邦先生，那位法国绅士—同样重要的还有他个人可能的好恶倾向。
Of course, his lordship and his colleagues were concerned to brief each other as accurately as possible on each one of the expected participants; but overwhelmingly, their concerns centred on a single figure – that of M. Dupont, the French gentleman – and on his likely sympathies and antipathies.

实际上，有一次我走进吸烟室的时候，确信我听到其中一位绅士正在说：“欧洲的命运事实上可能全系于我们是否能在这一点上劝说杜邦先生改变他既有的观点。”
Indeed, at one point, I believe I came into the smoking room and heard one of the gentlemen saying: ‘The fate of Europe could actually hang on our ability to bring Dupont round on this point.’

也正是在这一初步讨论的阶段当中，爵爷曾信托给我一项极不寻常的任务，而正因为它的不同寻常，它才同那意义重大的一周当中发生的其他明显更加令人难忘的事件一起，至今仍深深地铭刻在我的脑海当中。
It was in the midst of these preliminary discussions that his lordship entrusted me with a mission sufficiently unusual for it to have remained in my memory to this day, alongside those other more obviously unforgettable occurrences that were to take place during that remarkable week.

达林顿勋爵特意把我叫进他的书房，我马上就看出他有点心烦意乱。
Lord Darlington called me into his study, and I could see at once that he was in a state of some agitation.

他端坐在书桌后面，像通常一样，手里捧着一本打开的大书作为遮掩—这次是本《名人录》—来来回回地翻着其中的一页。
He seated himself at his desk and, as usual, resorted to holding open a book – this time it was Who's Who – turning a page to and fro.

“哦，史蒂文斯，”他假作漠不关心地开口道，可是下面似乎就不知道该怎么继续下去了。
‘Oh, Stevens,’ he began with a false air of nonchalance, but then seemed at a loss how to continue.

我站在原地，准备一有机会就为他排忧解难。
I remained standing there ready to relieve his discomfort at the first opportunity.

爵爷继续翻弄了一会儿书页，俯下身去细看其中的一个条目，然后才说：“史蒂文斯，我也知道我想请你去做的这件事有些不合常规。”
His lordship went on fingering his page for a moment, leaned forward to scrutinize an entry, then said: ‘Stevens, I realize this is a somewhat irregular thing to ask you to do.’

“先生？”
‘Sir?’

“只是因为现在我有太多重要的事情需要操心，实在分身乏术。”
‘It's just that one has so much of importance on one's mind just now.’

“我很乐于为您效劳，先生。”
‘I would be very glad to be of assistance, sir.’

“我很抱歉向你提出这样的要求，史蒂文斯。
‘I'm sorry to bring up a thing like this, Stevens.

我知道你自己也肯定忙得不可开交。
I know you must be awfully busy yourself.

可是我又不知道究竟该如何才能妥善地解决此事。”
But I can't see how on earth to make it go away.’

我静等吩咐，而爵爷的注意力又重新回到了《名人录》上。
I waited a moment while Lord Darlington returned his attention to Who's Who.

然后他才又开了口，说话的时候头都没抬：“你应该，我想，熟谙人生的事实吧？”
Then he said, without looking up: ‘You are familiar, I take it, with the facts of life.’

“先生？”
‘Sir?’

“人生的事实，史蒂文斯。
‘The facts of life, Stevens.

男女之事。
Birds, bees.

你应该清楚的，是不是？”
You are familiar, aren't you?’

“恐怕我不太明白您的意思，先生。”
‘I'm afraid I don't quite follow you, sir.’

“就让我们摆明了说吧，史蒂文斯。
‘Let me put my cards on the table, Stevens.

大卫爵士是我多年的老友。
Sir David is a very old friend.

而且他在目前这次会议组织工作上的贡献是无可估量的。
And he's been invaluable in organizing the present conference.

要是没有他，我敢说，我们就无法确保杜邦先生会同意出席此次会议。”
Without him, I dare say, we'd not have secured M. Dupont's agreement to come.’

“的确如此，先生。”
‘Indeed, sir.’

“不过呢，史蒂文斯，大卫爵士也自有他的古怪之处。
‘However, Stevens, Sir David has his funny side.

你自己或许也已经注意到了。
You may have noticed it yourself.

他是带他的公子，雷金纳德，一起来的。
He's brought his son, Reginald, with him.

充当他的秘书。
To act as secretary.

问题是，他已经订婚了。
The point is, he's engaged to be married.

小雷金纳德，我指的是。”
Young Reginald, I mean.’

“是的，先生。”
‘Yes, sir.’

“最近五年以来，大卫爵士一直试图告诉他的公子一些人生的基本事实。
‘Sir David has been attempting to tell his son the facts of life for the last five years.

这位年轻人已经二十三岁了。”
The young man is now twenty-three.’

“的确如此，先生。”
‘Indeed, sir.’

“我就有话直说了，史蒂文斯。
‘I'll get to the point, Stevens.

我碰巧是这位年轻人的教父。
I happen to be the young man's godfather.

所以呢，大卫爵士就请求我来负责向小雷金纳德传达有关的人生事实。”
Accordingly, Sir David has requested that I convey to young Reginald the facts of life.’

“的确如此，先生。”
‘Indeed, sir.’

“大卫爵士本人发现这是个颇为艰巨的任务，他怀疑自己在雷金纳德的大婚之日前恐怕是完不成这个任务了。”
‘Sir David himself finds the task rather daunting and suspects he will not accomplish it before Reginald's wedding day.’

“的确如此，先生。”
‘Indeed, sir.’

“问题是，史蒂文斯，我也忙得分身乏术啊。
‘The point is, Stevens, I'm terribly busy.

对此大卫爵士应该是知道的，但他仍旧来求我帮忙。”
Sir David should know that, but he's asked me none the less.’

爵爷停顿了一下，又继续去研究面前的书页了。
His lordship paused and went on studying his page.

“您的意思是不是，先生，”我接过话头，“希望我来向这位年轻的绅士传达这方面的信息？”
‘Do I understand, sir,’ I said, ‘that you wish me to convey the information to the young gentleman?’

“如果你不介意的话，史蒂文斯。
‘If you don't mind, Stevens.

这会让我如释重负的。
Be an awful lot off my mind.

大卫爵士每隔一两个钟头就会问我是不是已经跟他的公子讲解过了。”
Sir David continues to ask me every couple of hours if I've done it yet.’

“我明白，先生。
‘I see, sir.

这在目前的压力之下肯定是很令人心烦的。”
It must be most trying under the present pressures.’

“当然，这已经远远超出了你的职责范围，史蒂文斯。”
‘Of course, this is far beyond the call of duty, Stevens.’

“我会尽力而为的，先生。
‘I will do my best, sir.

可是要找到合适的时机来传达这样的信息，恐怕会有一定的困难。”
I may, however, have difficulty finding the appropriate moment to convey such information.’

“你只要愿意一试，我已经是感激不尽了，史蒂文斯。
‘I’d be very grateful if you'd even try, Stevens.

你真是太乐于助人了。
Awfully decent of you.

听我说，没必要小题大做。
Look here, there's no need to make a song and dance of it.

只需传递基本的事实就够了。
Just convey the basic facts and be done with it.

简单明了就是最好的方式，这是我的建议，史蒂文斯。”
Simple approach is the best, that's my advice, Stevens.’

“是的，先生。
‘Yes, sir.

我将尽力而为。”
I shall do my best.’

“真是感激不尽，史蒂文斯。
‘Jolly grateful to you, Stevens.

请把进展的情况告诉我。”
Let me know how you get on.’

您或许也能想象得到，我对于这一要求还是感到有点错愕的，而且放在平时，碰上这种事我一定会花上一点时间好好琢磨一下的。
I was, as you might imagine, a little taken aback by this request and ordinarily the matter might have been one I would have spent some time pondering.

然后，这次却是在如此繁忙的节骨眼上突然降临到我头上来的，我可没那么多时间腾出来专门让它来占用，于是我决定一找到机会就速战速决。
Coming upon me as it did, however, in the midst of such a busy period, I could not afford to let it preoccupy me unduly, and I thus decided I should resolve it at the earliest opportunity.

我记得就在我接受这个任务不过一个钟头左右，就注意到小卡迪纳尔先生独自一人待在藏书室里，他正端坐在一张写字台后面，埋头于几份文件当中。
As I recall, then, it was only an hour or so after being first entrusted with the mission that I noticed the young Mr Cardinal alone in the library, sitting at one of the writing tables, absorbed in some documents.

只要近距离地仔细观察一下这位年轻绅士，也就能体会爵爷—当然还有这位年轻绅士的尊亲为什么会知难而退了。
On studying the young gentleman closely, one could, as it were, appreciate the difficulty experienced by his lordship – and indeed, by the young gentleman's father.

我主人的这位教子一看就是一位态度诚恳、学究气十足的年轻人，五官清秀正派；可是碰上这样一个话题，你倒是宁肯对方更加轻松快活一点才好，甚而至于宁肯他是那种有些轻浮之气的年轻绅士。
My employer's godson looked an earnest, scholarly young man, and one could see many fine qualities in his features; yet given the topic one wished to raise, one would have certainly preferred a lighter-hearted, even a more frivolous sort of young gentleman.

不管怎么说，既然已经决定了要快刀斩乱麻，我也就硬着头皮走进藏书室，在离卡迪纳尔先生的写字台不远处停下脚步，轻轻咳嗽了一声。
In any case, resolved to bring the whole matter to a satisfactory conclusion as quickly as possible, I proceeded further into the library, and stopping a little way from Mr Cardinal's writing desk, gave a cough.

“打搅了，先生，我有个口信要转达给您。”
‘Excuse me, sir, but I have a message to convey to you.’

“哦，是吗？”
‘Oh, really?’

卡迪纳尔先生急切地道，把目光从那些文件上抬了起来。
Mr Cardinal said eagerly, looking up from his papers.

“是家父的口信吗？”
‘From Father?’

“是的，先生。
‘Yes, sir.

也可以这么认为吧。”
That is, effectively.’

“请稍等。”
‘Just a minute.’

这位年轻绅士伸手从脚边的公文包里取出笔记本和铅笔。
The young gentleman reached down to the attaché case at his feet and brought out a notebook and pencil.

“请讲吧，史蒂文斯。”
‘Fire away, Stevens.’

我又轻咳了一声，尽可能保持一种就事论事的语气。
I coughed again and set my voice into as impersonal a tone as I could manage.

“大卫爵士希望您能知晓，先生，女士和绅士们在几个关键的地方是大为不同的。”
‘Sir David wishes you to know, sir, that ladies and gentlemen differ in several key respects.’

我在构思下句话的措辞时想必是停顿了片刻，因为卡迪纳尔先生这时叹了一口气，说：“对此我真是再清楚不过了，史蒂文斯。
I must have paused a little to form my next phrase, for Mr Cardinal gave a sigh and said: ‘I'm only too aware of that, Stevens.

就请你有话直说好吗？”
Would you mind coming to the point?’

“您已经很清楚了，先生？”
‘You are aware, sir?’

“家父总是低估了我的能力。
‘Father is perpetually underestimating me.

对这整个领域我已经进行过广泛的阅读和扎实的基础研究工作。”
I've done extensive reading and background work on this whole area.’

“真的吗，先生？”
‘Is that so, sir?’

“在过去这整整一个月里，除此以外我实际上就没考虑过其他的事情。”
‘I’ve thought about virtually nothing else for the past month.’

“是吗，先生。
‘Really, sir.

既然如此，我要传达的这个口信或许就是多余的了。”
In that case, perhaps my message is rather redundant.’

“你可以向家父保证，对于基本的情况我已经做到了充分的了解。
‘You can assure Father I'm very well briefed indeed.

这个公文包，”—他用脚碰了一下那个公文包—“就塞满了我对于但凡能够想到的每个可能的角度所做的笔记。”
This attaché case’ – he nudged it with his foot – ‘is chock-full of notes on every possible angle one can imagine.’

“真的吗，先生？”
‘Is that so, sir?’

“我真的认为我已经充分考虑到了人类的大脑所能想到的每一种排列组合方式。
‘I really think I've thought through every permutation the human mind is capable of.

希望你转告家父，请他但放宽心。”
I wish you'd reassure Father of that.’

“我会的，先生。”
‘I will, sir.’

卡迪纳尔先生显得轻松了一些。
Mr Cardinal seemed to relax a little.

他又碰了碰那个公文包—我很想把眼睛别开，不去看它—然后说道：“我猜你也一直都纳闷为什么这个公文包我从不离手。
He prodded once more his attaché case – which I felt inclined to keep my eyes averted from – and said: ‘I suppose you've been wondering why I never let go of this case.

好了，现在你知道了。
Well, now you know.

想想要是给不该打开的人打开了会有什么样的结果吧。”
Imagine if the wrong person opened it.’

“那可就不能再尴尬了，先生。”
‘That would be most awkward, sir.’

“可不是嘛，”他说，突然又把身子坐直了，“除非家父又想出了什么全新的因素，希望我进一步斟酌考虑。”
‘That is, of course,’ he said, sitting up again suddenly, ‘unless Father has come up with an entirely new factor he wants me to think about.’

“我想不大可能会有了，先生。”
‘I cannot imagine he has, sir.’

“没有吗？
‘No?

关于这位杜邦伙计就再也没有更多的资讯了吗？”
Nothing more on this Dupont fellow?’

“恐怕是没有了，先生。”
‘I fear not, sir.’

我竭尽所能不流露出丝毫恼怒的情绪：原本以为已经圆满解决了的难题，这才发现实际上根本就还是原封未动地摆在我面前。
I did my best not to give away anything of my exasperation on discovering that a task I had thought all but behind me was in fact still there unassaulted before me.

我相信我正集中思想，准备重整旗鼓的时候，那位年轻的绅士突然间站起身来，一把抓起他的公文包，说：“好了，我想我该去呼吸点新鲜空气了。
I believe I was collecting my thoughts for a renewed effort when the young gentleman suddenly rose to his feet and clutching his attaché case to his person, said: ‘Well, I think I'll go and take a little fresh air.

多谢你的帮忙，史蒂文斯。”
Thanks for your help, Stevens.’

我本想在最短的时间内就另找机会再跟他谈一次的，可是实际证明已经是不可能了，主要是因为当天下午—比预定的时间早了足足有两天—美国的参议员刘易斯先生就到了。
It had been my intention to seek out a further interview with Mr Cardinal with minimum delay, but this proved to be impossible, owing largely to the arrival that same afternoon – some two days earlier than expected – of Mr Lewis, the American senator.

当时我正在楼下的餐具室里核对供货的清单，突然听到上头传来无可置疑的好几辆汽车驶进庭院停下来的声音。
I had been down in my pantry working through the supplies sheets, when I had heard somewhere above my head the unmistakable sounds of motor cars pulling up in the courtyard.

我赶忙上楼去的时候，在后廊里碰巧遇到了肯顿小姐—当然也就是我们上次不欢而散的同一场景—而或许正是这一令人不快的巧合促使她继续采用了跟上次一样的幼稚举动。
As I hastened to go upstairs, I happened to encounter Miss Kenton in the back corridor – the scene, of course, of our last disagreement – and it was perhaps this unhappy coincidence that encouraged her to maintain the childish behaviour she had adopted on that previous occasion.

因为在我问她是谁到了的时候，肯顿小姐径直地继续走她的路，只丢下一句话：“如果事态紧急就请人传个口信，史蒂文斯先生。”
For when I inquired who it was that had arrived, Miss Kenton continued past me, stating simply: ‘A message if it is urgent, Mr Stevens.’

这实在太令人恼火了，不过当然了，我别无选择，只能赶紧往楼上跑去。
This was extremely annoying, but, of course, I had no choice but to hurry on upstairs.

在我的印象中刘易斯先生是位人高马大的绅士，脸上总是挂着亲切的笑容。
My recollection of Mr Lewis is that of a gentleman of generous dimensions with a genial smile that rarely left his face.

他的早到显然给爵爷和他的同僚们带来了不便，因为他们原指望还有一两天的独处时间可以比较充分地做好准备的。
His early arrival was clearly something of an inconvenience to his lordship and his colleagues who had reckoned on a day or two more of privacy for their preparations.

不过，刘易斯先生那不拘小节、令人愉快的举止态度，以及他在餐桌上的一番表态—美国“将永远站在正义的一方，为此而不惜承认凡尔赛已经铸成的错误”—却大大赢得了爵爷那“主场团队”的信任；随着酒过三巡菜过五味，席间的交谈已经慢慢地从诸如刘易斯先生的家乡宾州的诸多优点这样的话题，明确地转回到即将召开的会议上，而等到饭毕绅士们悠然点起雪茄的时候，他们提出来的某些深思熟虑的意见已经跟刘易斯先生到来前只在他们之间私下交流的看法同样私密了。
However, Mr Lewis's engagingly informal manner, and his statement at dinner that the United States ‘would always stand on the side of justice and didn't mind admitting mistakes had been made at Versailles’ seemed to do much to win the confidence of his lordship's ‘home team’; as dinner progressed, the conversation had slowly but surely turned from topics such as the merits of Mr Lewis's native Pennsylvania back to the conference ahead, and by the time the gentlemen were lighting their cigars, some of the speculations being offered appeared to be as intimate as those exchanged prior to Mr Lewis's arrival.

其间，刘易斯先生曾对在座的诸公说道：
At one point, Mr Lewis said to the company:

“先生们，我同意你们的看法，我们这位杜邦先生可能是位非常难以逆料的人物。
‘I agree with you, gentlemen, our M. Dupont can be very unpredictable.

不过容我告诉诸位，关于他至少有一点是肯定的，可以说有十足的把握。”
But let me tell you, there's one thing you can bet on about him. One thing you can bet on for sure.’

他俯身向前，挥动着雪茄以示强调。
He leaned forward and waved his cigar for emphasis.

“杜邦憎恨德国人。
‘Dupont hates Germans.

在战前他就憎恨他们，而如今更是变本加厉，他仇视德国人的程度之深恐怕是在座的诸位先生所难以理解的。”
He hated them before the war and he hates them now with a depth you gentlemen here would find hard to understand.’

说完这句话后，刘易斯先生再次靠回到椅背上，脸上重又堆满亲切的笑容。
With that, Mr Lewis sat back in his chair again, the genial smile returning fully to his face.

“不过请告诉我，诸位先生，”他继续道，“你很难因为一个法国人憎恨德国人而责怪于他，是也不是？
‘But tell me, gentlemen,’ he continued, ‘you can hardly blame a Frenchman for hating the Germans, can you?

毕竟，法国人这么做也是有其正当理由的，是也不是？”
After all, a Frenchman has good cause to do so, hasn't he?’

说完，刘易斯先生环顾了一下餐桌边就座的几位绅士，一时间气氛略有些尴尬。
There was a moment of slight awkwardness as Mr Lewis glanced around the table.

这时达林顿勋爵说道：
Then Lord Darlington said:

“有些怨恨当然是在所难免的。
‘Naturally, some bitterness is inevitable.

可是话又说回来了，我们英国人也曾跟德国人进行过长期的苦战。”
But then, of course, we English also fought the Germans long and hard.’

“不过你们英国人又自不同了，”刘易斯先生道，“貌似你们已经不再真心憎恨德国人了。
‘But the difference with you Englishmen,’ Mr Lewis said, ‘seems to be that you don't really hate the Germans any more.

但法国人是这样看的：德国人毁灭了欧洲的整个文明，再怎么惩罚他们都不为过。
But the way the French see it, the Germans destroyed civilization here in Europe and no punishment is too bad for them.

当然了，这在我们美国人看来未免不切实际，不过我们一直感到困惑的倒是你们英国人为什么没有跟法国人持相同的观点。
Of course, that looks an impractical kind of position to us in the United States, but what's always puzzled me is how you English don't seem to share the view of the French.

毕竟，诚如您刚才所说，不列颠在那场战争中也损失惨重。”
After all, like you say, Britain lost a lot in that war too.’

餐桌上又是一段尴尬的沉默，大卫爵士这才相当不确定地说：
There was another awkward pause before Sir David said, rather uncertainly:

“我们英国人在看待事物的方式上经常跟法国人有所不同，刘易斯先生。”
‘We English have often had a different way of looking at things from the French, Mr Lewis.’

“啊，一种性情上的不同，您也许可以这么说。”
‘Ah. A kind of temperamental difference, you might say.’

刘易斯先生在说这句话时脸上的笑意似乎又加深了一点。
Mr Lewis's smile seemed to broaden slightly as he said this.

他顾自点了点头，仿佛很多问题对他而言已经迎刃而解了，然后就抽起了雪茄。
He nodded to himself, as though many things had now become clear to him, and drew on his cigar.

也可能是后见之明影响了我的记忆，不过我有一种明确的感觉：就是在那一刻我第一次在这位表面看来非常迷人的美国绅士身上觉察到某种古怪的，或许是某种两面三刀的东西。
It is possible this is a case of hindsight colouring my memory, but I have a distinct feeling that it was at that moment I first sensed something odd, something duplicitous perhaps, about this apparently charming American gentleman.

不过，就算我当真是在那一刻起了疑心，达林顿勋爵却显然是居之不疑。
But if my own suspicions were aroused at that moment, Lord Darlington evidently did not share them.

因为在又一次一两秒钟的尴尬沉默之后，爵爷似乎下定了决心。
For after another second or two of awkward silence, his lordship seemed to come to a decision.

“刘易斯先生，”他道，“让我开诚布公地说吧。
‘Mr Lewis,’ he said, ‘let me put it frankly.

我们大部分英国人都认为法国人目前的态度是有些可鄙的。
Most of us in England find the present French attitude despicable.

您当然也许会称其为一种性情上的不同，不过容我冒昧地说一句，我们现在要讨论的却远非这一点东西而已。
You may indeed call it a temperamental difference, but I venture we are talking about something rather more.

在冲突已经结束以后，再继续这样地仇视敌人是一种很不得体的行为。
It is unbecoming to go on hating an enemy like this once a conflict is over.

一旦你已经把一个人打倒在地上，就应该到此为止。
Once you've got a man on the canvas, that ought to be the end of it.

你就不能再继续对他拳打脚踢了。
You don't then proceed to kick him.

在我们看来，法国人的行为已经变得越来越像野蛮人了。”
To us, the French behaviour has become increasingly barbarous.’

这番言辞似乎让刘易斯先生感到了某种程度的满意。
This utterance seemed to give Mr Lewis some satisfaction.

他咕哝了一句什么话表示赞同，并透过餐桌上面已经相当浓厚的雪茄烟云冲着几位共同用餐的绅士满意地微微一笑。
He muttered something in sympathy and smiled with contentment at his fellow diners through the clouds of tobacco smoke by now hanging thickly across the table.

第二天早上，又有更多的客人提前到达；就是来自德国的那两位女士—尽管大家都会觉得她们出身背景悬殊，两人居然是结伴同行的—随行的有一大群男女仆从，以及数不胜数的行李箱。
The next morning brought more early arrivals; namely, the two ladies from Germany – who had travelled together despite what one would have imagined to have been the great contrast in their backgrounds – bringing with them a large team of ladies-in-waiting and footmen, as well as a great many trunks.

下午的时候，一位意大利绅士也先期抵达，有一位贴身男仆、一位秘书、一位“专家”以及两位保镖随侍左右。
Then in the afternoon, an Italian gentleman arrived accompanied by a valet, a secretary, an ‘expert’ and two bodyguards.

我无法想象这位绅士究竟以为来到的是什么地方，竟然特意带来了保镖，不过我必须得说，在达林顿府看到有这么两位身材魁伟、一声不吭的壮汉，无论那位意大利绅士出现在哪里他们都如影随形，时刻以怀疑的目光警觉地窥伺着周围数码内的动静，这实在算得上是诡异的一景。
I cannot imagine what sort of place this gentleman imagined he was coming to in bringing the latter, but I must say it struck something of an odd note to see in Darlington Hall these two large silent men staring suspiciously in all directions a few yards from wherever the Italian gentleman happened to be.

顺带说一句，在这之后的几天当中我们才得知，这两位保镖的工作模式是两人轮流休息，以确保整个夜里至少有一位在主人身旁当值。
Incidentally, the working pattern of these bodyguards, so it transpired over the following days, entailed one or the other of them going up to sleep at unusual hours so as to ensure at least one was on duty throughout the night.

我在刚听说这一安排以后就想马上知会肯顿小姐，以便她能相机做出安排，可是她再次拒绝跟我交谈，为了尽快落实此事，我也只得勉为其难地写了张字条，把它塞进了她起坐间的门下。
But when on first hearing of this arrangement I tried to inform Miss Kenton of it, she once again refused to converse with me, and in order to accomplish matters as quickly as possible I was actually obliged to write a note and put it under the door of her parlour.

第二天，又有几位客人到达，距离正式的会期足足还有两天的时间，而达林顿府已经挤满了各个国家的客人，要么聚在房间里闲谈，要么无所事事地闲逛，在门厅里、走廊上和楼梯平台上，细看墙上的画作和各种饰品。
The following day brought several more guests and with two days yet to go to the start of the conference, Darlington Hall was filled with people of all nationalities, talking in rooms, or else standing around, apparently aimlessly, in the hall, in corridors and on landings, examining pictures or objects.

客人们相互间当然都以礼相待，尽管如此，这一阶段却似乎弥漫着一种相当紧张的气氛，主要的原因是缺乏互信。
The guests were never less than courteous to one another, but for all that, a rather tense atmosphere, characterized largely by distrust, seemed to prevail at this stage.

这种焦躁不安的气氛也表现在随行的贴身男仆和仆佣相互之间那明显的冷淡态度上，我自己的员工则很高兴由于过于忙碌而无暇跟他们过多地打交道。
And reflecting this unease, the visiting valets and footmen appeared to regard one another with marked coldness and my own staff were rather glad to be too busy to spend much time with them.

正是在这个节骨眼上，面对各路要求应接不暇之际，我偶然往窗外一瞥，发现了小卡迪纳尔先生的身影，他应该正在庭院里呼吸新鲜空气。
It was around this point, in the midst of dealing with the many demands being made on my attention, that I happened to glance out of a window and spotted the figure of the young Mr Cardinal taking some fresh air around the grounds.

他一如既往地紧紧夹着自己的公文包，正沿着环绕草坪的小径缓步闲行，深深地陷在思绪当中。
He was clutching his attaché case as usual and I could see he was strolling slowly along the path that runs the outer perimeter of the lawn, deeply absorbed in thought.

我当然会想起对于这位年轻绅士，我还有任务没有完成，而且我灵机一动，感觉户外的环境因为可以亲近大自然，尤其是旁边还有鹅群可以拿来当作实例，倒不失为是传递我肩负的那类信息的理想场合。
I was of course reminded of my mission regarding the young gentleman and it occurred to me that an outdoor setting, with the general proximity of nature, and in particular the example of the geese close at hand, would not be an unsuitable setting at all in which to convey the sort of message I was bearing.

而且我还看出，如果我现在就快步走出去，藏身于小径旁边那高大的杜鹃花丛背后守株待兔，很快就能等到卡迪纳尔先生从我身边路过。
I could see, moreover, that if I were quickly to go outside and conceal my person behind the large rhododendron bush beside the path, it would not be long before Mr Cardinal came by.

到了那时，我就可以现身出来，向他传达我的信息。
I would then be able to emerge and convey my message to him.

这诚然算不上什么无比精妙的谋略，可是话又说回来了，你也得承认这个任务固然有其自身的重要性，可是在那个节骨眼上却怎么也算不上最该优先考虑的要事。
It was not, admittedly, the most subtle of strategies, but you will appreciate that this particular task, though no doubt important in its way, hardly took the highest priority at that moment.

地面和多数植物的叶子上都笼罩着一层薄霜，不过对于一年当中的这个时节来说，那算得上是温煦的一天。
There was a light frost covering the ground and much of the foliage, but it was a mild day for that time of the year.

我快步穿过草坪，藏身于灌木花丛之后，不久就听到卡迪纳尔先生的脚步声近了。
I crossed the grass quickly, placed my person behind the bush, and before long heard Mr Cardinal's footsteps approaching.

不幸的是我稍稍估错了现身的时机。
Unfortunately, I misjudged slightly the timing of my emergence.

我原打算在卡迪纳尔先生距我的藏身之处尚有一段距离的时候就从树丛后出来的，那样他就会提早看到我，以为我正要前往凉亭，或者也许是园丁的小屋。
I had intended to emerge while Mr Cardinal was still a reasonable distance away, so that he would see me in good time and suppose I was on my way to the summerhouse, or perhaps to the gardener's lodge.

这样的话我就能假装是意外撞见了他，如此，便能赋予我们的谈话以一种临时起意的意味。
I could then have pretended to notice him for the first time and have engaged him in conversation in an impromptu manner.

结果却是我出来得稍晚了一点，恐怕真是吓了那位年轻绅士一跳，他马上把那宝贝公文包拿得离我远远的，用两条胳膊紧紧地抱在胸前。
As it happened, I emerged a little late and I fear I rather startled the young gentleman, who immediately pulled his attaché case away from me and clutched it to his chest with both arms.

“我非常抱歉，先生。”
‘I'm very sorry, sir.’

“我的天哪，史蒂文斯。
‘My goodness, Stevens.

你吓了我一大跳。
You gave me a shock.

我还以为发生了什么不测呢。”
I thought things were hotting up a bit there.’

“非常抱歉，先生。
‘I'm very sorry, sir.

不过我碰巧有件事要向您转达。”
But as it happens, I have something to convey to you.’

“我的天哪，好吧，你可真是把我吓了一跳。”
‘My goodness, yes, you gave me quite a fright.’

“那就容我有话直说了，先生。
‘If I may come straight to the point, sir.

您会注意到在我们的不远处有几只鹅。”
You will notice the geese not far from us.’

“鹅？”
‘Geese?’

他有些困惑地四顾一望。
He looked around a little bewildered.

“哦，是的。
‘Oh yes.

还确实有几只鹅。”
That's what they are.’

“同样的，还有鲜花和灌木。
‘And likewise the flowers and shrubs.

事实上，现在并非它们一年当中的鼎盛时节，不过您自然明白，先生，随着春天的到来，我们将会看到周围的环境发生一种改变—一种非常特别的改变。”
This is not, in fact, the best time of year to see them in their full glory, but you will appreciate, sir, that with the arrival of spring, we will see a change – a very special sort of change – in these surroundings.’

“是的，我确信现在的庭院并非它们最美的时节。
‘Yes, I'm sure the grounds are not at their best just now.

可是跟你实话实说吧，史蒂文斯，我其实并不太留意大自然的美好。
But to be perfectly frank, Stevens, I wasn't paying much attention to the glories of nature.

眼下的事态实在令人忧心忡忡。
It's all rather worrying.

杜邦先生是满怀能够想象得到的最恶劣的心绪来到这里的。
That M. Dupont's arrived in the foulest mood imaginable.

这也是我们最不想见到的情形。”
Last thing we wanted really.’

“杜邦先生已经来到了这里，先生？”
‘M. Dupont has arrived here at this house, sir?’

“大约半小时前。
‘About half an hour ago.

情绪简直坏透了。”
He's in the most foul temper.’

“那抱歉了，先生。
‘Excuse me, sir.

我必须马上去招待他了。”
I must attend to him straight away.’

“那是自然，史蒂文斯。
‘Of course, Stevens.

呃，感谢你特意出来跟我聊天。”
Well, kind of you to have come out to talk to me.’

“请您原谅，先生。
‘Please excuse me, sir.

关于这个方面—也就是您所谓的大自然的美好，我碰巧还有一两句话要跟您说。
As it happened, I had a word or two more to say on the topic of – as you put it yourself – the glories of nature.

如果您肯屈尊听我唠叨几句的话，我将不胜感激之至。
If you will indulge me by listening, I would be most grateful.

不过恐怕这得等下次找机会再说了。”
But I am afraid this will have to wait for another occasion.’

“好的，我愿闻其详，史蒂文斯。
‘Well, I shall look forward to it, Stevens.

虽然我个人更偏爱鱼类。
Though I'm more of a fish man myself.

对于鱼类我可以说是无所不知，不管是淡水的还是咸水的。”
I know all about fish, fresh water and salt.’

“所有的生命都跟我们预期中的讨论息息相关，先生。
‘All living creatures will be relevant to our forthcoming discussion, sir.

不过，我必须向您告退了。
However, you must now please excuse me.

我都不知道杜邦先生已经到了。”
I had no idea M. Dupont had arrived.’

我匆忙返回室内，迎头撞到的第一男仆忙不迭地跟我说：“我们正四处找您呢，先生。
I hurried back to the house to be met immediately by the first footman saying: ‘We’ve been looking all over for you, sir.

那位法国绅士已经到了。”
The French gentleman's arrived.’

杜邦先生是位个头高挑、举止优雅的绅士，蓄着灰白的胡须，戴着单片眼镜。
M. Dupont was a tall, elegant gentleman with a grey beard and a monocle.

抵达时他穿的是一身人们经常看到欧陆士绅们度假时穿的那种服饰，确实，他在整个逗留期间，都始终刻意地保持着一副他完全是出于游赏和交情才会来到达林顿府的架势。
He had arrived in the sort of clothes one often sees continental gentlemen wearing on their holidays, and indeed, throughout his stay, he was to maintain diligently the appearance of having come to Darlington Hall entirely for pleasure and friendship.

正如卡迪纳尔先生指出的，杜邦先生抵达的时候情绪不佳；现在我已经记不清楚在他来到英国的这几天里到底都有什么事情惹得他不开心了，不过最让他难过的应该是他在伦敦观光时脚上就磨起来的几个痛疮，而且他很担心它们会化脓感染。
As Mr Cardinal had indicated, M. Dupont had not arrived in a good temper; I cannot recall now all the various things that had upset him since his arrival in England a few days previously, but in particular he had obtained some painful sores on his feet while sightseeing around London and these, he feared, were growing septic.

我知会他的贴身男仆有事可以找肯顿小姐帮忙，可是这并没有妨碍杜邦先生每隔几个钟头就冲着我打一下响指，跟我说：“管家！
I referred his valet to Miss Kenton, but this did not prevent M. Dupont snapping his fingers at me every few hours to say: ‘Butler!

我还需要一些绷带。”
I am in need of more bandages.’

见到刘易斯先生以后，他的情绪明显地大为改观。他跟这位美国参议员相互就像老同事那样亲热地打招呼，而且在那天剩余的大部分时间里，他们俩都待在一起开心地谈笑忆旧。
His mood seemed much lifted on seeing Mr Lewis. He and the American senator greeted each other as old colleagues and they were to be seen together for much of the remainder of the day, laughing over reminiscences.

事实上，明眼人都看得出来，刘易斯先生跟杜邦先生这么几乎寸步不离其实对于达林顿勋爵造成了极大的不便，因为爵爷自然是切望能够在讨论正式开始前，先跟这位著名的人物进行一番密切的个人接触的。
In fact, one could see that Mr Lewis's almost constant proximity to M. Dupont was proving a serious inconvenience to Lord Darlington, who was naturally keen to make close personal contact with this distinguished gentleman before the discussions began.

在几个场合，我都亲眼见到爵爷试图把杜邦先生拉到一边好私下里说几句话的，可是刘易斯先生却每次都故意插进来作梗，笑嘻嘻地说一句类似这样的话：“请原谅，先生们，但是有件事让我百思不得其解。”如此一来，爵爷很快就发现自己不得不去听刘易斯先生讲他更多的趣闻轶事了。
On several occasions I witnessed his lordship make attempts to draw M. Dupont aside for some private conversation, only for Mr Lewis smilingly to impose himself upon them with some remark like: ‘Pardon me, gentlemen, but there's something that's been greatly puzzling me,’ so that his lordship soon found himself having to listen to some more of Mr Lewis's jovial anecdotes.

不过除了刘易斯先生之外，其他的客人或许是出于敬畏，或许是因为敌意，都刻意地跟杜邦先生保持距离；这一点即便是在当时普遍都心怀戒备的气氛下都显而易见，而这也似乎更加凸显了这样一种感觉，即杜邦先生果然是能够左右未来数日会议的最终成果的关键人物。
Mr Lewis apart, however, the other guests, perhaps through awe, perhaps through a sense of antagonism, kept a wary distance from M. Dupont, a fact that was conspicuous even in that generally guarded atmosphere, and which seemed to underline all the more the feeling that it was M. Dupont who somehow held the key to the outcome of the following days.

会议在一九二三年三月最后一周的一个下雨的早上正式召开，为了顾及很多与会者“不宜公开”的性质，会场特意设在会客厅这样一个有些超乎想象的地方。
The conference began on a rainy morning during the last week of March 1923 in the somewhat unlikely setting of the drawing room – a venue chosen to accommodate the ‘off the record’ nature of many of the attendances.

事实上，在我看来，这种“非正式”的做派已经达到了稍显滑稽的程度。
In fact, to my eyes, the appearance of informality had been taken to a faintly ludicrous degree.

这样一个相当女性化的房间里挤满了这么多表情严峻、一身深色正装的绅士，有的沙发上一下子并肩坐了三四个人，这一场景本身就够古怪的了；而且有的与会者又是如此坚决地一定要维持一种“这不过是次社交活动”的表象，居然到了不惜为此而将一份打开的报章杂志故意摊放在膝头上的程度。
It was odd enough to see that rather feminine room crammed full with so many stern, dark-jacketed gentlemen, sometimes sitting three or four abreast upon a sofa; but such was the determination on the part of some persons to maintain the appearance that this was nothing more than a social event that they had actually gone to the lengths of having journals and newspapers open on their knees.

在第一个上午的会议进程中我因为不得不频繁出入于会客厅，所以无法完全跟进会议的整个过程。
I was obliged during the course of that first morning to go constantly in and out of the room, and so was unable to follow the proceedings at all fully.

不过我记得达林顿勋爵的开场白是首先正式欢迎各位嘉宾的莅临，然后就概述了一下需要放宽《凡尔赛和约》诸多条款的苛酷规定这一强烈的道德诉求的基本内涵，强调指出了他亲眼目睹的德国人民正在承受的巨大苦难。
But I recall Lord Darlington opening the discussions by formally welcoming the guests, before going on to outline the strong moral case for a relaxing of various aspects of the Versailles treaty, emphasizing the great suffering he had himself witnessed in Germany.

当然，这同样的感想我之前已经在很多场合听爵爷表达过了，可是他在这个庄严的场景中的发言句句出自肺腑，是如此令人信服，我不禁再次为之而动容。
Of course, I had heard these same sentiments expressed by his lordship on many occasions before, but such was the depth of conviction with which he spoke in this august setting that I could not help but be moved afresh.

大卫·卡迪纳尔爵士接下来发言，虽然我错过了他发言的大部分内容，不过感觉基本上更偏重技术性的层面，而且坦白说我觉得是有些高深莫测。
Sir David Cardinal spoke next, and though I missed much of his speech, it seemed to be more technical in substance, and quite frankly, rather above my head.

不过其基本的要旨似乎与爵爷的意思非常接近，他的讲话以呼吁不要让德国再继续赔款以及法国军队撤出鲁尔区做结。
But his general gist seemed to be close to his lordship's, concluding with a call for a freezing of German reparation payments and the withdrawal of French troops from the Ruhr region.

那位德国伯爵夫人紧接着发言，不过这个时候我不得不离开会客厅相当长一段时间，具体原因已经不记得了。
The German countess then began to speak, but I was at this point, for some reason I do not recollect, obliged to leave the drawing room for an extended period.

等我再次进去的时候，来宾们已经开始进行开放式的讨论，而这些讨论的内容—大部分是关于商业贸易和金融利率的—就不是我能理解得了的了。
By the time I reentered, the guests were in open debate, and the discussion – with much talk of commerce and interest rates – was quite beyond me.

至少据我的观察而言，杜邦先生并没有参与到讨论当中，从他那闷闷不乐的行为举止上也很难看出他到底是在认真倾听别人的发言呢，还是全神贯注在别的思绪当中。
M. Dupont, so far as I could observe, was not contributing to the discussions, and it was hard to tell from his sullen demeanour if he was attending carefully to what was being said or else deeply engrossed in other thoughts.

在某个阶段，我碰巧在一位德国绅士的发言中间有事要离开，杜邦先生也突然站起身来，跟我一起走了出来。
At one stage, when I happened to depart the room in the midst of an address by one of the German gentlemen, M. Dupont suddenly rose and followed me out.

“管家，”我们一走进门厅他就说道，“不知道能不能叫人帮我换换脚上的纱布。
‘Butler,’ he said, once we were in the hall, ‘I wonder if I could have my feet changed.

它们现在搞得我不舒服极了，根本就听不进那些绅士们在说些什么了。”
They are giving me so much discomfort now, I can hardly listen to these gentlemen.’

我记得，我在请求肯顿小姐给予协助以后—自然是派人送去的口信—就把杜邦先生安置在弹子房里坐等护士的到来，正在这时第一男仆急匆匆地从楼梯上奔下来，面带痛苦的神情告诉我家父在楼上病倒了。
As I recall, I had conveyed a plea to Miss Kenton for assistance – via a messenger, naturally – and had left M. Dupont sitting in the billiard room awaiting his nurse, when the first footman had come hurrying down the staircase in some distress to inform me that my father had been taken ill upstairs.

我匆忙朝二楼跑去，刚转过楼梯口，就看到了一幅奇怪的景象。
I hurried up to the first floor and on turning at the landing was met by a strange sight.

在走廊的尽头，几乎就正在那扇大窗户前面，映着灰蒙蒙的光线和窗外的雨景，家父定格在一个姿势当中，就好像正在参加某种庄严的仪式一般。
At the far end of the corridor, almost in front of the large window, at that moment filled with grey light and rain, my father's figure could be seen frozen in a posture that suggested he was taking part in some ceremonial ritual.

他单膝跪地，脑袋低垂，好像正在奋力推着面前那辆手推车，而那辆小车不知何故竟顽固地纹丝不动。
He had dropped down on to one knee and with head bowed seemed to be pushing at the trolley before him, which for some reason had taken on an obstinate immobility.

两位卧房的女仆表示尊敬地离开一段距离，面带敬畏的神情注视着他所做出的努力。
Two chambermaids were standing at a respectful distance, watching his efforts in some awe.

我走到家父面前，把他紧抓在手推车边缘的手松开，扶着他在地毯上躺下来。
I went to my father and releasing his hands from their grip on the edge of the trolley, eased him down on to the carpet.

他双目紧闭，面如死灰，前额上满是汗珠。
His eyes were closed, his face was an ashen colour, and there were beads of sweat on his forehead.

我叫人前来帮忙，及时搬来了一辆带篷的轮椅，家父就被转移到了他自己的房间。
Further assistance was called, a bath-chair arrived in due course, and my father was transported up to his room.

将家父安置在床上以后，我一时间颇有些手足无措，不知道接下来该如何是好；因为家父正处在这种情况下，我就这么一走了之实在不合情理，但我又真是一点空余时间都匀不出来。
Once my father had been laid in his bed, I was a little uncertain as to how to proceed; for while it seemed undesirable that I leave my father in such a condition, I did not really have a moment more to spare.

正当我站在门口踌躇不决之际，肯顿小姐出现在了我身旁，并且说道：“史蒂文斯先生，在目前这种情况下，我比您还稍微多那么点空余时间。
As I stood hesitating in the doorway, Miss Kenton appeared at my side and said: ‘Mr Stevens, I have a little more time than you at the moment.

如果您愿意的话，我可以代您照顾一下令尊。
I shall, if you wish, attend to your father.

我会带梅雷迪思大夫上这儿来进行诊治，要是有什么要紧的情况我会通知您的。”
I shall show Dr Meredith up and notify you if he has anything noteworthy to say.’

“谢谢您，肯顿小姐，”我说，然后我就离开了。
‘Thank you, Miss Kenton,’ I said, and took my leave.

当我返回会客厅的时候，一位神职人员正在讲述柏林的儿童所遭受的苦难。
When I returned to the drawing room, a clergyman was talking about the hardships being suffered by children in Berlin.

我立刻忙着为客人们添茶倒咖啡。
I immediately found myself more than occupied replenishing the guests with tea and coffee.

有几位绅士，我注意到，正在饮用烈酒；尽管有两位女士在场，有一两位绅士已经开始抽起烟来。
A few of the gentlemen, I noticed, were drinking spirits, and one or two, despite the presence of the two ladies, had started to smoke.

我记得当我手持空茶壶离开会客室的时候，肯顿小姐叫住了我，说：“史蒂文斯先生，梅雷迪思大夫正准备离开了。”
I was, I recall, leaving the drawing room with an empty teapot in my hand when Miss Kenton stopped me and said: ‘Mr Stevens, Dr Meredith is just leaving now.’

她说这番话的时候，我看到那位大夫正在门厅里穿戴雨衣和帽子，于是我就走上前去，那把茶壶还在我手里拿着。
As she said this, I could see the doctor putting on his mackintosh and hat in the hall and so went to him, the teapot still in my hand.

大夫面带不悦地望着我。
The doctor looked at me with a disgruntled expression.

“令尊的状况不太乐观，”他说。
‘Your father's not so good,’ he said.

“如果情况恶化，马上通知我。”
‘If he deteriorates, call me again immediately.’

“是，先生。
‘Yes, sir.

谢谢您，先生。”
Thank you, sir.’

“令尊高寿了，史蒂文斯？”
‘How old is your father, Stevens?’

“七十有二了，先生。”
‘Seventy-two, sir.’

梅雷迪思大夫想了一会儿，然后又说：“如果情况恶化，务必马上通知我。”
Dr Meredith thought about this, then said again: ‘If he deteriorates, call me immediately.’

我再度向大夫致谢，然后送他出去。
I thanked the doctor again and showed him out.

也正是在那天傍晚，晚餐即将开始前，我无意中听到了刘易斯先生和杜邦先生的谈话。
It was that evening, shortly before dinner, that I overheard the conversation between Mr Lewis and M. Dupont.

当时我出于某个原因上楼来到杜邦先生的房间，在敲门前我习惯性地稍停了片刻，听一下门内的动静。
I had for some reason gone up to M. Dupont's room and was about to knock, but before doing so, as is my custom, I paused for a second to listen at the door.

您或许没有养成这种习惯，为了避免在某些极不适宜的时候敲门打搅了别人而采取这种小小的预防措施，我却一直都有这种习惯，而且我敢担保这在我们许多同行当中也是非常普遍的做法。
You may not yourself be in the habit of taking this small precaution to avoid knocking at some highly inappropriate moment, but I always have been and can vouch that it is common practice amongst many professionals.

也就是说，我们这样做的背后并无什么不可告人的动机，就拿这次来说，我根本不是有意要去偷听他们讲话的。
That is to say, there is no subterfuge implied in such an action, and I for one had no intention of overhearing to the extent I did that evening.

然而，也是事出偶然，当我把耳朵贴到杜邦先生的房门上时，正巧听到了刘易斯先生的说话声，虽然我不记得当时听到的确切字句了，可他讲话的语气引起了我的怀疑。
However, as fortune would have it, when I put my ear to M. Dupont's door, I happened to hear Mr Lewis's voice, and though I cannot recall precisely the actual words I first heard, it was the tone of his voice that raised my suspicions.

这位美国绅士的声音听来仍旧一如既往地亲切而又和缓—自打他来到这里以后，这声音已经为他赢得了很多人的好感—可是这会子却又带上了某种绝不会弄错的鬼鬼祟祟的成分。
I was listening to the same genial, slow voice with which the American gentleman had charmed many since his arrival and yet it now contained something unmistakably covert.

正是因为这一点，再加上他正在杜邦先生的房内、应该正在跟这位至关重要的人物侃侃而谈的事实，使得我没有去敲门，反而继续听了下去。
It was this realization along with the fact that he was in M. Dupont's room, presumably addressing this most crucial personage, that caused me to stop my hand from knocking, and continue to listen instead.

达林顿府各间卧室的房门都是很厚实的，我是无论如何也听不清楚完整的谈话内容的；因此上，我现在也很难回忆得起当时听到的确切的语句，其实当天的稍晚时候我向爵爷汇报此事时，情况就已经是如此了。
The bedroom doors of Darlington Hall are of a certain thickness and I could by no means hear complete exchanges; consequently, it is hard for me now to recall precisely what I overheard, just as, indeed, it was for me later that same evening when I reported to his lordship on the matter.

话虽如此，这并不等于我对当时房内正在发生的事情没有一个相当清楚的概念。
Nevertheless, this is not to say I did not gain a fairly clear impression of what was taking place within the room.

事实上，那位美国绅士正在表明这样的一个观点，即杜邦先生受到了爵爷以及其他与会者的操纵；他们故意将邀请杜邦先生与会的时间推后，以便于其他人等在他不在场时先行讨论重大的议题；即便在他来到之后，也有人看到爵爷与几位最重要的代表举行了好几次私下的讨论，而没有邀请杜邦先生参加。
In effect, the American gentleman was putting forward the view that M. Dupont was being manipulated by his lordship and other participants at the conference; that M. Dupont had been deliberately invited late to enable the others to discuss important topics in his absence; that even after his arrival, it was to be observed that his lordship was conducting small private discussions with the most important delegates without inviting M. Dupont.

然后刘易斯先生就开始打小报告，把他来到这里第一天的晚宴上爵爷和其他人说过的那些话讲给杜邦先生听。
Then Mr Lewis began to report certain remarks his lordship and others had made at dinner on that first evening after his arrival.

“坦白说吧，先生，”我听到刘易斯先生这么说，“我因为他们对于贵国人民的态度而惊骇万分。
‘To be quite frank, sir,’ I heard Mr Lewis say, ‘I was appalled at their attitude towards your countrymen.

他们实实在在地使用了‘野蛮’和‘可鄙’这样的词汇。
They actually used words like “barbarous” and “despicable”.

事实上，几个小时之后我就把它们原原本本地记在了我的日记里。”
In fact, I noted them in my diary only a few hours afterwards.’

杜邦先生简短地说了句什么，我没听清，然后刘易斯先生又说道：“我就跟您说吧，先生，我真是惊骇万分。
M. Dupont said something briefly which I did not catch, then Mr Lewis said again: ‘Let me tell you, sir, I was appalled.

这样的词汇能用来形容仅仅几年前还肩并肩站在一起的盟友吗？”
Are these words to use about an ally you stood shoulder to shoulder with only a few years back?’

现在我已经不能确定当时自己有没有去敲门了；考虑到我听到的内容那令人警醒的性质，我当时的判断应该还是撤退为宜。
I am not sure now if I ever proceeded to knock; it is quite possible, given the alarming nature of what I heard, that I judged it best to withdraw altogether.

反正是并没有在门外逗留太久—正如事后不久我责无旁贷必须跟爵爷解释清楚的那样—没有听到更多的内容，以便可以据以判断杜邦先生听了刘易斯先生的这番话以后到底会持一种什么样的态度。
In any case, I did not linger long enough – as I was obliged to explain to his lordship shortly afterwards – to hear anything that would give a clue as to M. Dupont's attitude to Mr Lewis's remarks.

第二天，会客室里的讨论已经达到了一个全新的激烈水平，到午餐时间的时候，唇枪舌剑的往还已经趋于白热化了。
The next day, the discussions in the drawing room appeared to reach a new level of intensity and by lunchtime, the exchanges were becoming rather heated.

我的印象是发言的内容已经带有责难的意味，发言的态度也愈发无所顾忌，矛头直指杜邦先生，而他则手捻胡须，端坐在扶手椅中，几乎不言不语。
My impression was that utterances were being directed accusingly, and with increasing boldness, towards the armchair where M. Dupont sat fingering his beard, saying little.

每次暂时休会，我注意到—爵爷无疑也会有些担忧地注意到—刘易斯先生都会马上就把杜邦先生拉到某个角落或是别的他们能够不受打扰地密商的所在。
Whenever the conference adjourned, I noticed, as no doubt his lordship did with some concern, that Mr Lewis would quickly take M. Dupont away to some corner or other where they could confer quietly.

我清楚地记得，用过午餐后不久，我无意中撞见这两位绅士就在藏书室刚刚进门的位置颇为鬼鬼祟祟地交谈，让我印象格外深刻的是，他们一见到我走上前来，就马上闭口不谈了。
Indeed, once, shortly after lunch, I recall I came upon the two gentlemen talking rather furtively just inside the library doorway, and it was my distinct impression they broke off their discussion upon my approach.

与此同时，家父的状况既没有好转，也没有恶化。
In the meantime, my father's condition had grown neither better nor worse.

据我的理解，他多数的时间都在昏睡，有几次我有点空余时间爬到那个小阁楼上去探望他的时候，他确实是沉睡不醒。
As I understood, he was asleep for much of the time, and indeed, I found him so on the few occasions I had a spare moment to ascend to that little attic room.

我实际上一直都没有机会再跟他说说话，直到他病情再次发作后的第二天傍晚。
I did not then have a chance actually to converse with him until that second evening after the return of his illness.

那次我进去的时候，家父也在睡梦中。
On that occasion, too, my father was sleeping when I entered.

可是肯顿小姐留下来照看家父的那个卧房的女仆一看到我就马上站起来，开始摇晃家父的肩膀。
But the chambermaid Miss Kenton had left in attendance stood up upon seeing me and began to shake my father's shoulder.

“蠢丫头！”
‘Foolish girl!’

我叫道。
I exclaimed.

“你这是在干什么？”
‘What do you think you are doing?’

“史蒂文斯先生交代过，如果您再来的话就叫醒他。”
‘Mr Stevens said to wake him if you returned, sir.’

“让他睡吧。
‘Let him sleep.

他这个病就是累的。”
It's exhaustion that's made him ill.’

“他说过一定要把他叫醒，先生，”那姑娘道，又开始摇晃家父的肩膀。
‘He said I had to, sir,’ the girl said, and again shook my father's shoulder.

家父睁开眼睛，在枕头上微微侧了一下头，看着我。
My father opened his eyes, turned his head a little on the pillow, and looked at me.

“希望父亲现在感觉好些了，”我说。
‘I hope Father is feeling better now,’ I said.

他继续盯着我看了一会儿，然后问我：“楼下一切尽在掌控中吧？”
He went on gazing at me for a moment, then asked: ‘Everything in hand downstairs?’

“情况一直都瞬息万变。
‘The situation is rather volatile.

这才刚过六点钟，所以父亲也很可以想象此刻厨房里的气氛了。”
It is just after six o'clock, so Father can well imagine the atmosphere in the kitchen at this moment.’

家父的脸上掠过一丝不耐烦。
An impatient look crossed my father's face.

“但一切都尽在掌控之中吧？”他又问了一遍。
‘But is everything in hand?’ he said again.

“是的，我敢说您对此可以尽管放心。
‘Yes, I dare say you can rest assured on that.

我很高兴父亲感觉好些了。”
I'm very glad Father is feeling better.’

他有些慎重地慢慢把胳膊从被单底下抽出来，疲惫地盯着自己的手背。
With some deliberation, he withdrew his arms from under the bedclothes and gazed tiredly at the backs of his hands.

看了好长一段时间。
He continued to do this for some time.

“我很高兴父亲现在感觉已经大好了，”我最后又说了一遍。
‘I'm glad Father is feeling so much better,’ I said again eventually.

“现在我真的最好还是回去了。
‘Now really, I'd best be getting back.

就像我说的，现在的情况真是瞬息万变。”
As I say, the situation is rather volatile.’

他又继续看了自己的手背一阵子。
He went on looking at his hands for a moment.

然后才缓缓地道：“真希望我对你来说是个好父亲。”
Then he said slowly: ‘I hope I've been a good father to you.’

我轻轻一笑道：“真高兴您现在感觉好些了。”
I laughed a little and said: ‘I'm so glad you're feeling better now.’

“我为你感到骄傲。
‘I'm proud of you.

一个好儿子。
A good son.

希望我对你来说也是个好父亲。
I hope I've been a good father to you.

但我想我并不是。”
I suppose I haven't.’

“恐怕我们现在真是忙得不可开交，不过我们可以明天早上找时间再聊。”
‘I'm afraid we're extremely busy now, but we can talk again in the morning.’

家父仍旧望着自己的双手，仿佛对它们略有些恼怒似的。
My father was still looking at his hands as though he were faintly irritated by them.

“真高兴您现在感觉好些了，”我又说了一遍，然后就告退了。
‘I'm so glad you're feeling better now,’ I said again and took my leave.

来到楼下，我发现厨房里几乎是一片混乱，而且总体来说，各级员工无不笼罩在一种极端紧张的气氛当中。
On descending, I found the kitchen on the brink of pandemonium, and in general, an extremely tense atmosphere amongst all levels of staff.

不过，我很高兴地记得，到大约一个钟头以后的晚宴时间，就我的团队而言，展现出来的就唯有高效以及专业性的镇定自若了。
However, I am pleased to recall that by the time dinner was served an hour or so later, nothing but efficiency and professional calm was exhibited on the part of my team.

看到那座富丽堂皇的宴会厅高朋满座的场景，总是让人过目难忘，那天傍晚就是如此。
It was always something of a memorable sight to see that magnificent banqueting hall employed to its full capacity and that evening was no exception.

当然了，略显美中不足的是那一排排鱼贯入场、清一色身着晚宴礼服的绅士们在数量上超过女性的代表太多，整体的氛围未免显得有些过于严峻；不过话又说回来了，当年餐桌上方悬挂的那两盏巨型的枝形吊灯还是以煤气为燃料的—整个大厅因此都笼罩在一片清浅而又柔和的光晕之中—不像电气化时代以后的灯光那样亮得刺眼。
Of course, the effect produced by unbroken lines of gentlemen in evening suits, so outnumbering representatives of the fairer sex, was a rather severe one; but then again, in those days, the two large chandeliers that hang over the table still ran on gas – resulting in a subtle, quite soft light pervading the room – and did not produce the dazzling brightness they have done ever since their electrification.

在会议期间那第二次也是最后一次晚宴上—大部分来宾预计第二天用过午餐后就将动身离开—在座的来宾已经卸去了那在前几天里显而易见的大部分矜持和拘谨。
On that second and final dinner of the conference – most guests were expected to disperse after lunch the following day – the company had lost much of the reserve that had been noticeable throughout the previous days.

不仅是闲谈更加随心和大声，我们发现斟酒的频率也显著提升。
Not only was the conversation flowing more freely and loudly, we found ourselves serving out wine at a conspicuously increased rate.

从专业的角度来看，晚宴进行得可说是相当顺畅，并无任何明显的差池；宴会临近结束之时，爵爷起身向众位宾客致辞。
At the close of dinner, which from a professional viewpoint had been executed without any significant difficulties, his lordship rose to address his guests.

他首先向在座的所有来宾表示感谢，因为在前两天的讨论当中“虽不时有令人振奋的坦率陈词”，却也始终秉持友好的精神以及乐见“善”最终获胜的意愿。
He opened by expressing his gratitude to all present that the discussions during the previous two days, ‘though at times exhilaratingly frank’, had been conducted in a spirit of friendship and the desire to see good prevail.

他在前两天中亲眼目睹的团结一致已经远远超出了他之预期，他确信，在次日上午举行的“总结”会上，与会者必将达成充分共识，承诺各自都将在瑞士即将举行的重要国际会议之前采取有效的行动。
The unity witnessed over the two days had been greater than he could ever have hoped for, and the remaining morning's session of ‘rounding up’ would, he trusted, be rich in commitments on the part of participants concerning action each would be taking before the important international conference in Switzerland.

大约正是在这个节骨眼上—我不知道他是否事先就已计划好要这么做—爵爷开始缅怀起了他的故友卡尔—海因茨·布雷曼先生。
It was around this point – and I have no idea if he had planned to do so beforehand – that his lordship began to reminisce about his late friend, Herr Karl-Heinz Bremann.

这实在是个小小的不幸，这一直都是爵爷心念系之的一个话题，而且他一提起来就会滔滔不绝地说个没完。
This was a little unfortunate, the topic being one close to his lordship's heart and one he was inclined to explicate at some length.

或许有一点也该说明，即爵爷从来就不是那种可以被称为天生演说家的人，所以没过多久，整个宴会厅就响起了坐立不安的嘁嘁喳喳声，这表明听众们已经渐渐失去了耐心。
It should also be said, perhaps, that Lord Darlington was never what might be called a natural public speaker, and soon all those small sounds of restlessness that betray that an audience's attention has been lost grew steadily around the room.

说实话，到了爵爷终于把话讲完，敦请诸位来宾全体起立为“欧洲的和平与正义”而干杯之时，那种嘈杂的程度—或许也是大家尽兴畅饮的结果—在我看来已经迹近于失礼了。
Indeed, by the time Lord Darlington had finally come round to bidding his guests rise and drink to ‘peace and justice in Europe’, the level of such noises – perhaps on account of the liberal amounts of wine that had been consumed – struck me as bordering on the ill-mannered.

众人纷纷再次落座，闲谈重又开始启动之际，突然响起一阵颇有权威性的指节敲击桌面的声音，杜邦先生已经站了起来。
The company had seated themselves again, and conversation was just beginning to resume, when there came an authoritative rapping of knuckles upon wood and M. Dupont had risen to his feet.

立刻，室内全都安静了下来。
At once, a hush fell over the room.

这位显赫的绅士以近乎严厉的目光环视了餐桌周围的众人一眼。
The distinguished gentleman glanced around the table with a look almost of severity.

然后他说：“我希望我并没有僭越在座的某位绅士所肩负的职责，不过迄今为止我还没有听到任何人提议大家共同举杯感谢我们的主人，最可敬、最仁厚的达林顿勋爵。”
Then he said: ‘I hope I am not trespassing over a duty ascribed to someone else present here, but then I had heard no proposals for anyone to give a toast in thanks to our host, the most honourable and kind Lord Darlington.’

现场响起一阵喃喃的赞许声。
There was a murmur of approval.

杜邦先生继续道：“在过去这几天的时间里，大家在这幢府第里讲过了很多令人感兴趣的事。
M. Dupont went on: ‘Many things of interest have been said in this house over the past days.

很多非常重要的事。”
Many important things.’

他稍作沉吟，此刻的宴会厅里一片肃静。
He paused, and there was now utter stillness in the room.

“有很多言论，”他继续道，“非常含蓄甚或坦率地批评—这个措辞还不算是言过其实—批评了敝国的外交政策。”
‘There has been much’, he continued, ‘which has implicitly or otherwise criticized – it is not so strong a word – criticized the foreign policy of my country.’

他再次稍作沉吟，神色相当严峻。
He paused again, looking rather stern.

你也许都会以为他动怒了。
One might even have thought him to be angry.

“在这两天当中，我已经几次听到对于欧洲当前异常复杂的情势所做的详尽而又睿智的分析。
‘We have heard in these two days several thorough and intelligent analyses of the present very complex situation in Europe.

不过恕我直言，还没有一种分析对于法国为什么会对其邻国秉持这样的态度表现出真正的理解。
But none of them, may I say, has fully comprehended the reasons for the attitude France has adopted towards her neighbour.

然而，”—他伸出一根手指—“现在不是进行此类辩论的时候。
However,’ – he raised a finger – ‘this is not the time to enter into such debates.

事实上，在过去的这几天当中我一直都刻意地避免参与这类辩论，因为我来到这里主要是为了倾听的。
In fact, I deliberately refrained from entering into such debates during these past days because I came principally to listen.

现在请容许我告诉诸位，我在这里听到的不少意见都给我留下了深刻的印象。
And let me say now that I have been impressed by certain of the arguments I have heard here.

不过诸位也许要问了，这印象到底有多么深刻呢？”
But how impressed, you may be asking.’

杜邦先生再度稍作沉吟，以一种近乎悠闲的态度挨个儿扫视了一圈所有注视着他的面孔。
M. Dupont took another pause during which his gaze travelled in an almost leisurely manner around all the faces fixed upon him.

最后他才继续道：“先生们—还有女士们，请原谅—对此我已进行过反复的思考，我希望借此机会推心置腹地跟诸位交个底：尽管对于如何解读欧洲目前的真实现状，我本人与在座的诸位之间仍然存在着分歧，尽管如此，对于大家在这次会议中所提出的要旨，我深为信服，先生们，既为其正义性又为其务实性而深深信服。”
Then at last he said: ‘Gentlemen – and ladies, pardon me – I have given much thought to these matters and I wish to say here in confidence to you, that while there remains between myself and many of those present differences of interpretation as to what is really occurring in Europe at this moment, despite this, as to the main points that have been raised in this house, I am convinced, gentlemen, convinced both of their justice and their practicality.’

一阵既宽慰而又欢欣的喃喃低语传遍了餐桌周围，可是这时杜邦先生却稍稍提高了嗓音，压过这阵窃窃私语继续道：“我很高兴向在座的诸位做出保证，我保证竭尽个人的绵薄之力，努力促成法国政策的重心之改变，以期符合本次会议的多数意见。
A murmur which seemed to contain both relief and triumph went around the table, but this time M. Dupont raised his voice slightly and pronounced over it: ‘I am happy to assure you all here that I will bring what modest influence I have to encourage certain changes of emphasis in French policy in accordance with much of what has been said here.

而且我将赶在瑞士会议之前及早地采取行动。”
And I will endeavour to do so in good time for the Swiss conference.’

宴会厅里响起了阵阵掌声，我看到爵爷跟大卫爵士交换了一个眼色。
There was a ripple of applause, and I saw his lordship exchange a look with Sir David.

杜邦先生举起手来，不知道是表示接受还是阻止大家的掌声。
M. Dupont held up his hand, though whether to acknowledge the applause or to stem it was not clear.

“不过在我接下来向我们的主人达林顿勋爵表示感谢之前，我还有件小事不吐不快，希望能在此一抒胸臆。
‘But before I go on to thank our host, Lord Darlington, I have some small thing I would wish to remove from my chest.

诸位也许有人会说，在餐桌上把自己胸臆中的东西吐出来可是有些失礼之举。”
Some of you may say it is not good manners to be removing such things from one's chest at the dinner table.’

这句话引来了热情的欢笑。
This brought enthusiastic laughter.

“不过我在这类事情上一直都是直言不讳的。这就像一定要正式地、公开地向达林顿勋爵表示感激之情一样，是他将我们召集到这里，并使得目前这种团结一致、友好善意的精神成为可能的；同样，我也相信一定要公开地谴责任何跑到这儿来滥用主人的殷勤好客，一门心思只想着散布不满和猜疑的宵小之辈。
‘However, I am for frankness in these matters. Just as there is an imperative to express gratitude formally and publicly to Lord Darlington, who has brought us here and made possible this present spirit of unity and goodwill, there is, I believe, an imperative to openly condemn any who come here to abuse the hospitality of the host, and to spend his energies solely in trying to sow discontent and suspicion.

这种人不但在社交场合令人厌恶，在我们现今的社会气候之下更是极端危险的。”
Such persons are not only socially repugnant, in the climate of our present day they are extremely dangerous.’

他再次稍作沉吟，整个宴会厅里再次鸦雀无声。
He paused again and once more there was utter stillness.

杜邦先生继续语气平静、从容不迫地道：“对于刘易斯先生我只有一事不明：他那令人憎恶的行径在多大程度上代表了美国当局的态度？
M. Dupont went on in a calm, deliberate voice: ‘My only question concerning Mr Lewis is this. To what extent does his abominable behaviour exemplify the attitude of the present American administration?

女士们、先生们，那就请容我斗胆一猜吧，因为对于这样一位几天来已经充分地展现出其欺诈水准之高的绅士，我们是没办法指望他能给我们提供一个诚实的答案的。
Ladies and gentlemen, let me myself hazard a guess as to the answer, for such a gentleman capable of the levels of deceit he has displayed over these past days should not be relied upon to provide a truthful reply.

所以，我也就只能姑且一猜了。当然了，如果德国不再继续赔款，美国自然会很关心我们对其债务的偿付能力。
So, I will hazard my guess. Of course, America is concerned about our debt payments to her in the event of a freeze in German reparations.

不过在过去这半年当中，我也曾有机会跟不少位高权重的美国人士直接讨论过这个问题，依我看来，该国对这一问题的看法要远比他们这位在座的同胞所代表的观点高瞻远瞩得多。
But I have over the last six months had occasion to discuss this very matter with a number of very highly placed Americans, and it seems to me that thinking in that country is much more far-sighted than that represented by their countryman here.

我们所有这些关心欧洲未来福祉的人尽可以但放宽心，因为事实上刘易斯先生现在的影响力—我们该怎么表述呢？—已经是今非昔比了。
All those of us who care for the future well-being of Europe will take comfort from the fact that Mr Lewis is now – how shall we put it? – hardly the influence he once was.

您也许会觉得我这么丝毫不肯假以辞色未免过于不近人情，但事实上，女士们、先生们，我已经算得上是仁至义尽了。
Perhaps you think me unduly harsh to express these things so openly. But the reality is, ladies and gentlemen, I am being merciful.

您瞧，我并没有把这位绅士一直以来对我说的那些话原样搬出来—关于在座的每一位。
You see, I refrain from outlining just what this gentleman has been saying to me – about you all.

他所说的那些话，其技巧是如此拙劣低能，其态度是如此厚颜无耻，其内容是如此粗鄙下流，简直令人难以置信。
And with a most clumsy technique, the audacity and crudeness of which I could hardly believe. But enough of condemnations.

不过谴责的话已经说够了，该是我们表示感谢的时候了。那就请跟我一起，女士们、先生们，我们一起举杯敬达林顿勋爵。”
It is time for us to thank. Join me then, please, ladies and gentlemen, in raising your glasses to Lord Darlington.’

杜邦先生在讲这番话的过程中，一直都不曾朝刘易斯先生的方向看过一眼，也确实，大家在向爵爷敬酒致谢、再次落座后，目光也似乎全都刻意地避免朝那位美国绅士看去。
M. Dupont had not once looked over in Mr Lewis's direction during the course of this speech, and indeed, once the company had toasted his lordship and were seated again, all those present seemed to be studiously avoiding looking towards the American gentleman.

一种令人难堪的沉默一度笼罩了宴会现场，然后刘易斯先生终于站起身来。
An uneasy silence reigned for a moment, and then finally Mr Lewis rose to his feet.

他的脸上仍习惯性地堆满了亲切的笑容。
He was smiling pleasantly in his customary manner.

“喔，既然每个人都发表了讲话，我不妨也来说上两句，”他说道，听他的声音明显是已经喝得很不少了。
‘Well, since everyone's giving speeches, I may as well take a turn,’ he said, and it was at once apparent from his voice that he had had a good deal to drink.

“对于我们的法国朋友刚才的那一番无稽之谈，我没什么话好说。
‘I don't have anything to say to the nonsense our French friend has been uttering.

对那样的言论我根本就不屑于理会。
I just dismiss that sort of talk.

有多少人都曾妄图将此谰言强加到我头上，我见得多了，但让我来告诉诸位吧，先生们，这也不过是枉费心机。
I've had people try to put one over on me many times, and let me tell you, gentlemen, few people succeed.

枉费心机罢了。”
Few people succeed.’

刘易斯先生突然停住了话头，一时间似乎不知该如何接下去才好了。
Mr Lewis came to a halt and for a moment seemed at a loss as to how he should go on.

终于他又笑了笑，继续道：“如我所说的，我不会再在我们那位法国朋友身上浪费时间了。
Eventually he smiled again and said: ‘As I say, I'm not going to waste my time on our French friend over there.

不过事有凑巧，我倒确实还有几句话想说。
But as it happens, I do have something to say.

既然我们现在都这么坦诚相见了，我也就实话实说吧。
Now we're all being so frank, I'll be frank too.

你们在座的诸位先生，恕我直言，你们全都不过是一群幼稚的梦想家罢了。
You gentlemen here, forgive me, but you are just a bunch of naive dreamers.

你们要是不这么一门心思地想着掺和影响全球的那些重大事务的话，你们其实还都挺有魅力的。
And if you didn't insist on meddling in large affairs that affect the globe, you would actually be charming.

就拿我们这位善良的东道主来说吧。
Let's take our good host here.

他是何等样人呢？
What is he?

他是位绅士。
He is a gentleman.

这一点我相信在座的没有任何人会反对的。
No one here, I trust, would care to disagree.

一位典型的英国绅士。
A classic English gentleman.

正派，诚实，用心良苦。
Decent, honest, well-meaning.

可是这位爵爷却是个外行。”
But his lordship here is an amateur.’

他在这个字眼上面略作停顿，并且环顾了一下众人。
He paused at the word and looked around the table.

“他是个外行，而如今的国际事务已经轮不到这些外行的绅士们插手了。
‘He is an amateur and international affairs today are no longer for gentlemen amateurs.

这一点，你们这些欧洲人越早明白越好。
The sooner you here in Europe realize that the better.

诸位在座的为人正派、用心良苦的绅士大人们，让我问你们一句，你们知道你们周围的这个世界正在变成什么样子吗？
All you decent, well-meaning gentlemen, let me ask you, have you any idea what sort of place the world is becoming all around you?

你们可以出于你们那高贵的本性治国理政的日子已经一去不复返了。
The days when you could act out of your noble instincts are over.

只不过当然啦，你们这些欧洲人似乎都还没有意识到这一点。
Except of course, you here in Europe don't yet seem to know it.

像我们善良的主人这样的绅士仍旧相信，他们就该去瞎掺和那些他们根本就不懂的事务。
Gentlemen like our good host still believe it's their business to meddle in matters they don't understand.

这两天以来，在这儿说了多少蠢话和废话。用心良苦、天真幼稚的蠢话和废话。
So much hog-wash has been spoken here these past two days. Well-meaning, naïve hog-wash.

你们这些欧洲人需要专业人士来掌管你们的事务。
You here in Europe need professionals to run your affairs.

你们如果仍旧执迷不悟，很快你们就要大难临头了。
If you don't realize that soon you're headed for disaster.

举杯吧，先生们。
A toast, gentlemen.

让我们一起举杯—敬专业精神。”
Let me make a toast. To professionalism.’

现场一阵惊愕，寂然无声，没有一个人动弹。
There was a stunned silence and no one moved.

刘易斯先生耸了耸肩膀，举起酒杯向所有人照了一圈，一饮而尽，坐了回去。
Mr Lewis shrugged, raised his glass to all the company, drank and sat back down.

达林顿勋爵几乎马上就站了起来。
Almost immediately, Lord Darlington stood up.

“我本不希望，”爵爷道，“在我们这济济一堂的最后一个夜晚陷入无谓的争执当中，因为这是个欢庆胜利的时刻，大家本该好好享受一下的。不过正是出于对您这种观点的尊重，刘易斯先生，我感觉就更不应该把它当作某个街头怪人的演说那样置之不理了。
‘I have no wish,’ his lordship said, ‘to enter into a quarrel on this our last evening together which we all deserve to enjoy as a happy and triumphant occasion. But it is out of respect for your views, Mr Lewis, that I feel one should not simply cast them to one side as though they were uttered by some soapbox eccentric.

让我这么来说吧：您所谓的‘外行’，先生，我想在座的大多数人更愿意称之为‘荣誉’。”
Let me say this. What you describe as “amateurism”, sir, is what I think most of us here still prefer to call “honour”.’

这番话引来了一阵响亮的赞许声，夹杂着几句“听听，听听”的感叹声以及几声鼓掌和喝彩。
This brought a loud murmur of assent with several ‘hear, hear's’ and some applause.

“更重要的是，先生，”爵爷继续道，“我相信我很清楚您所谓的‘专业精神’指的是什么。
‘What is more, sir,’ his lordship went on, ‘I believe I have a good idea of what you mean by “professionalism”.

它指的无非是通过欺骗和操纵的手段来为所欲为。
It appears to mean getting one's way by cheating and manipulating.

它指的无非是依照自己的贪欲和利益来排定轻重缓急，而绝非是为了看到善良与正义在世界上获得胜利。
It means ordering one's priorities according to greed and advantage rather than the desire to see goodness and justice prevail in the world.

如果这就是您所谓的‘专业精神’，先生，我实在是有些嗤之以鼻，巴不得对它敬而远之呢。”
If that is the “professionalism” you refer to, sir, I don't much care for it and have no wish to acquire it.’

这一席话赢得了迄今为止最为热烈的赞许声，继之以热情而又持久的鼓掌和喝彩。
This was met by the loudest burst of approval yet, followed by warm and sustained applause.

我看到刘易斯先生冲着自己的酒杯微微一笑，萎靡不振地摇了摇头。
I could see Mr Lewis smiling at his wine glass and shaking his head wearily.

也正是在这个时候，我觉察到第一男仆来到我身边，附耳对我悄声道：“肯顿小姐想跟您说句话，先生。
It was just around this stage that I became aware of the first footman beside me, who whispered: ‘Miss Kenton would like a word with you, sir.

她就在门外。”
She's just outside the door.’

我尽可能小心翼翼地悄悄退出，因为爵爷仍然站在那儿，正在发表进一步的看法。
I made my exit as discreetly as possible just as his lordship, still on his feet, was embarking on a further point.

肯顿小姐一脸忧色。
Miss Kenton looked rather upset.

“令尊的情况非常危急，史蒂文斯先生，”她说。
‘Your father has become very ill, Mr Stevens,’ she said.

“我已经派人去请梅雷迪思大夫了，不过据我所知他可能要稍微耽搁一会儿。”
‘I’ve called for Dr Meredith, but I understand he may be a little delayed.’

我的面色想必是有些摸不着头脑，因为肯顿小姐又接着道：“史蒂文斯先生，他的情况真的非常不好。
I must have looked a little confused, for Miss Kenton then said: ‘Mr Stevens, he really is in a poor state.

您最好是去看看他。”
You had better come and see him.’

“我只能抽出一点点时间。
‘I only have a moment.

先生们随时都有可能离席前往吸烟室。”
The gentlemen are liable to retire to the smoking room at any moment.’

“当然。
‘Of course.

不过您现在务必要去一趟，史蒂文斯先生，要不然事后您也许会追悔莫及的。”
But you must come now, Mr Stevens, or else you may deeply regret it later.’

肯顿小姐已经在头前领路了，我们急匆匆地穿过府第，朝家父那个小阁楼上的房间奔去。
Miss Kenton was already leading the way, and we hurried through the house up to my father's small attic room.

莫蒂默太太，我们的厨娘，正站在家父的床头，身上的围裙都没摘。
Mrs Mortimer, the cook, was standing over my father's bed, still in her apron.

“哦，史蒂文斯先生，”我们一进来她就道，“他已经快不行了。”
‘Oh, Mr Stevens,’ she said upon our entry, ‘he's gone very poorly.’

确实，家父的脸色已经变成了一种暗红色，我还从没见过哪个活人有过这样的面色。
Indeed, my father's face had gone a dull reddish colour, like no colour I had seen on a living being.

我听见肯顿小姐在我身后轻声说：“他的脉搏非常弱了。”
I heard Miss Kenton say softly behind me: ‘His pulse is very weak.’

我凝视了家父一会儿，轻轻摸了一下他的额头，然后就把手抽了回来。
I gazed at my father for a moment, touched his forehead slightly, then withdrew my hand.

“依我看，”莫蒂默太太道，“他是中风了。
‘In my opinion,’ Mrs Mortimer said, ‘he's suffered a stroke.

我这辈子亲眼看到过两次中风，我想他是中风了。”
I've seen two in my time and I think he's suffered a stroke.’

说着，她就哭了起来。
With that, she began to cry.

我注意到她身上散发出浓烈的煎炸和烧烤的气味。
I noticed she reeked powerfully of fat and roast cooking.

我转过身对肯顿小姐道：
I turned away and said to Miss Kenton:

“这太让人难过了。
‘This is most distressing.

可是，我现在必须回到楼下去了。”
Nevertheless, I must now return downstairs.’

“当然，史蒂文斯先生。
‘Of course, Mr Stevens.

大夫到的时候我会告诉您的。
I will tell you when the doctor arrives.

或者出现任何变故的时候。”
Or else when there are any changes.’

“谢谢您，肯顿小姐。”
‘Thank you, Miss Kenton.’

我匆忙来到楼下，及时地赶上了绅士们正开始移师到吸烟室。
I hurried down the stairs and was in time to see the gentlemen proceeding into the smoking room.

几位男仆一看到我也似乎松了一口气，我马上示意他们各就各位。
The footmen looked relieved to see me, and I immediately signalled them to get to their positions.

不管在我暂时离开期间宴会厅里到底发生过什么，反正现在的客人当中洋溢着的是一种货真价实的欢庆气氛。
Whatever had taken place in the banqueting hall after my departure, there was now a genuinely celebratory atmosphere amongst the guests.

在整个吸烟室里，绅士们三五成群地站在一起，全都有说有笑，相互拍着对方的肩膀。
All around the smoking room, gentlemen seemed to be standing in clusters laughing and clapping each other on the shoulder.

刘易斯先生，据我判断，已经告退回自己的房间去了。
Mr Lewis, so far as I could ascertain, had already retired.

我穿梭于诸位宾客之间，托盘上摆着一个装满波尔图葡萄酒的酒壶。
I found myself making my way through the guests, a decanter of port upon my tray.

我刚为一位绅士斟了一杯，一个声音在我背后说：“啊，史蒂文斯，你对鱼儿也感兴趣的，你说过。”
I had just finished serving a glass to a gentleman when a voice behind me said: ‘Ah, Stevens, you're interested in fish, you say.’

我转身，发现是小卡迪纳尔先生正对我笑逐颜开。
I turned to find the young Mr Cardinal beaming happily at me.

我也微微一笑，说：“鱼儿，先生？”
I smiled also and said: ‘Fish, sir?’

“我小时候曾在一个鱼缸里养过各个品种的热带鱼。
‘When I was young, I used to keep all sorts of tropical fish in a tank.

简直可以称得上个小水族馆了。
Quite a little aquarium it was.

我说，史蒂文斯，你没事吧？”
I say, Stevens, are you all right?’

我又笑了笑。
I smiled again.

“我挺好的，谢谢您，先生。”
‘Quite all right, thank you, sir.’

“你说得很是，我真该春天的时候再到这儿来一趟。
‘As you so rightly pointed out, I really should come back here in the spring.

那时候的达林顿府肯定美极了。
Darlington Hall must be rather lovely then.

上次我来这儿的时候，我想也是在冬天。
The last time I was here, I think it was winter then too.

我说，史蒂文斯，你确定你没事吗？”
I say, Stevens, are you sure you're all right there?’

“我好端端的，谢谢您，先生。”
‘Perfectly all right, thank you, sir.’

“不是身体有什么不舒服吧？”
‘Not feeling unwell, are you?’

“绝对不是，先生。
‘Not at all, sir.

我暂且告退了。”
Please excuse me.’

我又继续为他们几位客人斟酒。我背后爆发出一阵响亮的笑声，我听到那位比利时神职人员兴奋地嚷道：“这可真是异端邪说！
I proceeded to serve port to some other of the guests. There was a loud burst of laughter behind me and I heard the Belgian clergyman exclaim: ‘That is really heretical!

绝对是异端邪说！”然后自己又放声大笑。
Positively heretical!’ then laugh loudly himself.

我感觉有什么东西碰了一下我的胳膊肘，转身发现是达林顿勋爵。
I felt something touch my elbow and turned to find Lord Darlington.

“史蒂文斯，你没事吧？”
‘Stevens, are you all right?’

“没事，先生。
‘Yes, sir.

我很好。”
Perfectly.’

“你看起来好像哭了。”
‘You look as though you're crying.’

我笑了笑，掏出手帕迅速了擦了擦脸。
I laughed and taking out a handkerchief, quickly wiped my face.

“非常抱歉，先生。
‘I'm very sorry, sir.

是劳累了一天，太紧张了。”
The strains of a hard day.’

“是呀，确实够累的。”
‘Yes, it's been hard work.’

有人跟爵爷讲话，他转过身去作答。
Someone addressed his lordship and he turned away to reply.

我正准备继续四处走动侍酒的时候，透过敞开的房门看到了肯顿小姐，她正朝我点头示意。
I was about to continue further around the room when I caught sight of Miss Kenton through the open doorway, signalling to me.

我就穿过人群朝门口走去，可是还没到门口，杜邦先生就拉了一下我的胳膊。
I began to make my way towards the doors, but before I could reach them, M. Dupont touched my arm.

“管家，”他说，“不知道你能不能帮我找些干净的绷带过来。
‘Butler,’ he said, ‘I wonder if you would find me some fresh bandages.

我的脚又受不了了。”
My feet are unbearable again.’

“好的，先生。”
‘Yes, sir.’

我继续朝门口走去的时候，意识到杜邦先生就跟在我后头。
As I proceeded towards the doors, I realized M. Dupont was following me.

我转过身对他说：“我会过来找您的，先生，一拿到绷带就马上过来。”
I turned and said: ‘I will come and find you, sir, just as soon as I have what is required.’

“请快一点，管家。
‘Please hurry, butler.

真有点疼。”
I am in some pain.’

“好的，先生。
‘Yes, sir.

非常抱歉，先生。”
I'm very sorry, sir.’

肯顿小姐仍然站在门厅里我第一次看到她的地方。
Miss Kenton was still standing out in the hall where I had first spotted her.

我一出来，她就默不作声地朝楼梯走去，奇怪的是举动中又没有一点着急的意思。
As I emerged, she walked silently towards the staircase, a curious lack of urgency in her manner.

然后她才转过身来对我说：“史蒂文斯先生，我深感遗憾。
Then she turned and said: ‘Mr Stevens, I'm very sorry.

令尊在大约四分钟以前过世了。”
Your father passed away about four minutes ago.’

“我知道了。”
‘I see.’

她看了看她的手，然后又抬眼看着我的脸。
She looked at her hands, then up at my face.

“史蒂文斯先生，我深感遗憾，”她说。
‘Mr Stevens, I'm very sorry’, she said.

然后又补充道：“真希望我能说些什么。”
Then she added: ‘I wish there was something I could say.’

“不必了，肯顿小姐。”
‘There's no need, Miss Kenton.’

“梅雷迪思大夫还没有到。”
‘Dr Meredith has not yet arrived.’

她低下头好一阵子，忍不住迸发出一声啜泣。
Then for a moment she bowed her head and a sob escaped her.

不过她几乎马上就控制住了自己，声音沉着地问：“您想上去看看他吗？”
But almost immediately, she resumed her composure and asked in a steady voice: ‘Will you come up and see him?’

“我眼下实在是太忙了，肯顿小姐。
‘I'm very busy just now, Miss Kenton.

过一会儿再说吧。”
In a little while perhaps.’

“这样的话，史蒂文斯先生，您允许我为他合上眼睛吗？”
‘In that case, Mr Stevens, will you permit me to close his eyes?’

“如果您肯的话，我将感激不尽，肯顿小姐。”
‘I would be most grateful if you would, Miss Kenton.’

她开始走上楼梯，但我又叫住她，跟她说：“肯顿小姐，请别把我此刻不肯马上上楼去为家父送终看作不近人情之举。
She began to climb the staircase, but I stopped her, saying: ‘Miss Kenton, please don't think me unduly improper in not ascending to see my father in his deceased condition just at this moment.

您知道，我相信家父也会希望我现在履行好自己的职责。”
You see, I know my father would have wished me to carry on just now.’

“当然，史蒂文斯先生。”
‘Of course, Mr Stevens.’

“否则的话，我感觉，反而会让他感到失望。”
‘To do otherwise, I feel, would be to let him down.’

“当然，史蒂文斯先生。”
‘Of course, Mr Stevens.’

我转过身，那装着波尔图葡萄酒的酒壶仍旧在我的托盘里，重又回到了吸烟室。
I turned away, the decanter of port still on my tray, and reentered the smoking room.

在那个相对狭小的房间里，就像是出现了一片由黑色的晚宴礼服、灰白的头发和雪茄烟雾组成的森林。
That relatively small room appeared to be a forest of black dinner jackets, grey hair and cigar smoke.

我在这帮绅士们当中缓步前进，寻找需要添酒的酒杯。
I wended my way past the gentlemen, searching for glasses to replenish.

杜邦先生拍了拍我的肩膀说：
M. Dupont tapped my shoulder and said:

“管家，我的事情你关照过没有？”
‘Butler, have you seen to my arrangements?’

“我很抱歉，先生，可是眼下还没办法立刻为您提供帮助。”
‘I am very sorry, sir, but assistance is not immediately available at this precise moment.’

“你这是什么意思，管家？
‘What do you mean, butler?

你们的医疗用品都用光了吗？”
You've run out of basic medical supplies?’

“实际的情况是，先生，有位大夫正往这儿赶。”
‘As it happens, sir, a doctor is on his way.’

“啊，太好了！
‘Ah, very good!

你已经叫了大夫来了。”
You called a doctor.’

“是的，先生。”
‘Yes, sir.’

“好，很好。”
‘Good, good.’

杜邦先生重新回到他跟旁人的谈话中，我则继续在房间里转悠了一段时间。
M. Dupont resumed his conversation and I continued my way around the room for some moments.

其间，那位德国伯爵夫人突然从男人堆里冒了出来，我还没来得及为她斟酒，她就自己拿起酒壶给自己倒了些波尔图。
At one point, the German countess emerged from the midst of the gentlemen and before I had had a chance to serve her, began helping herself to some port from my tray.

“你得替我夸奖一下你们的厨娘，史蒂文斯，”她说。
‘You will compliment the cook for me, Stevens,’ she said.

“当然，夫人。
‘Of course, madam.

谢谢您，夫人。”
Thank you, madam.’

“还有你和你的团队也表现得非常出色。”
‘And you and your team did well also.’

“非常感谢您，夫人。”
‘Thank you most kindly, madam.’

“在晚宴进行当中，史蒂文斯，我一度还当真以为你至少一下子变成了三个人呢，”她说得开心地笑了起来。
‘At one point during dinner, Stevens, I would have sworn you were at least three people,’ she said and laughed.

我马上也报以一笑，说：“我很高兴能为您效劳，夫人。”
I laughed quickly and said: ‘I'm delighted to be of service, madam.’

一会儿以后，我看到小卡迪纳尔先生就在不远处，还是独自一人站在那里，我猛然想到，这位年轻的绅士置身于这么一大群显赫的人物当中可能会有些畏畏缩缩的。
A moment later, I spotted the young Mr Cardinal not far away, still standing on his own, and it struck me the young gentleman might be feeling somewhat overawed in the present company.

反正他手里的酒杯也已经空了，我于是朝他走了过去。
His glass, in any case, was empty and so I started towards him.

他看到我过来显得非常高兴，立刻把酒杯朝前一递。
He seemed greatly cheered at the prospect of my arrival and held out his glass.

“我想，你热爱大自然是件极好的事，史蒂文斯，”他在我给他斟酒的时候说道。
‘I think it's admirable that you're a nature-lover, Stevens,’ he said, as I served him.

“我敢说，达林顿勋爵有你这么一位行家里手帮他督促园丁的工作，也真是一大福气。”
‘And I dare say it's a great advantage to Lord Darlington to have someone to keep an expert eye on the activities of the gardener.’

“您说什么，先生？”
‘I'm sorry, sir?’

“大自然呀，史蒂文斯。
‘Nature, Stevens.

那天我们不是一直都在谈论大自然的神奇奥妙吗？
We were talking the other day about the wonders of the natural world.

我非常同意你的看法，面对我们周围的这些伟大的奇迹，我们都未免太过沾沾自喜了。”
And I quite agree with you, we are all much too complacent about the great wonders that surround us.’

“是的，先生。”
‘Yes, sir.’

“我的意思是说，你看看我们整天谈论的都是些什么。
‘I mean, all this we've been talking about.

合约啦，疆界啦，赔款啦，占领啦。
Treaties and boundaries and reparations and occupations.

而大自然母亲却一直都以她美好的方式生生不息。
But Mother Nature just carries on her own sweet way.

这么想问题的话确实挺可笑的，你说是不是？”
Funny to think of it like that, don't you think?’

“是的，确实是这样，先生。”
‘Yes, indeed it is, sir.’

“我有时在想啊，如果万能的上帝将我们都创造成为—呃—某种植物什么的，是不是会更好一些？
‘I wonder if it wouldn't have been better if the Almighty had created us all as – well – as sort of plants.

你知道，全都牢牢地扎根在土壤当中。
You know, firmly embedded in the soil.

这么一来，像战争啊，疆界啊之类的这些鬼话岂不从一开始就根本不会出现了吗？”
Then none of this rot about wars and boundaries would have come up in the first place.’

这位年轻的绅士似乎觉得这是个很有趣儿的想法。
The young gentleman seemed to find this an amusing thought.

他笑了笑，又想了想，又笑了笑。我也和他一起笑了笑。
He gave a laugh, then on further thought laughed some more.

然后他用胳膊肘轻轻捅了捅我说：“你能想象得出吗，史蒂文斯？”然后又笑了起来。
I joined him in his laughter. Then he nudged me and said: ‘Can you imagine it, Stevens?’ and laughed again.

“是的，先生，”我也笑着说，“那将成为一个最为奇特的替代性选择。”
‘Yes, sir,’ I said, laughing also, ‘it would have been a most curious alternative.’

“可是我们仍旧需要像你这样的伙计来回地传递口信、端茶倒水什么的。
‘But we could still have chaps like you taking messages back and forth, bringing tea, that sort of thing.

要不然，我们又怎么能办成任何一件事呢？
Otherwise, how would we ever get anything done?

你能想象得出吗，史蒂文斯？
Can you imagine it, Stevens?

我们全都扎根于土壤中？
All of us rooted in the soil?

你想象一下！”
Just imagine it!’

正在这时，一个男仆出现在我身后。
Just then a footman emerged behind me.

“肯顿小姐想跟您说句话，先生，”他说。
‘Miss Kenton is wishing to have a word with you, sir,’ he said.

我跟卡迪纳尔先生告了罪，朝门口走去。
I excused myself from Mr Cardinal and moved towards the doors.

我注意到杜邦先生显然一直就守在门边，看到我走近了，他就问我：“管家，大夫到了吗？”
I noticed M. Dupont apparently guarding them and as I approached, he said: ‘Butler, is the doctor here?’

“我正要出去看看，先生。
‘I am just going to find out, sir.

我马上就回来。”
I won't be a moment.’

“我真是有点疼。”
‘I am in some pain.’

“我很抱歉，先生。
‘I'm very sorry, sir.

大夫应该很快就到了。”
The doctor should not be long now.’

这一次杜邦先生就干脆跟着我走了出去。
On this occasion, M. Dupont followed me out of the door.

肯顿小姐又一次站在门厅里候着。
Miss Kenton was once more standing out in the hall.

“史蒂文斯先生，”她说，“梅雷迪思大夫已经到了，现在到楼上去了。”
‘Mr Stevens,’ she said, ‘Dr Meredith has arrived and gone upstairs.’

她是特意压低了声音说的，可是我身后的杜邦先生却马上大声叫道：“啊，太好啦！”
She had spoken in a low voice, but M. Dupont behind me exclaimed immediately: ‘Ah, good!’

我转身对他道：“那就请您随我来吧，先生。”
I turned to him and said: ‘If you will perhaps follow me, sir.’

我把他领进弹子房，他在一把皮椅子上坐下来开始脱鞋子的时候，我赶紧把壁炉里的火拨旺。
I led him into the billiard room where I stoked the fire while he sat down in one of the leather chairs and began to remove his shoes.

“很抱歉这里实在有点冷，先生。
‘I'm sorry it is rather cold in here, sir.

大夫马上就会过来了。”
The doctor will not be long now.’

“谢谢你，管家。
‘Thank you, butler.

你做得很到位。”
You've done well.’

肯顿小姐仍在门厅里等着我，我们俩默不作声地一起穿过整个府第。
Miss Kenton was still waiting for me in the hallway and we ascended through the house in silence.

来到父亲的房间，发现梅雷迪思大夫正在做着一些记录，莫蒂默太太哭得很伤心。
Up in my father's room, Dr Meredith was making some notes and Mrs Mortimer weeping bitterly.

围裙还在她身上，显然她一直就是拿它来擦眼泪的；结果弄得她脸上尽是一道道油渍，她那副模样简直就像是在参加一场假扮黑人的滑稽说唱秀。
She was still wearing her apron, which, evidently, she had been using to wipe away her tears; as a result there were grease marks all over her face, giving her the appearance of a participant in a minstrel show.

我原本以为房间里肯定会弥漫着死亡的气息，但是拜莫蒂默太太—或者是她的围裙所赐，房间里居然一股子烧烤味儿。
I had expected the room to smell of death, but on account of Mrs Mortimer – or else her apron – the room was dominated by the smell of roasting.

梅雷迪思大夫起身对我说：“请节哀顺变，史蒂文斯。
Dr Meredith rose and said: ‘My condolences, Stevens.

令尊发作的是一次严重的中风。
He suffered a severe stroke.

他应该没有遭受太多的痛苦，这也算是不幸中的万幸。
If it's any comfort to you, he wouldn't have suffered much pain.

他这个病你无论做什么都已经无能为力了。”
There was nothing in the world you could have done to save him.’

“谢谢您，先生。”
‘Thank you, sir.’

“我这就走了。
‘I'll be on my way now.

你会安排好一切后事吧？”
You'll see to arrangements?’

“是的，先生。
‘Yes, sir.

不过如果方便的话，楼下有一位最为尊贵的绅士还需要您的诊治。”
However, if I may, there is a most distinguished gentleman downstairs in need of your attention.’

“紧急吗？”
‘Urgent?’

“他表达了迫切需要见到您的愿望，先生。”
‘He expressed a keen desire to see you, sir.’

我领梅雷迪思大夫下去，带他来到弹子房，然后立刻又返回了吸烟室，那里的气氛如果说有什么不同的话，就是已经变得越发欢快友好了。
I led Dr Meredith downstairs, showed him into the billiard room, then returned quickly to the smoking room where the atmosphere, if anything, had grown even more convivial.

当然了，绝不应该由我来暗示，我已经配得上跟我同辈的比如说马歇尔或是莱恩先生一样，跻身于“伟大”的管家之列了—虽然也不应讳言，确有很多人或许是出于谬赏之意，过于慷慨地倾向于如此认为。
Of course, it is not for me to suggest that I am worthy of ever being placed alongside the likes of the ‘great’ butlers of our generation, such as Mr Marshall or Mr Lane – though it should be said there are those who, perhaps out of misguided generosity, tend to do just this.

请容我澄清一下，当我说一九二三年的那次会议，尤其是那个夜晚在我的职业发展进程中构成了一个转折点的时候，我主要是以我自己那远为卑微的标准来衡量的。
Let me make clear that when I say the conference of 1923, and that night in particular, constituted a turning point in my professional development, I am speaking very much in terms of my own more humble standards.

即便如此，如果您能考虑到那一晚我所承受的那些不可预料的压力，倘若我斗胆认为我在面对一切意外情况时，也许的确表现出了至少是某种程度上的“尊严”素质—这种素质只有像马歇尔先生，或者实事求是地说，像家父这样的管家才能具备的，您或许不会认为我是过于自欺了吧？
Even so, if you consider the pressures contingent on me that night, you may not think I delude myself unduly if I go so far as to suggest that I did perhaps display, in the face of everything, at least in some modest degree a ‘dignity’ worthy of someone like Mr Marshall – or come to that, my father.

的确，我又何必要惺惺作态呢？
Indeed, why should I deny it?

那一晚诚然会有种种令人悲痛的联想，但每忆及此，我发现一种巨大的成就感总会油然而生。
For all its sad associations, whenever I recall that evening today, I find I do so with a large sense of triumph.

# 第二天—傍晚 | DAY TWO–AFTERNOON

莫蒂默池塘，多塞特郡
Mortimer's Pond, Dorset

看来，对于“怎样才算得上一个‘伟大’的管家”这个问题，似乎还有很大的一个维度迄今为止我还没有好好地思考过。
It would seem there is a whole dimension to the question ‘what is a “great” butler?’ I have hitherto not properly considered.

对于这样一个如此心念系之，尤其是这些年来我已经反复思考过的问题，意识到这一点，不得不说真让我颇为忐忑不安。
It is, I must say, a rather unsettling experience to realize this about a matter so close to my heart, particularly one I have given much thought to over the years.

现在想来，我当初对于海斯协会有关其会员资格之规定的某些方面嗤之以鼻，或许是有些操之过急了。
But it strikes me I may have been a little hasty before in dismissing certain aspects of the Hayes Society's criteria for membership.

请先允许我解释清楚，我并无意收回自己对于“尊严”及其与“伟大”之间关键联系的个人观点。不过，我不免对于海斯协会的另一项规定做了些更为审慎的思考—亦即其公开承认加入协会的先决条件之一是“申请者须服务于显赫门庭”。
I have no wish, let me make clear, to retract any of my ideas on ‘dignity’ and its crucial link with ‘greatness’. But I have been thinking a little more about that other pronouncement made by the Hayes Society – namely the admission that it was a prerequisite for membership of the Society that ‘the applicant be attached to a distinguished household’.

我现在的感觉跟当初并无二致，仍旧认为这表现了该协会的一种不假思索的势利心态。不过，我现在想到，我所特别反对的或许只是他们对于何为“显赫门庭”的过时理解，而非其中所表达的一般原则。
My feeling remains, no less than before, that this represents a piece of unthinking snobbery on the part of the Society. However, it occurs to me that perhaps what one takes objection to is, specifically, the outmoded understanding of what a ‘distinguished household’ is, rather than to the general principle being expressed.

确实，在进一步对此问题进行过一番思考以后，我相信，“伟大”的先决条件是“须服务于显赫门庭”这种说法本身也许确有其道理—只要对于“显赫”的理解比海斯协会的认识更加深入即可。
Indeed, now that I think further on the matter, I believe it may well be true to say it is a prerequisite of greatness that one ‘be attached to a distinguished household’ – so long as one takes ‘distinguished’ here to have a meaning deeper than that understood by the Hayes Society.

事实上，只要将我对于“显赫门庭”可能的诠释与海斯协会对它的理解做一比较，则我相信就能极为鲜明地体现出我们这一代与上一代管家在价值观上的根本差异。我这么说，不仅是想请您注意到这样一个事实，即我们这一辈对于雇主到底是地产贵族还是“经商致富”的态度已经没有那么势利了。
In fact, a comparison of how I might interpret ‘a distinguished household’ with what the Hayes Society understood by that term illuminates sharply, I believe, the fundamental difference between the values of our generation of butlers and those of the previous generation. When I say this, I am not merely drawing attention to the fact that our generation had a less snobbish attitude as regards which employers were landed gentry and which were ‘business’.

我想说的是—我并不认为这种说法有失公允—我们是远比上一代更加理想主义的一代。
What I am trying to say – and I do not think this an unfair comment – is that we were a much more idealistic generation.

我们的老辈更加关心的或许是雇主是不是有封号的贵族，或者是否出身于“旧”族，而我们更在意的则是雇主的道德地位。
Where our elders might have been concerned with whether or not an employer was titled, or otherwise from one of the ‘old’ families, we tended to concern ourselves much more with the moral status of an employer.

我这么说的意思并不是指我们一心瞩目于雇主的私人行为，我的意思是我们更加热切地希望效力于那些—可以这么说—其作为正在促进人类进步的绅士，这一追求在上一代看来想必是颇不寻常的。
I do not mean by this that we were preoccupied with our employers’ private behaviour. What I mean is that we were ambitious, in a way that would have been unusual a generation before, to serve gentlemen who were, so to speak, furthering the progress of humanity.

打个比方说，我们宁肯效力于像乔治·凯特里奇先生这样尽管出身卑微，却为大英帝国未来的福祉做出过无可争辩之卓越贡献的绅士，而不愿意侍奉那些虽有显赫的贵族出身，却只会把光阴虚掷在俱乐部和高尔夫球场上的老爷们。
It would have been seen as a far worthier calling, for instance, to serve a gentleman such as Mr George Ketteridge, who, however humble his beginnings, has made an undeniable contribution to the future well-being of the empire, than any gentleman, however aristocratic his origin, who idled away his time in clubs or on golf courses.

当然，在实际中，很多出身于最高贵家族的绅士一直都有着致力于缓解当前面临之重大难题的传统，所以乍看之下，我们这代人的抱负可能表现得与我们的先辈也并无多大差异。
In practice, of course, many gentlemen from the noblest families have tended to devote themselves to alleviating the great problems of the day, and so, at a glance, it may have appeared that the ambitions of our generation differed little from those of our predecessors.

不过我敢断言，在态度上还是有根本之不同的，这种不同不仅表现在业内的同行相互间热衷于传达的种种话题，更反映在我们这一代中的众多翘楚人物在职位去留方面做出的选择上。
But I can vouch there was a crucial distinction in attitude, reflected not only in the sorts of things you would hear fellow professionals express to each other, but in the way many of the most able persons of our generation chose to leave one position for another.

做出这类决定所考虑的已不仅仅是所得薪水的高低、手下员工的多寡或者雇主门庭的显赫与否了；对我们这代人而言，我们职业声望的高低最根本地取决于我们雇主道德价值的高下上，我感觉这不失为一种公允的说法。
Such decisions were no longer a matter simply of wages, the size of staff at one's disposal or the splendour of a family name; for our generation, I think it fair to say, professional prestige lay most significantly in the moral worth of one's employer.

我相信，借助形象化的比喻方式可以最为鲜明地突出这两代人之间的不同。
I believe I can best highlight the difference between the generations by expressing myself figuratively.

可以这么说，家父那一代管家更倾向于将世界看成是一架梯子—王室成员、公爵以及出身最古老世家的勋爵们居于顶端位置，那些“新贵”阶层等而次之，以此类推，直到降到一个基准点，基准点之下的层级就全由财富的多寡甚或有无来确定了。
Butlers of my father's generation, I would say, tended to see the world in terms of a ladder – the houses of royalty, dukes and the lords from the oldest families placed at the top, those of ‘new money’ lower down and so on, until one reached a point below which the hierarchy was determined simply by wealth – or the lack of it.

任何一位有雄心有抱负的管家只管竭尽全力往这架梯子顶上爬就是了，总的说来，爬得越高，其职业声望也就越大。
Any butler with ambition simply did his best to climb as high up this ladder as possible, and by and large, the higher he went, the greater his professional prestige.

这当然也正是海斯协会那套“显赫门庭”的观念所体现出来的价值观，而迟至一九二九年该协会还在大言不惭地公开发表此类声明，这一事实本身就已清楚不过地说明为什么其灭亡是不可避免的，甚至早就该到来的了。
Such are, of course, precisely the values embodied in the Hayes Society's idea of a ‘distinguished household’, and the fact that it was confidently making such pronouncements as late as 1929 shows clearly why the demise of that society was inevitable, if not long overdue.

因为到了那个时候，这样的想法已经完全跟不上我们这个行业中涌现出来的佼佼者们的观念了。
For by that time, such thinking was quite out of step with that of the finest men emerging to the forefront of our profession.

对于我们这代人而言，这个世界已经不再是一架梯子，而更像是一个轮子了，我相信这种说法还是相当准确的。
For our generation, I believe it is accurate to say, viewed the world not as a ladder, but more as a wheel.

或许我该进一步做些解释。
Perhaps I might explain this further.

在我的印象中，是我们这代人最先认识到了前几代人全都忽略了的一个事实：即世界上的那些重大的决定事实上并不是在公共议事厅里，或者在会期只有寥寥数日又完全置于公众和新闻界关注之下的某个国际会议上做出的。
It is my impression that our generation was the first to recognize something which had passed the notice of all earlier generations: namely that the great decisions of the world are not, in fact, arrived at simply in the public chambers, or else during a handful of days given over to an international conference under the full gaze of the public and the press.

更多的情况下，那些关键性的决定反倒是在国内那些隐秘而又幽静的豪宅里经过讨论、进行权衡后做出的。
Rather, debates are conducted, and crucial decisions arrived at, in the privacy and calm of the great houses of this country.

在众目睽睽之下伴以无比盛大的排场和典礼所发生的那一切，经常不过是执行在这样的豪宅内部经过几周甚或几个月的时间达成的决议，或只是对其进行官方的认可。
What occurs under the public gaze with so much pomp and ceremony is often the conclusion, or mere ratification, of what has taken place over weeks or months within the walls of such houses.

因此在我们看来，这世界就是个轮子，以这些豪门巨宅为轴心而转动，由他们做出的那些重大决策向外辐射到所有围着他们转的人，不论穷人还是富人。
To us, then, the world was a wheel, revolving with these great houses at the hub, their mighty decisions emanating out to all else, rich and poor, who revolved around them.

我们所有这些拥有职业抱负的人，莫不竭尽所能以尽量靠近这个轴心为志向。
It was the aspiration of all those of us with professional ambition to work our way as close to this hub as we were each of us capable.

因为正如我说，我们是充满理想主义的一代人，对我们来说，问题并不是简单地在多大程度上发挥出了我之所能，而是以我之所能达至了何种结果；我们每个人都怀抱着这样的渴望，愿为创造一个更加美好的世界略尽绵薄，做出贡献；我们也都认识到，身在我们这一行，要想做到这一点，最可靠的途径就是效命于那些肩负着当代文明重任的伟大的士绅。
For we were, as I say, an idealistic generation for whom the question was not simply one of how well one practised one's skills, but to what end one did so; each of us harboured the desire to make our own small contribution to the creation of a better world, and saw that, as professionals, the surest means of doing so would be to serve the great gentlemen of our times in whose hands civilization had been entrusted.

当然了，我这么说不过是最为宽泛地概而论之，我乐于承认，我们这一代中有太多人根本就没耐心去做这样深入的思考。
Of course, I am now speaking in broad generalizations and I would readily admit there were all too many persons of our generation who had no patience for such finer considerations.

反而言之，我敢肯定家父那一代当中也有很多人出于本能，已经意识到了他们的工作的这一“道德”维度。
Conversely, I am sure there were many of my father's generation who recognized instinctively this ‘moral’ dimension to their work.

不过总的来说，我相信我这些概括还是准确无误的，而且我所描述的这种“理想主义的”动机至少在我个人的职业生涯中，确实起到了至关重要的作用。
But by and large, I believe these generalizations to be accurate, and indeed, such ‘idealistic’ motivations as I have described have played a large part in my own career.

在我职业生涯的早期，我曾动不动就更换雇主—就是因为意识到那些环境全都无法给我带来持久的满足感—总算是天道酬勤，一直到有机会效命于达林顿勋爵我才终于安顿下来。
I myself moved quite rapidly from employer to employer during my early career – being aware that these situations were incapable of bringing me lasting satisfaction – before being rewarded at last with the opportunity to serve Lord Darlington.

说也奇怪，我是直到今天才头一次从这个角度来考虑问题的；的确，当初我们在仆役大厅里围炉夜话的时候，曾花了那么多时间来讨论“伟大”的本质，像格雷厄姆先生这样杰出的管家和我都从来没有考虑到在这个问题当中还有这样的一整个维度。
It is curious that I have never until today thought of matters in these terms; indeed, that through all those many hours we spent discussing the nature of ‘greatness’ by the fire of our servants’ hall, the likes of Mr Graham and I never considered this whole dimension to the question.

尽管我不会收回之前我对于“尊严”的特质所发表的任何观点，但我必须承认对于这一论题应该附加一个补充条款，即无论一位管家已在多大程度上具备了这样的素质，如果他未能成功地找到一个适当的通道来将他的成就发挥出来，他也很难期望同行们能够认可他的“伟大”。
And while I would not retract anything I have previously stated regarding the quality of ‘dignity’, I must admit there is something to the argument that whatever the degree to which a butler has attained such a quality, if he has failed to find an appropriate outlet for his accomplishments he can hardly expect his fellows to consider him ‘great’.

当然，我们也注意到像马歇尔和莱恩先生这样的人物，他们都只效命于那些其道德地位毫无争议的绅士—韦克林勋爵、坎伯利勋爵、伦纳德·格雷爵士—你不免会得到这样的印象，即他们是不会屈身侍奉那些成色不足的绅士的。
Certainly, it is observable that figures like Mr Marshall and Mr Lane have served only gentlemen of indisputable moral stature – Lord Wakeling, Lord Camberley, Sir Leonard Gray – and one cannot help get the impression that they simply would not have offered their talents to gentlemen of lesser calibre.

确实，这个问题你越想就越明显：隶属于一个真正的显赫门庭确是达至“伟大”的先决条件。
Indeed, the more one considers it, the more obvious it seems: association with a truly distinguished household is a prerequisite of ‘greatness’.

一个“伟大的”管家肯定只能是那种人：他在指点自己多年的服务生涯时能够自豪地说，他已经将他的全副才能用以服务一位伟大的绅士了—而通过这样的一位绅士，他也等于是服务了全人类。
A ‘great’ butler can only be, surely, one who can point to his years of service and say that he has applied his talents to serving a great gentleman – and through the latter, to serving humanity.

我说过，这些年来我居然从来没有从这样的角度考虑过这个问题；不过话又说回来了，或许正是难得地出门进行这样一次旅行，才促使我对于这个我本以为早就彻彻底底思考清楚了的题目产生了如此出乎意料的新鲜观点。
As I say, I have never in all these years thought of the matter in quite this way; but then it is perhaps in the nature of coming away on a trip such as this that one is prompted towards such surprising new perspectives on topics one imagined one had long ago thought through thoroughly.

而且大约一个钟头之前发生的一个小状况想必也起到了推波助澜的作用，促使我沿着这样的思路来思考问题—我得承认，这个小状况还颇使我担了不小的心。
I have also, no doubt, been prompted to think along such lines by the small event that occurred an hour or so ago – which has, I admit, unsettled me somewhat.

我在极为宜人的天气中心情愉快地开了一上午的车，然后又在一个乡村小酒馆里享用了一顿丰盛的午餐。
Having enjoyed a good morning's motoring in splendid weather, and having lunched well at a country inn, I had just crossed the border into Dorset.

但在刚驶入多塞特郡不久，我就觉察到从汽车引擎那儿发出了一种过热的气味。
It was then I had become aware of a heated smell emanating from the car engine.

一想到我可能对主人的福特车造成了某种损害，我当然吓得不轻，赶快就把车停了下来。
The thought that I had done some damage to my employer's Ford was, of course, most alarming and I had quickly brought the vehicle to a halt.

我发现自己正处在一条狭窄的小路当中，小路的两侧全都被繁茂的林木遮了个严实，很难看清周围的情况。
I found myself in a narrow lane, hemmed in on either side by foliage so that I could gain little idea of what was around me.

往前也看不远，因为那条小路在前方大约二十码的地方就拐了个大弯。
Neither could I see far ahead, the lane winding quite sharply twenty yards or so in front.

我意识到我不能在这儿长时间停留，因为如果前方有车转过那个弯道，弄不好就会跟我主人的福特车撞个正着。
It occurred to me that I could not remain where I was for long without incurring the risk of an oncoming vehicle coming round the same bend and colliding into my employer's Ford.

于是我又重新发动了引擎，发觉这次的气味已经没有先前那么强烈了，这才稍稍安了一下心。
I thus started the engine again and was partially reassured to find that the smell seemed not as powerful as before.

我知道最好的办法是找一家修车行，或者是找一家绅士的大宅，宅里极有可能找到能看得出毛病出在哪里的司机。
My best course, I could see, was to look for a garage, or else a large house of a gentleman where there would be a good chance I might find a chauffeur who could see what the matter was.

可是那条小路继续蜿蜒了不短的距离，道路两旁高大的树篱也一直都不曾间断，很大程度上挡住了我的视线，所以尽管我经过了几户人家的大门，有的院内明显是有车道的，我却一直都没办法瞥见里面的宅第。
But the lane continued to wind for some distance, and the high hedges on either side of me also persisted, obscuring my vision so that though I passed several gates, some of which clearly yielded on to driveways, I was unable to glimpse the houses themselves.

我又开了约莫半英里远，那恼人的气味已经是越来越浓了，这才终于摆脱了那条小路，开上了一段乡村的主干道路。
I continued for another half-mile or so, the disturbing smell now growing stronger by the moment, until at last I came out on to a stretch of open road.

我看到前方的不远处，没错，就在我的左侧，隐约浮现出一幢高大的维多利亚时代的宅第，宅前有一大片草坪，还有一条显然是由旧的马车道改造而成的汽车道。
I could now see some distance before me, and indeed, ahead to my left there loomed a tall Victorian house with a substantial front lawn and what was clearly a driveway converted from an old carriage track.

当我驶近那幢大宅时，我就更是大受鼓舞了，因为主建筑附设的车库大门敞开着，里面赫然停着一辆宾利汽车。
As I drew up to it, I was encouraged further to glimpse a Bentley through the open doors of a garage attached to the main house.

宅第的大门也敞开着，我于是将福特车沿着车道开了一小段，下车朝宅第的后门走去。
The gate too had been left open and so I steered the Ford a little way up the drive, got out and made my way to the back door of the house.

开门的是个只穿了件衬衣的男人，也没有系领带，不过我在向他打听府上的司机时，他开心地回答说我“一下子就中了头彩”。
This was opened by a man dressed in his shirt sleeves, wearing no tie, but who, upon my asking for the chauffeur of the house, replied cheerfully that I had ‘hit the jackpot first time’.

听我描述了一下问题以后，他大步流星地来到福特车前，打开引擎盖只查看了几秒钟的时间就跟我说：“水，您哪。
On hearing of my problem, the man without hesitation came out to the Ford, opened the bonnet and informed me after barely a few seconds’ inspection: ‘Water, guv.

您的散热器里得加点水啦。”
You need some water in your radiator.’

他貌似对这整个状况感到非常好笑，不过又很热心帮忙；他回到屋里去，不一会就提着一壶水和一个漏斗回来了。
He seemed to be rather amused by the whole situation, but was obliging enough; he returned inside the house and after a few moments emerged again with a jug of water and a funnel.

他在把散热器灌满的过程中，头低在引擎上方，开始亲切地跟我闲聊起来，知道我正驾车在这一区域旅行以后，他向我推荐了当地的一处美景，是个距此不过半英里远的池塘。
As he filled the radiator, his head bent over the engine, he began to chat amiably, and on ascertaining that I was undertaking a motoring tour of the area, recommended I visit a local beauty spot, a certain pond not half a mile away.

趁着这个工夫，我也好好观察了一下这幢大宅；宅子的高度要大于其宽度，有四层楼高，正立面几乎爬满了常春藤，一路都爬到了顶端的山墙上。
I had had in the meantime more opportunity to observe the house; it was taller than it was broad, comprising four floors, with ivy covering much of the front right up to the gables.

可是透过窗户往里看去，却发现至少有一半的房间里都蒙着防尘布。
I could see from its windows, however, that at least half of it was dust-sheeted.

一等那个人给散热器加满了水，重新盖好引擎盖，我就跟他说起了这件事。
I remarked on this to the man once he had finished with the radiator and closed the bonnet.

“真是可惜啊，”他说。
‘A shame really,’ he said.

“这是幢很招人喜欢的老房子。
‘It's a lovely old house.

实际情况是上校打算把它给卖了。
Truth is, the Colonel's trying to sell the place off.

他现在也是用不着这么大的房子了。”
He ain't got much use for a house this size now.’

我忍不住向他打听这里一共雇了多少人，听他说就只有他一个人，再有就是一个厨子每天傍晚过来做做饭的时候，我也并没有感到吃惊。
I could not help inquiring then how many staff were employed there, and I suppose I was hardly surprised to be told there was only himself and a cook who came in each evening.

看起来他是身兼管家、贴身男仆、司机和清洁工于一身了。
He was, it seemed, butler, valet, chauffeur and general cleaner.

他在大战期间曾是上校的勤务兵，他解释道；德军入侵比利时的时候他跟上校正在那里，协约国联军登陆时他跟上校也躬逢其盛。
He had been the Colonel's batman in the war, he explained; they had been in Belgium together when the Germans had invaded and they had been together again for the Allied landing.

之后他又仔细地打量了我一番，这才说：
Then he regarded me carefully and said:

“现在我才明白了。
‘Now I got it.

一开始我还没看出来，不过现在我弄明白了。
I couldn't make you out for a while, but now I got it.

您就是他们说的那种顶尖级别的大管家。
You're one of them top-notch butlers.

是那种名门贵族的大宅门里出来的。”
From one of them big posh houses.’

我跟他说这话也不算离谱以后，他又继续道：
When I told him he was not so far off the mark, he continued:

“现在我算是明白了。
‘Now I got it.

一时间我还没看出来，您瞧，因为您说起话来十足就像个绅士。
Couldn't make you out for a while, see, ’cause you talk almost like a gentleman.

而且您还开着这么辆漂亮的古董车，”—他朝那辆福特做了个手势—“一开始我还想，哟，来了位货真价实的贵族老爷子。
And what with you driving an old beauty like this’ – he gestured to the Ford – ‘I thought at first, here's a really posh geezer.

这就对啦，您哪。
And so you are, guv.

真是上流社会的做派，我是说。
Really posh, I mean.

我还从来都没真正领教过呢，您瞧。
I never learnt any of that myself, you see.

我不过就是个退了伍的老勤务兵。”
I'm just a plain old batman gone civvy.’

然后他又问我受雇于哪户人家，我跟他说了以后，他侧着头，脸上露出好奇的神情。
He then asked me where it was I was employed, and when I told him he leant his head to one side with a quizzical look.

“达林顿府，”他自语道。
‘Darlington Hall,’ he said to himself.

“达林顿府。
‘Darlington Hall.

肯定是个上流社会的人家，就连在下这样的白痴听着都觉得耳熟。
Must be a really posh place, it rings a bell even to an idiot like yours truly.

达林顿府。
Darlington Hall.

等等，您说的不会就是达林顿勋爵的那个达林顿府吧？”
Hang on, you don't mean Darlington Hall, Lord Darlington's place?’

“以前确实是达林顿勋爵的府第，直到三年前爵爷逝世，”我告诉他。
‘It was Lord Darlington's residence until his death three years ago,’ I informed him.

“如今是约翰·法拉戴先生的住处了，他是位美国绅士。”
‘The house is now the residence of Mr John Farraday, an American gentleman.’

“您在那样的地方工作，那就肯定是顶尖级别的大管家无疑啦。
‘You really must be top-notch working in a place like that.

像您这样的如今剩下来的可不多了吧，呃？”
Can't be many like you left, eh?’

然后他在问的时候语气明显有了变化。“您是说，您当真曾为那位达林顿勋爵工作过？”
Then his voice changed noticeably as he inquired: ‘You mean you actually used to work for that Lord Darlington?’

他再次细细地打量了我一番。
He was eyeing me carefully again.

我说：
I said:

“哦，不是，我是受雇于约翰·法拉戴先生的，就是那位从达林顿家族手里买下那幢宅第的美国绅士。”
‘Oh no, I am employed by Mr John Farraday, the American gentleman who bought the house from the Darlington family.’

“喔，那您就不大可能认识那位达林顿勋爵了。
‘Oh, so you wouldn't have known that Lord Darlington.

我只是很好奇他到底什么样子。
Just that I wondered what he was like.

他是个什么样的人。”
What sort of bloke he was.’

我告诉那人我得上路了，郑重地感谢了他的热心帮助。
I told the man that I would have to be on my way and thanked him emphatically for his assistance.

他可真是个可亲可爱的小伙子，不厌其烦地引导我把车倒出大门，分别前，他俯下身再次推荐我去参观一下当地的那个池塘，反复告诉我该怎么到那儿去。
He was, after all, an amiable fellow, taking the trouble to guide me in reversing out through the gateway, and before I parted, he bent down and recommended again that I visit the local pond, repeating his instructions as to how I would find it.

“那是个很美的小地方，”他补充道。
‘It's a beautiful little spot,’ he added.

“要是错过了你肯定会后悔的。
‘You'll kick yourself for missing it.

事实上，上校这会子就正在那儿钓鱼呢。”
In fact, the Colonel's doing a bit of fishing there this minute.’

福特车确乎又回到了最佳状态，既然那个池塘离我预定的线路并不远，只需稍微绕一下，我就决定从善如流，采纳那位勤务兵的建议。
The Ford seemed to be in fine form again, and since the pond in question was but a small detour off my route, I decided to take up the batman's suggestion.

他的指示听起来原本挺清楚的，可是我一旦离开了主干道，打算照他的指示往那儿开，我就发现自己在那些狭窄而又曲里拐弯的小路上迷了路，那些小路就跟之前我第一次闻到那令人心焦的气味时的路段非常相似。
His directions had seemed clear enough, but once I had turned off the main road in an attempt to follow them, I found myself getting lost down narrow, twisting lanes much like the one in which I had first noticed the alarming smell.

有时候道路两旁的树木是如此浓密，几乎完全把阳光给遮住了，于是我的眼睛就不得不努力地去适应明亮的阳光与阴暗的浓荫之间的强烈反差。
At times, the foliage on either side became so thick as practically to blot out the sun altogether, and one found one's eyes struggling to cope with the sudden contrasts of bright sunlight and deep shade.

不过在经过一番搜寻之后，我终于还是找到了那个指向“莫蒂默池塘”的路标，于是在半个多钟头前，我顺利抵达了这个景点。
Eventually, however, after some searching, I found a signpost to ‘Mortimer's Pond’, and so it was that I arrived here at this spot a little over half an hour ago.

此刻我觉得自己真该深深地感激那位勤务兵，因为除了帮我修好了车以外，他还让我发现了这么一个万分迷人的所在，要是没有他，我是绝不可能找到这儿来的。
I now find myself much indebted to the batman, for quite aside from assisting with the Ford, he has allowed me to discover a most charming spot which it is most improbable I would ever have found otherwise.

池塘并不大—周长估计不过四分之一英里左右—只要站在任何一个突起的位置，它的全景你都可以尽收眼底。
The pond is not a large one – a quarter of a mile around its perimeter perhaps – so that by stepping out to any promontory, one can command a view of its entirety.

这里弥漫着一种异常静谧的气氛。
An atmosphere of great calm pervades here.

池塘周遭遍植树木，其密度恰好能为池畔提供宜人的荫蔽，这里那里一丛丛高高的芦苇和香蒲钻出水面，也打破了那静止不动的天光云影。
Trees have been planted all around the water just closely enough to give a pleasant shade to the banks, while here and there clusters of tall reeds and bulrushes break the water's surface and its still reflection of the sky.

我脚上的鞋子颇不便于我绕着池畔走上一圈—从我现在坐着的位置就能看到池畔的小径逐渐没入了一片片深深的泥泞中—不过我要说，一见之下这正是此地风景的魅力所在，我真想踩着泥泞走上那么一圈。
My footwear is not such as to permit me easily to walk around the perimeter – I can see even from where I now sit the path disappearing into areas of deep mud – but I will say that such is the charm of this spot that on first arriving, I was sorely tempted to do just that.

只有在想到这样一番探险可能导致的灾难性后果，想到这么一来我身上这套旅行服装就要毁于一旦了，我这才按捺住这一时的冲动，退而求其次地满足于坐在这条长凳上静静地欣赏。
Only the thought of the possible catastrophes that might befall such an expedition, and of sustaining damage to my travelling suit, persuaded me to content myself with sitting here on this bench.

半个钟头过去了，我就这么坐在这里，静观池畔各个位置静坐垂钓者的进展。
And so I have done for the past half-hour, contemplating the progress of the various figures seated quietly with their fishing rods at various points around the water.

从我坐的那个位置，我大约能看到十来位钓客，不过那强烈的日光再加上低垂的枝柯形成的树荫却让我无法看清楚他们当中的任何一位，于是我也不得不放弃之前期望着不妨一试的那个小游戏：猜测哪位钓客有可能是刚刚帮了我一个大忙的那幢宅第的主人—那位退役的上校。
At this point, I can see a dozen or so such figures, but the strong lights and shades created by the low-hanging branches prevent me from making any of them out clearly and I have had to forgo the small game I had been anticipating of guessing which of these fishermen is the Colonel at whose house I have just received such useful assistance.

无疑，正是周遭环境的清幽使我能够更为全面透彻地细细思考这半个多钟头以来进入我思绪的那些念头。
It is no doubt the quiet of these surroundings that has enabled me to ponder all the more thoroughly these thoughts which have entered my mind over this past half-hour or so.

的确，要不是周围的这份静谧，我也不太可能再细细去咂摸跟那位勤务兵邂逅以后我自己的言行举止。
Indeed, but for the tranquillity of the present setting, it is possible I would not have thought a great deal further about my behaviour during my encounter with the batman.

也即，我为什么要给人留下我从未受雇于达林顿勋爵这样一个明确的印象。因为毋庸置疑，方才发生的情形确实是这样的。
That is to say, I may not have thought further why it was that I had given the distinct impression I had never been in the employ of Lord Darlington. For surely, there is no real doubt that is what occurred.

他问我：“您是说，您当真曾为那位达林顿勋爵工作过？”而我给出的回答只能被理解为我并没有为爵爷工作过。
He had asked: ‘You mean you actually worked for that Lord Darlington?’ and I had given an answer which could mean little other than that I had not.

当时我也可能只是突发奇想，并无深意—不过对于如此明显的怪异举动，这恐怕很难说是个令人信服的解释。因为不管怎么说，我现在都得承认，像是跟勤务兵之间发生的类似的小插曲，这已经并非是头一遭了；虽说我对其性质还没有明确的认识，不过这个小插曲无疑跟几个月前威克菲尔德夫妇来访期间发生的那件事有些必然的联系。
It could simply be that a meaningless whim had suddenly overtaken me at that moment – but that is hardly a convincing way to account for such distinctly odd behaviour. In any case, I have now come to accept that the incident with the batman is not the first of its kind; there is little doubt it has some connection – though I am not quite clear of the nature of it – with what occurred a few months ago during the visit of the Wakefields.

威克菲尔德先生和太太是对美国夫妇，已经在英国—据我所知，是在肯特郡的某个地方—定居了有二十年了。
Mr and Mrs Wakefield are an American couple who have been settled in England – somewhere in Kent, I understand – for some twenty years.

因为跟法拉戴先生在波士顿的社交圈里有些共同的熟人，他们有一天就造访了达林顿府，待到用过午餐，在下午茶之前离开。
Having a number of acquaintances in common with Mr Farraday amidst Boston society, they paid a short visit one day to Darlington Hall, staying for lunch and leaving before tea.

那个时候法拉戴先生来到达林顿府也不过几周的时间，他对这处房产的热情正是最为高涨的时候；于是威克菲尔德夫妇来访的大部分时间都花在参观这处房产上，由我的雇主亲自带领上上下下看了一个遍，连那些罩着防尘布的区域都没放过，实在是显得没这个必要。
I now refer to a time only a few weeks after Mr Farraday had arrived at the house, a time when his enthusiasm for his acquisition was at a height; consequently, much of the Wakefields’ visit was taken up with my employer leading them on what might have seemed to some an unnecessarily extensive tour of the premises, including all the dust-sheeted areas.

不过，威克菲尔德夫妇对于四处探访表现出来的兴致至少跟法拉戴先生一样高涨，我在府里各处忙我工作的时候，经常会听到从他们刚刚到达的地方传来的各式各样美国人所特有的赞叹和惊呼声。
Mr and Mrs Wakefield, however, appeared to be as keen on the inspection as Mr Farraday, and as I went about my business, I would often catch various American exclamations of delight coming from whichever part of the house they had arrived at.

法拉戴先生是带领客人从顶楼开始参观的，等他们来到底层逐一参观那些富丽堂皇的厅堂时，他已经像是坐上了一飞冲天的飞机，陶陶然、飘飘然了，不厌其烦地向客人指出檐口和窗架上那精雕细琢的细部，手舞足蹈地描述“那些英国的爵爷”在每个房间都曾做过些什么。
Mr Farraday had commenced the tour at the top of the house, and by the time he had brought his guests down to inspect the magnificence of the ground-floor rooms, he seemed to be on an elevated plane, pointing out details on cornicings and window frames, and describing with some flourish ‘what the English lords used to do’ in each room.

我当然不会有意去偷听，不过从听到的一句半句当中也就知道他们谈话的大意了，我不禁为我的雇主知识面之广博而感到吃惊，其中除了偶有不尽不实之处以外，足以透露出他对英式传统和习惯的深深迷恋。
Although of course I made no deliberate attempt to overhear, I could not help but get the gist of what was being said, and was surprised by the extent of my employer's knowledge, which, despite the occasional infelicity, betrayed a deep enthusiasm for English ways.

值得注意的还有，威克菲尔德夫妇—尤其是威克菲尔德太太—对我国的传统其实也所知甚详，从他们的言谈话语当中可以得知，他们自己也拥有一幢颇为富丽堂皇的英式旧宅。
It was noticeable, moreover, that the Wakefields – Mrs Wakefield in particular – were themselves by no means ignorant of the traditions of our country, and one gathered from the many remarks they made that they too were owners of an English house of some splendour.

在那次参观探访活动的某个阶段—我从门厅那儿穿过，本以为宾主一行已经到户外参观庭院去了—发现威克菲尔德太太并没有出去，正在仔细地检视通往餐厅的那道石质的拱形门廊。
It was at a certain stage during this tour of the premises – I was crossing the hall under the impression that the party had gone out to explore the grounds – when I saw that Mrs Wakefield had remained behind and was closely examining the stone arch that frames the doorway into the dining room.

我从她身边经过时，轻声道了声“请原谅，夫人”，她转过头道：
As I went past, muttering a quiet ‘excuse me, madam,’ she turned and said:

“哦，史蒂文斯，也许你能够告诉我。
‘Oh, Stevens, perhaps you're the one to tell me.

这座拱廊看起来像是十七世纪的，不过它难道不是相当晚近的时候才添造的吗？
This arch here looks seventeenth century, but isn't it the case that it was built quite recently?

也许就是达林顿勋爵的时代修建的？”
Perhaps during Lord Darlington's time?’

“有这个可能，夫人。”
‘It is possible, madam.’

“非常美。
‘It's very beautiful.

不过它有可能是仿造时期的一个产物，其实只有几年的历史。
But it is probably a kind of mock period piece done only a few years ago.

难道不是这样吗？”
Isn't that right?’

“我不能确定，夫人，不过确实有此可能。”
‘I'm not sure, madam, but that is certainly possible.’

接着，威克菲尔德太太刻意压低嗓音道：“不过请跟我说说，史蒂文斯，这位达林顿勋爵到底是什么样子的呢？
Then, lowering her voice, Mrs Wakefield had said: ‘But tell me, Stevens, what was this Lord Darlington like?

你想必肯定是为他工作过的。”
Presumably you must have worked for him.’

“没有，夫人，我并没有。”
‘I didn't, madam, no.’

“哦，我还以为你有过呢。
‘Oh, I thought you did.

奇怪了，我怎么会有那样的想法呢。”
I wonder why I thought that.’

威克菲尔德太太转回头去继续端详那座拱廊，把手放在那上面道：“如此说来我们是没办法确定了。
Mrs Wakefield turned back to the arch and putting her hand to it, said: ‘So we don't know for certain then.

不过，在我看来它还是像一件仿造品。
Still, it looks to me like it's mock.

非常精妙，但是仿造的。”
Very skilful, but mock.’

本来我可能很快就会把这次短暂的交谈完全忘掉的；然而，在威克菲尔德夫妇离开后，我把下午茶给法拉戴先生端到会客厅里的时候，却注意到他显得颇为心事重重。
It is possible I might have quickly forgotten this exchange; however, following the Wakefields’ departure, I took in afternoon tea to Mr Farraday in the drawing room and noticed he was in a rather preoccupied mood.

经过开始的一段沉默后，他说：
After an initial silence, he said:

“你知道吗，史蒂文斯，威克菲尔德太太对这幢宅子的好感并没有我原本料想的那般强烈。”
‘You know, Stevens, Mrs Wakefield wasn't as impressed with this house as I believe she ought to have been.’

“是吗，先生？”
‘Is that so, sir?’

“事实上，她似乎认为我夸大了这座庄园的背景和世系。
‘In fact, she seemed to think I was exaggerating the pedigree of this place.

认为所有那些可以追溯到几世纪前的建筑特色都是我编造出来的。”
That I was making it up about all these features going back centuries.

“真的吗，先生？”
‘Indeed, sir?’

“她不断地断言每一样东西这也是‘仿造的’那也是‘仿造的’。
‘She kept asserting everything was “mock” this and “mock” that.

她甚至认为连你都是‘仿造的’，史蒂文斯。”
She even thought you were “mock”, Stevens.’

“真的吗，先生？”
‘Indeed, sir?’

“真的，史蒂文斯。
‘Indeed, Stevens.

我跟她说过你是货真价实的，一位货真价实的老牌英国管家。
I'd told her you were the real thing. A real old English butler.

跟她说你在这幢老宅里已经工作了三十多年，效命于一位货真价实的英国爵爷。
That you'd been in this house for over thirty years, serving a real English lord.

可是威克菲尔德太太在这一点上都敢于反驳我。
But Mrs Wakefield contradicted me on this point.

事实上，她反驳我的时候显得可有把握了。”
In fact, she contradicted me with great confidence.’

“是吗，先生？”
‘Is that so, sir?’

“威克菲尔德太太确信，史蒂文斯，你是在被我雇定以后才到这儿来工作的。
‘Mrs Wakefield, Stevens, was convinced you never worked here until I hired you.

事实上，她给人的印象是这都是你亲口告诉她的。
In fact, she seemed to be under the impression she'd had that from your own lips.

你应该能够想象，这让我显得十足像个傻瓜。”
Made me look pretty much a fool, as you can imagine.’

“这真是太令人遗憾了，先生。”
‘It's most regrettable, sir.’

“我的意思是说，史蒂文斯，这确是一幢名副其实、历史悠久的英国府第，难道不是吗？
‘I mean to say, Stevens, this is a genuine grand old English house, isn't it?

我就是为了这个才花钱买下了的。
That's what I paid for.

你是一位名副其实的旧式英国管家，并不是什么小男仆假装冒充的。
And you're a genuine old-fashioned English butler, not just some waiter pretending to be one.

你是货真价实的，不是吗？
You're the real thing, aren't you?

我想要的是真货，我得到的难道不是真货吗？”
That's what I wanted, isn't that what I have?’

“我敢说您得到的确实是真货，先生。”
‘I venture to say you do, sir.’

“那么你能跟我解释一下威克菲尔德太太到底在说些什么吗？
‘Then can you explain to me what Mrs Wakefield is saying?

对我来说这可真是个不解之谜。”
It's a big mystery to me.’

“关于我的职业，我确实有可能对这位夫人造成了一点点误导，先生。
‘It is possible I may well have given the lady a slightly misleading picture concerning my career, sir.

如果由此而导致了您的难堪，我要向您郑重地道歉。”
I do apologize if this caused embarrassment.’

“我得说，这确实让我很难堪。
‘I'll say it caused embarrassment.

那些人现在肯定把我当成吹牛大王和骗子手了。
Those people have now got me down for a braggart and a liar.

可是，你说你有可能对她造成了‘一点点误导’，你这话到底是什么意思？”
Anyway, what do you mean, you may have given her a “slightly misleading picture”?’

“我深表歉意，先生。
‘I'm very sorry, sir.

我原不知道我有可能会让您这么难堪的。”
I had no idea I might cause you such embarrassment.’

“真该死，史蒂文斯，你为什么要跟她编这么个故事呢？”
‘But dammit, Stevens, why did you tell her such a tale?’

我权衡了一下当时的情势，而后说道：“我深表歉意，先生。
I considered the situation for a moment, then said: ‘I'm very sorry, sir.

不过我这么做是出于本国传统礼俗的考虑。”
But it is to do with the ways of this country.’

“你到底在说些什么呀，伙计？”
‘What are you talking about, man?’

“我的意思是说，先生，在英国，一个雇员随便议论他前任的雇主是不符合礼俗的行为。”
‘I mean to say, sir, that it is not customary in England for an employee to discuss his past employers.’

“史蒂文斯，你不希望辜负前任雇主对你的信任，这很好。
‘OΚ, Stevens, so you don't wish to divulge past confidences.

但你至于离谱到空口白牙地否认在我之前就再没有为别的人工作过吗？”
But does that extend to you actually denying having worked for anyone other than me?’

“如果您要这样说的话，这确实显得有些离谱了，先生。
‘It does seem a little extreme when you put it that way, sir.

不过对于雇员来说，给人这样的印象的确经常被认为是值得称许的。
But it has often been considered desirable for employees to give such an impression.

就让我这么来说吧，先生，这就有点像是婚姻方面的习惯性做法。
If I may put it this way, sir, it is a little akin to the custom as regards marriages.

如果一位离过婚的女士陪同她的第二任丈夫抛头露面，通常认为还是压根不要提及她的前一段婚姻更为合适。
If a divorced lady were present in the company of her second husband, it is often thought desirable not to allude to the original marriage at all.

在我们这一行里，也有类似的习惯性礼俗。”
There is a similar custom as regards our profession, sir.’

“好吧，要是我能早点知道你们有这些讲究就好了，”我的雇主说着靠回到椅背上去。
‘Well, I only wish I'd known about your custom before, Stevens,’ my employer said, leaning back in his chair.

“这让我看起来活像是个傻瓜。”
‘It certainly made me look like a chump.’

我相信即便就在当时，我也已经意识到我对法拉戴先生的解释—虽说，当然了，并没有全然违背事实—非常不幸，是很不充分的。
I believe I realized even at the time that my explanation to Mr Farraday – though, of course, not entirely devoid of truth – was woefully inadequate.

不过当一个人有太多别的事情需要考虑的时候，也就很自然地不会过多地去考虑这类问题了，所以有段时间我也确实把整个儿这个插曲全都抛在了脑后。
But when one has so much else to think about, it is easy not to give such matters a great deal of attention, and so I did, indeed, put the whole episode out of my mind for some time.

可是如今在池塘边这静谧的环境中再次回想起此事，就可以看出，那天我对威克菲尔德太太的那番举动毫无疑问跟今天下午刚刚发生的这件事是有明显的关联的。
But now, recalling it here in the calm that surrounds this pond, there seems little doubt that my conduct towards Mrs Wakefield that day has an obvious relation to what has just taken place this afternoon.

当然了，现如今很多人对于达林顿勋爵都发表过很多无知的谬论，也许您会以为我是对自己跟爵爷的关系感到难堪或是羞耻，而正是为此才会做出了那样的举动。
Of course, there are many people these days who have a lot of foolish things to say about Lord Darlington, and it may be that you are under the impression I am somehow embarrassed or ashamed of my association with his lordship, and it is this that lies behind such conduct.

那就让我在此明确地予以澄清，事实绝非如此。
Then let me make it clear that nothing could be further from the truth.

现在人们听到的有关爵爷的传闻，其绝大多数都纯属无稽之谈，几乎没有任何事实的根据。
The great majority of what one hears said about his lordship today is, in any case, utter nonsense, based on an almost complete ignorance of the facts.

在我看来，如果将我那古怪的举动解释为希望借此避免再次听到有关爵爷的无稽之谈，这确实倒是颇为讲得通的；也就是说，在这两次事件当中我都选择以善意的谎言予以应对，无非是为了避免不愉快的事情发生。
Indeed, it seems to me that my odd conduct can be very plausibly explained in terms of my wish to avoid any possibility of hearing any further such nonsense concerning his lordship; that is to say, I have chosen to tell white lies in both instances as the simplest means of avoiding unpleasantness.

我越想越是觉得这的确像是非常合理的解释；因为确实，这些日子以来最让我感到恼怒的就无过于反复听到这种无知的谬论了。
This does seem a very plausible explanation the more I think about it; for it is true, nothing vexes me more these days than to hear this sort of nonsense being repeated.

让我这么来说吧，达林顿勋爵是一位具有崇高道德地位的绅士—这种高度足以使那些传播有关他的无知谬论的绝大多数人都相形见绌—而且我非常乐意担保，他这种高度的道德感一直到他逝世都未曾有过丝毫的松懈。
Let me say that Lord Darlington was a gentleman of great moral stature – a stature to dwarf most of these persons you will find talking this sort of nonsense about him – and I will readily vouch that he remained that to the last.

如果有人以为我会因为自己跟这样一位绅士的关系而感到后悔的话，那可绝对是大谬不然。
Nothing could be less accurate than to suggest that I regret my association with such a gentleman.

事实上，您应该可以理解，在过去那么长的岁月中我都得以朝夕侍奉、亲炙爵爷，就等于是最为接近了这个世界运行的轴心，而这正是我这样的人所梦寐以求的最佳契机。
Indeed, you will appreciate that to have served his lordship at Darlington Hall during those years was to come as close to the hub of this world's wheel as one such as I could ever have dreamt.

我为达林顿勋爵整整服务了三十五年；如果我说在这些年间，我是真正意义上的“隶属于显赫门庭”的话，这肯定是不会有丝毫疑义的。
I gave thirty-five years’ service to Lord Darlington; one would surely not be unjustified in claiming that during those years, one was, in the truest terms, ‘attached to a distinguished household’.

回顾我迄今为止的职业生涯，我最大的满足即来自那段岁月所获得的成就，今天，对于自己居然能获得如此之殊荣，我体验到的唯有最为深切的自豪与感恩。
In looking back over my career thus far, my chief satisfaction derives from what I achieved during those years, and I am today nothing but proud and grateful to have been given such a privilege.

# 第三天—上午 | DAY THREE–MORNING

汤顿市，萨默塞特郡
Taunton, Somerset

昨夜我投宿于萨默塞特郡汤顿城外不远处的一家小旅店，名叫“马车与马”。
I lodged last night in an inn named the Coach and Horses a little way outside the town of Taunton, Somerset.

这是位于路边的一幢茅草屋顶的小村舍，在最后一线夕阳当中我来到这里的时候，从福特车内望去，那小旅店显得异常迷人。
This being a thatch-roofed cottage by the roadside, it had looked a conspicuously attractive prospect from the Ford as I had approached in the last of the daylight.

店老板领我走上一段木质楼梯，来到个小房间里，屋内陈设相当简朴却非常适用。
The landlord led me up a timber stairway to a small room, rather bare, but perfectly decent.

他问我是否用过了晚餐，我就请他送一份三明治到我房间里，结果证明我这个选择虽说简单无比，却非常令人满意。
When he inquired whether I had dined, I asked him to serve me with a sandwich in my room, which proved a perfectly satisfactory option as far as supper was concerned.

不过随着夜幕的降临，我在房间里开始有点坐立不安了，最后我决定还是到楼下的酒吧里去尝一点当地的苹果酒。
But then as the evening drew on, I began to feel a little restless in my room, and in the end decided to descend to the bar below to try a little of the local cider.

总共有五六位顾客，全都聚在吧台周围—从外表看来都是干各种农活儿的—房间的其余部分还是空荡荡的。
There were five or six customers all gathered in a group around the bar – one guessed from their appearance they were agricultural people of one sort or another – but otherwise the room was empty.

我向店老板要了一啤酒杯的苹果酒，在距离吧台有段距离的一张桌子边坐下来，打算放松一下，并且整理一下这一天来的思绪。
Acquiring a tankard of cider from the landlord, I seated myself at a table a little way away, intending to relax a little and collect my thoughts concerning the day.

不过没过多久我就意识到，我的出现还是干扰了那几位本地人，他们似乎觉得有必要表现一下好客之道。
It soon became clear, however, that these local people were perturbed by my presence, feeling something of a need to show hospitality.

每次他们的闲谈稍有停歇，他们其中就总有一位朝我坐的方向偷瞄上一眼，仿佛是一心想找个机会跟我攀谈两句。
Whenever there was a break in their conversation, one or the other of them would steal a glance in my direction as though trying to find it in himself to approach me.

最后，终于有个人提高嗓门对我说：
Eventually one raised his voice and said to me:

“看来您是要在楼上住一宿了，先生。”
‘It seems you've let yourself in for a night upstairs here, sir.’

我跟他说正是如此，说话的那位表示怀疑地摇了摇头道：“您在楼上恐怕是睡不了几个钟头的，先生。
When I told him this was so, the speaker shook his head doubtfully and remarked: ‘You won't get much of a sleep up there, sir.

除非是您喜欢老鲍勃弄出来的动静，”—他指了指店老板—“砰砰地在这底下一直闹到夜半三更。
Not unless you're fond of the sound of old Bob’ – he indicated the landlord – ‘banging away down here right the way into the night.

天刚破晓您就会被他老婆冲他吼叫的声音给吵醒的。”
And then you'll get woken by his missus shouting at him right from the crack of dawn.’

尽管店老板一叠声地抗议，还是引来周围人等的哄堂大笑。
Despite the landlord's protests, this caused loud laughter all round.

“确实如此吗？”
‘Is that indeed so?’

我说。
I said.

说话间，我突然想到—最近有好多次在法拉戴先生面前也有同样的念头浮起—这时候我应该回应一句俏皮话之类的。
And as I spoke, I was struck by the thought – the same thought as had struck me on numerous occasions of late in Mr Farraday's presence – that some sort of witty retort was required of me.

的确，那帮当地人此时都颇有礼貌地保持着沉默，等着我下面的言辞。
Indeed, the local people were now observing a polite silence, awaiting my next remark.

我于是搜索枯肠，最后终于道：
I thus searched my imagination and eventually declared:

“堪称本地的鸡鸣变奏曲喽，无疑该是。”
‘A local variation on the cock crow, no doubt.’

起先，沉默仍在继续，仿佛那些当地人以为我还有进一步的发挥。
At first the silence continued, as though the local persons thought I intended to elaborate further.

不过在注意到我脸上那逗人发笑的表情时，这才爆发出一阵笑声，但笑得总有点困惑不解的意思。
But then noticing the mirthful expression on my face, they broke into a laugh, though in a somewhat bemused fashion.

完了以后他们又重新回到之前的闲谈当中，我也再没有跟他们有什么言谈往还，直到不久之后互道了一声晚安。
With this, they returned to their previous conversation, and I exchanged no further words with them until exchanging good nights a little while later.

我刚想到那句俏皮话的时候，还颇曾感觉沾沾自喜，而且我得承认，眼看着它的效果居然不过如此，我还是稍稍有些失望的。
I had been rather pleased with my witticism when it had first come into my head, and I must confess I was slightly disappointed it had not been better received than it was.

我尤其感到失望之处，我想，正在于最近的这几个月来我颇花了不少时间特用来提升我在这一领域的技巧。
I was particularly disappointed, I suppose, because I have been devoting some time and effort over recent months to improving my skill in this very area.

也就是说，最近我一直竭尽所能将这一技巧添加到我的职业锦囊当中，以便于可以满有把握地充分满足法拉戴先生在打趣调侃方面对我所抱的期望。
That is to say, I have been endeavouring to add this skill to my professional armoury so as to fulfil with confidence all Mr Farraday's expectations with respect to bantering.

比如说，近来我只要有一点空余时间，就会回到房间里去听无线电广播—像是碰到法拉戴先生晚间外出的时候。
For instance, I have of late taken to listening to the wireless in my room whenever I find myself with a few spare moments – on those occasions, say, when Mr Farraday is out for the evening.

我经常收听的一个节目叫作《每周两次或更多》，实际上每周播出三次，基本上是由两位主持人针对读者来信提出的各种话题进行幽默的评论。
One programme I listen to is called Twice a Week or More, which is in fact broadcast three times each week, and basically comprises two persons making humorous comments on a variety of topics raised by readers’ letters.

我一直都在认真地研究这个节目，因为它表现出来的谐趣，其品位一直都是最高的，而且在我看来，其基调也跟法拉戴先生可能期待我表现出来的风趣相去不远。
I have been studying this programme because the witticisms performed on it are always in the best of taste and, to my mind, of a tone not at all out of keeping with the sort of bantering Mr Farraday might expect on my part.

从这个节目得到启发以后，我已经设计出了一个简单的演练方案，我争取每天至少实际操练一次；只要一有空闲，我就尝试以当时所处的即时环境为素材，构想出三句俏皮话来。
Taking my cue from this programme, I have devised a simple exercise which I try to perform at least once a day; whenever an odd moment presents itself, I attempt to formulate three witticisms based on my immediate surroundings at that moment.

或者，作为这同一种演练的变通方式，也可能会尝试着以过去一个钟头内发生的事件构想出三句俏皮话来。
Or, as a variation on this same exercise, I may attempt to think of three witticisms based on the events of the past hour.

如此一来，您可能也就会理解对于昨天晚上的那句俏皮话，我所感到的失望之情了。
You will perhaps appreciate then my disappointment concerning my witticism yesterday evening.

起先，我以为它不太成功的原因可能是我说得不够清楚。
At first, I had thought it possible its limited success was due to my not having spoken clearly enough.

可是在我已经回房休息以后，我才想到我有可能已经冒犯了这些当地人。
But then the possibility occurred to me, once I had retired, that I might actually have given these people offence.

毕竟，我那句俏皮话很容易被理解为我是在暗示老板娘就像一只鸡—当时我可是绝无此意的。
After all, it could easily have been understood that I was suggesting the landlord's wife resembled a cockerel – an intention that had not remotely entered my head at the time.

这个想法在我尽力入睡的过程中继续不断地折磨着我，我甚至都有些想在今天一早跟店老板正式道歉了。
This thought continued to torment me as I tried to sleep, and I had half a mind to make an apology to the landlord this morning.

可是他在为我端来早餐时表现得非常愉快，情绪上没有任何的保留，最后我也就决定略过不提了。
But his mood towards me as he served breakfast seemed perfectly cheerful and in the end I decided to let the matter rest.

不过这个小小的插曲极好地说明了那些脱口而出的俏皮话有可能带来的风险。
But this small episode is as good an illustration as any of the hazards of uttering witticisms.

由于谐趣的本质就在于当下的急智反应，你在顺应情势把一句俏皮话抛出去之前是不会有时间去充分评估它可能引发的各种后果的，你要是没有事先就掌握了必要的技巧和经验，就有极大的风险会脱口说出各种不甚得体的话语来。
By the very nature of a witticism, one is given very little time to assess its various possible repercussions before one is called to give voice to it, and one gravely risks uttering all manner of unsuitable things if one has not first acquired the necessary skill and experience.

只要假以时间和勤学苦练，没有理由认定我在这个领域就成不了行家里手，不过既然存在这样的风险，我已经决定现在最好还是暂时不要急着去履行法拉戴先生期望于我的这一责任，等我多加练习、熟谙此道以后再去表现不迟。
There is no reason to suppose this is not an area in which I will become proficient given time and practice, but, such are the dangers, I have decided it best, for the time being at least, not to attempt to discharge this duty in respect of Mr Farraday until I have practised further.

不管怎么说吧，我很遗憾地向诸位报告，昨晚那些当地人当作玩笑话来说的—预计我是睡不好的，因为楼下不时地会有干扰—倒是被证实了果不其然。老板娘倒是并没有大呼小叫，可是你能听到她跟她丈夫两个人一直在楼下四处走动忙活这忙活那，一边喋喋不休地说个没完，而且今天一大早就又开始了。
In any case, I am sorry to report that what the local people had themselves offered last night as a witticism of sorts – the prediction that I would not have a good night owing to disturbances from below – proved only too true. The landlord's wife did not actually shout, but one could hear her talking incessantly both late into the night as she and her husband went about their tasks, and again from very early this morning.

不过，我能够体谅这对夫妻，因为他们很显然已经养成了辛勤劳作的习惯，至于他们制造出来的那些噪声，也全都应该归因于此。
I was quite prepared to forgive the couple, however, for it was clear they were of diligent hard-working habits, and the noise, I am sure, was all attributable to this fact.

再者说了，我昨天也说过那么一句很不得体的俏皮话，所以我在向店老板致谢的时候丝毫没有提及我其实一夜未曾安枕，然后我就动身前去探访汤顿这个著名的集镇了。
Besides, of course, there had been the matter of my unfortunate remark. I thus gave no indication of having had a disturbed night when I thanked the landlord and took my leave to explore the market town of Taunton.

也许，我昨晚本该在我眼下正愉快地享用一杯早茶的这家店里住宿的。
Perhaps I might have done better to have lodged here in this establishment where I now sit enjoying a pleasant mid-morning cup of tea.

因为的确，外面的店招上大字写着，店里不仅提供“茶点、小吃和蛋糕”，还有“干净、安静而又舒适的客房”。
For indeed, the notice outside advertises not only ‘teas, snacks and cakes’, but also ‘clean, quiet, comfortable rooms’.

这家店就位于汤顿的主街之上，离市集广场咫尺之遥，是一幢有些沉陷的建筑，外观以深色的木质桁梁为特色。
It is situated on the high street of Taunton, very close to the market square, a somewhat sunken building, its exterior characterized by heavy dark timber beams.

眼下我就坐在它那宽敞的茶室里，墙面是橡木镶板，茶桌的数量我猜就是同时招待二十几位客人都丝毫不会显得拥挤。
I am at present sitting in its spacious tearoom, oak-panelled, with enough tables to accommodate, I would guess, two dozen people without a feeling of crowding.

两位快活的年轻姑娘站在柜台后面负责招待顾客，柜台上陈列着琳琅满目的各色糕点。
Two cheery young girls serve from behind a counter displaying a good selection of cakes and pastries.

总而言之，这是个享用早茶的绝佳场所，可是愿意光顾此地的汤顿居民却出奇地稀少。
All in all, this is an excellent place to partake of morning tea, but surprisingly few of the inhabitants of Taunton seem to wish to avail themselves of it.

眼下，店内的顾客除了我以外就只有两位上了年纪的女士，并肩坐在我对面靠墙的一张桌子边；还有一位男士—可能是位退休的农夫—坐在一扇巨大的凸窗旁边。
At present, my only companions are two elderly ladies, sitting abreast one another at a table along the opposite wall, and a man – perhaps a retired farmer – at a table beside one of the large bay windows.

我看不清他的长相，因为明亮的晨光此刻将他照得只剩下了一个剪影。
I am unable to discern him clearly because the bright morning sunlight has for the moment reduced him to a silhouette.

不过我能看得出他正在仔细地阅读手里的报纸，时不时地抬头望一下窗外人行道上的过路人。
But I can see him studying his newspaper, breaking off regularly to look up at the passers-by on the pavement outside.

他的这一举止起先让我以为他是在等什么人，不过后来看来他不过是想跟路经此处的熟人们打个招呼。
From the way he does this, I had thought at first that he was waiting for a companion, but it would seem he wishes merely to greet acquaintances as they pass by.

我自己几乎隐藏在茶室最里面的靠墙位置，不过即便隔着整个房间的距离，我依然能清楚地看到户外阳光朗照的街道，还能辨认得出对面人行道上的路标，上面指出了几个附近的目的地。
I am myself ensconced almost at the back wall, but even across the distance of this room, I can see clearly out into the sunlit street, and am able to make out on the pavement opposite a signpost pointing out several nearby destinations.

其中一个目的地是默斯登村。
One of these destinations is the village of Mursden.

您或许也会觉得“默斯登”这个地方听来耳熟，我昨天在道路交通图上第一次看到这个地方时心里也是一动。
Perhaps ‘Mursden’ will ring a bell for you, as it did for me upon my first spotting it on the road atlas yesterday.

实际上，我必须承认，我甚至一度想稍稍调整一下既定的路线，绕点路前去亲眼看看那个村庄。
In fact, I must say I was even tempted to make a slight detour from my planned route just to see the village.

萨默塞特郡的默斯登曾是吉芬公司的所在地，在过去，人们都是向默斯登发送订单，订购吉芬公司生产的抛光用深色蜡烛的，该产品是“切成薄片后与上光蜡粉以手工混制而成”。
Mursden, Somerset, was where the firm of Giffen and Co. was once situated, and it was to Mursden one was required to dispatch one's order for a supply of Giffen's dark candles of polish, ‘to be flaked, mixed into wax and applied by hand’.

在很长一段时间里，吉芬的产品绝对是市面上最好的银器上光剂，一直到战前不久，市场上出现了新式化工替代品以后，对这一优质产品的需求才开始衰落。
For some time, Giffen's was undoubtedly the finest silver polish available, and it was only the appearance of new chemical substances on the market shortly before the war that caused demand for this impressive product to decline.

我记得，吉芬银器上光剂是二十年代初问世的，而且我能肯定，我并非唯一一个将这一产品的出现与我们业内心态上的转变紧密联系在一起的人—那一转变将为银器清洁上光的工作推到了至为重要的中心位置，而且总体说来直到今天仍是如此。
As I remember, Giffen's appeared at the beginning of the twenties, and I am sure I am not alone in closely associating its emergence with that change of mood within our profession – that change which came to push the polishing of silver to the position of central importance it still by and large maintains today.

这一重心的转移，我认为，就像这一时期其他众多的转变一样，是一种代际间的变革；正是在那些年间，我们这一代管家已经“长大成人”，尤其是像马歇尔先生这样的人物，在使银器上光成为核心要务方面扮演了关键性的角色。
This shift was, I believe, like so many other major shifts around this period, a generational matter; it was during these years that our generation of butlers ‘came of age’, and figures like Mr Marshall, in particular, played a crucial part in making silver-polishing so central.

当然这并不是说为银器清洁上光的工作—尤其是那些会摆上餐桌的银制器皿—在过去并没有得到严肃的对待。
This is not to suggest, of course, that the polishing of silver – particularly those items that would appear at table – was not always regarded a serious duty.

但如果说，比如家父那一代管家并没有把这项工作看得有如此重要，这应该不算是有失公允的；有如下事实可资证明：在当时，大户人家的管家极少有人亲自监管银器清洁上光的工作，大都认为交给像是副管家这样的下属去督管也就足够了，只不过时不时地检查一下而已。
But it would not be unfair to suggest that many butlers of, say, my father's generation did not consider the matter such a key one, and this is evidenced by the fact that in those days, the butler of a household rarely supervised the polishing of silver directly, being content to leave it to, say, the under-butler's whims, carrying out inspections only intermittently.

大家公认是马歇尔先生首度全面认识到了银器的重要意义—亦即，阖府上下再也没有其他任何物件会像餐桌上的银器那般受到外人如此深入的仔细审视，由是，银器也就起到了衡量一户人家整体水准的公共指数的作用。
It was Mr Marshall, it is generally agreed, who was the first to recognize the full significance of silver – namely, that no other objects in the house were likely to come under such intimate scrutiny from outsiders as was silver during a meal, and as such, it served as a public index of a house's standards.

马歇尔先生是第一位因为将沙勒维尔府的银器抛光到前此无法想象的程度，使得来访的淑女士绅为之而心醉神迷的人物。
And Mr Marshall it was who first caused stupefaction amongst ladies and gentlemen visiting Charleville House with displays of silver polished to previously unimagined standards.

势所必然，全国上下的管家们在各自雇主的压力之下，很快也就将全副精力集中在银器的清洁上光这一问题之上了。
Very soon, naturally, butlers up and down the country, under pressure from their employers, were focusing their minds on the question of silver-polishing.

我记得，很快也就有好几位管家异军突起，每一位都宣称自己发现了可以超过马歇尔先生的妙方—这种妙方他们又无不装模作样地当作独得之秘概不外传，就如同那些独守祖传食谱秘方的法国名厨一般。
There quickly sprang up, I recall, various butlers, each claiming to have discovered methods by which they could surpass Mr Marshall – methods they made a great show of keeping secret, as though they were French chefs guarding their recipes.

可是我确信—在当时我就这么认为—像是杰克·内伯斯之辈所卖弄的那些煞有介事而又神秘兮兮的上光步骤对于最终的结果是极少甚至根本就不会有任何作用的。
But I am confident – as I was then – that the sorts of elaborate and mysterious processes performed by someone like Mr Jack Neighbours had little or no discernible effect on the end result.

在我看来，这项工作并无任何神秘可言：只要你使用上好的上光剂，只要你加以严格的督责即可。
As far as I was concerned, it was a simple enough matter: one used good polish, and one supervised closely.

吉芬曾是当时所有独具慧眼的管家们的共同选择，只要使用得法，你就无须担心自家的银器会比任何人家的有丝毫逊色。
Giffen's was the polish ordered by all discerning butlers of the time, and if this product was used correctly, one had no fear of one's silver being second best to anybody's.

我很高兴能够回忆起，达林顿府的银器有好几次都对于客人产生了可喜的影响。
I am glad to be able to recall numerous occasions when the silver at Darlington Hall had a pleasing impact upon observers.

比如说，我记得阿斯特夫人曾经说过，语气中不无一定的苦涩，我们的银器“有可能是无与伦比的”。
For instance, I recall Lady Astor remarking, not without a certain bitterness, that our silver ‘was probably unrivalled’.

我还记得曾亲眼看到萧伯纳先生，那位著名的剧作家，有天晚上在餐桌上极为仔细地检查他面前的那把吃甜点的小银匙，还特意把它举到灯光底下，拿它的表面跟手边的主菜盘进行细细的比照，对于周围的客人则完全视而不见。
I recall also watching Mr George Bernard Shaw, the renowned playwright, at dinner one evening, examining closely the dessert spoon before him, holding it up to the light and comparing its surface to that of a nearby platter, quite oblivious to the company around him.

不过，如今回忆起来最让我感到得意的，应属某个夜晚一位相当显赫的人物—一位内阁大臣，不久后即出任外交大臣—对达林顿府进行的一次绝对“不宜公开”的访问。
But perhaps the instance I recall with most satisfaction today concerns the night that a certain distinguished personage – a cabinet minister, shortly afterwards to become foreign secretary – paid a very ‘off the record’ visit to the house.

事实上，既然当时那些来访所造成的结果早已详细地记录于文献当中，我也就没有理由再遮遮掩掩了，我所说的这位访客就是哈利法克斯勋爵。
In fact, now that the subsequent fruits of those visits have become well documented, there seems little reason not to reveal that I am talking of Lord Halifax.

结果，那次特别的来访只是哈利法克斯勋爵与时任德国驻英大使里宾特洛甫先生之间整个一连串此类“非官方”会晤的开始。
As things turned out, that particular visit was simply the first of a whole series of such ‘unofficial’ meetings between Lord Halifax and the German Ambassador of that time, Herr Ribbentrop.

不过在那第一个晚上，哈利法克斯勋爵的态度却极为审慎；实际上他来到达林顿府的第一句话就是：“说实话，达林顿，我真不知道你敦促我到这儿来干什么。
But on that first night, Lord Halifax had arrived in a mood of great wariness; virtually his first words on being shown in were: ‘Really, Darlington, I don't know what you've put me up to here.

我知道我肯定会为此而后悔的。”
I know I shall be sorry.’

里宾特洛甫先生估计还要一个多钟头才能到，爵爷于是就建议先带客人参观一下达林顿府—这个策略曾帮助不少精神紧张的客人放松下来。
Herr Ribbentrop not being expected for a further hour or so, his lordship had suggested to his guest a tour of Darlington Hall – a strategy which had helped many a nervous visitor to relax.

不过我在继续忙我的工作的时候，多次听到哈利法克斯勋爵在府里不同的地方不断地表达着他对于当晚那次会晤的疑虑之情，达林顿勋爵对他的反复安抚也终归是徒劳。可是又过了一段时间，我突然听到哈利法克斯勋爵惊呼道：“我的天哪，达林顿，尊府的这些银器真是太赏心悦目了。”
However, as I went about my business, all I could hear for some time was Lord Halifax, in various parts of the building, continuing to express his doubts about the evening ahead, and Lord Darlington trying in vain to reassure him. But then at one point I overheard Lord Halifax exclaiming: ‘My goodness, Darlington, the silver in this house is a delight.’

当时我听到这样的赞誉自然是非常高兴，不过这个小插曲所带来的真正令人满意的结果却是两三天后才出现的，达林顿勋爵特意对我说：“顺便说一句，史蒂文斯，咱们的银器那天晚上给哈利法克斯勋爵留下了极为深刻的美好印象，使得他整个的心绪都为之而一变。”
I was of course very pleased to hear this at the time, but what was for me the truly satisfying corollary to this episode came two or three days later, when Lord Darlington remarked to me: ‘By the way, Stevens, Lord Halifax was jolly impressed with the silver the other night. Put him into a different frame of mind altogether.’

这是—我记得很清楚—爵爷的原话，所以那可绝非是我个人的想入非非：银器所保持的良好状态对于缓和那晚哈利法克斯勋爵和里宾特洛甫先生之间的紧张关系，的确做出了虽说微不足道却又是意义重大的贡献。
These were – I recollect it clearly – his lordship's actual words and so it is not simply my fantasy that the state of the silver had made a small, but significant contribution towards the easing of relations between Lord Halifax and Herr Ribbentrop that evening.

话已至此，关于里宾特洛甫先生的情况我再多说几句或许也不为过。
It is probably apt at this point to say a few words concerning Herr Ribbentrop.

当然，现在大家普遍接受的看法是里宾特洛甫先生是个大骗子手：那些年间希特勒的计划就是尽可能长时间地欺骗英国，隐瞒其真实意图，而里宾特洛甫先生在我们国家唯一的使命即具体地实施这一骗术。
It is, of course, generally accepted today that Herr Ribbentrop was a trickster: that it was Hitler's plan throughout those years to deceive England for as long as possible concerning his true intentions, and that Herr Ribbentrop's sole mission in our country was to orchestrate this deception.

如我所说，这是大家普遍持有的观点，我并不想在此提出异议。
As I say, this is the commonly held view and I do not wish to differ with it here.

然而，令人着恼的是听到大家如今说起这件事来的那种口气，就仿佛他们从未有一时一刻上过里宾特洛甫先生的当似的—仿佛就只有达林顿勋爵一个人相信他是位高尚的绅士，只有爵爷一个人跟他建立过工作上的关系似的。
It is, however, rather irksome to have to hear people talking today as though they were never for a moment taken in by Herr Ribbentrop – as though Lord Darlington was alone in believing Herr Ribbentrop an honourable gentleman and developing a working relationship with him.

事实是，在整个的三十年代，里宾特洛甫先生在所有那些最为显赫的宅第中都被视为一位备受尊敬的人物，甚至是位光彩照人、富有魅力的人物。
The truth is that Herr Ribbentrop was, throughout the thirties, a well-regarded figure, even a glamorous one, in the very best houses.

尤其是在一九三六和三七年间，我还记得仆役大厅里随侍主人来访的仆佣们围绕着“那位德国大使”的所有那些话题，从他们的谈话当中可以清楚地了解到，当时本国的许多最为显赫的名媛和士绅都很为他着迷和倾倒。
Particularly around 1936 and 1937, I can recall all the talk in the servants’ hall from visiting staff revolving around ‘the German Ambassador’, and it was clear from what was said that many of the most distinguished ladies and gentlemen in this country were quite enamoured of him.

如前所说，听到同样这些人现在谈起当时的情况居然完全变了样，尤其是有些人说到爵爷的那些话，实在是令人着恼。
It is, as I say, irksome to have to hear the way these same people now talk of those times, and in particular, what some have said concerning his lordship.

只要看看他们其中几位当年的邀客名单，你立刻就会明白这些人有多么伪善；你就会看得清清楚楚，当初里宾特洛甫先生不仅仅是在同样这些人的餐桌上用过餐，而且还经常是作为贵宾被奉为上座的。
The great hypocrisy of these persons would be instantly obvious to you were you to see just a few of their own guest lists from those days; you would see then not only the extent to which Herr Ribbentrop dined at these same persons’ tables, but that he often did so as guest of honour.

不仅如此，你还会听到同样这些人说起来就好像是因为达林顿勋爵做了什么见不得人的事，所以他在那些年间的几次德国之行才受到了纳粹的特别礼遇。
And then again, you will hear these same persons talking as though Lord Darlington did something unusual in receiving hospitality from the Nazis on the several trips he made to Germany during those years.

如果，比方说，只要《泰晤士报》刊登一份纽伦堡集会期间德国人大宴宾客的邀客名单，我想这些人肯定就不会这么大言不惭地胡说八道了。
I do not suppose they would speak quite so readily if, say, The Times were to publish even one of the guest lists of the banquets given by the Germans around the time of the Nuremberg Rally.

事实上，英国最为显贵、最受尊敬的名媛和士绅都曾受到德国领导人的殷勤款待，而且我敢发誓，我亲眼所见、亲耳所闻这些人当中的绝大多数从德国回来以后对于招待他们的东道主都赞誉有加。
The fact is, the most established, respected ladies and gentlemen in England were availing themselves of the hospitality of the German leaders, and I can vouch at first hand that the great majority of these persons were returning with nothing but praise and admiration for their hosts.

任何对于达林顿勋爵当初是在跟一位众所周知的敌人暗通款曲的暗示，都可以说是只图自己方便而完全罔顾了当时真实的政治气候。
Anyone who implies that Lord Darlington was liaising covertly with a known enemy is just conveniently forgetting the true climate of those times.

还需要说明的一点是，有人声称达林顿勋爵是个排犹主义者，或者说他跟类似英国法西斯主义者同盟那样的组织过从甚密，这都绝对是卑鄙龌龊的无耻谰言。
It needs to be said too what salacious nonsense it is to claim that Lord Darlington was anti-Semitic, or that he had close association with organizations like the British Union of Fascists.

这类说法只能是那些对于爵爷的为人一无所知之辈的诬罔之词。
Such claims can only arise from complete ignorance of the sort of gentleman his lordship was.

达林顿勋爵对于排犹主义憎恶之极；我就亲耳听他在好几个不同的场合表达过他在面对排犹主义情绪时的厌恶之情。
Lord Darlington came to abhor anti-Semitism; I heard him express his disgust on several separate occasions when confronted with anti-Semitic sentiments.

还有人指控爵爷从不允许犹太人踏入达林顿府一步或者从不雇用犹太员工，这也是完全没有根据的信口雌黄—唯一一次例外或许就是三十年代发生过的一个非常微不足道的小插曲，结果后来却被言过其实地大肆渲染。
And the allegation that his lordship never allowed Jewish people to enter the house or any Jewish staff to be employed is utterly unfounded – except, perhaps, in respect to one very minor episode in the thirties which has been blown up out of all proportion.

至于说到那个英国法西斯主义者同盟，我只能说任何有关将爵爷跟这些人联系起来的说法都是非常荒唐可笑的。
And as for the British Union of Fascists, I can only say that any talk linking his lordship to such people is quite ridiculous.

我要说的是，奥斯瓦尔德·莫斯利爵士，领导“黑衫党”的头目对达林顿府的造访最多只有三次，而且全都是在该组织成立的早期，那时候他们还没有背叛其初衷。
Sir Oswald Mosley, the gentleman who led the ‘blackshirts’, was a visitor at Darlington Hall on, I would say, three occasions at the most, and these visits all took place during the early days of that organization before it had betrayed its true nature.

一旦黑衫党运动的丑恶嘴脸大白于天下—且不说爵爷比大多数人都更早地看穿了他们的真面目—达林顿勋爵就再未跟这些人有任何瓜葛了。
Once the ugliness of the blackshirts’ movement became apparent – and let it be said his lordship was quicker than most in noticing it – Lord Darlington had no further association with such people.

再怎么说，这类组织对于本国政治生活的核心而言也根本就是无足轻重的。
In any case, such organizations were a complete irrelevance to the heart of political life in this country.

您应该能够理解，达林顿勋爵是那种只会致力于那些真正的核心事务的绅士，而且多年以来他所努力罗致的也都是那些对于这类令人厌恶的边缘组织避之唯恐不及、距离十万八千里的人士。
Lord Darlington, you will understand, was the sort of gentleman who cared to occupy himself only with what was at the true centre of things, and the figures he gathered together in his efforts over those years were as far away from such unpleasant fringe groups as one could imagine.

他们不但备受尊敬，而且都是对英国的政治生活具有真正影响力的人物：政治家、外交家、军方人士和神职人员。
Not only were they eminently respectable, these were figures who held real influence in British life: politicians, diplomats, military men, clergy.

的确，这其中就有犹太人，单单这一个事实就足以说明，有关爵爷的大多数传闻是多么地荒诞无稽。
Indeed, some of the personages were Jewish, and this fact alone should demonstrate how nonsensical is much of what was said about his lordship.

不过我跑题了。
But I drift.

我谈的原本是银器，以及哈利法克斯勋爵跟里宾特洛甫先生会晤的那天晚上，达林顿府的银器给他留下了多么深刻的印象。
I was in fact discussing the silver, and how Lord Halifax had been suitably impressed on the evening of his meeting with Herr Ribbentrop at Darlington Hall.

请允许我特别澄清一下，我可从来就没有暗示过一个原本极有可能令我的雇主大为失望的夜晚，完全是因为银器擦得雪亮就变得无比成功了。
Let me make clear, I was not for a moment suggesting that what had initially threatened to be a disappointing evening for my employer had turned into a triumphant one solely on account of the silver.

不过，正如我说过的，达林顿勋爵就曾亲口表示过，那些银器至少有可能是那晚使来宾的心情大为改观的一个小小的因素，如果我在回顾这样的事例时怀有一种称心满意的心情，或许也不算是太过荒唐可笑吧。
But then, as I indicated, Lord Darlington himself suggested that the silver might have been at least a small factor in the change in his guest's mood that evening, and it is perhaps not absurd to think back to such instances with a glow of satisfaction.

我们这一行中也有一些人认为无论为什么样的雇主服务都是没什么实质性的不同的；认为我们这代人中盛行的那种理想主义—即我们这些做管家的应力争去为那些能够促进人类福祉的伟大的绅士们服务的这种观念—只不过是唱高调，并无现实的基础。
There are certain members of our profession who would have it that it ultimately makes little difference what sort of employer one serves; who believe that the sort of idealism prevalent amongst our generation – namely the notion that we butlers should aspire to serve those great gentlemen who further the cause of humanity – is just high-flown talk with no grounding in reality.

当然，显而易见，散布这种怀疑主义论调的个人，结果无一例外地证明自己只是我们这一行中的平庸之辈—他们知道自己根本就不具备跃居显要位置的能力，所以只能力图将尽可能多的同行拉低到他们自己的水平—没有人愿意认真对待这样的观点。
It is of course noticeable that the individuals who express such scepticism invariably turn out to be the most mediocre of our profession – those who know they lack the ability to progress to any position of note and who aspire only to drag as many down to their own level as possible – and one is hardly tempted to take such opinions seriously.

即便如此，如果能够从自己的职业生涯中举出一些实例，以清楚地烛照出他们是何等大谬不然，这仍旧是令人感到满意的赏心乐事。
But for all that, it is still satisfying to be able to point to instances in one's career that highlight very clearly how wrong such people are.

当然了，我们所追求的是为自己的雇主提供全面而又持久的服务，其价值绝不该被降低至几个特定的实例—比如上述跟哈利法克斯勋爵有关的这件事。
Of course, one seeks to provide a general, sustained service to one's employer, the value of which could never be reduced to a number of specific instances – such as that concerning Lord Halifax.

但我要说的是，正是这一类的实例，透过时间的流逝愈加清晰地彰显出一个无可辩驳的事实；即此人曾经有幸身处于那些重大事件至为枢纽的位置，实践了自己的职业操守。
But what I am saying is that it is these sorts of instances which over time come to symbolize an irrefutable fact; namely that one has had the privilege of practising one's profession at the very fulcrum of great affairs.

而且此人或许有权利体验到一种满足感，这是那些安于为平庸的雇主服务之辈所永远无缘体味的—这种满足感就在于，它让你有理由可以说，我所付出的努力，不管多么微不足道，毕竟对于历史的进程做出了属于自己的贡献。
And one has a right, perhaps, to feel a satisfaction those content to serve mediocre employers will never know – the satisfaction of being able to say with some reason that one's efforts, in however modest a way, comprise a contribution to the course of history.

不过也许一个人不该如此频繁地回望过去。
But perhaps one should not be looking back to the past so much.

毕竟，摆在我面前的仍有要求我尽心服务的好多个年头。
After all, I still have before me many more years of service I am required to give.

法拉戴先生不仅是位最好的雇主，他还是位美国绅士，这肯定是我责无旁贷的义务，向他充分展示英国最高的服务水准。
And not only is Mr Farraday a most excellent employer, he is an American gentleman to whom, surely, one has a special duty to show all that is best about service in England.

既然如此，将自己的注意力聚焦于当下就是至为重要的了；必须谨防因为过去所取得的一点点成就而滋生任何自满的情绪。
It is essential, then, to keep one's attention focused on the present; to guard against any complacency creeping in on account of what one may have achieved in the past.

因为不得不承认，在过去的几个月中，达林顿府内的现状已经显得不那么尽如人意了。
For it has to be admitted, over these last few months, things have not been all they might at Darlington Hall.

近来已经出现了几次小小的疏失，这其中就包括去年四月发生的那个跟银器有关的小插曲。
A number of small errors have surfaced of late, including that incident last April relating to the silver.

万幸的是当时法拉戴先生并没有客人在场，不过即便如此，那对我而言也是极端难堪的一刻。
Most fortunately, it was not an occasion on which Mr Farraday had guests, but even so, it was a moment of genuine embarrassment to me.

事情发生在某天上午的早餐时间，在他那方面，法拉戴先生—要么是他宅心仁厚，不忍苛责，要么就是因为他是个美国人，所以对那次差错的程度缺乏认识—自始至终未曾有过只字的埋怨。
It had occurred at breakfast one morning, and for his part, Mr Farraday – either through kindness, or because being an American he failed to recognize the extent of the shortcoming – did not utter one word of complaint to me throughout the whole episode.

他在餐桌前就座以后，只是拿起一把餐叉细看了一下，用指尖碰了碰叉尖，然后就将注意力转移到晨报的头版新闻上去了。
He had, upon seating himself, simply picked up a fork, examined it for a brief second, touching the prongs with a fingertip, then turned his attention to the morning headlines.

他整个的姿态都是以一种漫不经心的方式做出的，不过当然了，我已经全都看在了眼里，马上快步走上前去，拿走了那样碍眼的东西。
The whole gesture had been carried out in an absent-minded sort of way, but of course, I had spotted the occurrence and had advanced swiftly to remove the offending item.

可能因为我心里不安，动作太快了一点，因为法拉戴先生略为有些吃惊，嘟囔了一句：“啊，史蒂文斯。”
I may in fact have done so a little too swiftly on account of my disturbance, for Mr Farraday gave a small start, muttering: ‘Ah, Stevens.’

我拿着那把餐叉快步走出房间，没作任何耽搁马上又拿了一把令人满意的餐叉回来。
I had continued to proceed swiftly out of the room, returning without undue delay bearing a satisfactory fork.

我朝餐桌走去的时候—法拉戴先生显然已经全神贯注于他的报纸当中—我也想到我可以悄没声地把餐叉放在桌布上，不要打搅了我的主人读报。
As I advanced upon the table – and a Mr Farraday now apparently absorbed in his newspaper – it occurred to me I might slip the fork on to the tablecloth quietly without disturbing my employer's reading.

可是，我已经想到了法拉戴先生有可能是为了不让我感到难堪才佯装浑然不觉的，如果我这么偷偷摸摸地把餐叉换回去，恐怕会被主人误解为对于自己的疏失我非但不痛心疾首，反而自鸣得意—或者更糟，是试图予以遮掩了。
However, the possibility had already occurred to me that Mr Farraday was simply feigning indifference in order to minimize my embarrassment, and such a surreptitious delivery could be interpreted as complacency on my part towards my error – or worse, an attempt to cover it up.

正是为此，我于是决定我应该带有某种强调的意味把餐叉放回到桌上才算合适，结果是又让主人吃了一惊，他抬眼一看，又嘟囔了一句：“啊，史蒂文斯。”
This was why, then, I decided it appropriate to put the fork down on to the table with a certain emphasis, causing my employer to start a second time, look up and mutter again: ‘Ah, Stevens.’

类似这样的疏失，在过去的这几个月里，自然是对我身为管家的自尊心的一种伤害，不过话又说回来了，我认为这只是人手短缺造成的，并没有理由相信它们是更加严重的问题的先兆。
Errors such as these which have occurred over the last few months have been, naturally enough, injurious to one's self-respect, but then there is no reason to believe them to be the signs of anything more sinister than a staff shortage.

并不是说人手短缺的问题无足轻重；不过只要肯顿小姐当真愿意重返达林顿府，我相信这样的小小疏漏也就自然会成为过去。
Not that a staff shortage is not significant in itself; but if Miss Kenton were indeed to return to Darlington Hall, such little slips, I am sure, would become a thing of the past.

当然了，我们必须谨记，肯顿小姐在来信上并没有愿意复职的明确表示—顺带提一下，昨晚在关灯之前我又在房内重读了一遍。
Of course, one has to remember there is nothing stated specifically in Miss Kenton's letter – which, incidentally, I reread last night up in my room before putting out the light – to indicate unambiguously her desire to return to her former position.

事实上，我必须承认确实有这种可能，即我出于一厢情愿的工作上的考虑，而过于夸大了她那方面有此意愿的蛛丝马迹。
In fact, one has to accept the distinct possibility that one may have previously – perhaps through wishful thinking of a professional kind – exaggerated what evidence there was regarding such a desire on her part.

因为我必须承认，昨晚我不无惊讶地发现，还真的很难明确指出她来信当中有任何一段清楚明白地表示出了她想回来工作的愿望。
For I must say I was a little surprised last night at how difficult it was actually to point to any passage which clearly demonstrated her wish to return.

不过话又说回来了，现在也不值当地再在这样的问题上煞费苦心地去思忖揣测，因为很可能在四十八个钟头之内我就能够跟肯顿小姐当面进行晤谈了。
But then again, it seems hardly worthwhile to speculate greatly on such matters now when one knows one will, in all likelihood, be talking face to face with Miss Kenton within forty-eight hours.

不过我还是得承认，昨天晚上我躺在黑暗当中，听着楼下传来的店老板和老板娘洗洗涮涮的声响，我还是颇花了不少的时间，在我脑子里反复地琢磨肯顿小姐信中的字句。
Still, I must say, I did spend some long minutes turning those passages over in my mind last night as I lay there in the darkness, listening to the sounds from below of the landlord and his wife clearing up for the night.

# 第三天—傍晚 | DAY THREE–EVENING

莫斯科姆村，近塔维斯托克，德文郡
Moscombe, near Tavistock, Devon

我觉得也许有必要再回到爵爷对待犹太人的这个问题上多说几句，既然排犹主义的这整个问题，我意识到，近来已经变得如此敏感。
I feel I should perhaps return a moment to the question of his lordship's attitude to Jewish persons, since this whole issue of anti-Semitism, I realize, has become a rather sensitive one these days.

尤其是，让我在此澄清一下外界有关达林顿府绝不雇用犹太人的传闻。
In particular, let me clear up this matter of a supposed bar against Jewish persons on the staff at Darlington Hall.

既然这一指控直接就落在我本人的管辖范围，我也就能有绝对的权威予以批驳了。
Since this allegation falls very directly into my own realm, I am able to refute it with absolute authority.

在我服侍爵爷的这全部的岁月当中，我的雇员里面一直都有很多的犹太人，而且我要再补充一句的是，他们从来都没有因为其种族的缘故而受到任何不同的对待。
There were many Jewish persons on my staff throughout all my years with his lordship, and let me say furthermore that they were never treated in any way differently on account of their race.

你真是猜不出这些荒唐无稽的指控到底所为何来—除非，这是非常荒谬可笑的，它们全都源自三十年代初期那短暂的几个星期里发生的几件完全无足轻重的小事，在那段时间里卡罗琳·巴尼特太太曾对爵爷拥有过某种非同寻常的影响力。
One really cannot guess the reason for these absurd allegations – unless, quite ludicrously, they originate from that brief, entirely insignificant few weeks in the early thirties when Mrs Carolyn Barnet came to wield an unusual influence over his lordship.

巴尼特太太是查尔斯·巴尼特先生的遗孀，当时四十开外—是位非常健美端庄，有人也会说是光彩照人、魅力四射的女士。
Mrs Barnet, the widow of Mr Charles Barnet, was at that point in her forties – a very handsome, some might say glamorous lady.

她拥有聪颖无比、令人敬畏有加的盛誉，在当年，你经常能听说她是如何在宴会上就当今某个重大问题将这位或是那位饱学之士羞辱得无地自容的传闻。
She had a reputation for being formidably intelligent, and in those days one often tended to hear of how she had humiliated this or that learned gentleman at dinner over some important contemporary issue.

在一九三二年的大半个夏季里，她曾是达林顿府的常客，经常跟爵爷一谈就是几个钟头，就重大的社会或者政治问题深入地交换意见。
For much of the summer of 1932, she was a regular presence at Darlington Hall, she and his lordship often spending hour after hour deep in conversation, typically of a social or political nature.

我记得，也正是这位巴尼特太太，曾带领爵爷数度深入伦敦东区最贫穷的地段，进行“有向导引领的视察工作”，其间，爵爷曾亲自实地访问了那些年间很多身陷赤贫境地的人家。
And it was Mrs Barnet, as I recall, who took his lordship on those ‘guided inspections’ of the poorest areas of London's East End, during which his lordship visited the actual homes of many of the families suffering the desperate plight of those years.

这也就是说，巴尼特太太极有可能在促使爵爷越来越关心我们国家的贫困问题上做出过重要的贡献，如此说来，她对于爵爷的影响也不能说全都是负面的。
That is to say, Mrs Barnet, in all likelihood, made some sort of contribution to Lord Darlington's developing concern for the poor of our country and as such, her influence cannot be said to have been entirely negative.

不过当然了，她是奥斯瓦尔德·莫斯利爵士领导的“黑衫党”组织的成员，而爵爷与奥斯瓦尔德爵士仅有的几次接触也就在那年夏天的几个星期之内。
But she was too, of course, a member of Sir Oswald Mosley's ‘blackshirts’ organization, and the very little contact his lordship ever had with Sir Oswald occurred during those few weeks of that summer.

我猜想，应该就是在这短短的几周里发生在达林顿府里的几桩完全不具有典型意义的事件，给那些荒唐无稽的指控提供了完全站不住脚的所谓依据。
And it was during those same weeks that those entirely untypical incidents took place at Darlington Hall which must, one supposes, have provided what flimsy basis exists for these absurd allegations.

我将其称为“事件”，但其中有一些根本就不值一提。
I call them ‘incidents’ but some of these were extremely minor.

比如说，我记得在一次晚宴上听到他们提到某一份报纸，爵爷对此的反应是：“哦，你们说的是那份犹太宣传单啊。”
For instance, I recall overhearing at dinner one evening, when a particular newspaper had been mentioned, his lordship remarking: ‘Oh, you mean that Jewish propaganda sheet.’

同样还是在那段时期里另有一次，我记得他指示我不要再给某个定期上门募捐的当地慈善组织捐款，因为其管理委员会“或多或少都是犹太人组成的”。
And then on another occasion around that time, I remember his instructing me to cease giving donations to a particular local charity which regularly came to the door on the grounds that the management committee was ‘more or less homogeneously Jewish’.

我之所以记得这些确切的表达，是因为当时乍听之下我真是大为惊讶，爵爷此前可是从未对于犹太民族表露过任何的敌意。
I have remembered these remarks because they truly surprised me at the time, his lordship never previously having shown any antagonism whatsoever towards the Jewish race.

再后来，当然就是终于出了那档子事。
Then, of course, came that afternoon his lordship called me into his study.

有天下午爵爷把我叫到他的书房里，起先只是一些大而化之的闲谈，问问我府里的情况是否一切正常，然后他就说：
Initially, he made rather general conversation, inquiring if all was well around the house and so on. Then he said:

“最近我反反复复思考良久，史蒂文斯。
‘I’ve been doing a great deal of thinking, Stevens.

思考良久。
A great deal of thinking.

我已经得出了结论。
And I've reached my conclusion.

我们达林顿府里不能雇用犹太员工。”
We cannot have Jews on the staff here at Darlington Hall.’

“先生？”
‘Sir?’

“这是为了我们府里着想，史蒂文斯。
‘It's for the good of this house, Stevens.

是为了来我们这里做客的客人的利益着想。
In the interests of the guests we have staying here.

我已经就此做过认真的调查，史蒂文斯，我现在就是要让你知道我的结论。”
I've looked into this carefully, Stevens, and I'm letting you know my conclusion.’

“很好，先生。”
‘Very well, sir.’

“告诉我，史蒂文斯，目前我们的员工当中就有几位，对吧？
‘Tell me, Stevens, we have a few on the staff at the moment, don't we?

犹太人，我是说。”
Jews, I mean.’

“我相信目前我们的员工当中有两名是属于这个类别的，先生。”
‘I believe two of the present staff members would fall into that category, sir.’

“啊。”
‘Ah.’

爵爷沉吟了半晌，凝视着窗外。
His lordship paused for a moment, staring out of his window.

“当然，你必须让他们离开。”
‘Of course, you'll have to let them go.’

“您说什么，先生？”
‘I beg your pardon, sir?’

“这非常令人遗憾，史蒂文斯，可我们别无选择。
‘It's regrettable, Stevens, but we have no choice.

必须考虑到我的客人们的安全与康乐。
There's the safety and well-being of my guests to consider.

我可以向你保证，对此问题我已做过认真的调查，而且彻彻底底地考虑清楚了。
Let me assure you, I've looked into this matter and thought it through thoroughly.

这完全是出于我们最大利益的考虑。”
It's all in our best interests.’

这其中涉及的两位员工，事实上都是卧房的女仆。
The two staff members concerned were, in fact, both housemaids.

所以，如果不事先将此情况告知肯顿小姐就采取任何行动的话，那将是极为不妥的，于是我决定当天傍晚去她的起坐间里喝可可的时候就跟她说一声。
It would hardly have been proper, then, to have taken any action without first informing Miss Kenton of the situation, and I resolved to do just this that same evening when I met her for cocoa in her parlour.

对于每天工作结束以后去她的起坐间里碰个面的这种安排，或许应该稍作说明。
I should perhaps say a few words here concerning these meetings in her parlour at the end of each day.

应该说，这种安排完全是事务性的—虽说时不时地，我们也会讨论一些非正式的话题。
These were, let me say, overwhelmingly professional in tone – though naturally we might discuss some informal topics from time to time.

我们安排这种会面的理由非常简单：我们发现我们各自的公务经常都过于繁忙，经常是一连好几天我们连交换一些最基本的信息的机会都没有。
Our reason for instituting such meetings was simple: we had found that our respective lives were often so busy, several days could go by without our having an opportunity to exchange even the most basic of information.

我们认识到这种情况会严重地危及正常工作的平稳运转，而最直接有效的补救办法莫过于在一天的工作结束以后，在肯顿小姐的起坐间里不受打扰地待上个一刻钟左右的时间。
Such a situation, we recognized, seriously jeopardized the smooth running of operations, and to spend fifteen minutes or so together at the end of the day in the privacy of Miss Kenton's parlour was the most straightforward remedy.

我必须重申的是，这些会面主要都是工作性质的；也就是说，打个比方，我们可能会商量即将举行的某一社交活动的具体计划，或者讨论某位新近招募的员工的适应情况。
I must reiterate, these meetings were predominantly professional in character; that is to say, for instance, we might talk over the plans for a forthcoming event, or else discuss how a new recruit was settling in.

总之，言归正传，您应该可以理解，考虑到要告诉肯顿小姐我即将解雇她手下的两位女仆，我内心也难免会有些波澜起伏。
In any case, to return to my thread, you will appreciate I was not unperturbed at the prospect of telling Miss Kenton I was about to dismiss two of her maids.

实事求是地说，这两位女仆一直以来都是非常令人满意的优秀雇员—既然近来犹太人的问题已经变得如此敏感，我不如索性把话挑明了—出于本意，我是完全反对将她们解雇的。
Indeed, the maids had been perfectly satisfactory employees and – I may as well say this since the Jewish issue has become so sensitive of late – my every instinct opposed the idea of their dismissal.

尽管如此，我在这一问题上的职责又是非常明确的，而且我也看得很清楚，即便是我不负责任地将我个人的质疑和盘托出，也是完全于事无补的。
Nevertheless, my duty in this instance was quite clear, and as I saw it, there was nothing to be gained at all in irresponsibly displaying such personal doubts.

这是个艰巨的任务，可是正因为如此，就尤其要求我要颇有尊严地予以完成。
It was a difficult task, but as such, one that demanded to be carried out with dignity.

也正是为此，当天傍晚在我们的日常交谈即将结束的时候，我才把这件事提了出来，而且是以尽可能简明扼要和就事论事的态度提出的，我具体是这样说的：
And so it was that when I finally raised the matter towards the end of our conversation that evening, I did so in as concise and businesslike a way as possible, concluding with the words:

“明天上午十点半，我将在我的餐具室里跟这两位雇员谈一下。
‘I will speak to the two employees in my pantry tomorrow morning at ten thirty.

如果届时您能差她们过来一趟的话，肯顿小姐，我将感激不尽。
I would be grateful then, Miss Kenton, if you would send them along.

至于您事先是否要将我会跟她们谈的内容知会她们，就交由您全权决定吧。”
I leave it entirely to yourself whether or not you inform them beforehand as to the nature of what I am going to say to them.’

话已至此，肯顿小姐像是全然无言以对了。
At this point, Miss Kenton seemed to have nothing to say in response.

我于是继续道：“那好，肯顿小姐，谢谢您的可可。
So I continued: ‘Well, Miss Kenton, thank you for the cocoa.

我想我也该回房休息了。
It's high time I was turning in.

明天又是繁忙的一天。”
Another busy day tomorrow.’

在这个时候，肯顿小姐终于开口说话了：“史蒂文斯先生，我简直不相信自己的耳朵。
It was then Miss Kenton said: ‘Mr Stevens, I cannot quite believe my ears.

鲁思和萨拉在我手底下已经工作了有六年多了。
Ruth and Sarah have been members of my staff for over six years now.

我完全信任她们，她们也的确信任我。
I trust them absolutely and indeed they trust me.

她们在达林顿府里的工作非常出色。”
They have served this house excellently.’

“我相信这都是事实，肯顿小姐。
‘I am sure that is so, Miss Kenton.

可是，我们决不能让私人情感渗透进我们的判断中来。
However, we must not allow sentiment to creep into our judgement.

好了，我现在真的要跟您道声晚安了……”
Now really, I must bid you good night …’

“史蒂文斯先生，我非常气愤，你居然可以坐在那儿轻轻松松地说出刚才那番话，就仿佛你不过是在跟我讨论家用食品的订货似的。
‘Mr Stevens, I am outraged that you can sit there and utter what you have just done as though you were discussing orders for the larder.

我实在是无法相信。
I simply cannot believe it.

你说鲁思和萨拉要被解雇，就因为她们是犹太人？”
You are saying Ruth and Sarah are to be dismissed on the grounds that they are Jewish?’

“肯顿小姐，我刚刚已经把全部的实情跟您解释过了。
‘Miss Kenton, I have just this moment explained the situation to you fully.

爵爷已经做出了决定，你我是没有任何可以争辩的余地的。”
His lordship has made his decision and there is nothing for you and I to debate over.’

“你难道就没有想过，史蒂文斯先生，以这样的理由解雇鲁思和萨拉根本就是—错的吗？
‘Does it not occur to you, Mr Stevens, that to dismiss Ruth and Sarah on these grounds would be simply – wrong?

我不会容忍这样的事情发生。
I will not stand for such things.

我不会在居然发生这种事情的宅第中继续工作下去了。”
I will not work in a house in which such things can occur.’

“肯顿小姐，我请求您不要这么激动，并请您以与您的职位相称的态度规范您的言行。
‘Miss Kenton, I will ask you not to excite yourself and to conduct yourself in a manner befitting your position.

这是一桩简单明了的事务。
This is a very straightforward matter.

如果爵爷希望终止这两份特定的雇用合同的话，那么别人谁都没有资格说三道四。”
If his lordship wishes these particular contracts to be discontinued, then there is little more to be said.’

“我警告你，史蒂文斯先生，如果你明天把我的两位姑娘给解雇了的话，我也跟着一起走。”
‘I am warning you, Mr Stevens, I will not continue to work in such a house. If my girls are dismissed, I will leave also.’

“肯顿小姐，我很惊讶于您居然做出这样的反应。
‘Miss Kenton, I am surprised to find you reacting in this manner.

我肯定不需要提醒您我们的职业责任不应以自己的癖好和情感为出发点，而应遵从我们雇主的意愿。”
Surely I don't have to remind you that our professional duty is not to our own foibles and sentiments, but to the wishes of our employer.’

“我要告诉你的是，史蒂文斯先生，你如果明天解雇了我的两位姑娘，那将是大错特错的，那将是莫大的罪恶，我决不会继续在这样的宅第中工作下去了。”
‘I am telling you, Mr Stevens, if you dismiss my girls tomorrow, it will be wrong, a sin as any sin ever was one and I will not continue to work in such a house.’

“肯顿小姐，请容我向您提个忠告，您所处的地位还不足以使您做出如此趾高气扬的决断。
‘Miss Kenton, let me suggest to you that you are hardly well placed to be passing judgements of such a high and mighty nature.

事实上，现今的世界是个异常复杂而又危机四伏的所在。
The fact is, the world of today is a very complicated and treacherous place.

有很多事情，比如说有关犹太民族的本质这样的问题，都不是处在你我这样地位的人能够理解的。
There are many things you and I are simply not in a position to understand concerning, say, the nature of Jewry.

然而爵爷，我冒昧说一句，肯定比我们更有资格判定怎么做才是最好的。
Whereas his lordship, I might venture, is somewhat better placed to judge what is for the best.

好了，肯顿小姐，我真的必须告退了。
Now, Miss Kenton, I really must retire.

再次感谢您的可可。
I thank you again for the cocoa.

明天上午十点半。
Ten thirty tomorrow morning.

请让那两名相关的雇员过来见我。”
Send the two employees concerned, please.’

第二天上午，从那两位女仆踏进我餐具室的那一刻看来，肯顿小姐已经跟她们说过了，因为她们俩都是抽抽搭搭地进来的。
It was evident from the moment the two maids stepped into my pantry the following morning that Miss Kenton had already spoken to them, for they both came in sobbing.

我尽可能简明扼要地将情况向她们解释了一下，特别强调了她们的工作一直都是非常令人满意的，因此肯定会拿到评价很高的推荐信。
I explained the situation to them as briefly as possible, underlining that their work had been satisfactory and that they would, accordingly, receive good references.

据我的记忆，她们俩自始至终都没说过任何值得注意的话，那次面谈最多也就持续了三四分钟的时间，她们就像来的时候一样，抽抽搭搭地离开了。
As I recall, neither of them said anything of note throughout the whole interview, which lasted perhaps three or four minutes, and they left sobbing just as they had arrived.

自从解雇了那两位女仆以后，肯顿小姐一连好多天对我的态度都极其冷淡。
Miss Kenton was extremely cold towards me for some days following the dismissal of the employees.

确切说来，有时对我甚至相当粗鲁，而且还是当着其他员工的面。
Indeed, at times she was quite rude to me, even in the presence of staff.

尽管我们仍旧保持着每天傍晚碰个头、喝杯可可的习惯，会面的时间却变得异常短促，而且气氛也很不友好。
And although we continued our habit of meeting for cocoa in the evening, the sessions tended to be brief and unfriendly.

事情都过去半个月了，她的态度仍然没有缓和的迹象，我想您也应该能够理解，我也开始有些不耐烦了。
When there had been no sign of her behaviour abating after a fortnight or so, I think you will understand that I started to become a little impatient.

于是在我们某次碰头一起喝可可的时候，我故意语带讽刺地跟她说：
I thus said to her during one of our cocoa sessions, in an ironic tone of voice:

“肯顿小姐，我还以为您这会儿应该已经递上辞呈来了呢，”说完我轻轻一笑。
‘Miss Kenton, I'd rather expected you to have handed in your notice by now,’ accompanying this with a light laugh.

我想，我当时是希望她的态度能够终于和缓下来，做出某种和解的回应之类的，如此一来，我们就能把这整件事彻底抛到一边去了。
I did, I suppose, hope that she might finally relent a little and make some conciliatory response or other, allowing us once and for all to put the whole episode behind us.

可是肯顿小姐却只是目光严厉地看着我说：
Miss Kenton, however, simply looked at me sternly and said:

“我仍旧一如既往，很想把辞呈递上去，史蒂文斯先生。
‘I still have every intention of handing in my notice, Mr Stevens.

只是因为我这段时间实在太忙，没有时间实际着手这件事。”
It is merely that I have been so busy, I have not had time to see to the matter.’

我得承认，她这番话还当真让我担心了好一阵子，唯恐她的这个威胁是当真的。
This did, I must admit, make me a little concerned for a time that she was serious about her threat.

不过随着时间一周周地过去，显然她并没有离开达林顿府的打算，而且随着我们之间的气氛逐渐趋向和缓，我想我也开始时不时地提起她曾经威胁要辞职的这件事来取笑她。
But then as week followed week, it became clear that there was no question of her leaving Darlington Hall, and as the atmosphere between us gradually thawed, I suppose I tended to tease her every now and again by reminding her of her threatened resignation.

比如说，如果碰上我们正在讨论府里即将举行的某项重大的社交活动，我就会故意找补一句：“也就是说，肯顿小姐，那得假设您届时还会跟我们在一起。”
For instance, if we were discussing some future large occasion to be held at the house, I might put in: ‘That is, Miss Kenton, assuming you are still with us at that stage.’

即便是在事情已经过去了好几个月以后，这样的取笑仍会让肯顿小姐一下子就默不作声了—虽说到了这个阶段，我想这更多的是出于尴尬而非恼怒。
Even months after the event, such remarks still tended to make Miss Kenton go quiet – though by this stage, I fancy, this was due more to embarrassment than anger.

最后，当然了，这件事基本上也就逐渐被淡忘了。
Eventually, of course, the matter came to be, by and large, forgotten.

不过我记得这件事最后一次又被提起，是在那两位女仆被辞退的一年多以后。
But I remember it coming up one last time well over a year after the dismissal of the two maids.

有一天下午我在会客厅为达林顿勋爵奉上茶点的时候，是爵爷首先旧事重提的。
It was his lordship who initially revived the matter one afternoon when I was serving his tea in the drawing room.

那个时候，卡罗琳·巴尼特太太对爵爷拥有巨大影响的时期已经过去了—的确，那位夫人已经完全不再是达林顿府的座上宾了。
By then, Mrs Carolyn Barnet's days of influence over his lordship were well over – indeed, the lady had ceased to be a visitor at Darlington Hall altogether.

还有一点值得指出的是，爵爷到了那时也已经认识到“黑衫党”那丑陋的真面目，跟该组织中断了所有的联系。
It is worth pointing out, furthermore, that his lordship had by that time severed all links with the ‘blackshirts’, having witnessed the true, ugly nature of that organization.

“哦，史蒂文斯，”他对我道。
‘Oh, Stevens,’ he said to me.

“我一直都想再跟你谈谈。
‘I’ve been meaning to say to you.

关于去年的那件事。
About that business last year.

就是那两位犹太女仆。
About the Jewish maids.

你还记得吧？”
You recall the matter?’

“当然，先生。”
‘Indeed, sir.’

“我想，现在也没办法找到她们的去向了吧，是不是？
‘I suppose there's no way of tracing them now, is there?

我当初的处理方式是错的，所以我总想能为她们受到的错待做一点补偿。”
It was wrong what happened and one would like to recompense them somehow.’

“我一定去追查一下这件事，先生。
‘I will certainly look into the matter, sir.

不过时至今日，我一点都没有把握是否还有可能查明她们的去向。”
But I am not at all certain it will be possible to ascertain their whereabouts at this stage.’

“你就尽力而为吧。
‘See what you can do.

当初的做法是错的。”
It was wrong, what occurred.’

我猜想我跟爵爷的这番交谈肯顿小姐应该是有兴趣知道的，而且我也认为只有把这件事告诉她才是唯一正确的做法—即使冒着再次把她激怒的风险。
I assumed this exchange with his lordship would be of some interest to Miss Kenton, and I decided it only proper to mention it to her – even at the risk of getting her angry again.

却不料，在那个雾蒙蒙的下午，我在凉亭里碰到她跟她说起这件事的时候，竟产生了某些意想不到的结果。
As it turned out, my doing so on that foggy afternoon I encountered her in the summerhouse produced curious results.

我记得那天下午我横穿草坪的时候，雾气已经开始降了下来。
I recall a mist starting to set in as I crossed the lawn that afternoon.

我到凉亭里去是为了将爵爷刚才招待几位客人在那儿享用茶点的残剩收拾干净。
I was making my way up to the summerhouse for the purpose of clearing away the remains of his lordship's tea there with some guests a little while earlier.

我记得我远远地就看到—距离家父当年摔倒的那几级台阶还很远—肯顿小姐的身影在凉亭内走动。
I can recall spotting from some distance – long before reaching the steps where my father had once fallen – Miss Kenton's figure moving about inside the summerhouse.

我走进凉亭的时候，她已经在散放于里面的其中一把柳条椅子上坐了下来，显然正忙于手上的针线活儿。
When I entered she had seated herself on one of the wicker chairs scattered around its interior, evidently engaged in some needlework.

走近一看，发现她是在缝补一个靠垫。
On closer inspection, I saw she was performing repairs to a cushion.

我开始把散放在盆栽当中和藤编家具上的各种瓷器收拾起来，我应该是一边收拾，一边跟肯顿小姐相互打趣了几句，也许还讨论了一两件工作上的事情。
I went about gathering up the various items of crockery from amidst the plants and the cane furniture, and as I did so, I believe we exchanged a few pleasantries, perhaps discussed one or two professional matters.

事实上，一连好几天都在主楼里面足不出户，这会子能来到这个户外的凉亭里，感觉格外神清气爽，所以我们俩都不着急把手里的活计干完。
For the truth was, it was extremely refreshing to be out in the summerhouse after many continuous days in the main building and neither of us was inclined to hurry with our tasks.

也确实，虽说因为那天雾气渐浓，外面也看不到很远的地方，再加上那时候天光正迅速地暗下去，迫使肯顿小姐不得不就着最后几缕光线飞针走线，我记得我们仍旧经常停下手上的工作，只是为了抬眼望望我们周遭的景色。
Indeed, although one could not see out far that day on account of the encroaching mist, and the daylight too was rapidly fading by this stage, obliging Miss Kenton to hold her needlework up to the last of it, I remember our often breaking off from our respective activities simply to gaze out at the views around us.

事实上，我也只能望到草坪那头沿着马车道种植的那排白杨树，那里已经被浓雾所笼罩了，这时我才终于把话题引到了去年解雇两位女仆的那件事上。
In fact, I was looking out over the lawn to where the mist was thickening down around the poplar trees planted along the cart-track, when I finally introduced the topic of the previous year's dismissals.

也许可以预见，我是这么说的：
Perhaps a little predictably, I did so by saying:

“我刚才还一直在想呢，肯顿小姐。
‘I was just thinking earlier, Miss Kenton.

现在想来感觉还是挺滑稽的，可是您知道，就在一年前的这个时候，您还一直执意打算要辞职来着呢。
It's rather funny to remember now, but you know, only this time a year ago, you were still insisting you were going to resign.

一想起来我就觉得挺好玩儿的。”
It rather amused me to think of it.’

我说完呵呵一笑，可是我身后的肯顿小姐却默不作声。
I gave a laugh, but behind me Miss Kenton remained silent.

等我终于回头去看她的时候，发现她正透过玻璃，怔怔地望着窗外铺天盖地的浓雾。
When I finally turned to look at her, she was gazing through the glass at the great expanse of fog outside.

“您可能没有想到，史蒂文斯先生，”她终于说道，“我曾经多么认真地考虑过要离开这里。
‘You probably have no idea, Mr Stevens,’ she said eventually, ‘how seriously I really thought of leaving this house.

发生的那件事对我的冲击太大了。
I felt so strongly about what happened.

我如果还有一丝一毫值得让人尊敬的地方，我敢说我老早就已经离开达林顿府了。”
Had I been anyone worthy of any respect at all, I dare say I would have left Darlington Hall long ago.’

她沉吟片刻，我把目光转向外面远处的白杨树。
She paused for a while, and I turned my gaze back out to the poplar trees down in the distance.

然后她用倦怠的口气继续道：“那是怯懦，史蒂文斯先生。
Then she continued in a tired voice: ‘It was cowardice, Mr Stevens.

完完全全就是怯懦。
Simple cowardice.

我能到哪儿去呢？
Where could I have gone?

我没有家人。
I have no family.

只有一位姨妈。
Only my aunt.

我很爱她，可如果跟她住在一起的话，我没有一天不会感觉我整个的一生都被蹉跎掉了。
I love her dearly, but I can't live with her for a day without feeling my whole life is wasting away.

当然，我也的确曾安慰过自己，我很快就能找到一个新的职位。
I did tell myself, of course, I would soon find myself some new situation.

可是我太害怕了，史蒂文斯先生。
But I was so frightened, Mr Stevens.

每次我一想到要离开这里，我眼前就会浮现出我孤零零流落在外的情景，而周围没有一个认识我、关心我的人。
Whenever I thought of leaving, I just saw myself going out there and finding nobody who knew or cared about me.

您瞧，我所有的高尚原则总共也就值这么多。
There, that's all my high principles amount to.

我真是为自己感到羞愧难当。
I feel so ashamed of myself.

可我就是离不开这儿，史蒂文斯先生，我就是下不了一走了之的决心。”
But I just couldn't leave, Mr Stevens, I just couldn't bring myself to leave.’

肯顿小姐再次停了下来，像是深陷在思绪当中。
Miss Kenton paused again and seemed to be deep in thought.

于是我想这倒是个好机会，就尽可能精确地把之前我和达林顿勋爵之间的那番对话复述了一遍。
I thus thought it opportune to relate at this point, as precisely as possible, what had taken place earlier between myself and Lord Darlington.

转述完以后，我又加了一句：
I proceeded to do so and concluded by saying:

“事已至此，覆水难收，不过能听到爵爷如此毫不含糊地宣称当初那件事完全是个可怕的误会，至少让人心下大为宽慰。
‘What's done can hardly be undone. But it is at least a great comfort to hear his lordship declare so unequivocally that it was all a terrible misunderstanding.

我只是觉得您应该愿意听到这个消息，肯顿小姐，因为我记得您当时为了这件事是跟我一样深感苦恼和难过的。”
I just thought you'd like to know, Miss Kenton, since I recall you were as distressed by the episode as I was.’

“不好意思，史蒂文斯先生，”我身后的肯顿小姐以一种全新的声音说道，就仿佛她刚从梦中被惊醒一样，“我真是搞不懂你了。”
‘I'm sorry, Mr Stevens,’ Miss Kenton said behind me in an entirely new voice, as though she had just been jolted from a dream, ‘I don't understand you.’

我转过身来面向她的时候，她继续道：“我记得，你当时认为让鲁思和萨拉卷铺盖走人才是唯一正确而又正当的做法。
Then as I turned to her, she went on: ‘As I recall, you thought it was only right and proper that Ruth and Sarah be sent packing.

对于这件事你当时根本就是兴高采烈的。”
You were positively cheerful about it.’

“肯顿小姐，您这种说法实在是既不正确又不公道。
‘Now really, Miss Kenton, that is quite incorrect and unfair.

那整个事件曾引起我极大的忧虑，的的确确是万分的忧虑。
The whole matter caused me great concern, great concern indeed.

在这幢宅子里发生这样的事情，那绝非是我乐于看到的。”
It is hardly the sort of thing I like to see happen in this house.’

“那为什么，史蒂文斯先生，你为什么当时不这样跟我说呢？”
‘Then why, Mr Stevens, did you not tell me so at the time?’

我笑了笑，可是一时间竟也无言以对。
I gave a laugh, but for a moment was rather at a loss for an answer.

还没等我想出应对之词，肯顿小姐已经把手里的针线活放下来道：
Before I could formulate one, Miss Kenton put down her sewing and said:

“你有没有意识到，史蒂文斯先生，如果你去年就肯跟我分享你的感受的话，那对我的意义有多么重大？
‘Do you realize, Mr Stevens, how much it would have meant to me if you had thought to share your feelings last year?

你明知道我那两个姑娘被解雇的时候，我是多么五内俱焚。
You knew how upset I was when my girls were dismissed.

你有没有意识到那会对我有多大的帮助？
Do you realize how much it would have helped me?

为什么，史蒂文斯先生，为什么，为什么，为什么你总是要去假装呢？”
Why, Mr Stevens, why, why, why do you always have to pretend?’

对于我们的谈话这突然间匪夷所思的转向，我又笑了笑。
I gave another laugh at the ridiculous turn the conversation had suddenly taken.

“说真的，肯顿小姐，”我说，“我不是很确定能明白您的意思。
‘Really, Miss Kenton,’ I said, ‘I'm not sure I know what you mean.

假装？
Pretend?

真是的，我为什么要……”
Why, really …’

“我因为鲁思和萨拉不得不离开我们而痛苦万分。
‘I suffered so much over Ruth and Sarah leaving us.

而令我感觉更加痛苦的是我当时以为自己是完全孤立无援的。”
And I suffered all the more because I believed I was alone.’

“说真的，肯顿小姐……”我端起那个我用来放使用过的瓷器的托盘。
‘Really, Miss Kenton …’ I picked up the tray on which I had gathered together the used crockery.

“对那样的解雇我自然是极不赞同的。
‘Naturally, one disapproved of the dismissals.

我还以为那是不言自明的。”
One would have thought that quite self-evident.’

她没再说什么，离开前我回头看了她一眼。
She did not say anything, and as I was leaving I glanced back towards her.

她再次怔怔地望着窗外的景色，但到了这个时候，凉亭里面已经差不多完全暗了下来，我能看到的，就只是暗淡和空茫的背景映衬下的她的侧影。
She was again gazing out at the view, but it had by this point grown so dark inside the summerhouse, all I could see of her was her profile outlined against a pale and empty background.

我向她告了个退，就走出了凉亭。
I excused myself and proceeded to make my exit.

由于回忆两位犹太雇员遭到解雇的那一事件，连带地也让我想起另一件事，我想可以被称为是那整个事件的一个有些奇怪的必然结果：就是那个叫丽萨的女仆的到来。
Now that I have recalled this episode of the dismissing of the Jewish employees, I am reminded of what could, I suppose, be called a curious corollary to that whole affair: namely, the arrival of the housemaid called Lisa.

也就是说，我们不得不找人替代那两位被解雇的女仆，而这位丽萨就成为其中的一位。
That is to say, we were obliged to find replacements for the two dismissed Jewish maids, and this Lisa turned out to be one of them.

这个年轻女人是带着一封最为可疑的推荐信前来应征那个空缺的，任何一位有点经验的管家从中都能看出，她离开前一个职位的时候是蒙受着某种嫌疑的。
This young woman had applied for the vacancy with the most dubious of references, which spelt out to any experienced butler that she had left her previous situation under something of a cloud.

更有甚者，肯顿小姐和我在面试的时候发现，显然她在任何一个工作岗位上最长都没有干够一个月的时间。
Moreover, when Miss Kenton and I questioned her, it became clear that she had never remained in any position for longer than a few weeks.

总之一句话，她整个的态度和作风在我看来都极不适合在达林顿府供职。
In general, her whole attitude suggested to me that she was quite unsuitable for employment at Darlington Hall.

然而，令我吃惊的是，对这个姑娘的面试结束以后，肯顿小姐却开始坚持我们应该雇用她。
To my surprise, however, once we had finished interviewing the girl, Miss Kenton began to insist we take her on.

“我在这个姑娘身上看到了极大的潜力，”面对我的反对她继续道。
‘I see much potential in this girl,’ she continued to say in the face of my protests.

“我会将她置于我的直接监管之下，我会负责让她证明她是能够干得好的。”
‘She will be directly under my supervision and I will see to it she proves good.’

我记得我们因为意见分歧僵持了好一阵子，或许只是因为解雇那两位女仆的事件在我们的脑海中是如此切近，我才没有像原本可能的那样坚持己见，反对肯顿小姐的主张。
I recall we became locked in disagreement for some time, and it was perhaps only the fact that the matter of the dismissed maids was so recent in our minds that I did not hold out as strongly as I might against Miss Kenton.

不管怎么说吧，结果是我终于让了步，尽管我还是这么说：
In any case, the result was that I finally gave way, albeit by saying:

“肯顿小姐，我希望您能意识到如此一来，雇用这个姑娘的责任就完完全全落到你的肩膀上了。
‘Miss Kenton, I hope you realize that the responsibility for taking on this girl rests squarely with yourself.

因为在我看来，至少在目前她毫无疑问是远远没有资格成为我们团队的一员的。
There is no doubt as far as I am concerned that at this present moment she is far from adequate to be a member of our staff.

我现在姑且允许她加入进来，但前提是您必须亲自负责监督她在职业上的发展。”
I am only allowing her to join on the understanding that you will personally oversee her development.’

“这姑娘会表现得很不错的，史蒂文斯先生。
‘The girl will turn out well, Mr Stevens.

你就等着瞧吧。”
You will see.’

让我吃惊的是，在接下来的几个礼拜当中，这位年轻的姑娘倒是的确取得了长足的进步。
And to my astonishment, during the weeks that followed, the young girl did indeed make progress at a remarkable rate.

她的态度简直是每日一新，就连她走路和执行任务的仪态—在刚开始的那几天里实在是懒散邋遢到了惨不忍睹的程度—居然也有了极为显著的改善。
Her attitude seemed to improve by the day, and even her manner of walking and going about tasks – which during the first days had been so slovenly that one had to avert one's eyes – improved dramatically.

随着时间一周周过去，这姑娘像是发生了奇迹一般，居然已经蜕变为我们团队中非常有用的一员，肯顿小姐的成功是显而易见了。
As the weeks went on, and the girl appeared miraculously to have been transformed into a useful member of staff, Miss Kenton's triumph was obvious.

她似乎特别喜欢给丽萨分配一些需要负担那么一点额外责任的工作任务，我要是在旁边看着，她肯定就会特意跟我交换个眼神，脸上不乏几分揶揄的表情。
She seemed to take particular pleasure in assigning Lisa some task or other that required a little extra responsibility, and if I were watching, she would be sure to try and catch my eye with her rather mocking expression.

那天夜里我们在肯顿小姐的起坐间里一边喝可可一边闲谈的时候，丽萨可是个逃不过的重要话题。
And the exchange we had that night in Miss Kenton's parlour over cocoa was fairly typical of the sort of conversation we tended to have on the topic of Lisa.

“毫无疑问，史蒂文斯先生，”她对我这么说，“听说丽萨迄今为止居然还没有犯什么值得一提的大错儿，您想必非常失望吧。”
‘No doubt, Mr Stevens,’ she said to me, ‘you will be extremely disappointed to hear Lisa has still not made any real mistake worth speaking of.’

“我一点都没有感到失望，肯顿小姐。
‘I'm not disappointed at all, Miss Kenton.

我很为您也为我们大家感到高兴。
I'm very pleased for you and for all of us.

我承认，到目前为止，您已经在这个姑娘身上取得了些微的成功。”
I will admit, you have had some modest success regarding the girl thus far.’

“些微的成功！
‘Modest success!

瞧瞧您脸上的微笑，史蒂文斯先生。
And look at that smile on your face, Mr Stevens.

我一提到丽萨，您就总会浮现出这样的笑容。
It always appears when I mention Lisa.

这笑容本身就在告诉我们一个有趣的故事。
That tells an interesting story in itself.

一个非常有趣的故事，一点没错。”
A very interesting story indeed.’

“喔，真的吗，肯顿小姐？
‘Oh, really, Miss Kenton.

我能请教到底是个什么样的故事吗？”
And may I ask what exactly?’

“的确非常有趣，史蒂文斯先生。
‘It is very interesting, Mr Stevens.

您居然对她抱有如此悲观的偏见，这本身就非常有趣。
Very interesting you should have been so pessimistic about her.

一定是因为丽萨是个漂亮姑娘的缘故，这一点是毫无疑问的。
Because Lisa is a pretty girl, no doubt about it.

而且我已经注意到了，您对于咱们团队中的漂亮姑娘总是抱有一种奇怪的厌恶之情。”
And I've noticed you have a curious aversion to pretty girls being on the staff.’

“您自己也很清楚您这绝对是无稽之谈，肯顿小姐。”
‘You know perfectly well you are talking nonsense, Miss Kenton.’

“啊，可我真的已经注意到了，史蒂文斯先生。
‘Ah, but I've noticed it, Mr Stevens.

您不喜欢我们的团队中有漂亮姑娘。
You do not like pretty girls to be on the staff.

也许是因为我们的史蒂文斯先生害怕因此而分心？
Might it be that our Mr Stevens fears distraction?

难道我们的史蒂文斯先生终究也是血肉之躯，不能完全信得过自己吗？”
Can it be that our Mr Stevens is flesh and blood after all and cannot fully trust himself?’

“真有你的，肯顿小姐。
‘Really, Miss Kenton.

我要是觉得您这番话里哪怕有那么一丁点儿的道理，我也许就会耐着性子跟您好好地探讨一番了。
If I thought there was one modicum of sense in what you are saying I might bother to engage with you in this discussion.

照目前的情况来看，我想我还是省点心想想别的去吧，由着您怎么高兴怎么说去。”
As it is, I think I shall simply place my thoughts elsewhere while you chatter away.’

“啊，可是为什么那心虚的笑容仍旧挂在您的脸上呢，史蒂文斯先生？”
‘Ah, but then why is that guilty smile still on your face, Mr Stevens?’

“那根本就不是什么心虚的笑容，肯顿小姐。
‘It is not a guilty smile at all, Miss Kenton.

我只是为您那惊人的瞎扯功夫感觉有些好笑罢了。”
I am slightly amused by your astonishing capacity to talk nonsense, that is all.’

“您脸上挂的就是心虚的笑容，史蒂文斯先生。
‘It is a guilty little smile you have on, Mr Stevens.

而且我已经注意到您是如何几乎都不敢正眼瞧丽萨了。
And I've noticed how you can hardly bear to look at Lisa.

当初您为什么那么强烈地反对录用她，那原因现在已经开始变得非常清楚了。”
Now it is beginning to become very clear why you objected so strongly to her.’

“我当初的反对意见都绝对是有真凭实据的，肯顿小姐，您自己也心知肚明。
‘My objections were extremely solid, Miss Kenton, as you very well know.

这姑娘前来应聘的时候是完全够不上录用标准的。”
The girl was completely unsuitable when she first came to us.’

当然了，您想必也能理解，我们是从来不会在员工们听得到的情况下以这样的语气调侃抬杠的。
Now of course, you must understand we would never have carried on in such a vein within the hearing of staff members.

不过也差不多就在那个时候，我们的可可之夜在本质上虽然仍属于工作性质，却也经常会为这种无伤大雅的闲扯留出相应的空间—应该说，这对于纾解辛苦工作的一天所带来的压力是大为有益的。
But just around that time, our cocoa evenings, while maintaining their essentially professional character, often tended to allow room for a little harmless talk of this sort – which did much, one should say, to relieve the many tensions produced by a hard day.

丽萨和我们一起工作了大约有八九个月的时间—到了这个时候我已经基本上忘掉她的存在了—然后就跟第二男仆双双消失不见了。
Lisa had been with us for some eight or nine months – and I had largely forgotten her existence by this point – when she vanished from the house together with the second footman.

当然了，对于任何一位大户人家的管家而言，这种事情已经是其日常生活的一部分了。
Now, of course, such things are simply part and parcel of life for any butler of a large household.

事情诚然非常令人恼火，不过你也得学着去接受。
They are intensely irritating, but one learns to accept them.

事实上，在这类“夜奔”的事件当中，这一次还算是比较文明的。
In fact, as far as these sorts of ‘moonlight’ departures were concerned, this was among the more civilized.

除了一点食物以外，这对小情侣并没有顺带携走任何府里的财物，不仅如此，人家两位还都分别留下了书信。
Aside from a little food, the couple had taken nothing that belonged to the house, and furthermore, both parties had left letters.

第二男仆，他的名字我已经记不得了，留了一张短笺给我，大致的内容是：“请不要对于我们过于苛责。
The second footman, whose name I no longer recall, left a short note addressed to me, saying something like: ‘Please do not judge us too harshly.

我们相爱了并且就要正式成婚。”
We are in love and are going to be married.’

丽萨给“女管家”写了一封长信，在他们失踪以后的第二天一早，肯顿小姐带着这封信来到了我的餐具室。
Lisa had written a much longer note addressed to ‘the Housekeeper’, and it was this letter Miss Kenton brought into my pantry on the morning following their disappearance.

我记得那封信里有很多拼写错误和不通的句子，详细描述了他们俩是如何相爱，第二男仆是个多么出色的人，以及他们的未来是何等地美妙无比。
There were, as I recall, many misspelt, ill-formed sentences about how much in love the couple were, how wonderful the second footman was, and how marvellous the future was that awaited them both.

我还记得其中有一句的大意是这样的：“我们没有钱但是谁在乎这个我们已经有了爱情谁还想要别的什么呢我们拥有了彼此再也别无所求。”
One line, as I recall it, read something to the effect of: ‘We don't have money but who cares we have love and who wants anything else we've got one another that's all anyone can ever want.’

这封信虽然足足写了有三页纸，可是没有一个字对肯顿小姐给予她的无微不至的照顾表示感激，也没有任何因为让我们大家都感到失望了的歉意表示。
Despite the letter being three pages long, there was no mention of any gratitude towards Miss Kenton for the great care she had given the girl, nor was there any note of regret at letting all of us down.

肯顿小姐明显地非常难过。
Miss Kenton was noticeably upset.

我在快速浏览那年轻女人的长信期间，她始终都坐在我面前的桌子旁边，低头看着自己的双手。
All the while I was running my eye over the young woman's letter, she sat there at the table before me, looking down at her hands.

事实上—这也让我觉得挺匪夷所思的—我真不记得曾见过她有比那天早上更失魂落魄的时候。
In fact – and this strikes one as rather curious – I cannot really recall seeing her more bereft than on that morning.

当我把那封信放到桌子上的时候，她说道：
When I put the letter down on the table, she said:

“这么看来，史蒂文斯先生，还是你对了，是我错了。”
‘So, Mr Stevens, it seems you were right and I was wrong.’

“肯顿小姐，你实在没必要自寻烦恼，”我说。
‘Miss Kenton, this is nothing to upset yourself over,’ I said.

“这种事情总是有的。
‘These things happen.

我们无论做什么，都是没办法防止这些事情发生的。”
There really is little the likes of us can ever do to prevent these things.’

“错在我身上，史蒂文斯先生。
‘I was at fault, Mr Stevens.

我诚心接受。
I accept it.

你一直都是对的，一如既往，错的是我。”
You were right all along, as ever, and I was wrong.’

“肯顿小姐，你这话我实在是无法苟同。
‘Miss Kenton, I really cannot agree with you.

你在那个姑娘身上创造了奇迹。
You did wonders with that girl.

通过你的指导，她已经多少次用事实证明了实际上当初是我错认了她。
What you managed with her proved many times over that it was in fact I who was in error.

说真的，肯顿小姐，现在发生的这种事情也可能发生在任何雇员身上。
Really, Miss Kenton, what has happened now might have happened with any employee.

你在她的身上已经取得了了不起的成就。
You did remarkably well with her.

你有绝对充分的理由为她的忘恩负义感到失望，可是没有任何理由为她的错误感到自责。”
You may have every reason to feel let down by her, but no reason at all to feel any responsibility on your own part.’

肯顿小姐看上去仍旧很灰心丧气。
Miss Kenton continued to look very dejected.

她轻声道：“你这么说真是宽宏大量，史蒂文斯先生。
She said quietly: ‘You're very kind to say so, Mr Stevens.

我非常感激。”
I'm very grateful.’

然后她疲惫不堪地叹了口气，说道：“她真傻。
Then she sighed tiredly and said: ‘She's so foolish.

她本来完全可以有一个锦绣前程的。
She might have had a real career in front of her.

她有这个能力。
She had ability.

有那么多年轻女人就像她那样把大好的机会全都浪费掉了，为的又是什么呢？”
So many young women like her throw away their chances, and all for what?’

我们俩不约而同地看着我们之间桌子上的那几张信纸，然后肯顿小姐怒冲冲地把头别了过去。
We both looked at the notepaper on the table between us, and then Miss Kenton turned her gaze away with an air of annoyance.

“的确，”我说。
‘Indeed,’ I said.

“真是种浪费，你说得没错。”
‘Such a waste, as you say.’

“真傻。
‘So foolish.

那姑娘以后肯定会后悔的。
And the girl is bound to be let down.

她只要肯坚持下去，会过上不错的生活的。
And she had a good life ahead of her if only she'd persevered.

不出一两年，我就能让她够资格去个规模不大的公馆里担任女管家的。
In a year or two, I could have had her ready to take on a housekeeper's post in some small residence.

你也许觉得这有些痴心妄想，史蒂文斯先生，可是你瞧瞧这才几个月的时间，我已经把她调教成什么样子了。
Perhaps you think that farfetched, Mr Stevens, but then look how far I came with her in a few months.

可是现在，她就这么把这一切全都抛下了。
And now she's thrown it all away.

真是白忙活了一场。”
All for nothing.’

“她真是傻透了。”
‘It really is most foolish of her.’

我已经开始收拾面前的那几张信纸，想着或许应该把它们存档备查。
I had started to gather up the sheets of notepaper before me, thinking I might file them away for reference.

可是我在这么做的时候，又有点不太确定肯顿小姐是否打算让我保留这封信，抑或她更希望由她自己保留，于是我又把那几张信纸放回到我们之间的桌子上。
But then as I was doing so, I became a little uncertain as to whether Miss Kenton had intended me to keep the letter, or if she herself wished to do so, and I placed the pages back down on the table between the two of us.

可是不管我怎么做，肯顿小姐一直都显得心不在焉。
Miss Kenton, in any case, seemed far away.

“她日后肯定会后悔莫及的，”她又说了一遍。
‘She's bound to be let down,’ she said again.

“太傻了。”
‘So foolish.’

不过看起来我已经有些迷失在这些陈年往事的记忆中了。
But I see I have become somewhat lost in these old memories.

这绝非我的本意，不过或许这也并非什么坏事，因为如此一来，我至少就可以避免过分地沉溺于今天傍晚发生的那些事情中了—我确信这些事情终于算是告一段落了。
This had never been my intention, but then it is probably no bad thing if in doing so I have at least avoided becoming unduly preoccupied with the events of this evening – which I trust have now finally concluded themselves.

因为刚刚过去的那几个钟头，我必须坦言，对我来说实在是一种煎熬。
For these last few hours, it must be said, have been rather trying ones.

此刻，我正借宿于泰勒先生和太太那幢小小的农舍的阁楼上。
I find myself now in the attic room of this small cottage belonging to Mr and Mrs Taylor.

也就是说，这是一幢私人住宅；泰勒夫妇非常热心地供我今晚借宿的这个房间原本是他们的长子住的，他早已长大成人，如今住在埃克塞特。
That is to say, this is a private residence; this room, made so kindly available to me tonight by the Taylors, was once occupied by their eldest son, now long grown and living in Exeter.

房间里最显眼的就是顶上粗重的梁椽，木地板上没有铺任何地毯和地垫，气氛却出奇地舒适惬意。
It is a room dominated by heavy beams and rafters, and the floorboards have no carpet or rug to cover them, and yet the atmosphere is surprisingly cosy.

很明显，泰勒太太不只是为我铺好了床铺，她还特意清扫收拾了一番；因为除了椽子那儿还有几个蜘蛛网以外，几乎看不出这个房间已经有好多年无人居住了。
And it is clear Mrs Taylor has not only made up the bed for me, she has also tidied and cleaned; for aside from a few cobwebs near the rafters, there is little to reveal that this room has been unoccupied for many years.

至于泰勒先生和太太，我已经探听清楚，他们夫妻俩自从二十年代起就经营村里的蔬菜水果店，一直干到三年前退休。
As for Mr and Mrs Taylor themselves, I have ascertained that they ran the village green grocery here from the twenties until their retirement three years ago.

他们夫妻心地善良、为人和气，尽管今晚我不止一次提出要为他们的好意收留给以报酬，可他们一概都坚辞不受。
They are kind people, and though I have on more than one occasion tonight offered remuneration for their hospitality, they will not hear of it.

眼下我之所以来到这里，今晚之所以流落到只能仰仗泰勒先生和太太的慷慨大度才有地方过夜的地步，全都是因为我自己的一个愚蠢的、令人恼怒的简单疏忽造成的：即我居然把那辆福特车开得完全没有了汽油。
The fact that I am now here, the fact I came to be to all intents and purposes at the mercy of Mr and Mrs Taylor's generosity on this night, is attributable to one foolish, infuriatingly simple oversight: namely, I allowed the Ford to run out of petrol.

一位旁观者如果从这件事以及昨天因散热器缺水而造成的麻烦上得出我这个人办事天性就缺乏条理的结论，那也不能说是完全没有道理的。
What with this and the trouble yesterday concerning the lack of water in the radiator, it would not be unreasonable for an observer to believe such general disorganization endemic to my nature.

当然了，可以稍稍为我开脱的理由也不是没有：我在驾车长途旅行方面毕竟还是个新手，这类愚蠢的疏忽也还不算是特别离谱。
It may be pointed out, of course, that as far as long-distance motoring is concerned, I am something of a novice, and such simple oversights are only to be expected.

可是话又说回来了，当我想到良好的组织才能和深谋远虑恰恰是干我们这一行最重要的职业素养之时，不管怎么说，我也就很难避免再次深为自己感到失望和沮丧了。
And yet, when one remembers that good organization and foresight are qualities that lie at the very heart of one's profession, it is hard to avoid the feeling that one has, somehow, let oneself down again.

不过在汽油耗尽之前的那一个小时左右的时间里我一直都有些丧魂失魄的，这也是事实。
But it is true, I had been considerably distracted during the last hour or so of motoring prior to the petrol running out.

我原本是计划夜宿塔维斯托克镇的，在不到八点的时候我就到了那里。
I had planned to lodge the night in the town of Tavistock, where I arrived a little before eight o'clock.

可是在镇上那家最大的客栈里，店家却告诉我，由于当地正在举办一个农产品交易会，他们所有的房间都已经客满了。
At the town's main inn, however, I was informed all the rooms were occupied on account of a local agricultural fair.

他们向我推荐了其他几家旅店，我一家家问过去，但每一家都以同样的理由向我道歉。
Several other establishments were suggested to me, but though I called at each, I was met every time with the same apology.

最后，在镇子边上的一家家庭旅馆里，老板娘建议我不妨继续朝前再开个几英里，路边有她亲戚开的一家小旅店—那家店，她向我保证肯定会有空房，因为距离塔维斯托克太远，不会受到交易会的影响。
Finally, at a boarding house on the edge of the town, the landlady suggested I motor on several miles to a roadside inn run by a relative of hers – which, she assured me, was bound to have vacancies, being too far out of Tavistock to be affected by the fair.

她给了我详尽的指示，当时感觉是够清楚的了，现在也不可能说清楚到底是谁的错了，反正结果我是没有发现这家路边旅店的任何踪影。
She had given me thorough directions, which had seemed clear enough at the time, and it is impossible to say now whose fault it was that I subsequently failed to find any trace of this roadside establishment.

而在往前开了十五分钟左右以后，我发现自己已经驶入了一条蜿蜒穿越荒凉开阔的高沼地的长路。
Instead, after fifteen minutes or so of motoring, I found myself out on a long road curving across bleak, open moorland.

道路两侧看上去都像是沼泽地，而且一阵薄雾正慢慢漫过我眼前的道路。
On either side of me were what appeared to be fields of marsh, and a mist was rolling across my path.

在我左手边，我能看到太阳落山的最后一缕霞光。
To my left, I could see the last glow of the sunset.

天际线时不时会被不远处田野当中的谷仓以及农舍的轮廓打破，否则的话，我真像是已经被遗落在了荒无人烟的野地。
The skyline was broken here and there by the shapes of barns and farmhouses some way away over the fields, but otherwise, I appeared to have left behind all signs of community.

我记得大约是到了这个时候，我才掉转车头，往回开了一段距离，想找到之前经过的一个岔路口。
I recall turning the Ford round at about this stage and doubling back some distance in search of a turning I had passed earlier.

可是等我开上那条岔路以后，却发现这条路比我刚才离开的那条路线更加荒凉。
But when I found it, this new road proved, if anything, more desolate than the one I had left.

有一段时间，我就在近乎全黑的道路中行驶，两旁都是高大的树篱，然后又发现那条路开始爬起了陡坡。
For a time, I drove in near-darkness between high hedges, then found the road beginning to climb steeply.

事已至此，我已经放弃了找到那家路边旅店的希望，决定还是继续往前开，等来到下一个城镇或是乡村的时候再找栖身之地。
I had by now given up hope of finding the roadside inn and had set my mind on motoring on till I reached the next town or village and seeking shelter there.

我可以明天一早再返回预定的路线，那应该是很容易做到的，我这样说服自己。
It would be easy enough, so I was reasoning to myself, to resume my planned route first thing in the morning.

就在这个时候，在山路爬了一半的时候，引擎开始发出了突突的噪声，我这才第一次注意到汽油已经用光了。
It was at this point, half-way up the hill road, that the engine stuttered and I noticed for the first time that my petrol was gone.

福特车又继续爬行了几码远，然后就停了下来。
The Ford continued its climb for several more yards, then came to a halt.

我走下车来评估一下当下的情势时，发现我只剩下几分钟的天光可用了。
When I got out to assess my situation, I could see I had only a few more minutes of daylight left to me.

我站在一条陡路之上，被茂密的树木和灌木树篱夹在当中；再往山上望去，在老远的地方才看到连绵不断的树篱有了个缺口，衬着背后的天空现出一道栅栏门的宽大轮廓。
I was standing on a steep road bound in by trees and hedgerows; much further up the hill, I could see a break in the hedges where a wide barred gate stood outlined against the sky.

我开始朝山上的那个地方走去，心想从那道栅栏门那儿也许能辨明自己的方位；或许甚至有希望在附近看到一家农舍，我能够指望得到及时的帮助。
I began to make my way up to it, supposing that a view from this gate would give me some sense of my bearings; perhaps I had even hoped to see a farmhouse near by where I could gain prompt assistance.

可是最后出现在我眼前的景象却不禁让我有点仓皇失措了。
I was a little disconcerted then by what eventually greeted my eyes.

那扇门的另一侧是一片地势陡降的草地，视野所及只能看到面前二十码左右的距离，再往下就什么都看不清了。
On the other side of the gate a field sloped down very steeply so that it fell out of vision only twenty yards or so in front of me.

越过那片牧场隆起的高坡，远远的有一个小村庄—直线距离十足有一英里左右。
Beyond the crest of the field, some way off in the distance – perhaps a good mile or so as the crow would fly – was a small village.

透过薄雾可以辨别出一座教堂的尖塔，尖塔周围是一片深色石板瓦的屋顶；散布四处的烟囱里正冒出缕缕白烟。
I could make out through the mist a church steeple, and around about it, clusters of dark-slated roofs; here and there, wisps of white smoke were rising from chimneys.

我得承认，在那一刻，我的内心是颇为灰心丧气的。
One has to confess, at that moment, to being overcome by a certain sense of discouragement.

当然了，当时的情况绝对说不上令人绝望；福特车并没有损坏，只不过没了汽油。
Of course, the situation was not by any means hopeless; the Ford was not damaged, simply out of fuel.

半个小时之内就能走到那个小村庄，到了那里以后我肯定是能找到个投宿的地方和一桶汽油的。
A walk down to the village could be accomplished in a half-hour or so and there I could surely find accommodation and a can of petrol.

可是独立伫立在一个荒凉的山坡上，透过一扇栅栏门望着远处一个村庄的灯火，天光几乎已经完全褪尽，雾气越来越浓，那滋味实在不怎么好受。
And yet it was not a happy feeling to be up there on a lonely hill, looking over a gate at the lights coming on in a distant village, the daylight all but faded, and the mist growing ever thicker.

可是徒然地意气消沉也于事无补。
There was little to be gained in growing despondent, however.

不管怎么说，浪费掉那天光仅存的最后几分钟时间就真是太傻了。
In any case, it would have been foolish to waste the few remaining minutes of daylight.

我下坡走回福特车旁，把一些必需品放进一个公文包里。
I walked back down to the Ford where I packed a briefcase with some essential items.

然后用一盏自行车灯把自己武装起来—那盏灯投射出来的光柱居然出人意料地明亮—我就开始寻找一条能让我步行前往那个村庄的道路。
Then, arming myself with a bicycle lamp, which cast a surprisingly good beam, I went in search of a path by which I could descend to the village.

虽然我往山上走了挺长一段距离，已经把那扇栅栏门远远抛在后面了，可我还是找不到这么一条道儿。
But no such path offered itself, though I went some distance up the hill, a good way past my gate.

这时我才感觉到那条路已经不再向上攀升，而是开始朝那个村庄相反的方向缓缓地蜿蜒而下—透过树篱枝叶的缝隙我不时能瞥见那个村庄的灯火—我的心头再次感到一阵灰心丧气。
Then when I sensed that the road had ceased to climb, but was beginning to curve slowly down in a direction away from the village – the lights of which I could glimpse regularly through the foliage – I was overcome again by a sense of discouragement.

事实上，我一度怀疑最好的策略是不是应该重新回到福特车那里，干脆在车里坐等另一位司机开车经过。
In fact, for a moment I wondered if my best strategy would not be to retrace my steps to the Ford and simply sit in it until another motorist came by.

可是到了这个时候，天色几乎已经完全黑了下来，我很清楚，如果在这样的情况下招手去拦截路过的车辆，是很容易会被人误以为拦路抢劫的。
By then, however, it was very close to being dark, and I could see that if one were to attempt to hail a passing vehicle in these circumstances, one might easily be taken for a highwayman or some such.

再者说了，自打我从福特车里出来，还没有一辆车从我身边开过；事实上，打从我离开塔维斯托克以来，我压根就不记得曾经看到过一辆其他的汽车。
Besides, not a single vehicle had passed since I had got out of the Ford; in fact, I could not really remember having seen another vehicle at all since leaving Tavistock.

最后我打定主意，还是回到那扇栅栏门附近，就从那儿走下那个草坡，尽量朝着村里的灯火直线前进，不去管它有没有什么适合行走的道路了。
I resolved then to return as far as the gate, and from there, descend the field, walking in as direct a line as possible towards the lights of the village, regardless of whether or not there was a proper path.

结果我发现，那个斜坡倒并非太过险峻。
It was not, in the end, too arduous a descent.

一片片牧草地，一片紧接着一片，朝着村庄的方向铺展开去，而下坡的时候只要尽量贴着草地的边缘，走起来倒也并不太费力。
A series of grazing fields, one after the next, led the way down to the village and by keeping close to the edge of each field as one descended, one could be ensured of reasonable walking.

只有那么一次，在距离村庄已经很近的地方，我实在找不到一条可以进入下面一片草地的明显通道了，我只得拿着那盏自行车灯来回地探照挡住我去路的灌木树篱。
Only once, with the village very close, could I find no obvious way to gain access to the next field down, and I had to shine my bicycle lamp to and fro along the hedgerow obstructing me.

最后终于被我找到了一个小缺口，我人是可以勉强钻过去，只不过我外套的肩部和裤脚的卷边就得做出点牺牲了。
Eventually, I discovered a small gap through which I proceeded to squeeze my person, but only at some cost to the shoulder of my jacket and the turn-ups of my trousers.

不仅如此，最后那几片草地变得越来越泥泞不堪，我只能故意强忍着不把灯光朝我的鞋子和裤脚上面照，免得自己越发灰心丧气。
The last few fields, furthermore, became increasingly muddy and I deliberately refrained from shining my lamp on to my shoes and turn-ups for fear of further discouragement.

渐渐地，我发现自己终于走上了一条通往村庄的经过铺砌的小路，也正是在沿着这条道路往下走的时候，我碰见了泰勒先生，今晚好心接待我的东道主。
By and by I found myself on a paved path going down into the village, and it was while descending this path that I met Mr Taylor, my kind host of this evening.

他从我前面几码远的一个拐弯处走出来，很有礼貌地等着我赶上他，然后他碰了一下帽檐向我致意，主动问我是否有可以为我效劳之处。
He had emerged out of a turning a few yards in front of me, and had courteously waited for me to catch up, whereupon he had touched his cap and asked if he could be of any assistance to me.

我尽量简明扼要地解释了一下我的处境，补充说明若是承蒙他指点一处不错的旅店，我将不胜感激之至。
I had explained my position as succinctly as possible, adding that I would be most gratified to be guided towards a good inn.

言已至此，泰勒先生不禁摇头道：“本村恐怕没有这样的旅店，先生。
At this, Mr Taylor had shaken his head, saying: ‘I'm afraid there's no inn as such in our village, sir.

约翰·汉弗莱斯先生平常倒是会接待过往的客人入住‘十字钥’的，可是不巧他眼下正在整修旅店的房顶。”
John Humphreys usually takes in travellers at the Crossed Keys, but he's having work done to the roof at the moment.’

不过，还没等这个令人失望的消息发挥其全部的效力，泰勒先生马上就接口说：“如果您不介意稍微将就一点的话，先生，我们可以为您提供一个房间和一个床铺供您过夜。
Before this distressing piece of information could have its full effect, however, Mr Taylor said: ‘If you didn't mind roughing it a little, sir, we could offer you a room and a bed for the night.

没有任何特别之处，不过我老伴儿肯定会负责把一切都收拾得干干净净、舒舒服服的。”
It's nothing special, but the wife will see to it everything's clean and comfortable enough in a basic sort of way.’

我相信自己也客套了几句，或许是颇为言不由衷，大意是我不能这么麻烦他们。
I believe I uttered some words, perhaps in a rather half-hearted way, to the effect that I could not inconvenience them to such an extent.

泰勒先生对此的回答是：“实不相瞒，先生，您若是肯光临寒舍，那将是我们的莫大荣幸。
To which Mr Taylor had said: ‘I tell you, sir, it would be an honour to have you.

我们这个莫斯科姆村可是不大见到像您这样的人物莅临的。
It's not often we get the likes of yourself passing through Moscombe.

而且恕我直言，天都这么晚了，除此以外您恐怕也没别的办法可想了。
And quite honestly, sir, I don't know what else you could do at this hour.

我要是就这么着把您扔在这黑更半夜里不管的话，我老伴儿是绝不会轻饶于我的。”
The wife would never forgive me if I were to let you away into the night.’

我于是恭敬不如从命，就这样接受了泰勒先生和太太的热情招待。
Thus it was that I came to accept the kind hospitality of Mr and Mrs Taylor.

不过我方才说起今晚的经历实在是种“煎熬”时，指的可并非只是汽油耗尽以及来到村里这一路上的狼狈不堪。
But when I spoke earlier of this evening's events being ‘trying’, I was not referring simply to the frustrations of running out of petrol and of having to make such an uncouth journey down into the village.

因为随后发生的事情—在我坐下来和泰勒先生和太太以及他们的邻人共进晚餐以后所发生的一系列事件—以自己的方式证明了它们对我身心的压力可远比之前那单纯的肉体不适繁重得多。
For what occurred subsequently – what unfolded once I sat down to supper with Mr and Mrs Taylor and their neighbours – proved in its own way far more taxing on one's resources than the essentially physical discomforts I had faced earlier.

不瞒您说，等到我终于能够退回到这个房间，可以把时间花在回味达林顿府那些陈年往事上的时候，这真算得上是一种巨大的解脱。
It was, I can assure you, a relief indeed to be able at last to come up to this room and to spend some moments turning over these memories of Darlington Hall from all those years ago.

事实上，近来我变得越来越容易沉湎于这些回忆当中了。
The fact is, I have tended increasingly of late to indulge myself in such recollections.

自打几周前第一次产生了再次见到肯顿小姐的希望之后，我想我已经花费了大量时间用来反复思量我们之间的关系为什么会经历了那样的变化。经过多年的共事，我们之间已经稳定地确立起一种良好的工作互信，可是在一九三五或是一九三六年，这种关系却产生了确确实实的转变。
And ever since the prospect of seeing Miss Kenton again first arose some weeks ago, I suppose I have tended to spend much time pondering just why it was our relationship underwent such a change. For change it certainly did, around 1935 or 1936, after many years in which we had steadily achieved a fine professional understanding.

实际上，到了最后，我们就连每天的工作结束后一起喝杯可可、聊聊天的例行性会面都放弃了。
In fact, by the end, we had even abandoned our routine of meeting over a cup of cocoa at the end of each day.

可是引起这种改变的到底是什么，究竟哪一串具体的事件真正要为此负责呢？我始终都没办法完全确定。
But as to what really caused such changes, just what particular chain of events was really responsible, I have never quite been able to decide.

近来在反复琢磨的时候，我觉得那天傍晚肯顿小姐不请自来、发生在我的餐具室里的那个奇怪的小插曲有可能就是个关键的转折点。
In thinking about this recently, it seems possible that that odd incident the evening Miss Kenton came into my pantry uninvited may have marked a crucial turning point.

她为什么要到我的餐具室里来，我已经记不真切了。
Why it was she came to my pantry I cannot remember with certainty.

感觉上她可能是捧了一瓶花来使“餐具室显得明亮一点”，可是这么一来，我可能又把它跟多年前我们刚开始共事时她那次同样的举动给搞混了。
I have a feeling she may have come bearing a vase of flowers ‘to brighten things up’, but then again, I may be getting confused with the time she attempted the same thing years earlier at the start of our acquaintanceship.

我确实记得在这些年间，她至少有三次试图把鲜花带进我的餐具室，不过也许真是我记混了，认定这就是那个特别的傍晚她来找我的原因。
I know for a fact she tried to introduce flowers to my pantry on at least three occasions over the years, but perhaps I am confused in believing this to have been what brought her that particular evening.

可是无论如何，我都想特别强调一下，尽管这些年来我们的工作关系都很融洽，我却从来也没有放任到允许女管家可以成天随意进出我的餐具室的程度。
I might emphasize, in any case, that notwithstanding our years of good working relations, I had never allowed the situation to slip to one in which the housekeeper was coming and going from my pantry all day.

管家的餐具室，至少在我看来，是个办公要地，是家务运营的心脏，在性质上并不亚于一场战役当中的司令部，所以，在这其中的大小物件，每一样都必须完完全全依照我的意愿摆放得井井有条—并且要维持原样—这是绝对不能含糊的。
The butler's pantry, as far as I am concerned, is a crucial office, the heart of the house's operations, not unlike a general's headquarters during a battle, and it is imperative that all things in it are ordered – and left ordered – in precisely the way I wish them to be.

我可不是允许各色人等进进出出、又是质询又是聒噪抱怨个没完的那种管家。
I have never been that sort of butler who allows all sorts of people to wander in and out with their queries and grumbles.

如果想要一切事务都能顺畅协调地得以施行，管家的餐具室就一定得确保私密和清静，这是显而易见、毋庸置疑的。
If operations are to be conducted in a smoothly co-ordinated way, it is surely obvious that the butler's pantry must be the one place in the house where privacy and solitude are guaranteed.

事有凑巧，那天傍晚她进入我的餐具室的时候，我其实并没有在处理公事。
As it happened, when she entered my pantry that evening, I was not in fact engaged in professional matters.

也就是说，那时正是一天的工作临近尾声，那个礼拜又碰巧风平浪静，因此我也难得地享受到一个钟头左右的闲暇时间。
That is to say, it was towards the end of the day during a quiet week and I had been enjoying a rare hour or so off duty.

前面已经说过，我已经不太确定肯顿小姐是不是捧着一瓶花进来的了，不过我确实记得她是这样说的：
As I say, I am not certain if Miss Kenton entered with her vase of flowers, but I certainly do recall her saying:

“史蒂文斯先生，您的房间在晚上显得甚至比白天还要令人不快。
‘Mr Stevens, your room looks even less accommodating at night than it does in the day.

那个电灯泡太暗了，肯定是不适合用来阅读的。”
The electric bulb is too dim, surely, for you to be reading by.’

“它完全合乎需要，谢谢您，肯顿小姐。”
‘It is perfectly adequate, thank you, Miss Kenton.’

“说真的，史蒂文斯先生，这个房间活像个囚室。
‘Really, Mr Stevens, this room resembles a prison cell.

只需要在墙角摆上一张小床，就完全想象得出那死刑犯在这儿度过最后几个钟头时光的情景。”
All one needs is a small bed in the corner and one could well imagine condemned men spending their last hours here.’

也许对此我也说过一句什么，我不记得了。
Perhaps I said something to this, I do not know.

总之，我的目光并没有离开面前的书本，时间一分一秒地过去，我正等着肯顿小姐告退然后离开呢，却不料突然听到她说：
In any case, I did not look up from my reading, and a few moments passed during which I waited for Miss Kenton to excuse herself and leave. But then I heard her say:

“现在我很好奇您到底在读什么呢，史蒂文斯先生。”
‘Now I wonder what it could be you are reading there, Mr Stevens.’

“不过一本书而已，肯顿小姐。”
‘Simply a book, Miss Kenton.’

“这个我看得出来，史蒂文斯先生。
‘I can see that, Mr Stevens.

可到底是本什么书呢—这才是让我大感兴趣的。”
But what sort of book – that is what interests me.’

我一抬头，发现肯顿小姐正朝着我走过来。
I looked up to see Miss Kenton advancing towards me.

我把书一合，把它紧紧地抓在手里、贴在胸口，站起身来。
I shut the book, and clutching it to my person, rose to my feet.

“说真的，肯顿小姐，”我说，“我必须要请您尊重我的隐私。”
‘Really, Miss Kenton,’ I said, ‘I must ask you to respect my privacy.’

“可是你为什么要对自己读的书感到这么难为情呢，史蒂文斯先生？
‘But why are you so shy about your book, Mr Stevens?

我相当怀疑这可能是本相当下流的书呢。”
I rather suspect it may be something rather racy.’

“这是绝不可能的，肯顿小姐，爵爷的书架上面是没有一本你所谓的‘下流’的书的。”
‘It is quite out of the question, Miss Kenton, that anything “racy”, as you put it, should be found on his lordship's shelves.’

“我曾听说很多学术性的书籍当中都包含最下流的段落，可我从来都没有胆量去找找看。
‘I have heard it said that many learned books contain the most racy of passages, but I have never had the nerve to look.

好了，史蒂文斯先生，请你务必让我看看你在读的到底是本什么书。”
Now, Mr Stevens, do please allow me to see what it is you are reading.’

“肯顿小姐，我必须要请您不要再纠缠我了。
‘Miss Kenton, I must ask you to leave me alone.

我难得有这么点属于自己的空闲时间，而您却非要这样胡搅蛮缠，这真是让人难以忍受。”
It is quite impossible that you should persist in pursuing me like this during the very few moments of spare time I have to myself.’

可是肯顿小姐却继续向我走来，我必须承认，在这种情况下最好以什么样的举动来应对还真是有点难以确定。
But Miss Kenton was continuing to advance and I must say it was a little difficult to assess what my best course of action would be.

我曾想到过干脆把书往桌子的抽屉里一扔，然后把抽屉锁上，不过这未免有些过于戏剧化了。
I was tempted to thrust the book into the drawer of my desk and lock it, but this seemed absurdly dramatic.

我只能往后退了几步，那本书仍紧贴在我胸口上。
I took a few paces back, the book still held to my chest.

“请让我看看你抱在怀里的到底是本什么书，史蒂文斯先生，”肯顿小姐道，继续步步紧逼，“看过以后我就不再打搅你，让你尽管去享受阅读的乐趣了。
‘Please show me the volume you are holding, Mr Stevens,’ Miss Kenton said, continuing her advance, ‘and I will leave you to the pleasures of your reading.

这到底是本什么书啊，为什么你这么着急上火地要去藏藏掖掖呢？”
What on earth can it be you are so anxious to hide?’

“肯顿小姐，您是否发现了这到底是本什么书，其实对我来说根本就无所谓。
‘Miss Kenton, whether or not you discover the title of this volume is in itself not of the slightest importance to me.

可是就原则而论，我反对您就这么不请自来，并且侵犯我的私人时间。”
But as a matter of principle, I object to your appearing like this and invading my private moments.’

“我很好奇，这到底是一本完全高尚的书呢，史蒂文斯先生，还是你其实是在保护我，以免我受到它可怕的影响呢？”
‘I wonder, is it a perfectly respectable volume, Mr Stevens, or are you in fact protecting me from its shocking influences?’

这时她已经站到了我面前，而突然间，气氛发生了奇怪的变化—就仿佛我们俩一下子一起被推到了另一个时空当中。
Then she was standing before me, and suddenly the atmosphere underwent a peculiar change – almost as though the two of us had been suddenly thrust on to some other plane of being altogether.

恐怕我也很难把我的意思完全解释清楚。
I am afraid it is not easy to describe clearly what I mean here.

我所能说的只是，我们周围的一切突然间变得完全凝固了；在我的印象中，肯顿小姐的态度也发生了突然的变化；她的表情奇怪地严肃了起来，我猛然间感觉她几乎像是被吓到了。
All I can say is that everything around us suddenly became very still; it was my impression that Miss Kenton's manner also underwent a sudden change; there was a strange seriousness in her expression, and it struck me she seemed almost frightened.

“请让我看看你的书，史蒂文斯先生。”
‘Please, Mr Stevens, let me see your book.’

她伸出手，开始轻轻地把我手里的那本书往外抽。
She reached forward and began gently to release the volume from my grasp.

我感觉在她这样做时我最好还是把目光从她身上避开，可是她人靠我这么近，要想做到这一点，就只能把我的脑袋扭到一个很不自然的角度。
I judged it best to look away while she did so, but with her person positioned so closely, this could only be achieved by my twisting my head away at a somewhat unnatural angle.

肯顿小姐继续非常轻柔地掰开我握着那本书的手指，简直可以说是一根手指掰开以后再去掰另一根手指。
Miss Kenton continued very gently to prise the book away, practically one finger at a time.

这个过程似乎持续了很长的时间—在此期间我一直都尽量保持着那个很不自然的姿态—一直到我听到她说：
The process seemed to take a very long time – throughout which I managed to maintain my posture – until I finally heard her say:

“天哪，史蒂文斯先生，这根本就不是什么见不得人的书嘛。
‘Good gracious, Mr Stevens, it isn't anything so scandalous at all.

只不过是个感伤的爱情故事。”
Simply a sentimental love story.’

我相信，大概正是在这个时候，我决定无须再忍耐下去了。
I believe it was around this point that I decided there was no need to tolerate any more.

我不记得当时我所说的具体字句了，不过我记得我相当坚决地将肯顿小姐请出了我的餐具室，这个小插曲也就此告一段落。
I cannot recall precisely what I said, but I remember showing Miss Kenton out of my pantry quite firmly and the episode was thus brought to a close.

我想，我应该就这个小插曲所实际涉及的那本书的情况再多说两句。
I suppose I should add a few words here concerning the matter of the actual volume around which this small episode revolved.

那本书确实可以被描述为一部“感伤的罗曼司”—有不少这类小说摆放在藏书室里，也放在几间客房里，主要是供女客们消遣之用。
The book was, true enough, what might be described as a ‘sentimental romance’ – one of a number kept in the library, and also in several of the guest bedrooms, for the entertainment of lady visitors.

而我之所以会选择阅读此类作品，有一个很简单的原因；这是一种维持并且提高自己对于英语这门语言的掌握程度的极为有效的方法。
There was a simple reason for my having taken to perusing such works; it was an extremely efficient way to maintain and develop one's command of the English language.

我个人认为—不知道您是否同意—就我们这一代管家而言，都一直过于强调高雅的口音和对语言的掌握在专业期许方面的地位；我的意思是说，有时候这些因素被强调得过了头，甚至不惜以牺牲更为重要的专业素质为代价。
It is my view – I do not know if you will agree – that in so far as our generation is concerned, there has been too much stress placed on the professional desirability of good accent and command of language; that is to say, these elements have been stressed sometimes at the cost of more important professional qualities.

尽管如此，我从来也没有否认优雅的口音和对语言的熟练掌握自是一种极有魅力的特质，而且一直都认为，尽我所能地发展自己在这方面的能力也是我分内的职责。
For all that, it has never been my position that good accent and command of language are not attractive attributes, and I always considered it my duty to develop them as best I could.

而最直接有效的一种方法就是在零碎的空余时间里尽可能多读上几页文辞优美的书籍。
One straightforward means of going about this is simply to read a few pages of a well-written book during odd spare moments one may have.

这就是我多年以来一直采取的策略方法，而我之所以经常选择肯顿小姐那天傍晚发现我在看的那类作品，只是因为其中那众多措辞优雅的对话对我具有极大的实用价值。
This had been my own policy for some years, and I often tended to choose the sort of volume Miss Kenton had found me reading that evening simply because such works tend to be written in good English, with plenty of elegant dialogue of much practical value to me.

换了一本分量更重的书籍—比如说一本学术专著—虽然总体来说更有提高自身修养的价值，但它更倾向于大量使用学术术语，这对于我在跟绅士淑女们日常交流过程中起到的作用反而非常有限。
A weightier book – a scholarly study, say – while it might have been more generally improving would have tended to be couched in terms likely to be of more limited use in the course of one's normal intercourse with ladies and gentlemen.

我极少有时间或者意愿把任何一本这类的罗曼司从头到尾读一遍，就我的认识，它们的情节全都甚为荒唐可笑—确实够得上感伤已极—若非因为前面提到的那些益处，我是一分一秒的时间都不愿意浪费在它们身上的。
I rarely had the time or the desire to read any of these romances cover to cover, but so far as I could tell, their plots were invariably absurd – indeed, sentimental – and I would not have wasted one moment on them were it not for these aforementioned benefits.

不过话虽如此，如今我也不介意坦白承认—我并不觉得这其中有任何应该感到羞愧的地方—从这些故事当中我有时候也确实能得到一些附带的乐趣。
Having said that, however, I do not mind confessing today – and I see nothing to be ashamed of in this – that I did at times gain a sort of incidental enjoyment from these stories.

或许当初我不太愿意承认这一点，不过就像我说过的，这有什么好自感羞愧的呢？
I did not perhaps acknowledge this to myself at the time, but as I say, what shame is there in it?

一个人为什么就不该放松心情，去享受那些绅士淑女陷入爱河的故事之乐呢？况且他们之间又是以最为优雅的遣词造句去尽情倾诉爱慕之情的。
Why should one not enjoy in a light-hearted sort of way stories of ladies and gentlemen who fall in love and express their feelings for each other, often in the most elegant phrases?

不过我这么说并非是想暗示那天傍晚我处理这件事的方式有欠妥当。
But when I say this, I do not mean to imply the stance I took over the matter of the book that evening was somehow unwarranted.

因为您必须理解，问题在于这牵涉到一个重要的原则。
For you must understand, there was an important principle at issue.

事实上，在肯顿小姐长驱直入我的餐具室的那一刻，我已经“下班”了。
The fact was, I had been ‘off duty’ at that moment Miss Kenton had come marching into my pantry.

当然，任何一位以其职业为荣的管家，任何一位矢志于追求海斯协会所谓“与其职位相称之尊严”的管家，在面对他人时是决不会允许自己“下班”的。
And of course, any butler who regards his vocation with pride, any butler who aspires at all to a ‘dignity in keeping with his position’, as the Hayes Society once put it, should never allow himself to be ‘off duty’ in the presence of others.

所以在那一刻走进来的到底是肯顿小姐还是一个完全的陌生人，都是无关紧要的。
It really was immaterial whether it was Miss Kenton or a complete stranger who had walked in at that moment.

任何一位具有专业素养的管家在别人面前都必须完全彻底地活在自己的角色中；他一刻都不能被人看到自己一会儿将这个角色抛到一边，一会儿又披挂整齐，就仿佛那职位不过是哑剧演员的一件戏服而已。
A butler of any quality must be seen to inhabit his role, utterly and fully; he cannot be seen casting it aside one moment simply to don it again the next as though it were nothing more than a pantomime costume.

只有在唯一的一种情况之下，一位注重其尊严的管家可以随意地卸下他的职业角色；那就是在他完全独处的时刻。
There is one situation and one situation only in which a butler who cares about his dignity may feel free to unburden himself of his role; that is to say, when he is entirely alone.

如此说来，您也就可以理解，肯顿小姐在我不无道理地认定自己是独自一人的时刻硬闯了进来，这件事也就成了一个至关重要的原则性问题、一个的的确确关乎尊严的问题了，因为我在任何人面前都不得有一丝一毫不符合我的角色设定的表现。
You will appreciate then that in the event of Miss Kenton bursting in at a time when I had presumed, not unreasonably, that I was to be alone, it came to be a crucial matter of principle, a matter indeed of dignity, that I did not appear in anything less than my full and proper role.

不过，我的本意并非是想在此分析多年前这个小插曲的不同方面。
However, it had not been my intention to analyse here the various facets of this small episode from years ago.

而重点是这件事使我警觉到肯顿小姐和我之间的关系已经发展到了—无疑是经过了很多个月的渐进过程—一种很不合适的状态。
The main point about it was that it alerted me to the fact that things between Miss Kenton and myself had reached – no doubt after a gradual process of many months – an inappropriate footing.

她居然会有那天傍晚如此这般的举动，这个事实本身就等于是敲响了警钟，我在把她送出餐具室、稍稍集中了一下思想以后，我记得我就决定要着手在一个更为适当的基础上来重建我们的工作关系。
The fact that she could behave as she had done that evening was rather alarming, and after I had seen her out of my pantry, and had had a chance to gather my thoughts a little, I recall resolving to set about re-establishing our professional relationship on a more proper basis.

不过至于说到那一事件对于那以后我们之间的关系所经历的巨大变化究竟有多大的影响，那就很难说得清了。
But as to just how much that incident contributed to the large changes our relationship subsequently underwent, it is very difficult now to say.

或许还有其他更加根本性的事态发展导致了最后的结果。
There may well have been other more fundamental developments to account for what took place.

比如，肯顿小姐的休假问题。
Such as, for instance, the matter of Miss Kenton's days off.

自从来到达林顿府工作，直到餐具室那一事件发生前大约一个月，肯顿小姐的休假安排一直都遵循着一个可以预期的模式。
From the time she arrived at Darlington Hall right up until perhaps a month or so before that incident in my pantry, Miss Kenton's days off had followed a predictable pattern.

每过六个星期她会休两天的假，去南安普敦看望她姨妈；要不然就学我的样，不会真正去休假，除非有段时间特别平静无事，在这种情况下，她会整天都在庭院里四处逛逛，或者就在她的起坐间里看看书。
She would, once every six weeks, take two days off to visit her aunt in Southampton; otherwise, following my own example, she would not really take days off as such unless we were going through a particularly quiet time, in which case she might spend a day strolling around the grounds and doing a little reading in her parlour.

可是到了我说的那个时候，这种模式也起了变化。
But then, as I say, the pattern changed.

她突然开始充分利用合同上规定的休息时间，经常一大早就不见了人影，除了当晚预计返回的时间以外，别的信息一概不留。
She began suddenly to take full advantage of her contracted time off, disappearing regularly from the house from early in the morning, leaving no information other than the hour she might be expected back that night.

当然了，她从来没有超出她应该享有的休息时限，所以我觉得再去询问她这些外出的详细情况也并不合适。
Of course, she never took more time than her entitlement, and thus I felt it improper to inquire further concerning these outings of hers.

不过我想她的这种改变确实使我有些心绪不宁，因为我记得自己曾跟詹姆斯·钱伯斯爵士的贴身男仆兼管家格雷厄姆先生提起过此事—他真是一位极好的同行，可是顺便提一句，我现在已经跟他失去了联系—就在他随主人定期造访达林顿府的某天晚上，我们围炉谈心的时候。
But I suppose this change did perturb me somewhat, for I remember mentioning it to Mr Graham, valet-butler to Sir James Chambers – a good colleague who, incidentally, I seem now to have lost touch with – as we sat talking by the fire one night during one of his regular visits to Darlington Hall.

其实，我不过就说了句我们的女管家情绪“近来有些阴晴不定”，所以颇有些惊讶于格雷厄姆先生闻言居然点了点头，探身挨近我，以一种心照不宣的语气对我说：
In fact, all I had said was something to the effect that the housekeeper had been ‘a little moody of late’ and so had been rather surprised when Mr Graham nodded, leaned towards me and said knowingly:

“我早就料到了，只是不知道还有多长时间。”
‘I’d been wondering how much longer it would be.’

我问他这话到底什么意思，格雷厄姆先生继续道：“你们的肯顿小姐呀。
When I asked him what he meant, Mr Graham went on: ‘Your Miss Kenton.

她今年多大年纪了？
I believe she's now what?

三十三？
Thirty-three?

三十四？
Thirty-four?

已经错过了做母亲的最佳年龄，不过还不算太晚。”
Missed out on the best of her mothering years, but it's not too late yet.’

“肯顿小姐，”我向他保证，“可是位恪尽职守的职业女性。
‘Miss Kenton’, I assured him, ‘is a devoted professional.

我碰巧知道，她根本就无意于组建家庭。”
I happen to know for a fact that she has no wish for a family.’

可是格雷厄姆先生却面带微笑摇了摇头道：“如果一个女管家告诉你她不想组建家庭，你可千万不可信以为真。
But Mr Graham had smiled and shook his head, saying: ‘Never believe a housekeeper who tells you she doesn't want a family.

说起来了，史蒂文斯先生，咱们就坐在这里掰着指头数一下，至少得有十多位女管家都信誓旦旦地这么宣称过，结果还不是嫁了人，离开了我们这一行。”
Indeed, Mr Stevens, I should think you and I could sit here now and count up at least a dozen between us that once said as much, then got married and left the profession.’

我记得那天傍晚我还颇有自信地对格雷厄姆先生的理论置之不理，可打那以后，我必须承认，我就发现自己很难摆脱肯顿小姐这些神秘外出可能是去会一位追求者这样的想法。
I recall I dismissed Mr Graham's theory with some confidence that evening, but thereafter, I must admit, I found it hard to keep out of my mind the possibility that the purpose of these mysterious outings of Miss Kenton was to meet a suitor.

这的确是个令人颇为困扰的念头，因为不难看出，肯顿小姐的离开将是我们工作上相当重大的损失，一个达林顿府将很难从中恢复过来的重大损失。
This was indeed a disturbing notion, for it was not hard to see that Miss Kenton's departure would constitute a professional loss of some magnitude, a loss Darlington Hall would have some difficulty recovering from.

而且，我不得不承认，颇有些其他的小征兆看来也在支持格雷厄姆先生的理论。
Furthermore, I was obliged to recognize certain other little signs which tended to support Mr Graham's theory.

比方说，收取信件一直都是我的一项职责，我忍不住注意到肯顿小姐已经开始相当规律地收到—大约每周一次—同一位通信者的来信，而且这些信件上盖的都是本地的邮戳。
For instance, the collection of mail being one of my duties, I could not help noticing that Miss Kenton had started to get letters on a fairly regular basis – once a week or so – from the same correspondent, and that these letters bore a local postmark.

在此我或许应该指出的一点是，这样的变化我几乎是不可能注意不到的，因为此前她在达林顿府里这么多年间本来是极少收到信件的。
I should perhaps point out here that it would have been well nigh impossible for me not to have noticed such things, given that throughout all her preceding years at the house, she had received very few letters indeed.

此外，还有其他一些隐微的迹象也在支持格雷厄姆先生的观点。
Then there were other more nebulous signs to support Mr Graham's view.

比方说，虽然她继续以一贯的全副勤勉态度履行其职责，她的情绪总的来说却变得有些阴晴不定，这是我迄今为止从未有见到过的。
For instance, although she continued to discharge her professional duties with all her usual diligence, her general mood tended to undergo swings of a sort I had hitherto never witnessed.

而事实上，当她一连好几天情绪特别高涨的时候—而且没有任何明显的理由—几乎就跟她经常性地突然陷入长时间的郁郁寡欢同样让我备感困扰。
In fact the times when she became extremely cheerful for days on end – and for no observable reason – were almost as disturbing to me as her sudden, often prolonged sullen spells.

如我所说，她自始至终都保持着绝对的专业态度，可话又说回来了，为达林顿府的长远利益着想是我的职责，如果这些迹象果如格雷厄姆先生所言，预示着肯顿小姐正考虑为了爱情的缘故离开工作岗位，我自然是有责任就此事做些进一步的探究的。
As I say, she remained utterly professional throughout it all, but then again, it was my duty to think about the welfare of the house in the long term, and if indeed these signs tended to support Mr Graham's notion that Miss Kenton was contemplating departing for romantic purposes, I clearly had a responsibility to probe the matter further.

于是在某个我们惯常碰面一起喝杯热可可的傍晚，我就不揣冒昧把问题提了出来：
I did then venture to ask her one evening during one of our sessions over cocoa:

“您礼拜四还要外出吗，肯顿小姐？
‘And will you be going off again on Thursday, Miss Kenton?

我是说您休假的那天。”
On your day off, I mean.’

我原以为我这么问她，她多半是要生气的，可是恰恰相反，她简直就像是好长时间以来一直都在等着提出这个话题的机会似的。
I had half expected her to be angry at this inquiry, but on the contrary, it was almost as though she had been long awaiting an opportunity to raise the very topic.

因为她以几分如释重负的口气说：
For she said in something of a relieved way:

“哦，史蒂文斯先生，那不过是之前我在格兰切斯特宅工作时认识的一个人。
‘Oh, Mr Stevens, it's just someone I knew once when I was at Granchester Lodge.

事实上，他当时是那座宅子的管家，不过他现在已经完全离开了这一行，受雇于附近的一家商号。
As a matter of fact, he was the butler there at the time, but now he's left service altogether and is employed by a business near by.

他不知怎的得知了我在这里工作，就开始给我写信，建议我们重续旧交。
He somehow learnt of my being here and started writing to me, suggesting we renew our acquaintance.

史蒂文斯先生，长话短说就是这么回事。”
And that, Mr Stevens, is really the long and short of it.’

“我明白了，肯顿小姐。
‘I see, Miss Kenton.

偶尔离开这儿出去走走确实也能让人感觉身心舒畅。”
No doubt, it is refreshing to leave the house at times.’

“我发现正是如此，史蒂文斯先生。”
‘I find it so, Mr Stevens.’

出现了一阵短暂的沉默。
There was a short silence.

然后肯顿小姐像是下定了决心，继续道：
Then Miss Kenton appeared to make some decision and went on:

“说起我的这位旧相识。
‘This acquaintance of mine.

我记得他在格兰切斯特宅做管家的时候，他可真是壮志凌云。
I remember when he was butler at Granchester Lodge, he was full of the most marvellous ambitions.

事实上，我想他的终极梦想就是成为像达林顿府这样的豪门巨室的管家。
In fact, I imagine his ultimate dream would have been to become butler of a house like this one.

哦，可我现在一想起他当初的那些管理方法！
Oh, but when I think now of some of his methods!

说真的，史蒂文斯先生，如果您现在看到他那些做法的话，我能想象得出您会有什么样的表情。
Really, Mr Stevens, I can just imagine your face if you were to be confronted by them now.

也真是难怪他壮志难酬了。”
It really is no wonder his ambitions remained unfulfilled.’

我轻轻一笑。
I gave a small laugh.

“以我的经验，”我说，“有太多的人相信自己有能力在更高等级的岗位上工作，对于这更高的岗位所要求的素质却又没有丝毫的概念。
‘In my experience,’ I said, ‘too many people believe themselves capable of working at these higher levels without having the least idea of the exacting demands involved.

这样的工作肯定不是任何人都干得了的。”
It is certainly not suited to just anybody.’

“这话说得是。
‘So true.

史蒂文斯先生，如果您当初就有机会对他做出观察的话，真不知道您到底会怎么说！”
Really, Mr Stevens, what would you have said if you had observed him in those days!’

“干我们这一行的，肯顿小姐，到了这样的级别以后，就真不是每个人都能胜任的了。
‘At these sorts of levels, Miss Kenton, the profession isn't for everybody.

心怀凌云壮志自是容易，可是如果不具备特定的素质，一个做管家的到了一定的层次以后就真是再难有所进境了。”
It is easy enough to have lofty ambitions, but without certain qualities, a butler will simply not progress beyond a certain point.’

肯顿小姐像是对这番话默想了片刻，然后道：
Miss Kenton seemed to ponder this for a moment, then said:

“我突然想到，您肯定已经心满意足了吧，史蒂文斯先生。
‘It occurs to me you must be a well-contented man, Mr Stevens.

毕竟，您看，您已经处在了事业的顶峰，对于这个领域的方方面面，无不尽在您的掌握之中。
Here you are, after all, at the top of your profession, every aspect of your domain well under control.

我真是无法想象您还会有什么样的人生目标。”
I really cannot imagine what more you might wish for in life.’

我一时还真想不出对此该如何回应。
I could think of no immediate response to this.

在继之而起的一阵略显尴尬的沉默当中，肯顿小姐把目光转向手里盛热可可的杯子的底部，就好像被她在那里发现的某样东西给吸引住了。
In the slightly awkward silence that ensued, Miss Kenton turned her gaze down into the depths of her cocoa cup as if she had become engrossed by something she had noticed there.

最后，在经过一番考虑之后，我说：
In the end, after some consideration, I said:

“就我而言，肯顿小姐，我得一直等到尽我之所能协助爵爷把他为自己设定的那些伟大的任务统统完成以后，我的职业才能算得上是圆满了。
‘As far as I am concerned, Miss Kenton, my vocation will not be fulfilled until I have done all I can to see his lordship through the great tasks he has set himself.

爵爷的工作大功告成之日，到他对自己已经取得的荣誉终于感到满足了，到他满意地知道他已经做到了每个人对他提出的所有的合理要求以后，只有到了那一天，肯顿小姐，我才能够自称为，如您所言，一个心满意足之人。”
The day his lordship's work is complete, the day be is able to rest on his laurels, content in the knowledge that he has done all anyone could ever reasonably ask of him, only on that day, Miss Kenton, will I be able to call myself, as you put it, a well-contented man.’

她可能对我的这番话感到了一丝困惑；或者也许是其中有些地方让她感到了不快。
She may have been a little puzzled by my words; or perhaps it was that they had for some reason displeased her.

总之，她的情绪似乎就是在那一刻发生了改变，我们之间的谈话马上就丧失了一开始那种相当私人化的基调。
In any case, her mood seemed to change at that point, and our conversation rapidly lost the rather personal tone it had begun to adopt.

就在那次谈话以后不久，我们在她的起坐间里举行的这些热可可聚谈便无疾而终了。
It was not so long afterwards that these meetings over cocoa in her parlour came to an end.

事实上，我清楚地记得我们最后那次以这种方式进行的聚谈；我本来是希望跟肯顿小姐商量一下一桩即将到来的社交盛会的安排—苏格兰的一群名流显贵将来此举行一次周末聚会。
In fact, I recall quite clearly the very last time we met like that; I was wishing to discuss with Miss Kenton a forthcoming event – a weekend gathering of distinguished persons from Scotland.

事实上，那个活动尚有一个月左右的时间才会举行，不过对于盛大活动的具体安排及早进行讨论一直就是我们的习惯。
It is true the event was still a month or so away, but then it had always been our habit to talk over such events from an early stage.

就在那天傍晚，对于那次活动的方方面面我已经径自谈论了有一会儿了，这才意识到肯顿小姐一直都没怎么表态；又过了一段时间，我已经清楚地发现她的心思其实完全就不在这上头。
On this particular evening, I had been discussing various aspects of it for a little while when I realized Miss Kenton was contributing very little; indeed, after a time, it became perfectly obvious her thoughts were somewhere else altogether.

我有几次还特地问她：“您在听我说话吗，肯顿小姐？”尤其是在我针对某一点说了一大段话以后，虽然经我这么一问以后，她每次都会变得稍稍警醒一点，可是不出几秒钟，我就看得出来她已经又神游天外了。
I did on a few occasions say things like: ‘Are you with me, Miss Kenton?’ particularly if I had been making a lengthy point, and though whenever I did so she would become a little more alert, within seconds I could see her attention drifting again.

在我滔滔不绝地讲了好几分钟以后，她唯一的反应也不过就是回一句类似“当然，史蒂文斯先生”，或者“我非常同意，史蒂文斯先生”这样的话。最后我终于对她说：
After several minutes of my talking and her contributing only statements such as, ‘Of course, Mr Stevens,’ or, ‘I quite agree, Mr Stevens,’ I finally said to her:

“很抱歉，肯顿小姐，不过我看我们再继续下去也没什么意思了。
‘I am sorry, Miss Kenton, but I see little point in our continuing.

您像是根本就不觉得这次讨论有什么重要的。”
You simply do not seem to appreciate the importance of this discussion.’

“很抱歉，史蒂文斯先生，”她说，稍稍坐直了身子。
‘I'm sorry, Mr Stevens,’ she said, sitting up a little.

“只是因为我今晚真的有点累了。”
‘It's simply that I'm rather tired this evening.’

“您现在越来越容易累了，肯顿小姐。
‘You are increasingly tired now, Miss Kenton.

在过去您可是从来不需要求助于这样的借口的。”
It used not to be an excuse you needed to resort to.’

让我吃惊的是，肯顿小姐突然勃然变色道：
To my astonishment, Miss Kenton responded to this in a sudden burst:

“史蒂文斯先生，我这个礼拜都忙得不可开交。
‘Mr Stevens, I have had a very busy week.

我已经很累了。
I am very tired.

事实上，三四个钟头以前我就希望赶快上床休息了。
In fact, I have been wishing for my bed for the last three or four hours.

我真是非常、非常累了，史蒂文斯先生，难道您一点都看不出来吗？”
I am very, very tired, Mr Stevens, can you not appreciate that?’

我原本也没有期望她会为一直都心不在焉而向我道歉的，可是这个回答之强硬，我必须说，还是让我有点吃惊。
It is not as though I had expected an apology from her, but the stridency of this reply did, I must say, take me aback a little.

不过，我决定还是不跟她卷入一场无谓的争执，我刻意停顿了好一会儿以后，这才心平气和地道：
However, I decided not to get drawn into an unseemly argument with her and made sure to pause for a telling moment or two before saying quite calmly:

“如果您的感受是这样的话，肯顿小姐，那我们也就根本无须再继续这些晚上的碰面了。
‘If that is how you feel about it, Miss Kenton, there is no need at all for us to continue with these evening meetings.

我很抱歉，我居然一直都没有觉察到这样的碰面给您造成了这么大的不便。”
I am sorry that all this time I had no idea of the extent to which they were inconveniencing you.’

“史蒂文斯先生，我只是说我今天晚上很累……”
‘Mr Stevens, I merely said that I was tired tonight …’

“不，不，肯顿小姐，这是完全可以理解的。
‘No, no, Miss Kenton, it's perfectly understandable.

您本来就工作繁忙，这些碰面等于又给您增加了不必要的负担。
You have a busy life, and these meetings are a quite unnecessary addition to your burden.

即便是不以这种方式每天碰面，也还有很多其他的方法可以保证在我们之间实现工作层面上的必要沟通。”
There are many alternative options for achieving the level of professional communication necessary without our meeting on this basis.’

“史蒂文斯先生，实在没这个必要。
‘Mr Stevens, this is quite unnecessary.

我只是说……”
I merely said …’

“我是认真的，肯顿小姐。
‘I mean it, Miss Kenton.

事实上，已经有一段时间，我一直都在考虑是不是还要继续这样的碰面，既然它们平白又延长了我们本已经非常忙碌的日常工作。
In fact, I had been wondering for some time if we should not discontinue these meetings, given how they prolong our already very busy days.

我们每天在您这儿碰面晤谈的方式虽已延续了多年，但这一事实本身并不成其为我们就不该寻求一种更方便的安排方式的理由。”
The fact that we have met here now for years is no reason in itself why we should not seek a more convenient arrangement from here on.’

“史蒂文斯先生，请别这样，我相信这些碰面还是非常有用的……”
‘Mr Stevens, please, I believe these meetings are very useful …’

“可是它们给您带来了不便啊，肯顿小姐。
‘But they are inconvenient for you, Miss Kenton.

它们使您精疲力竭。
They tire you out.

请容我建议，从今往后，我们就只在正常的工作时间内找些空当来沟通重要的信息。
May I suggest that from now on, we simply make a special point of communicating important information during the course of the normal working day.

万一不能及时地找到对方，我建议我们写个字条留在对方的房门上。
Should we not be able to find each other readily, I suggest we leave written messages at one another's doors.

在我看来这不失为一种完善的解决办法。
That seems to me a perfectly fine solution.

好了，肯顿小姐，很抱歉耽误了您这么长时间。
Now, Miss Kenton, I apologize for keeping you up so long.

非常感谢您的热可可。”
Thank you very kindly for the cocoa.’

自然—我又何必不肯承认呢？—我偶尔也会暗自思忖，如果对于我们晚间的晤谈问题我的态度不是如此决绝的话—也就是说，如果在那以后的几个星期里，面对肯顿小姐好几次恢复晚间晤谈的建议，我的态度肯于软化的话，长远看来事态的发展究竟会是怎么样的。
Naturally – and why should I not admit this? – I have occasionally wondered to myself how things might have turned out in the long run had I not been so determined over the issue of our evening meetings; that is to say, had I relented on those several occasions over the weeks that followed when Miss Kenton suggested we reinstitute them.

直到现在我才开始考虑这个问题，是因为有鉴于此后事态的发展，我很有理由认为当初我在一劳永逸地决定终止那些晚间碰头的例会之时，我也许并没有完全意识到我的所作所为可能带来的全部影响。
I only speculate over this now because in the light of subsequent events, it could well be argued that in making my decision to end those evening meetings once and for all, I was perhaps not entirely aware of the full implications of what I was doing.

的确，甚至可以说我的这个小小的决定竟在某种程度上成为一个关键的转折点；我的这一决定使得事态的发展无可避免地迈向了最终的结果。
Indeed, it might even be said that this small decision of mine constituted something of a key turning point; that the decision set things on an inevitable course towards what eventually happened.

不过话又说回来了，人一旦凭借着后见之明，开始在自己的过去当中找寻类似的“转折点”，我想就常常会开始觉得它们无处不在了。
But then, I suppose, when with the benefit of hindsight one begins to search one's past for such ‘turning points’, one is apt to start seeing them everywhere.

不仅是我针对我们的晚间晤谈所做的决定，还有在我的餐具室里发生的那个小插曲，如果愿意这么想的话，也可以被视作是这样的“转折点”。
Not only my decision in respect of our evening meetings, but also that episode in my pantry, if one felt so inclined, could be seen as such a ‘turning point’.

人们也许会问，如果那天傍晚肯顿小姐捧着花瓶走进来的时候，我的反应稍有不同，那又会有什么样的结果呢？
What would have transpired, one may ask, had one responded slightly differently that evening she came in with her vase of flowers?

还有，在肯顿小姐收到姨妈的死讯后，我跟她在餐厅里不期而遇的那一次—大约跟这些事件发生在同一个时期—或许也可以被视作另一个这样的“转折点”。
And perhaps – occurring as it did around the same time as these events – my encounter with Miss Kenton in the dining room the afternoon she received the news of her aunt's death might be seen as yet another ‘turning point’ of sorts.

那死讯是几个钟头前送到的；的确，那天早上就是我敲开她起坐间的房门，亲手把那封信递给她的。
News of the death had arrived some hours earlier; indeed, I had myself knocked on the door of her parlour that morning to hand her the letter.

我走进去待了一小会儿，跟她讨论了某件工作上的事务，我记得我们围坐在她的桌前，而她就是在我们交谈中间把那封信拆开的。
I had stepped inside for a brief moment to discuss some professional matter, and I recall we were seated at her table and in mid-conversation at the moment she opened the letter.

她一下子就呆住了，值得赞扬的是她的神态仍能保持镇定，将那封信从头到尾看了至少有两遍。
She became very still, but to her credit she remained composed, reading the letter through at least twice.

然后她把信小心地塞回信封，抬头看着桌子对面的我。
Then she put the letter carefully back in its envelope and looked across the table to me.

“是我姨妈的伴当约翰逊太太写来的。
‘It is from Mrs Johnson, a companion of my aunt.

她说我姨妈前天去世了。”
She says my aunt died the day before yesterday.’

她顿了顿，然后说：“葬礼定在明天举行。
She paused a moment, then said: ‘The funeral is to take place tomorrow.

不知道我能不能告假一天？”
I wonder if it might be possible for me to take the day off.’

“肯定可以安排的，肯顿小姐。”
‘I am sure that could be arranged, Miss Kenton.’

“谢谢您，史蒂文斯先生。
‘Thank you, Mr Stevens.

请原谅，不过我也许现在想单独待一会儿。”
Forgive me, but perhaps I may now have a few moments alone.’

“当然了，肯顿小姐。”
‘Of course, Miss Kenton.’

我告退离开，可是直到我已经出来以后，这才想起我实际上并没有明确向她致以慰唁之意。
I made my exit, and it was not until after I had done so that it occurred to me I had not actually offered her my condolences.

我完全可以想象这消息对她是个多大的打击，因为她姨妈一直以来在方方面面对她而言就像是她的亲生母亲一样。我在走廊里犹豫了一会儿，思量着我是否应该返回去敲开门，好好弥补一下我的疏漏。
I could well imagine the blow the news would be to her, her aunt having been, to all intents and purposes, like a mother to her, and I paused out in the corridor, wondering if I should go back, knock and make good my omission.

可是我接着又想，要是我真这么做的话，极有可能会打扰到她不欲公开流露的哀伤之情。
But then it occurred to me that if I were to do so, I might easily intrude upon her private grief.

的的确确，就在那一刻，肯顿小姐极有可能就在距离我只有几英尺之遥的屋内痛哭失声。
Indeed, it was not impossible that Miss Kenton, at that very moment, and only a few feet from me, was actually crying.

这种想法在我心里激起了一种奇怪的感觉，使得我就在那走廊上独自踌躇、徘徊了良久。
The thought provoked a strange feeling to rise within me, causing me to stand there hovering in the corridor for some moments.

不过最终我还是判定，最好还是另找机会表达我的慰问之情，于是就先离开了。
But eventually I judged it best to await another opportunity to express my sympathy and went on my way.

结果是我直到当天下午才又见到她，如前所说，我是在餐厅里碰到她的，她正把瓷器往餐具柜里放。
As it turned out, I did not see her again until the afternoon, when, as I say, I came across her in the dining room, replacing crockery into the sideboard.

在此之前，肯顿小姐的丧亲之痛已经在我心头盘踞了好几个钟头，我一直都在琢磨最好是做点什么或是说点什么才能稍稍减轻一下她的情感负担。
By this point, I had been preoccupied for some hours with the matter of Miss Kenton's sorrow, having given particular thought to the question of what I might best do or say to ease her burden a little.

因此，我在听到她走进餐厅的脚步声以后—我当时正在门厅里忙着某样工作—我等了约莫有一分钟，就放下手里的工作走进了餐厅。
And when I had heard her footsteps entering the dining room – I was busy with some task out in the hall – I had waited a minute or so, then put down what I was doing and followed her in.

“啊，肯顿小姐，”我说。
‘Ah, Miss Kenton,’ I said.

“今天下午您感觉还好吗？”
‘And how might you be this afternoon?’

“挺好的，谢谢您，史蒂文斯先生。”
‘Quite well, thank you, Mr Stevens.’

“一切都还正常吧？”
‘Is everything in order?’

“一切都很正常，谢谢您。”
‘Everything is in order, thank you.’

“我一直想问问您，最近这批新到的员工有没有给您带来什么特别的麻烦。”
‘I had been meaning to ask you if you were experiencing any particular problems with the new recruits.’

我轻轻一笑。
I gave a small laugh.

“一时间有这么多新人同时到来，很容易出现各种各样的小麻烦和小问题。
‘Various small difficulties are apt to arise when so many new recruits arrive all at once.

我敢说，在这样的时候如果我们能稍稍探讨一下，即便是我们这一行当中的佼佼者都经常能得益匪浅呢。”
I dare say the best of us can often profit by a little professional discussion at such times.’

“谢谢您，史蒂文斯先生，不过我对新来的那两个姑娘感到非常满意。”
‘Thank you, Mr Stevens, but the new girls are very satisfactory to me.’

“有鉴于近来有多位新员工加入进来，您不觉得目前的人员配置规划有必要做些调整吗？”
‘You don't consider any changes necessary to the present staff plans on account of the recent arrivals?’

“我不觉得有什么调整的必要，史蒂文斯先生。
‘I don't think any such changes will be necessary, Mr Stevens.

不过如果我的想法有变的话，我会第一时间告诉您的。”
However, if I change my view on this, I will let you know immediately.’

她转头继续整理餐具柜，我一时间打算就此离开餐厅了，事实上，我相信我实际上已经朝餐厅门口走了几步了，不过我停下脚步，转过头来又对她说：
She turned her attention back to the sideboard, and for a moment, I thought about leaving the dining room. In fact, I believe I actually took a few steps towards the doorway, but then I turned to her again and said:

“这么说来，肯顿小姐，您觉得新来的几位员工适应得还不错喽？”
‘So, Miss Kenton, the new recruits are getting on well, you say.’

“两个姑娘表现得都非常好，我可以向您保证。”
‘They are both doing very well, I assure you.’

“啊，很高兴听您这么说。”
‘Ah, that is good to hear.’

我又短促地一笑。
I gave another short laugh.

“我只是想了解一下情况，因为我们都知道，她们俩都没有在这样规模的宅第里工作过。”
‘I merely wondered, because we had established that neither girl had worked previously in a house of this size.’

“的确如此，史蒂文斯先生。”
‘Indeed, Mr Stevens.’

我看着她把瓷器往餐具柜里摆，等着看看她还有什么想说的。
I watched her filling the sideboard and waited to see if she would say anything further.

过了好一会儿，看到她很明显再没有什么话要说了，我才开口道：“事实上，肯顿小姐，请恕我直言。
When after several moments it became clear she would not, I said: ‘As a matter of fact, Miss Kenton, I have to say this.

我已经注意到最近有一两件工作做得有失水准。
I have noticed one or two things have fallen in standard just recently.

我真觉得对于新来的这批员工，您也许还是不要这么沾沾自喜才好。”
I do feel you might be a little less complacent as regards new arrivals.’

“您这话是什么意思，史蒂文斯先生？”
‘Whatever do you mean, Mr Stevens?’

“就我个人而言，肯顿小姐，每当有新的员工到来，我都会加倍注意，以确保一切都不出问题。
‘For my part, Miss Kenton, whenever new recruits arrive, I like to make doubly sure all is well.

我会在各个方面检查他们的工作成效，并试图评估他们与其他员工相处得如何。
I check all aspects of their work and try to gauge how they are conducting themselves with other staff members.

毕竟，对于他们在业务方面以及整体的精神面貌方面的影响有个清楚的认识是非常重要的。
It is, after all, important to form a clear view of them both technically and in terms of their impact on general morale.

我不得不很遗憾地指出，肯顿小姐，不过我相信您在这些方面可能稍稍有点粗心大意。”
I regret to say this, Miss Kenton, but I believe you have been a little remiss in these respects.’

肯顿小姐一时间显得有些困惑不解。
For a second, Miss Kenton looked confused.

然后她转身看着我，脸色明显绷得紧紧的。
Then she turned towards me and a certain strain was visible in her face.

“您说什么，史蒂文斯先生？”
‘I beg your pardon, Mr Stevens?’

“比方说，肯顿小姐，虽说这些餐具清洗的情况符合我们一贯的高标准，可是我注意到它们摆放在厨房架子上的方式，尽管目前来看并无显而易见的危险，不过长此以往，餐具的破损率恐怕就会超过必要的标准了。”
‘For instance, Miss Kenton, although the crockery is being washed to as high a standard as ever, I have noticed it is being replaced on the kitchen shelves in a manner which, while not obviously dangerous, would nevertheless over time result in more breakages than necessary.’

“是这样吗，史蒂文斯先生？”
‘Is that so, Mr Stevens?’

“是的，肯顿小姐。
‘Yes, Miss Kenton.

还有啊，早餐厅后面那个小壁龛也有段时间没有打扫过了。
Furthermore, that little alcove outside the breakfast room has not been dusted for some time.

恕我失礼，不过还有一两件其他的小事可以提一下。”
You will excuse me, but there are one or two other small things I might mention.’

“您不必再特别强调了，史蒂文斯先生。
‘You needn't press your point, Mr Stevens.

我会遵照您的建议，重新检查新来的女仆的工作。”
I will, as you suggest, check the work of the new maids.’

“忽略了这么明显的小瑕疵，这可不像是您的做派啊，肯顿小姐。”
‘It is not like you to have overlooked such obvious things, Miss Kenton.’

肯顿小姐把脸别过去，脸上再次出现了那种表情，就像是努力想弄清楚让她困惑不已的某一件事。
Miss Kenton looked away from me, and again an expression crossed her face as though she was trying to puzzle out something that had quite confused her.

她的神色与其说是生气，不如说是疲惫。
She did not look upset so much as very weary.

然后她把餐具柜一关，说：“失陪了，史蒂文斯先生，”径自离去。
Then she closed the sideboard, said: ‘Please excuse me, Mr Stevens,’ and left the room.

可是，总是在悬想当年的某时某刻若是不像当初那般行事的话，结局将会怎样，这又有什么意义呢？
But what is the sense in forever speculating what might have happened had such and such a moment turned out differently?

这样下去，恐怕只会徒然让自己心烦意乱。
One could presumably drive oneself to distraction in this way.

总之，说说当初的哪件事成了“转折点”自是无妨，可是这样的时刻也只能在回顾当中才能追认。
In any case, while it is all very well to talk of ‘turning points’, one can surely only recognize such moments in retrospect.

自然，如今在回顾这些往事的时候，它们在我的人生当中确实呈现为异常关键而又珍贵的时刻；可是在当时自然是不会有这种想法的。
Naturally, when one looks back to such instances today, they may indeed take the appearance of being crucial, precious moments in one's life; but of course, at the time, this was not the impression one had.

反而会觉得在我面前还有数不尽的日、月、年，可以在其中慢慢地理清我跟肯顿小姐关系当中的那些别扭和无常；将来还有无数的机会可以弥补这个或那个误会所造成的影响。
Rather, it was as though one had available a never-ending number of days, months, years in which to sort out the vagaries of one's relationship with Miss Kenton; an infinite number of further opportunities in which to remedy the effect of this or that misunderstanding.

当时可是绝对没有丝毫迹象显示，这些显然都是渺不足道的小事竟会致使所有的梦想永远都无法兑现。
There was surely nothing to indicate at the time that such evidently small incidents would render whole dreams forever irredeemable.

不过我看我是变得有些过度内省了，而且还是一种性质相当阴郁的内省。
But I see I am becoming unduly introspective, and in a rather morose sort of way at that.

无疑，这肯定是跟夜静更深，以及今晚所经受的那一连串恼人的事件有关。
No doubt, this has to do with the late hour, and the trying nature of the events I have had to endure this evening.

无疑，我现在的心境肯定也跟明天我应该就能在多年暌违之后终于又能见到肯顿小姐这一事实不无关系—只要我能在当地的汽修厂买到汽油，就像泰勒夫妇向我保证的那样—我预计明天午饭时间就能到达小康普顿。
No doubt, too, my present mood is not unconnected with the fact that tomorrow – provided I am supplied with petrol by the local garage, as the Taylors assure me I will be – I should arrive in Little Compton by lunch-time and will, presumably, see Miss Kenton again after all these years.

当然，没有任何理由认为我们的重逢不会是友好而又热诚的。
There is, of course, no reason at all to suppose our meeting will be anything but cordial.

事实上，以我的预期，我们的会晤—除了几句在此情况下必不可少的朋友间的嘘寒问暖以外—主要应该还是以谈工作为主。
In fact, I would expect our interview – aside from a few informal exchanges quite proper in the circumstances – to be largely professional in character.

也就是说，既然肯顿小姐的婚姻已经是不幸地貌似走向了失败，而且连家都没有了，那么我的责任就是要确认她是否还有兴趣回到达林顿府重操旧业。
That is to say, it will be my responsibility to determine whether or not Miss Kenton has any interest, now that her marriage, sadly, appears to have broken down and she is without a home, in returning to her old post at Darlington Hall.

在此我也不妨直说了吧，今晚再次重读她的来信以后，我倾向于认为我此前对于其中某些字句的解读或许有先入为主和强作解人之嫌，实在不够明智。
I may as well say here that having reread her letter again tonight, I am inclined to believe I may well have read more into certain of her lines than perhaps was wise.

不过我仍旧认为她来信当中的特定段落的确流露出不只是一星半点的怀旧之情，尤其是当她写下类似这样的话语时：“当时我是多么喜欢从三楼的那几间卧室里俯瞰大草坪以及远处那绿草如茵的开阔高地。”
But I would still maintain there is more than a hint of nostalgic longing in certain parts of her letter, particularly when she writes such things as: ‘I was so fond of that view from the second floor bedrooms overlooking the lawn with the downs visible in the distance.’

不过话又说回来了，既然明天就能当面获悉肯顿小姐目前的真实意愿，再这样没完没了地反复猜度思量又有什么意义呢？
But then again, what is the purpose in endlessly speculating as to Miss Kenton's present wishes when I will be able to ascertain these from her own person tomorrow?

反正，我也已经远远偏离了对于今晚各种遭遇的讲述。就容我这么说吧，最后这几个钟头过得实在是活活要把人给累死。
And in any case, I have drifted considerably from the account I was giving of this evening's events. These last few hours, let me say it, have proved unreasonably taxing ones.

我原以为，在一个晚上不得不把福特车弃置于荒郊野岭、不得不摸黑从根本没有路的山上跋涉到这个村子里，这些遭遇已经是够我受的了；而且我相信，我那善良的主人泰勒先生和太太也绝非是故意让我承受刚刚经历的这番苦楚的。
One would have thought that having to abandon the Ford on some lonely hill, having to walk down to this village in near-darkness by the unorthodox route one did, would be sufficient inconvenience to befall one for a single evening. And my kind hosts, Mr and Mrs Taylor, would never, I am certain, have knowingly put me through what I have just endured.

但事实就是如此，一旦我在他们的餐桌前坐下来准备用晚餐，一旦他们的几位邻居开始过来拜访，那一连串最令人难熬的事件就在我身边轮流开始上演了。
But the fact is, once I had sat down to supper at their table, once a number of their neighbours had come calling, a most discomforting set of events began to unfold around me.

农舍楼下的房间看起来被泰勒先生和太太用作了餐厅兼日常的起居室。
The room downstairs at the front of this cottage would appear to serve Mr and Mrs Taylor as both dining room and general living quarters.

房间相当温馨舒适，正中摆放着一张农家的厨房里常见的那种做工粗糙的大木桌，桌面没有上漆，布满了切肉刀和切面包的刀子留下的细小刀痕。
It is a rather cosy room, dominated by a large, roughly hewn table of the sort one might expect to see in a farmhouse kitchen, its surface unvarnished and bearing many small marks left by choppers and breadknives.

尽管我们仅靠墙角架子上的一盏油灯那昏黄的光线照明，这些刀痕仍旧清晰可见。
These latter I could see quite clearly despite the fact that we were sitting in a low yellow light cast by an oil lamp on a shelf in one corner.

“并不是说我们这个偏僻地方没有供电，先生，”用餐期间泰勒先生对我说，同时朝那盏油灯点了点头。
‘It's not as though we don't have electricity out here, sir,’ Mr Taylor remarked to me at one point, nodding towards the lamp.

“可是线路出了问题，我们有差不多两个月没有电了。
‘But something went wrong with the circuit and we've been without it now for almost two months.

不过实不相瞒，我们也并不太想念有电的那些日子。
To tell you the truth, we don't miss it so much.

咱们这个村子里有几户人家就从来没用过电灯。
There's a few houses in the village that's never had electricity at all.

油灯的光线给人的感觉更加温暖。”
Oil gives a warmer light.’

泰勒太太给我们端上来可口的肉汤，我们以脆皮面包佐餐，那时还没有什么迹象预示着今天晚上还会有什么令人发怵的事情发生，我本以为也就再花一小时左右的时间愉快地聊聊天就可以上床休息了。
Mrs Taylor had served us with a good broth, which we had eaten with helpings of crusty bread, and at that point, there had been little to suggest the evening held for me anything more daunting than an hour or so of pleasant conversation before retiring to bed.

然而，我们刚刚吃完晚饭，泰勒先生正给我倒一杯邻居家酿的艾尔啤酒的时候，听到屋外的砾石路上传来了脚步声。
However, just as we had finished supper and Mr Taylor was pouring for me a glass of ale brewed by a neighbour, we heard footsteps approaching on the gravel outside.

在我听来，黑暗当中逐渐逼近一幢孤零零的偏僻村舍的脚步声里自有一点点不祥的味道，不过无论是主人还是主妇倒都像是并没有觉得来人有什么恶意。
To my ears, there was something a little sinister in the sound of feet coming ever closer in the darkness up to an isolated cottage, but neither my host nor hostess seemed to anticipate any menace.

因为从泰勒先生的问话当中就只听得出好奇的语气：“哈啰，来的是谁啊？”
For it was with curiosity and nothing else in his voice that Mr Taylor said: ‘Hello, now who could this be?’

他这话更像是自言自语，可是接着我们就听到门外有人大声地自报家门，就像是回答他这句问话一样：“是我，乔治·安德鲁斯。
He had said this more or less to himself, but then we heard, as though in reply, a voice call outside: ‘It's George Andrews.

正巧打这儿路过。”
Just happened to be walking by.’

紧接着，泰勒太太就将一位身材魁梧、五十来岁的男人迎了进来，看他的穿着打扮，他这一天应该都在干农活儿。
The next moment, Mrs Taylor was showing in a well-built man, perhaps in his fifties, who judging from his dress had spent the day engaged in agricultural work.

从他熟不拘礼的态度上可以看出他是这儿的常客，他在进门的一个小凳子上坐下，有点费劲地脱下脚上的威灵顿橡胶靴，一边跟泰勒太太闲聊了几句。
With a familiarity which suggested he was a regular visitor, he placed himself on a small stool by the entrance and removed his Wellington boots with some effort, exchanging a few casual remarks with Mrs Taylor as he did so.

然后朝餐桌走来，停下脚步，在我面前以立正姿势站得笔直，就像是军队里向长官进行汇报一样。
Then he came towards the table and stopped, standing to attention before me as though reporting to an officer in the army.

“敝姓安德鲁斯，先生，”他说。
‘The name's Andrews, sir,’ he said.

“祝您晚上好。
‘A very good evening to you.

听闻您的不幸遭遇我深感遗憾，不过我希望您在敝村莫斯科姆度过的这一夜不至于让您太过失望。”
I'm very sorry to hear about your mishap, but I hope you're not too put out to be spending the night here in Moscombe.’

我有点困惑不解，这位安德鲁斯先生又是怎么听说他所谓的我的“不幸遭遇”的呢？
I was a little puzzled as to how this Mr Andrews had come to hear of my ‘mishap’, as he termed it.

不管怎么说，我还是面带微笑地回答说，我绝没有感到什么“失望”，对于受到的盛情款待唯有不尽的感激之情。
In any case, I replied with a smile that far from being ‘put out’, I felt extremely indebted for the hospitality I was receiving.

我说这话当然指的是泰勒先生和太太的好心相助，谁知安德鲁斯先生像是自认为也被包括在我所感激的对象当中了，因为他马上就自卫一样地举起两只巨掌，说道：
By this I had of course been referring to Mr and Mrs Taylor's kindness, but Mr Andrews seemed to believe himself included by my expression of gratitude, for he said immediately, holding up defensively his two large hands:

“哦，不，先生，您太客气啦。
‘Oh no, sir, you're most welcome.

我们非常高兴您能来到这里。
We're very pleased to have you.

像您这样的人物可是不会经常途经敝村的。
It's not often the likes of yourself comes through here.

您能在此停留我们更是高兴还来不及呢。”
We're all very pleased you could stop by.’

听他这话的意思，像是说这整个村子的人都已经知道了我的“不幸遭遇”以及随后入住这幢农舍的经过。
The way he said this seemed to suggest the whole village was aware of my ‘mishap’ and subsequent arrival at this cottage.

我后来发现，事实上也差不多正是如此；我只能猜想，就在我刚刚被领进这个卧室以后—在我洗净双手，正尽力补救一下外套和裤脚的污损之际—泰勒先生和太太就把有关我的消息讲给了路过的村民们听了。
In fact, as I was soon to discover, this was very close to being the case; I can only imagine that in the several minutes after I had first been shown up to this bedroom – while I was washing my hands and doing what I could to make good the damage inflicted upon my jacket and trouser turn-ups – Mr and Mrs Taylor had conveyed news of me to passers-by.

总而言之，几分钟以后就又来了一位客人，那人的外貌跟安德鲁斯先生非常相像—也就是说，同样是肩宽背厚、务农为业，脚下一双沾满泥浆的威灵顿橡胶靴，而且他进门和脱靴的方式就跟安德鲁斯先生如出一辙。
In any case, the next few minutes saw the arrival of another visitor, a man with an appearance much like that of Mr Andrews – that is to say, somewhat broad and agricultural, and wearing muddy Wellington boots, which he proceeded to remove in much the way Mr Andrews had just done.

事实上，他们两位的相貌和做派真是太像了，我还真以为他们是兄弟俩，直到新来者自我介绍说：“敝姓摩根，先生，特雷弗·摩根。”
Indeed, their similarity was such that I supposed them to be brothers, until the newcomer introduced himself to me as, ‘Morgan, sir, Trevor Morgan.’

摩根先生先是对于我的“不幸”表达了遗憾之情，向我保证第二天一早一切都会迎刃而解，然后又表示整个村庄是多么欢迎我的到来。
Mr Morgan expressed regret concerning my ‘misfortune’, assuring me all would be well in the morning, before going on to say how welcome I was in the village.

当然，稍早之前我已经听到过类似的亲切致意了，可是摩根先生的原话居然是：“像您这样的绅士居然来到莫斯科姆村，这真是我们的无上荣光，先生。”
Of course, I had already heard similar sentiments a few moments earlier, but Mr Morgan actually said: ‘It's a privilege to have a gentleman like yourself here in Moscombe, sir.’

我还没来得及想好跟如何回答他这番话，屋外的小径上就又传来了更多的脚步声。
Before I had had any time to think of a reply to this, there came the sound of more footsteps on the path outside.

不久，一对中年夫妇就被迎了进来，主人向我介绍他们是哈里·史密斯先生和太太。
Soon, a middle-aged couple were shown in, who were introduced to me as Mr and Mrs Harry Smith.

这两位看起来却全然不像是务农的；史密斯太太是位发了福的大块头女人，不禁令我想起了二三十年代在达林顿府服务近二十年之久的厨娘莫蒂默太太。
These people did not look at all agricultural; she was a large, matronly woman who rather reminded me of Mrs Mortimer, the cook at Darlington Hall through much of the twenties and thirties.

哈里·史密斯先生却和太太形成了鲜明的对比，是个小个儿，眉头紧锁，表情一直都很紧张。
In contrast, Mr Harry Smith was a small man with a rather intense expression that furrowed his brow.

他们在桌边坐下以后，史密斯先生对我说：“您的车就是停在荆棘山上的那辆古董福特吧，先生？”
As they took their places around the table, he said to me: ‘Your car would be the vintage Ford up there on Thornley Bush Hill, sir?’

“如果您说的就是俯瞰这个村子的那座小山的话，”我说。
‘If that is the hill road overlooking this village,’ I said.

“不过听您说您居然见到了那辆车，我倒是挺惊讶的。”
‘But I'm surprised to hear you've seen it.’

“我并没有亲眼见到，先生。
‘I’ve not seen it myself, sir.

不过戴夫·桑顿刚才开着拖拉机回家的时候，在路上见到了它。看到居然有那么一辆车停在路边，他大为惊讶，他还特地停下拖拉机，下来看了看。”
But Dave Thornton passed it on his tractor a short while ago as he was coming home. He was so surprised to see it sitting there, he actually stopped and got out.’

说到这里，哈里·史密斯先生转过头去对着围桌而坐的其他人说道：“真是漂亮极了，那辆车。
At this point, Mr Harry Smith turned to address the others around the table. ‘Absolute beauty, it is.

他说他从来也没见过这么漂亮的车。
Said he'd never seen anything like it.

把林赛先生从前开的那辆车完全给比下去了！”
Put the car Mr Lindsay used to drive completely in the shade!’

这引起大家的哄堂大笑，泰勒先生特地给我解释说：“林赛先生是从前住在离这儿不远的那幢大房子里的一位绅士，先生。
This caused laughter around the table, which Mr Taylor explained to me by saying: ‘That was a gent used to live in the big house not far from here, sir.

他干过一两件挺出格的事，惹得周围的乡亲们不大待见他。”
He did one or two odd things and wasn't appreciated around here.’

这话引起一阵嘁嘁喳喳的赞同声。
This brought a general murmur of assent.

然后有个人说：“祝您健康，先生，”举起一大杯泰勒太太刚才给大家斟满的艾尔啤酒，紧接着大家就全体共同举杯向我敬起酒来。
Then someone said: ‘Your health, sir,’ lifting one of the tankards of ale Mrs Taylor had just finished distributing, and the next moment I was being toasted by the whole company.

我微笑道：“我向诸位保证，能来到贵地是我的荣幸。”
I smiled and said: ‘I assure you the privilege is all mine.’

“您太客气了，先生，”史密斯太太道。
‘You're very kind, sir,’ Mrs Smith said.

“这才是真正的绅士风度。
‘That's the way a real gentleman is.

那个林赛先生根本就不是什么绅士。
That Mr Lindsay was no gentleman.

他也许有很多钱，可他绝不是个绅士。”
He may have had a lot of money, but he was never a gentleman.’

这话再次赢得大家的一致赞同。
Again, there was agreement all round.

然后泰勒太太凑在史密斯太太的耳边悄声说了句什么，史密斯太太回答说：“他说他会尽快赶过来的。”
Then Mrs Taylor whispered something in Mrs Smith's ear, causing the latter to reply: ‘He said he'd try to be along as soon as he could.’

这两位太太一起转脸看着我，神色有些不太自然，还是史密斯太太开口道：“我们跟卡莱尔医生说了您在这儿的消息，先生。
They both turned towards me with a self-conscious air, then Mrs Smith said: ‘We told Dr Carlisle you were here, sir.

医生表示非常高兴能有机会跟您结识。”
The doctor would be very pleased to make your acquaintance.’

“我想他还有病人要接诊，”泰勒太太表示歉意地补充道。
‘I expect he has patients to see,’ Mrs Taylor added apologetically.

“恐怕我们无法确定他能在您需要休息之前及时赶过来。”
‘I'm afraid we can't say for certain he'll be able to call in before you'd be wanting to retire, sir.’

这个时候，那位眉头紧锁的小个子男人哈里·史密斯先生再次探身向前说道：“那位林赛先生，他真是大错特错了，不是吗？
It was then that Mr Harry Smith, the little man with the furrowed brow, leaned forward again and said: ‘That Mr Lindsay, he had it all wrong, see?

做出那样的事来。
Acting the way he did.

自以为不知道比我们高明多少，把我们全都当傻瓜。
Thought he was so much better than us, and he took us all for fools.

哼，我可以告诉您，先生，很快他就知道不是这么回事儿啦。
Well, I can tell you, sir, he soon learnt otherwise.

咱们村里可是有不少肯动脑筋、喜欢讨论的人。
A lot of hard thinking and talking goes on in this place.

咱们这里有的是明确的主见，而且从来不会羞于把它表达出来。
There's plenty of good strong opinion around and people here aren't shy about expressing it.

你们那位林赛先生很快就知道厉害，学了乖啦。”
That's something your Mr Lindsay learnt quickly enough.’

“他不是绅士，”泰勒先生平静地道。
‘He was no gentleman,’ Mr Taylor said quietly.

“他根本就不是个绅士，那位林赛先生。”
‘He was no gentleman, that Mr Lindsay.’

“一点都不假，先生，”哈里·史密斯先生道。
‘That's right, sir,’ Mr Harry Smith said.

“你只要打眼一看，就看得出他不是个绅士。
‘You could tell just watching him he was no gentleman.

不错，他是有一幢漂亮的房子，一身上等的套装，可尽管如此你就是知道。
All right, he had a fine house and good suits, but somehow you just knew.

他也很快就露了馅儿啦。”
And so it proved in good time.’

又是一阵嘁嘁喳喳的赞同声，一度所有在场的人都似乎在考虑向我透露当地这位名人的故事是否合适。
There was a murmur of agreement, and for a moment all present seemed to be considering whether or not it would be proper to divulge to me the tale concerning this local personage.

后来还是泰勒先生打破了沉默。
Then Mr Taylor broke the silence by saying:

“哈里说得没错。
‘That's true what Harry says.

你一打眼就能看得出谁是真正的绅士，谁是衣着光鲜的冒牌货。
You can tell a true gentleman from a false one that's just dressed in finery. Take yourself, sir.

就拿您自己来说吧，先生。使您成为一位绅士的可不是您身上衣服的剪裁，甚至不是您谈吐的优雅方式，而是别的某一种特质。
It's not just the cut of your clothes, nor is it even the fine way you've got of speaking. There's something else that marks you out as a gentleman.

很难说得清楚，可是只要眼睛不瞎，一打眼就看得出来。”
Hard to put your finger on it, but it's plain for all to see that's got eyes.’

这话引来了大家更多的赞同。
This brought more sounds of agreement around the table.

“卡莱尔先生应该很快就到了，先生，”泰勒太太插嘴道。
‘Dr Carlisle shouldn't be long now, sir,’ Mrs Taylor put in.

“您肯定会跟他谈得很愉快的。”
‘You'll enjoy talking with him.’

“卡莱尔先生也有那样的特质，”泰勒先生道。
‘Dr Carlisle's got it too,’ Mr Taylor said.

“他是有的。
‘He's got it.

他是个真正的绅士，一点不假。”
He's a true gent, that one.’

摩根先生自打进来以后就没怎么开口，这时候探身向前对我说：“您觉得这种特质到底是什么呢，先生？
Mr Morgan, who had said little since his arrival, bent forward and said to me: ‘What do you suppose it is, sir?

也许拥有这种特质的人能说得更加清楚。
Maybe one that's got it can better say what it is.

我们一直都在这么议论谁有谁没有的，可我们绝不可能比我们议论的对象更明智。
Here we are all talking about who's got it and who hasn't, and we're none the wiser about what we're talking about.

也许您能指点我们一二，先生。”
Perhaps you could enlighten us a bit, sir.’

大家顿时安静了下来，我能感到所有人都把脸转向了我这边。
A silence fell around the table and I could sense all the faces turn to me.

我轻咳了一声，说：
I gave a small cough and said:

“让我来对于我可能具备也可能不具备的特质发表意见，是极不合适的。
‘It is hardly for me to pronounce upon qualities I may or may not possess.

不过，就这个具体的问题而言，我料想大家所谓的这种特质可能可以最为方便地用‘尊严’二字来界定。”
However, as far as this particular question is concerned, one would suspect that the quality being referred to might be most usefully termed “dignity”.’

我认为对此无须再做任何进一步的解释了。
I saw little point in attempting to explain this statement further.

的确，我不过是在倾听大家谈话的过程中将我头脑中一闪而过的想法随口说了出来，若非大家的突然要求，我都很怀疑自己是否还会说出这番话来的。
Indeed, I had merely given voice to the thoughts running through my mind while listening to the preceding talk and it is doubtful I would have said such a thing had the situation not suddenly demanded it of me.

不过，大家对我的回答倒似乎是颇为满意。
My response, however, seemed to cause much satisfaction.

“您的话很有道理，先生，”安德鲁斯先生道，频频点头，其他几位也应声附和。
‘There's a lot of truth in what you say there, sir,’ Mr Andrews said, nodding, and a number of other voices echoed this.

“那位林赛先生也确实需要更多一点尊严才好，”泰勒太太道。
‘That Mr Lindsay could certainly have done with a little more dignity,’ Mrs Taylor said.

“可是他这一类人的问题就在于他们错把装腔作势、趾高气扬当成了尊严。”
‘The trouble with his sort is they mistake acting high and mighty for dignity.’

“不过请注意，”哈里·史密斯先生插嘴道，“应该说我非常尊重您的意见，先生。
‘Mind you,’ put in Mr Harry Smith, ‘with all respect for what you say, sir, it ought to be said.

不过，尊严可并非绅士们所独有的。
Dignity isn't just something gentlemen have.

尊严是这个国家的每一个男人和女人都可以凭自己的努力去争取并且能够最终得到的。
Dignity's something every man and woman in this country can strive for and get.

恕我冒昧直言，先生，不过就像我方才说过的，我们这里的人在需要表达自己观点的时候是不会客套的。
You'll excuse me, sir, but like I said before, we don't stand on ceremony here when it comes to expressing opinions.

而这就是我的看法，不管说得对不对。
And that's my opinion for what it's worth.

尊严可并不只是绅士们所独有的。”
Dignity's not just something for gentlemen.’

当然，我觉察到哈里·史密斯先生对于“尊严”的理解跟我的原意是大相径庭的，不过要想跟这些人解释清楚我的观点，这个任务就未免过于艰巨了。
I perceived, of course, that Mr Harry Smith and I were rather at cross purposes on this matter, and that it would be far too complicated a task for me to explain myself more clearly to these people.

所以我觉得最好的办法莫过于简单地微微一笑并加以认可：“当然，您说得很对。”
I thus judged it best simply to smile and say: ‘Of course, you're quite correct.’

这话非常有效，马上就驱散了哈里·史密斯先生刚才说那番话时所造成的那种轻微的紧张气氛。
This had the immediate effect of dispelling the slight tension that had built in the room while Mr Harry Smith had been speaking.

而哈里·史密斯先生本人却似乎变本加厉，变得毫无顾忌了，因为他倾身向前，继续说道：
And Mr Harry Smith himself seemed to lose all inhibitions, for now he leaned forward and continued:

“毕竟，这就是我们抗击希特勒的目的。
‘That's what we fought Hitler for, after all.

如果希特勒得逞了的话，我们现在就全都沦为奴隶了。
If Hitler had had things his way, we'd just be slaves now.

全世界就将只有几个主子和数以亿万计的奴隶了。
The whole world would be a few masters and millions upon millions of slaves.

而我不需要提醒在座的任何一位，作为奴隶可是没有任何尊严可言的。
And I don't need to remind anyone here, there's no dignity to be had in being a slave.

而这正是我们为之而奋战，也是我们最终所赢得的。
That's what we fought for and that's what we won.

我们赢得了成为自由公民的权利。
We won the right to be free citizens.

这就是生为英国人的一项基本人权，不管你是谁，不管是贫穷还是富有，你生而自由，你生而拥有自由表达你的观点的权利，你可以投票选举你支持的议员，或者投票将其罢免。
And it's one of the privileges of being born English that no matter who you are, no matter if you're rich or poor, you're born free and you're born so that you can express your opinion freely, and vote in your member of parliament or vote him out.

这就是尊严的真正意义，如果您恕我冒昧直言的话，先生。”
That's what dignity's really about, if you'll excuse me, sir.’

“好了，好了，哈里，”泰勒先生道。
‘Now now, Harry,’ Mr Taylor said.

“我看得出你又在为你的某个政治演说热身呢。”
‘I can see you're warming up to one of your political speeches.’

这引起一阵笑声。
This brought laughter.

哈里·史密斯先生有点腼腆地微微一笑，不过却又继续道：
Mr Harry Smith smiled a little shyly, but went on:

“我这不是在谈政治。
‘I'm not talking politics.

我只是想说说我的看法，仅此而已。
I'm just saying, that's all.

你要是个奴隶的话，你就不可能有任何尊严。
You can't have dignity if you're a slave.

不过每一个英国人，只要他愿意，对此都会有深刻的体会。
But every Englishman can grasp it if only he cares to.

因为我们曾为了这种权利而浴血奋战。”
Because we fought for that right.’

“我们这个村子也许看起来只是个偏僻的小地方，先生，”他妻子道。
‘This may seem like a small, out of the way place we have here, sir,’ his wife said.

“可是我们在战争中的付出超过了我们分所应该的程度。
‘But we gave more than our share in the war.

远远超过了。”
More than our share.’

她这句话一说完，气氛一下子就变得相当凝重了，一直到泰勒先生最终对我说：“哈里为我们地方上做了大量的人员组织工作。
A solemnness hung in the air after she said this, until eventually Mr Taylor said to me: ‘Harry here does a lot of organizing for our local member.

只要给他半点机会，他就会详详细细地告诉你这个国家的管理方式到底错在了哪里。”
Give him half a chance and he'll tell you everything that's wrong with the way the country's run.’

“啊，可我这次说的倒恰恰是这个国家对在了那里。”
‘Ah, but I was just saying what was right about the country this time.’

“您本人跟政治的关系算得上密切吗，先生？”
‘Have you had much to do with politics yourself, sir?’

安德鲁斯先生问。
Mr Andrews asked.

“并没有什么直接的关系，”我说，“尤其是这些年。
‘Not directly as such,’ I said, ‘And particularly not these days.

战前也许算得上有过接触吧。”
More so before the war perhaps.’

“我刚刚想起一两年前的时候有位下院议员就叫史蒂文斯先生的。
‘It's just that I seem to remember a Mr Stevens who was a member of parliament a year or two ago.

我在无线电上听过他的一两次演说。
Heard him on the wireless once or twice.

他对于住房问题有一些很有道理的看法。
Had some very sensible things to say about housing.

那不会就是您本人吧，先生？”
But that wouldn't be yourself, sir?’

“哦，当然不是，”我笑道。
‘Oh no,’ I said with a laugh.

现在回想起来，我真是一点都搞不懂当时我怎么会说出下面那番话来的；我只能说，置身于当时的那种环境当中，看来确乎是有如此表达的必要的。
Now I am not at all sure what made me utter my next statement; all I can say is that it seemed somehow called for in the circumstances in which I found myself.

因为我接下来是这么说的：“事实上，相比而言，我个人更关心的是国际事务而非内政方针。
For I then said: ‘In fact, I tended to concern myself with international affairs more than domestic ones.

是外交政策，也就是说。”
Foreign policy, that is to say.’

这番话对于我的听众们似乎产生的效果真让我有点感到吃惊。
I was a little taken aback by the effect this seemed to have upon my listeners.

也就是说，他们似乎油然生出一种敬畏之情。
That is to say, a sense of awe seemed to descend on them.

我赶紧补充说：“我可从来都没担任过任何高级职务，请注意。
I added quickly: ‘I never held any high office, mind you.

我所能够施加的任何一点点影响，都纯粹是非官方意义上的。”
Any influence I exerted was in a strictly unofficial capacity.’

不过那种鸦雀无声的寂静仍旧维持了好几秒钟。
But the hushed silence remained for several more seconds.

“请原谅，先生，”泰勒太太最后道，“不过您可曾见到过丘吉尔先生？”
‘Excuse me, sir,’ Mrs Taylor said eventually, ‘but have you ever met Mr Churchill?’

“丘吉尔先生？
‘Mr Churchill?

他确实有几次造访过敝府。
He did come to the house on a number of occasions.

不过坦白说来，泰勒太太，在我最为经常地与闻国际大事的那段时期内，丘吉尔先生还不是如今这样关键的人物，也没人当真以为他日后会成为这样的大人物。
But to be quite frank, Mrs Taylor, during the time I was most involved in great affairs, Mr Churchill was not such a key figure and was not really expected to become one.

当年更为经常性的来访者是艾登先生和哈利法克斯勋爵这些人。”
The likes of Mr Eden and Lord Halifax were more frequent visitors in those days.’

“可是您毕竟是见到过丘吉尔先生本人的，对吧，先生？
‘But you have actually met Mr Churchill, sir?

能够这么说是多大的荣幸啊。”
What an honour to be able to say that.’

“丘吉尔先生的很多观点我也并不认同，”哈里·史密斯先生道，“不过毫无疑问，他的确是个伟人。
‘I don't agree with many things Mr Churchill says,’ Mr Harry Smith said, ‘but there's no doubt about it, he's a great man.

能跟他这样的人物商讨大事，那肯定也是相当了不起的。”
It must be quite something, sir, to be discussing matters with his like.’

“呃，我必须重申，”我说，“我跟丘吉尔先生并无太多的接触。
‘Well, I must reiterate,’ I said, ‘I didn't have a great deal to do with Mr Churchill.

不过您说得很对，能有机会结识他确是令人深感满足的幸事。
But as you rightly point out it's rather gratifying to have consorted with him.

事实上，总而言之，我想我的确是非常幸运的，这是我首先必须承认的一点。
In fact, all in all, I suppose I have been very fortunate, I would be the first to admit that.

毕竟，我何幸之有，不但能够结识丘吉尔先生，而且还跟其他来自美洲和欧洲的众多伟大领袖和重要人物打过交道。
It has been my good fortune, after all, to have consorted not just with Mr Churchill, but with many other great leaders and men of influence – from America and from Europe.

您可能会觉得我何幸之有，居然能蒙这些伟人不弃，倾听我对于当时那些重大事件的意见，不错，回想起来，我的确备感荣宠。
And when you think that it was my good fortune to have had their ear on many great issues of the day, yes, when I think back, I do feel a certain gratitude.

毕竟，能在这样一个国际的舞台上扮演一个角色，无论那个角色是何其渺小，的确是一种莫大的荣幸。”
It's a great privilege, after all, to have been given a part to play, however small, on the world's stage.’

“请恕我多嘴，先生，”安德鲁斯先生道，“不过艾登先生到底是个什么样的人呢？
‘Excuse me asking, sir,’ Mr Andrews said, ‘but what sort of man is Mr Eden?

我的意思是在私底下。
I mean, at the personal level.

我一直都有个印象，觉得他是个非常正派的君子。
I've always had the impression he's a jolly decent sort.

是那种无论高低贵贱，他都愿意跟你交谈的人。
The sort that can talk to anyone high or low, rich or poor.

我这个印象对吗，先生？”
Am I right, sir?’

“我想，大体而言，这是一种很精确的描述。
‘I would say that is, by and large, an accurate picture.

不过当然了，最近这些年来我都再没有见过艾登先生，也许压力之下他已经有了很大的改变，也未可知。
But of course I have not seen Mr Eden in recent years, and he may have been much changed by pressures.

因为我曾经亲眼目睹过这样的实例，公共生活在短短的几年内就能把一个人改变到你都认不出来的程度。”
One thing I have witnessed is that public life can change people unrecognizably in a few short years.’

“这一点我毫不怀疑，先生，”安德鲁斯先生道。
‘I don't doubt that, sir,’ said Mr Andrews.

“就连咱们的哈里也不例外。
‘Even Harry here.

他自己涉足政治也就几年的时间，打那以后他就跟变了一个人一样。”
Got himself involved with his politics a few years back and he's never been the same man since.’

大家又是一阵哄笑，而哈里·史密斯先生则把肩一耸，脸上勉强掠过一丝微笑。
There was laughter again, while Mr Harry Smith shrugged and allowed a smile to cross his face.

然后他说：
Then he said:

“我的确把大量精力投入到了竞选工作中。
‘It's true I've put a lot into the campaigning work.

这当然只是地方性的，不要说是您交往过的那些大人物了，就算是重要程度只及他们一半的那种人，我也一个都没见过，先生，可是尽管我人微言轻，我相信我是在竭尽绵薄，做好我的本分。
It's only at a local level, and I never meet anyone half as grand as the likes you associate with, sir, but in my own small way I believe I'm doing my part.

在我看来，英国是个民主国家，为了捍卫它的民主制度，我们这个村子里的人经受过的磨难并不亚于任何人。
The way I see it, England's a democracy, and we in this village have suffered as much as anyone fighting to keep it that way.

现在也该当我们来行使我们的权利了，这是我们每个人的职责。
Now it's up to us to exercise our rights, every one of us.

我们村里有不少优秀的年轻人为了能使我们享有这种权利而牺牲了生命，依我之见，我们在座的每一个人都对他们有所亏欠，唯有尽好我们的本分才是对他们应有的回报。
Some fine young lads from this village gave their lives to give us that privilege, and the way I see it, each one of us here now owes it to them to play our part.

我们都有自己坚定不移的主见，我们的责任就是让大家都听到我们的见解。
We've all got strong opinions here, and it's our responsibility to get them heard.

没错，我们这里地处偏远，我们只是个小村庄，我们大家都不再年轻了，而且我们的村子也越来越小了。
We're out of the way, all right, a small village, we're none of us getting younger, and the village is getting smaller.

在我看来，我们必须对我们村子里那些为国捐躯的小伙子们有个交代。
But the way I see it we owe it to the lads we lost from this village.

这也正是为什么，先生，我投入这么多的时间和精力，就是确保我们的声音能够被上层听到。
That's why, sir, I give so much of my time now to making sure our voice gets heard in high places.

就算是我本人因此而有了改变，或者是提早把我送进了坟墓，我也在所不惜。”
And if it changes me, or sends me to an early grave, I don't mind.’

“我可是警告过您的，先生，”泰勒先生微笑道。
‘I did warn you, sir,’ Mr Taylor said with a smile.

“好容易碰上个像您这样的人物，哈里是决不会不让您听听他那套长篇大论就轻易把您放过去的。”
‘There was no way Harry was going to let an influential gentleman like yourself come through the village without giving you his usual earful.’

大家又是一阵哄笑，不过我几乎马上就接口道：
There was laughter again, but I said almost immediately:

“我想我非常理解您的立场，史密斯先生。
‘I think I understand your position very well, Mr Smith.

我也很能理解您希望这个世界变得更加美好、您和本地的村民们应该拥有为使这个世界更加美好而贡献一己之力的良好愿望。
I can well understand that you wish the world to be a better place and that you and your fellow residents here should have an opportunity to contribute to the making of a better world.

这种情怀值得我们为之而鼓掌喝彩。
It is a sentiment to be applauded.

我敢说，这跟促使我在战前投身于那些国际大事的出发点是非常类似的。
I dare say it was a very similar urge which led me to become involved in great affairs before the war.

所以，就如眼下的情形一样，尽管我们对于世界和平的把控无比脆弱，我也唯愿自己能够竭尽绵薄。”
Then, as now, world peace seemed something we had only the most fragile grasp of, and I wished to do my part.’

“恕我直言，先生，”哈里·史密斯先生道，“不过我的观点跟您略有不同。
‘Excuse me, sir,’ said Mr Harry Smith, ‘but my point was a slightly different one.

对于像您这样的人物来说，要发挥您的影响总是轻而易举的事情。
For the likes of yourself, it's always been easy to exert your influence.

您可以将国内那些最有权势的大人物视作自己的朋友，跟他们称兄道弟。
You can count the most powerful in the land as your friends.

可是像我们村里的这些人呢，先生，我们年复一年可能连一个真正的绅士都见不着—也许应该把卡莱尔医生除外。
But the likes of us here, sir, we can go year in year out and never even lay eyes on a real gentleman – other than maybe Dr Carlisle.

他确实是位一流的医生，可是容我冒昧，他可没有像您这样的人脉。
He's a first-class doctor, but with all respect, he doesn't have connections as such.

我们这些身处穷乡僻壤的人，很容易会忘掉我们身为公民的责任。
It gets easy for us here to forget our responsibility as citizens.

这也正是我这么卖力地投身竞选活动的原因所在。
That's why I work so hard at the campaigning.

不管大家同不同意我的政见—我知道，就算是在眼下的这个小屋里也没有人会同意我说的每一句话—至少我能促使他们开始思考。
Whether people agree or disagree – and I know there's not one soul in this room now who'd agree with everything I say – at least I'll get them thinking.

至少我提醒他们应该想到自己肩负的职责。
At least I'll remind them of their duty.

我们生活于其中的是一个民主国家。
This is a democratic country we're living in.

我们曾为了它而浴血奋战。
We fought for it.

我们全都应该尽我们的本分，做好我们的本职工作。”
We've all got to play our part.’

“真不知道卡莱尔大夫到底出了什么事，”史密斯太太道。
‘I wonder what could have happened to Dr Carlisle,’ Mrs Smith said.

“我相信我们这位绅士应该是需要来一点有教养的谈话了。”
‘I'm sure the gentleman could just about use some educated talk now.’

这话又激起了更多的笑声。
This provoked more laughter.

“实际上，”我说，“尽管非常高兴能跟大家坦诚相见，但我得坦白承认我开始觉得有些疲惫不堪了……”
‘In fact,’ I said, ‘although it has been extremely enjoyable to meet you all, I must confess I'm beginning to feel rather exhausted …’

“那是肯定的，先生，”泰勒太太道，“您一定是已经非常累了。
‘Of course, sir,’ Mrs Taylor said, ‘you must be very tired.

或许也应该再去给您拿一条毯子来。
Perhaps I'll fetch another blanket for you.

这个时候晚上真是冷得多了。”
It's getting much chillier at night now.’

“不，真的不用了，泰勒太太，夜里我肯定会睡得非常舒服的。”
‘No, I assure you, Mrs Taylor, I'll be most comfortable.’

可还没等我从桌边站起来，摩根先生就又道：
But before I could rise from the table, Mr Morgan said:

“我刚才还在想，先生，我们都很喜欢无线电里的有个伙计，叫作莱斯利·曼德雷克的。
‘I just wondered, sir, there's a fellow we like to listen to on the wireless, his name's Leslie Mandrake.

不知道您会不会碰巧认识他？”
I wondered if you'd happened to have met him.’

我回答说并不认识他，正要再次起身准备告退的时候，却又被更多的这种是否认识各色人物的问题给耽搁住了。
I replied that I had not, and was about to make another attempt to retire only to find myself detained by further inquiries regarding various persons I may have met.

于是，一直等到史密斯太太大声宣告又有人来了的时候，我仍旧在桌旁坐着：
I was, then, still seated at the table when Mrs Smith remarked:

“啊，有人来了。
‘Ah, there's someone coming.

我想应该是大夫终于到了。”
I expect that's the doctor at last.’

“我真的该告退了，”我讨饶道。
‘I really ought to be retiring,’ I said.

“我真感觉筋疲力尽了。”
‘I feel quite exhausted.’

“可我敢肯定这次一定是大夫到了，先生，”史密斯太太道。
‘But I'm sure this is the doctor now, sir,’ said Mrs Smith.

“请您一定再多待几分钟。”
‘Do wait a few more minutes.’

她正说话间，有一记敲门声响起，有个声音道：“是我呀，泰勒太太。”
Just as she said this, there came a knock and a voice said: ‘It's just me, Mrs Taylor.’

被迎进来的那位绅士还相当年轻—大概四十开外—又高又瘦；真是够高的，事实上，他进门的时候必须得稍稍弯弯腰才行。
The gentleman who was shown in was still fairly young – perhaps around forty or so – tall and thin; tall enough, in fact, that he was obliged to stoop to enter the doorway of the cottage.

他刚刚向我们大家道了个晚上好，泰勒太太已经忙不迭地跟他说：
No sooner had he bade us all a good evening than Mrs Taylor said to him:

“这位就是我们的绅士，大夫。
‘This is our gentleman here, Doctor.

他的汽车在荆棘山上抛了锚，结果他就不得不忍受哈里没完没了的政治演说了。”
His car's stuck up there on Thornley Bush and he's having to endure Harry's speeches as a result.’

医生走到桌前，向我伸出手来。
The doctor came up to the table and held out his hand to me.

“在下理查德·卡莱尔，”我起身跟他握手时，他笑容可掬地道。
‘Richard Carlisle,’ he said with a cheerful smile as I rose to shake it.

“您的车运气真是糟透了。
‘Rotten bit of luck about your car.

不过，相信您在这里肯定会得到很好的照顾。
Still, trust you're being well looked after here.

恐怕会被照顾得太好了一点，也未可知。”
Looked after rather too well, I imagine.’

“谢谢您，”我回答道。
‘Thank you,’ I replied.

“每个人对我都再好不过了。”
‘Everyone has been most kind.’

“那敢情好，很高兴您能来到敝村。”
‘Well, nice to have you with us.’

卡莱尔大夫在几乎正对着我的桌对面落座。
Dr Carlisle seated himself almost directly across the table from me.

“您是从国内的哪个地方来的？”
‘Which part of the country are you from?’

“牛津郡，”我说，确实，我还真不容易抑制住加上“先生”这个称呼的本能。
‘Oxfordshire,’ I said, and indeed, it was no easy task to suppress the instinct to add ‘sir’.

“好地方啊。
‘Fine part of the country.

我有个叔叔就住在牛津城外。
I have an uncle lives just outside Oxford.

真是个好地方。”
Fine part of the country.’

“这位绅士刚刚才告诉我们，大夫，”史密斯太太道，“他认识丘吉尔先生呢。”
‘The gentleman was just telling us, Doctor,’ Mrs Smith said, ‘he knows Mr Churchill.’

“是吗？
‘Is that so?

我以前认识他的一个侄子，不过早就失去联系了。
I used to know a nephew of his, but I've rather lost touch.

我还从来没有荣幸见这位伟人一面呢。”
Never had the privilege of meeting the great man, though.’

“不光是丘吉尔先生，”史密斯太太继续道。
‘And not only Mr Churchill,’ Mrs Smith went on.

“他还认识艾登先生。
‘He knows Mr Eden.

还有哈利法克斯勋爵呢。”
And Lord Halifax.’

“真的吗？”
‘Really?’

我能感觉到大夫的目光正在仔细地审视我。
I could sense the doctor's eyes examining me closely.

我正准备恰如其分地解释几句，还没等我开口，安德鲁斯先生就对医生道：
I was about to make some appropriate remark, but before I could do so, Mr Andrews said to the doctor:

“这位绅士刚才告诉我们，他想当年曾参与过很多外交事务呢。”
‘Gentleman was just telling us he's had a lot to do with foreign affairs in his time.’

“这是真的吗？”
‘Is that so indeed?’

我感觉卡莱尔大夫又继续观察了我相当长的一段时间。
It seemed to me that Dr Carlisle went on looking at me for an inordinate length of time.

然后他才又重拾愉快的态度，问我道：
Then he regained his cheerful manner and asked:

“这次驾车出游是四处游玩喽？”
‘Touring around for pleasure?’

“大体上算是吧，”我说，轻轻一笑。
‘Principally,’ I said, and gave a small laugh.

“附近可是有不少的乡村胜景。
‘Plenty of nice country around here.

哦，对了，安德鲁斯先生，很抱歉那把锯子还没还给您呢。”
Oh, by the way, Mr Andrews, I'm sorry not to have returned that saw yet.’

“完全不用着急，大夫。”
‘No hurry at all, Doctor.’

有那么一小会儿，大家关注的中心暂时从我身上转移开来，我也终于能够不再说话了。
For a little time, the focus of attention left me and I was able to remain silent.

然后，抓住一个貌似恰当的时机，我站起身来道：“恕我先行告退了。
Then, seizing what seemed a suitable moment, I rose to my feet, saying: ‘Please excuse me.

这真是个最令人愉快的夜晚，不过我现在真的必须告退了。”
It has been a most enjoyable evening, but I really must now retire.’

“真遗憾您已经要离开了，先生，”史密斯太太道。
‘Such a pity you have to retire already, sir,’ Mrs Smith said.

“大夫才刚到。”
‘The doctor's only just arrived.’

哈里·史密斯先生越过他妻子欠身跟卡莱尔大夫说：“我原本还希望这位绅士能对您那些有关大英帝国的观点发表些意见呢，大夫。”
Mr Harry Smith leaned across his wife and said to Dr Carlisle: ‘I was hoping the gentleman would have a few words to say about your ideas on the Empire, Doctor.’

然后他又转向我继续道：“我们的大夫主张帝国内的所有小国都应该独立。
Then turning to me, he went on: ‘Our doctor here's for all kinds of little countries going independent.

我没什么学识，明知道他这个观点是错误的却又没法予以证实。
I don't have the learning to prove him wrong, though I know he is.

不过我一直都有浓厚的兴趣，想听听像您这样的人物对这个问题究竟是怎么看的，先生。”
But I'd have been interested to hear what the likes of yourself would have to say to him on the subject, sir.’

于是卡莱尔大夫的目光似乎再度审视了我一遍。
Yet again, Dr Carlisle's gaze seemed to study me.

然后他说：“是很遗憾，不过我们必须得让这位绅士上床休息了。
Then he said: ‘A pity, but we must let the gentleman go off to bed.

这一天真够辛苦的，我想。”
Had a tiring day, I expect.’

“的确，”我说，再次轻轻一笑，然后开始起身绕过餐桌。
‘Indeed,’ I said, and with another small laugh, began to make my way round the table.

让我尴尬的是，屋里所有的人，包括卡莱尔大夫在内，全都站了起来。
To my embarrassment, everyone in the room, including Dr Carlisle, rose to their feet.

“非常感谢大家，”我面带微笑地致谢道。
‘Thank you all very much,’ I said, smiling.

“泰勒太太，晚餐美味极了。
‘Mrs Taylor, I did enjoy a splendid supper.

祝各位晚安。”
I wish you all a very good night.’

大家齐声回答：“晚安，先生。”
There came a chorus of, ‘Good night, sir,’ in reply.

我都快走出房间的时候，医生的声音又让我停在了门口。
I had almost left the room when the doctor's voice caused me to halt at the door.

“我说，老伙计，”他说道，我转过身，看到他仍旧站着。
‘I say, old chap,’ he said, and when I turned, I saw he had remained on his feet.

“明天一早我就要去一趟斯坦伯里。
‘I have a visit to make in Stanbury first thing in the morning.

我很愿意把你捎到你停车的那个地方。
I'd be happy to give you a lift up to your car.

省得你再走过去。
Save you the walk.

我们还可以顺道从特德·哈达克的修车铺那儿买上一桶汽油。”
And we can pick up a can of petrol from Ted Hardacre's on the way.’

“那真是太感谢啦，”我说。
‘That is most kind,’ I said.

“可我不希望给您增添任何麻烦。”
‘But I don't wish to put you to any trouble.’

“一点都不麻烦。
‘No trouble at all.

七点半你看可以吗？”
Seven thirty all right for you?’

“您这可真是帮了我的大忙了。”
‘That would be most helpful indeed.’

“那好，就七点半了。
‘Right then, seven thirty it is.

请确保您的贵客在七点半前起床并且用完了早饭哦，泰勒太太。”
Make sure your guest's up and breakfasted for seven thirty, Mrs Taylor.’

然后又转向我补充道：“这样的话，我们终究还是可以谈一谈了。
Then turning back to me, he added: ‘So we can have our talk after all.

只是如此一来哈里就没办法心满意足地亲眼目睹我出乖露丑了。”
Though Harry here won't have the satisfaction of witnessing my humiliation.’

大家又是一阵哄笑，再一次互道晚安之后，我才终于能够上楼来到了我的这间避难所。
There was laughter, and another exchange of good nights before I was at last allowed to ascend to the sanctuary of this room.

我确信我无须强调今晚由于大家对我个人那不幸的误解，使我感到多么地惶愧不安。
I trust I need hardly underline the extent of the discomfort I suffered tonight on account of the unfortunate misunderstanding concerning my person.

我现在只能说的是，我实在也是不知道自己该怎么做，才能适时地避免情势演变成那样；因为等我意识到正在发生什么的时候，事态已经进展到我若是把真相挑明势必会让所有人都大为难堪的程度。
I can only say now that in all honesty I fail to see how I might reasonably have prevented the situation developing as it did; for by the stage I had become aware of what was occurring, things had gone so far I could not have enlightened these people without creating much embarrassment all round.

不管怎么说吧，这整件事虽说令人感到遗憾，倒也并没有造成任何实质性的伤害。
In any case, regrettable as the whole business was, I do not see that any real harm has been done.

我反正第二天一早就要离开这些人，而且应该再也不会碰到他们了。
I will, after all, take my leave of these people in the morning and presumably never encounter them again.

再对这件事耿耿于怀看来也就没什么必要了。
There seems little point in dwelling on the matter.

不过，撇开那不幸的误解不谈，今天晚上发生的事件当中也许还真有一两个方面值得让人琢磨一番—即便仅仅是因为如不现在想想清楚，接下来的好几天里势必会让人心神不宁。
However, the unfortunate misunderstanding aside, there are perhaps one or two other aspects to this evening's events which warrant a few moments’ thought – if only because otherwise they may come to niggle one throughout the coming days.

比如说，哈里·史密斯先生对于“尊严”的本质所发表的看法。
For instance, there is the matter of Mr Harry Smith's pronouncements on the nature of ‘dignity’.

在他的那番陈述当中，当然并没有什么值得认真思考的地方。
There is surely little in his statements that merits serious consideration.

诚然，我必须得允许哈里·史密斯先生对于“尊严”这个字眼的应用与我对它的理解是大为不同的。
Of course, one has to allow that Mr Harry Smith was employing the word ‘dignity’ in a quite different sense altogether from my own understanding of it.

即便如此，即便是以他自己的阐释为准，他的那番陈述也肯定是太过理想化和理论化了，不值得认真对待。
Even so, even taken on their own terms, his statements were, surely, far too idealistic, far too theoretical, to deserve respect.

他的观点无疑在一定程度上也有他的道理：在一个像我们这样的国家当中，人民确实有一定的责任去思考国家大事、形成自己的观点。
Up to a point, no doubt, there is some truth in what he says: in a country such as ours, people may indeed have a certain duty to think about great affairs and form their opinions.

可是以真实的生活现状而言，你又怎么能指望普通的老百姓对五花八门的国家事务都有“明确的主见”呢—就像哈里·史密斯先生相当异想天开地宣称此地的村民所做的那样？
But life being what it is, how can ordinary people truly be expected to have ‘strong opinions’ on all manner of things – as Mr Harry Smith rather fancifully claims the villagers here do?

对于老百姓有这样的期许非但是不切实际的，而且我也相当怀疑老百姓那方面果真会有这样的意愿。
And not only are these expectations unrealistic, I rather doubt if they are even desirable.

毕竟，寻常百姓的所学和所知都很有限，要求他们每个人都对于国家的大是大非都能贡献“明确的主见”，这肯定是不明智的。
There is, after all, a real limit to how much ordinary people can learn and know, and to demand that each and every one of them contribute ‘strong opinions’ to the great debates of the nation cannot, surely, be wise.

不管怎么说，如果有人居然自作主张地以这方面的考量来界定个人的“尊严”，那肯定是荒诞不经的。
It is, in any case, absurd that anyone should presume to define a person's ‘dignity’ in these terms.

事有凑巧，我突然想到了一个实例，我相信恰好可以充分说明哈里·史密斯先生的观点所包含的真确性的实际限度。
As it happens, there is an instance that comes to mind which I believe illustrates rather well the real limits of whatever truth may be contained in Mr Harry Smith's views.

这一实例又碰巧是我的亲身经历，是发生在战前大约一九三五年的一个小插曲。
It is, as it happens, an instance from my own experience, an episode that took place before the war, around 1935.

我记得，某一天的深夜—已经过了午夜—爵爷打铃把我叫进了会客室，用完晚餐以后爵爷就一直在那儿款待三位贵宾。
As I recall, I was rung for late one night – it was past midnight – to the drawing room where his lordship had been entertaining three gentlemen since dinner.

那天夜里，我自然是已经有好几次被叫进会客室添补酒水饮料了，而且这几次我都发现宾主正就某些重大的议题进行深入的讨论。
I had, naturally, been called to the drawing room several times already that night to replenish refreshments, and had observed on these occasions the gentlemen deep in conversation over weighty issues.

不过，就在我最后这次进入会客室的时候，宾主却都停下了话头，而且目不转睛地看着我。
When I entered the drawing room on this last occasion, however, all the gentlemen stopped talking and looked at me.

这时候爵爷道：
Then his lordship said:

“请过来一下好吗，史蒂文斯？
‘Step this way a moment, will you, Stevens?

斯潘塞先生想跟你说句话。”
Mr Spencer here wishes a word with you.’

爵爷所说的那位绅士继续盯视了我一会儿，并没有改变他扶手椅里略显慵懒的坐姿。
The gentleman in question went on gazing at me for a moment without changing the somewhat languid posture he had adopted in his armchair.

然后他才说：
Then he said:

“我的朋友，我有个问题想问问你。
‘My good man, I have a question for you.

我们有个一直争执不下的问题需要你的帮助。
We need your help on a certain matter we've been debating.

告诉我，你认为我们跟美国之间的债务状况是导致目前贸易低迷的关键性因素吗？
Tell me, do you suppose the debt situation regarding America is a significant factor in the present low levels of trade?

抑或，你认为这只是个幌子，问题的根源其实是我们放弃了货币的金本位？”
Or do you suppose this is a red herring and that the abandonment of the gold standard is at the root of the matter?’

乍听之下，我自然是对这个问题有些吃惊，不过我很快也就明白了真实的状况；也就是说，很明显对方原本就期望我对这个问题束手无策的。
I was naturally a little surprised by this, but then quickly saw the situation for what it was; that is to say, it was clearly expected that I be baffled by the question.

的确，在我弄明白这是怎么一回事并且想出该怎么回答的这一小会儿中间，我甚至刻意表现出一副苦思冥想的表情，因为我看到在座的那几位绅士正愉快地相视而笑。
Indeed, in the moment or so that it took for me to perceive this and compose a suitable response, I may even have given the outward impression of struggling with the question, for I saw the gentlemen in the room exchange mirthful smiles.

“非常抱歉，先生，”我说，“可对于这个问题我实在是无能为力。”
‘I'm very sorry, sir,’ I said, ‘but I am unable to be of assistance on this matter.’

到了这个时候，我已经对当时的状况心知肚明了，不过那几位绅士仍继续窃笑不已。
I was by this point well on top of the situation, but the gentlemen went on laughing covertly.

然后斯潘塞先生又开口道：
Then Mr Spencer said:

“那么，你也许能在另一个问题上帮到我们。
‘Then perhaps you will help us on another matter.

倘若法国和布尔什维克之间当真达成了裁减军备的协议，你认为这对于欧洲的币值问题到底是利还是弊呢？”
Would you say that the currency problem in Europe would be made better or worse if there were to be an arms agreement between the French and the Bolsheviks?’

“非常抱歉，先生，可对于这个问题我实在是无能为力。”
‘I'm very sorry, sir, but I am unable to be of assistance on this matter.’

“哦，天哪，”斯潘塞先生道。
‘Oh dear,’ said Mr Spencer.

“所以在这方面你也帮不上我们的忙了。”
‘So you can't help us here either.’

又是一阵强忍住的笑声，然后爵爷才说：“很好，史蒂文斯。
There was more suppressed laughter before his lordship said: ‘Very well, Stevens.

那就这样吧。”
That will be all.’

“拜托了，达林顿，我还有一个问题想请教一下我们这位朋友，”斯潘塞先生道。
‘Please, Darlington, I have one more question to put to our good man here,’ Mr Spencer said.

“我亟需他在这个困扰我们许多人的问题上给予帮助，我们也全都认为这个问题对于我们该如何制定外交政策至关重要。
‘I very much wanted his help on the question presently vexing many of us, and which we all realize is crucial to how we should shape our foreign policy.

我的朋友，请一定帮帮我们这个忙。
My good fellow, please come to our assistance.

赖伐尔先生最近针对北非形势的演说的真实意图到底是什么？
What was M. Laval really intending, by his recent speech on the situation in North Africa?

你也认为他这只不过是对于他自己党内民族主义极端分子迎头痛击的一个策略吗？”
Are you also of the view that it was simply a ruse to scupper the nationalist fringe of his own domestic party?’

“很抱歉，先生，可我在这个问题上实在帮不上忙。”
‘I'm sorry, sir, but I am unable to assist in this matter.’

“你们看，先生们，”斯潘塞先生转向其他人道，“在这些问题我们的朋友都无法对我们有所帮助。”
‘You see, gentlemen,’ Mr Spencer said, turning to the others, ‘our man is unable to assist us in these matters.’

这话又引起了一阵笑声，这一次几乎是毫无遮掩的了。
This brought fresh laughter, now barely suppressed.

“然而，”斯潘塞先生继续道，“我们却仍旧坚持要将这个国家的重大决策权交到我们这儿的这位朋友以及像他这样的数百万民众手中。
‘And yet,’ Mr Spencer went on, ‘we still persist with the notion that this nation's decisions be left in the hands of our good man here and to the few million others like him.

这也就难怪，受制于我们目前的议会制，面对众多的难题我们全都一筹莫展了，不是吗？
Is it any wonder, saddled as we are with our present parliamentary system, that we are unable to find any solution to our many difficulties?

那还不如干脆就请母亲联盟的委员会去筹备一场战役得了。”
Why, you may as well ask a committee of the mothers’ union to organize a war campaign.’

这句话引来了一阵毫不掩饰的开心的大笑，爵爷在笑声当中悄声对我说：“谢谢你，史蒂文斯。”我这才得以告退。
There was open, hearty laughter at this remark, during which his lordship muttered: ‘Thank you, Stevens,’ thus enabling me to take my leave.

这当然是一个稍稍令人有些不舒服的场景，不过这在我的职业生涯中根本算不上是我碰到的最难应付、甚至最不寻常的事情，您无疑也会同意，任何一位像样的专业人士都应该有能力镇定自若地予以应对。
While of course this was a slightly uncomfortable situation, it was hardly the most difficult, or even an especially unusual one to encounter in the course of one's duties, and you will no doubt agree that any decent professional should expect to take such events in his stride.

第二天早上，我几乎已经把这个小插曲完全都抛诸脑后了，我正站在弹子房里的一个梯凳上为肖像画掸尘的时候，达林顿勋爵走了进来，对我说：
I had, then, all but forgotten the episode by the following morning, when Lord Darlington came into the billiard room while I was up on a step-ladder dusting portraits, and said:

“你瞧，史蒂文斯，那实在是太可怕了，我们昨天夜里让你承受的那番折磨。”
‘Look here, Stevens, it was dreadful. The ordeal we put you through last night.’

我停下手里的工作，说：“没有的事，先生。
I paused in what I was doing and said: ‘Not at all, sir.

能效犬马之劳，我高兴还来不及呢。”
I was only too happy to be of service.’

“那实在是太可怕了。
‘It was quite dreadful.

我想全都是因为晚餐吃得太尽兴的缘故。
We'd all had rather too good a dinner, I fancy.

请接受我的歉意。”
Please accept my apologies.’

“谢谢您，先生。
‘Thank you, sir.

不过我很高兴地向您保证，昨晚我并没有感觉太过为难。”
But I am happy to assure you I was not unduly inconvenienced.’

爵爷相当疲惫地走到一把皮扶手椅前，坐下来叹了口气。
His lordship walked over rather wearily to a leather armchair, seated himself and sighed.

从我在梯凳上的有利地势望去，我可以清清楚楚地看到他那映照在阳光中的整个瘦高的身形—冬日的阳光透过法式落地窗照进来，几乎洒满了整个房间。
From my vantage point up on my ladder, I could see practically the whole of his long figure caught in the winter sunshine pouring in through the french windows and streaking much of the room.

我记得，就在那一刻，我又一次深刻地认识到，短短几年的时间当中，生活的重压已经让爵爷付出了多么沉重的代价。
It was, as I recall it, one of those moments that brought home how much the pressures of life had taken their toll on his lordship over a relatively small number of years.

他的体格原本就偏于纤瘦，如今已经瘦得让人有些心惊了，瘦得甚至都有些脱了形，他的头发已经过早地变白了，他的面容则显得紧张而又枯槁。
His frame, always slender, had become alarmingly thin and somewhat misshapen, his hair prematurely white, his face strained and haggard.

良久，他望着落地窗外远处那开阔的草坡，然后他才又说：
For a while, he sat gazing out of the french windows towards the downs, then said again:

“那实在是挺可怕的。
‘It really was quite dreadful.

不过你知道，史蒂文斯，斯潘塞先生是想向伦纳德爵士证明一个观点。
But you see, Stevens, Mr Spencer had a point to prove to Sir Leonard.

实际上，如果这对你算得上是种安慰的话，你的确协助我们证实了一个非常重要的观点。
In fact, if it's any consolation, you did assist in demonstrating a very important point.

伦纳德爵士一直都在重复那些老套的废话。
Sir Leonard had been talking a lot of that old-fashioned nonsense.

说什么人民的意志就是最明智的仲裁这类的老生常谈。
About the will of the people being the wisest arbitrator and so on.

你能相信吗，史蒂文斯？”
Would you believe it, Stevens?’

“的确，先生。”
‘Indeed, sir.’

“我们这个国家对已经过时的观念的认识实在是太慢了。
‘We're really so slow in this country to recognize when a thing's outmoded.

其他的大国都已经充分地认识到，要想迎接每个新时代的各种挑战，就必须要扬弃那些陈旧的，有时甚至是广受爱戴的习惯做法。
Other great nations know full well that to meet the challenges of each new age means discarding old, sometimes well-loved methods.

可是我们的大不列颠却不是这个样子。
Not so here in Britain.

仍旧有很多就像昨晚伦纳德爵士那样的论调。
There's still so many talking like Sir Leonard last night.

这也是为什么斯潘塞先生觉得有必要证实一下他的观点的原因所在。
That's why Mr Spencer felt the need to demonstrate his point.

而且我告诉你，史蒂文斯，如果伦纳德爵士这样的人物能够因此而清醒过来，并认真思考一下，那么请相信我，你昨晚上所受的那番折磨就并没有白费。”
And I tell you, Stevens, if the likes of Sir Leonard are made to wake up and think a little, then you can take it from me your ordeal last night was not in vain.’

“的确，先生。”
‘Indeed, sir.’

达林顿爵爷又叹了口气。
Lord Darlington gave another sigh.

“我们总是落在最后，史蒂文斯。
‘We're always the last, Stevens.

总是最后一个死抱着已经过时的体系不放。
Always the last to be clinging on to outmoded systems.

可是我们迟早必须要去面对现实。
But sooner or later, we'll need to face up to the facts.

民主已经是一种属于过去的时代的诉求了。
Democracy is something for a bygone era.

目前的世界太过复杂，已经不适合普选这一类的制度了。
The world's far too complicated a place now for universal suffrage and such like.

因为数不胜数的议会辩论只能导致停滞不前。
For endless members of parliament debating things to a standstill.

在早些年也许还很不错，但在当今的世界呢？
All fine a few years ago perhaps, but in today's world?

斯潘塞先生昨晚是怎么说的来着？
What was it Mr Spencer said last night?

他已经表述得很清楚了。”
He put it rather well.’

“我相信，先生，他是将现今的议会制度比作了母亲联盟的委员会企图去筹备一场战役。”
‘I believe, sir, he compared the present parliamentary system to a committee of the mothers’ union attempting to organize a war campaign.’

“一点没错，史蒂文斯。
‘Exactly, Stevens.

我们这个国家，坦白说，已经远远落后于时代了。
We are, quite frankly, behind the times in this country.

所有有远见卓识的人士都有必要让伦纳德爵士这类的守旧之士认识到这一点。”
And it's imperative that all forward-looking people impress this on the likes of Sir Leonard.’

“的确，先生。”
‘Indeed, sir.’

“我问问你，史蒂文斯。
‘I ask you, Stevens.

我们如今正处在一连串持续不断的危机当中。
Here we are in the midst of a continuing crisis.

这是我跟惠特克先生一起去北方的时候亲眼所见的。
I've seen it with my own eyes when I went north with Mr Whittaker.

人民在受苦。
People are suffering.

普通的正派的劳动人民尤其苦不堪言。
Ordinary, decent working people are suffering terribly.

德国和意大利已经开始以实际行动进行内部整顿。
Germany and Italy have set their houses in order by acting.

我想，包括无耻的布尔什维克也在以他们的方式进行整改。
And so have the wretched Bolsheviks in their own way, one supposes.

就连罗斯福总统，你看看他，他也代表美国人民义无反顾地采取了若干大胆的改革。
Even President Roosevelt, look at him, he's not afraid to take a few bold steps on behalf of his people.

可是你再看看我们这儿，史蒂文斯。
But look at us here, Stevens.

年复一年，情况没有丝毫的改善。
Year after year goes by, and nothing gets better.

我们所做的就唯有争吵、辩论和因循守旧。
All we do is argue and debate and procrastinate.

任何不错的想法还没等经过一半必需的各种委员会的审批，就已经被修改得功效全无了。
Any decent idea is amended to ineffectuality by the time it's gone half-way through the various committees it's obliged to pass through.

为数极少的几位有见识有职权的人士也都被他周围那群无知之辈聒噪得止步不前。
The few people qualified to know what's what are talked to a standstill by ignorant people all around them.

你从中会得出什么样的看法，史蒂文斯？”
What do you make of it, Stevens?’

“这个国家看起来的确正处于一种令人遗憾的境地当中，先生。”
‘The nation does seem to be in a regrettable condition, sir.’

“就是嘛。
‘I'll say.

看看德国和意大利，史蒂文斯。
Look at Germany and Italy, Stevens.

看看强权的领导一旦得到认可，将有多大的作为吧。
See what strong leadership can do if it's allowed to act.

人家那儿可没有这套普选的谬论胡言。
None of this universal suffrage nonsense there.

要是你的房子着了火，你是不会把全家都召集到会客厅里，花上一个钟头的时间来讨论各种逃生办法的，是也不是？
If your house is on fire, you don't call the household into the drawing room and debate the various options for escape for an hour, do you?

这个办法也许曾经是挺不错的，可当今的世界已经变得无比复杂化了。
It may have been all very well once, but the world's a complicated place now.

你不能指望每个路人都通晓政治、经济和国际贸易之类的事务吧。
The man in the street can't be expected to know enough about politics, economics, world commerce and what have you.

况且他又为什么要去通晓这些东西呢？
And why should he?

事实上，你昨晚回答得就很好，史蒂文斯。
In fact, you made a very good reply last night, Stevens.

你是怎么说的来着？
How did you put it?

大意是这不属于你的认识范畴？
Something to the effect that it was not in your realm?

就是啊，它为什么应该属于你的认识范畴呢？”
Well, why should it be?’

在回忆达林顿勋爵当初的这些言论之时，我突然认识到以现在的眼光看来，他的很多观点自然是已经显得相当奇怪—有时候甚至是令人讨厌了。但无可否认的是，他那天早上在弹子房里对我说的那番话中自有某种重要的真确性存在。
It occurs to me in recalling these words that, of course, many of Lord Darlington's ideas will seem today rather odd – even, at times, unattractive. But surely it cannot be denied that there is an important element of truth in these things he said to me that morning in the billiard room.

当然了，期望任何一位管家居然能够令人信服地回答斯潘塞先生那晚向我提出的那类问题，本身就是极为荒谬的，而哈里·史密斯先生那类人居然宣称人的“尊严”就端赖他是否能够对这样的问题具有明确的主见，那自然也就大谬不然了。
Of course, it is quite absurd to expect any butler to be in a position to answer authoritatively questions of the sort Mr Spencer had put to me that night, and the claim of people like Mr Harry Smith that one's ‘dignity’ is conditional on being able to do so can be seen for the nonsense it is.

就让我们把话说清楚吧：一个管家的职责就是提供优质的服务，而不是去瞎掺和那些国家大事。
Let us establish this quite clearly: a butler's duty is to provide good service. It is not to meddle in the great affairs of the nation.

事实上，这一类国家大事无一例外都远远超出了你我这类人的理解范围，像我们这样的人若想做出一点成绩来，就必须认识到最佳的途径便是专注于属于我们认识范畴之内的那些事务；换言之，就是全心全意为那些真正掌握了文明命脉的伟大绅士们提供可能的范围内最好的服务。
The fact is, such great affairs will always be beyond the understanding of those such as you and me, and those of us who wish to make our mark must realize that we best do so by concentrating on what is within our realm; that is to say, by devoting our attention to providing the best possible service to those great gentlemen in whose hands the destiny of civilization truly lies.

这一点貌似显而易见，但我马上就能想出太多相反的实例，即太多的管家至少曾经一度对此并不以为然。
This may seem obvious, but then one can immediately think of too many instances of butlers who, for a time anyway, thought quite differently.

的确，哈里·史密斯先生今晚的那些话颇让我想起整个二三十年代困扰了我们这一代很多人的那种具有误导倾向的理想主义。
Indeed, Mr Harry Smith's words tonight remind me very much of the sort of misguided idealism which beset significant sections of our generation throughout the twenties and thirties.

我指的是在我们这一行中曾经盛行一时的一种观点，它主张任何一位具有严肃抱负的管家都应该以不间断地对其雇主进行重新的评估为己任—审视雇主的行为动机，分析其所持观点可能产生的结果。
I refer to that strand of opinion in the profession which suggested that any butler with serious aspirations should make it his business to be forever reappraising his employer – scrutinizing the latter's motives, analysing the implications of his views.

唯有通过这种途径，这派观点认为，你方能确保自己的服务善为人用，自己的才干得其所哉。
Only in this way, so the argument ran, could one be sure one's skills were being employed to a desirable end.

虽然我在某种程度上愿意认同这种论点当中所包含的理想主义色彩，不过几乎毫无疑问的是，这正如史密斯今晚的那番慷慨陈词一般，是思想误入歧途之后的产物。
Although one sympathizes to some extent with the idealism contained in such an argument, there can be little doubt that it is the result, like Mr Smith's sentiments tonight, of misguided thinking.

你只需看看那些试图将此要求付诸实践的管家们的实际情况，就会看到他们的事业—有些人的事业原本可能前途无量的—结果只能是一事无成。我本人至少就认识两位同行，原本都是颇有些能力的，却从一个雇主跳到另一个雇主，永远感到不满，从来无法在任何地方安顿下来，终于落得个四处漂泊、销声匿迹的结果。
One need only look at the butlers who attempted to put such an approach into practice, and one will see that their careers – and in some cases they were highly promising careers – came to nothing as a direct consequence. I personally knew at least two professionals, both of some ability, who went from one employer to the next, forever dissatisfied, never settling anywhere, until they drifted from view altogether.

出现这样的结果是丝毫都不会令人感到吃惊的。
That this should happen is not in the least surprising.

因为就实际操作的层面而言，你根本就绝无可能一边对雇主采取挑剔批判的态度，同时还能提供优质的服务。
For it is, in practice, simply not possible to adopt such a critical attitude towards an employer and at the same time provide good service.

你的注意力如果因为这些考虑而受到干扰，你不单单是无法满足更高水准的服务所提出的各项要求；更为根本的问题在于，一个总是一心想就其雇主的事务形成他自己“明确的主见”的管家，就必定会缺乏所有优秀的从业者理当具备的一项根本性的素质，那就是忠诚。
It is not simply that one is unlikely to be able to meet the many demands of service at the higher levels while one's attention is being diverted by such matters; more fundamentally, a butler who is forever attempting to formulate his own ‘strong opinions’ on his employer's affairs is bound to lack one quality essential in all good professionals: namely, loyalty.

请不用误解我的意思；我所指的并非是那些平庸的雇主因为留不住高素质的专业人士为自己服务，因而抱怨员工们缺乏的那种盲目的“忠诚”。
Please do not misunderstand me here; I do not refer to the mindless sort of ‘loyalty’ that mediocre employers bemoan the lack of when they find themselves unable to retain the services of high-calibre professionals.

的确，我倒是最不会主张将自己的忠诚轻率地奉献给任何一位碰巧暂时雇用了你的绅士或淑女的那种人。然而，一个管家若是真想对于生命中的任何事情或是任何人具有任何一点价值的话，那就必须要在某个时刻停止无休止的找寻；就必须要有一个时刻，他可以对自己这么说：“这位雇主具备了所有我认为高贵而且可敬的品质。
Indeed, I would be among the last to advocate bestowing one's loyalty carelessly on any lady or gentleman who happens to employ one for a time. However, if a butler is to be of any worth to anything or anybody in life, there must surely come a time when he ceases his searching; a time when he must say to himself: ‘This employer embodies all that I find noble and admirable.

从此以后我将献身于为他提供服务的事业当中。”这才是一种明智的忠诚。
I will hereafter devote myself to serving him.’ This is loyalty intelligently bestowed.

这其中又有什么“有损尊严”的呢？
What is there ‘undignified’ in this?

你只不过是接受了一个不容回避的事实：像你我这样的人是永远都不可能来到一个可以理解当今的世界大事的位置上的，最好的办法无一例外就是要完全信任我们已经认定为明智而又可敬的那位雇主，将我们全副的精力都奉献给为他提供最好的服务上，鞠躬尽瘁，死而后已。
One is simply accepting an inescapable truth: that the likes of you and I will never be in a position to comprehend the great affairs of today's world, and our best course will always be to put our trust in an employer we judge to be wise and honourable, and to devote our energies to the task of serving him to the best of our ability.

看看像马歇尔先生或者莱恩先生这样的管家—两人无疑都是我们这一行里最了不起的人物。
Look at the likes of Mr Marshall, say, or Mr Lane – surely two of the greatest figures in our profession.

我们能够想象马歇尔先生会跟坎伯利勋爵就其最近调任外交部一事进行磋商吗？
Can we imagine Mr Marshall arguing with Lord Camberley over the latter's latest dispatch to the Foreign Office?

我们会因为莱恩先生并没有在伦纳德·格雷爵士每一次发表下院演讲前对其进行诘难的习惯，就对他减少了丝毫的敬佩之情吗？
Do we admire Mr Lane any the less because we learn he is not in the habit of challenging Sir Leonard Gray before each speech in the House of Commons?

我们当然不会。
Of course we do not.

这样的态度当中有什么“有损尊严”的地方，又有什么该受谴责之处呢？
What is there ‘undignified’, what is there at all culpable in such an attitude?

既如此，如果由于时移世易的缘故，达林顿勋爵当初的那些努力已经被证明是受到了误导、甚至可以说是愚蠢之举，我在任何意义上又有什么该当受到责备的地方呢？在我为爵爷服务的这几十年间，一直都是爵爷独自一人在判定是非、权衡利弊，做出决断并一以贯之，而我只是恰如其分地谨守本分，负责处理好我本职范围内的那些事务。
How can one possibly be held to blame in any sense because, say, the passage of time has shown that Lord Darlington's efforts were misguided, even foolish? Throughout the years I served him, it was he and he alone who weighed up evidence and judged it best to proceed in the way he did, while I simply confined myself, quite properly, to affairs within my own professional realm.

就我的工作而言，我可以说已经鞠躬尽瘁、克尽厥职，确实做到了众人或许会认定为“第一流”的水准。如果爵爷的一生及其事业在今天看来，已经至多被当作是一种可悲的浪费，那也实在并非是我的过错—如果我为此而感到任何的遗憾或是羞惭的话，那可就真是违情悖理的苛责了。
And as far as I am concerned, I carried out my duties to the best of my abilities, indeed to a standard which many may consider ‘first rate’. It is hardly my fault if his lordship's life and work have turned out today to look, at best, a sad waste – and it is quite illogical that I should feel any regret or shame on my own account.

# 第四天—下午 | DAY FOUR–AFTERNOON

小康普顿，康沃尔郡
Little Compton, Cornwall

我终于抵达了小康普顿，此时我正在玫瑰花园旅店的餐厅里坐着，刚刚用完了午餐。
I have finally arrived at Little Compton, and at this moment, am sitting in the dining hall of the Rose Garden Hotel having recently finished lunch.

窗外的雨一直下个没完。
Outside, the rain is falling steadily.

这家玫瑰花园旅店虽说称不上豪华，却绝对算得上家常而又舒适，住在这里即使有些额外的花销你也会乐于承担的。
The Rose Garden Hotel, while hardly luxurious, is certainly homely and comfortable, and one cannot begrudge the extra expense of accommodating oneself here.

它就位于村镇广场的一角，位置非常便捷，是一座相当迷人地爬满常春藤的庄园主宅第，我想大约能容纳三十几位客人入住。
It is conveniently situated on one corner of the village square, a rather charming ivy-covered manor house capable of housing, I would suppose, thirty or so guests.

不过，我现在所在的这间“餐厅”却是在主宅一侧加盖的一幢现代风格的附属建筑—一个很长的平顶房间，其特色是房间的两侧各有一排宽大的窗户。
This ‘dining hall’ where I now sit, however, is a modern annexe built to adjoin the main building – a long, flat room characterized by rows of large windows on either side.

从一侧望出去就是村镇广场；另一侧对着的是后花园，这家旅店应该就是由此而得名的。
On one side, the village square is visible; on the other, the rear garden, from which this establishment presumably takes its name.

花园的避风设施看来做得很到位，园内也摆放了几套桌椅，天气晴好的时候应该是个用餐或是享用茶点的理想所在。
The garden, which seems well sheltered from the wind, has a number of tables arranged about it, and when the weather is fine, I imagine it is a very pleasant place to partake of meals or refreshments.

事实上，我知道就在刚才还有几位客人已经开始准备在那儿用餐了，可是天公不作美，被来势汹汹的乌云给扰了清兴。
In fact, I know that a little earlier, some guests had actually commenced lunch out there, only to be interrupted by the appearance of ominous storm clouds.

大约一个钟头前服务员把我迎进餐厅的时候，员工们正急急忙忙地把花园里的桌椅拆除—而那几位刚刚还坐在那儿的客人，包括一位衬衣的领口还塞着一块餐巾的绅士，全都站在旁边，一脸手足无措的表情。
When I was first shown in here an hour or so ago, staff were hurriedly stripping down the garden tables – while their recent occupants, including one gentleman with a napkin still tucked into his shirt, were standing about looking rather lost.

在这之后，暴雨很快就倾盆而至，其势头之猛使得所有的客人一时间全都停止了用餐，惊讶地望着窗外的雨势。
Then, very soon afterwards, the rain had come down with such ferocity that for a moment all the guests seemed to stop eating just to stare out of the windows.

我自己的桌子位于村镇广场的这一侧，所以过去这一个钟头的大部分时间里我都在观望那大雨落在广场以及停在外面的福特和其他几辆汽车上。
My own table is on the village square side of the room and I have thus spent much of the past hour watching the rain falling on the square, and upon the Ford and one or two other vehicles stationed outside.

这会子雨势已经有点稳定了下来，不过仍旧甚大，我也只好打消了出去在村里四处逛逛的雅兴。
The rain has now steadied somewhat, but it is still sufficiently hard as to discourage one from going out and wandering around the village.

当然，我也曾想过不如现在就动身前去拜会肯顿小姐；可是我已经在信上告诉她我将在三点钟登门拜访，所以我觉得如果提前过去给她一个措手不及恐怕殊为不智。
Of course, the possibility has occurred to me that I might set off now to meet Miss Kenton; but then in my letter, I informed her I would be calling at three o'clock, and I do not think it wise to surprise her by arriving any earlier.

看来雨势如果不能尽快停歇的话，我很可能只得待在餐厅里喝喝茶，一直等到合适的时间直接从这儿动身了。
It would seem quite likely then, if the rain does not cease very shortly, that I will remain here drinking tea until the proper time comes for me to set off.

我已经跟侍餐的那位年轻的女招待确认过了，到肯顿小姐目前的住处步行需要一刻钟左右，也就是说我至少还有四十分钟的时间需要消磨。
I have ascertained from the young woman who served me lunch that the address where Miss Kenton is presently residing is some fifteen minutes’ walk away, which implies I have at least another forty minutes to wait.

我也应该顺带说一句，我还没有傻到会对事情万一不谐的可能性没有任何心理准备。
I should say, incidentally, that I am not so foolish as to be unprepared for disappointment.

我其实再清楚不过了，我从未接到肯顿小姐任何表示她很高兴跟我会面的答复。
I am only too aware that I never received a reply from Miss Kenton confirming she would be happy about a meeting.

不过，以我对于肯顿小姐的了解，我倾向于认为大可把没有任何回信视作她的默许；如果会面果真有什么不便的话，我确信她肯定会毫不犹豫地告诉我的。
However, knowing Miss Kenton as I do, I am inclined to think that a lack of any letter can be taken as agreement; were a meeting for any reason inconvenient, I feel sure she would not have hesitated to inform me.

再者说了，我也已经在信中讲清楚了我在这个旅店里订了房间，任何临时的变故都可以通过旅店留话给我；既然并没有任何此类的留言，那我相信我是可以将其视作一切正常的另一重保证的。
Moreover, I had stated in my letter the fact that I had made a reservation at this hotel and that any last-minute message could be left for me here; that no such message was awaiting me can, I believe, be taken as further reason to suppose all is well.

眼下的这瓢泼大雨真是令人始料未及，因为自打离开达林顿府，我实在是三生有幸，每天早上都是阳光明媚的好天气。
This present downpour is something of a surprise, since the day started with the bright morning sunshine I have been blessed with each morning since leaving Darlington Hall.

事实上，今天一开始总的来说也是相当顺遂，早餐享用的是泰勒太太为我准备的产自农场的新鲜鸡蛋和吐司，卡莱尔大夫七点半的时候也依约开车来到门前，我因此得以在任何令人尴尬的交谈得以展开前就辞别了泰勒夫妇—夫妻俩再次坚拒了我给予酬劳的任何提议。
In fact, the day had generally begun well with a breakfast of fresh farm eggs and toast, provided for me by Mrs Taylor, and with Dr Carlisle calling by at seven thirty as promised, I was able to take my leave of the Taylors – who continued not to hear of remuneration – before any further embarrassing conversations had had a chance to develop.

“我给你找到了一罐汽油，”卡莱尔大夫一边请我坐到他那辆路虎车的副驾驶座，一边对我说。
‘I found a can of petrol for you,’ Dr Carlisle announced, as he ushered me into the passenger seat of his Rover.

我对他周到的考虑表示感谢，当我问及油钱的时候，我发现他也是坚决不肯接受。
I thanked him for his thoughtfulness, but when I made inquiries as to payment, I found that he, too, would hear none of it.

“这是什么话，老朋友。
‘Nonsense, old boy.

不过是我在车库后面找到的一点剩油。
It's only a little bit I found at the back of my garage.

不过也该够你开到克罗斯比门了，你可以在那里把油箱加得满满的。”
But it'll be enough for you to reach Crosby Gate and you can fill up good and proper there.’

现在的莫斯科姆村沐浴在朝阳当中，其中心地带是一座由几家小店铺簇拥环绕的教堂，昨天傍晚的时候我曾经在山上看到过它的尖塔。
The village centre of Moscombe, in the morning sunshine, could be seen to be a number of small shops surrounding a church, the steeple of which I had seen from the hill yesterday evening.

不过，我并没有机会细细观赏这个村庄，因为卡莱尔大夫已经迅速地把车开上了一座农场的车道。
I had little chance to study the village, however, for Dr Carlisle turned his car briskly into the driveway of a farmyard.

“这是条捷径，”他说，我们一路经过了几个谷仓和停在那儿的农用车辆。
‘Just a little short cut,’ he said, as we made our way past barns and stationary farm vehicles.

到处一个人影都不见，我们一度被一扇紧闭的大门挡住了去路，大夫说：“抱歉，老伙计，有劳你帮个忙吧。”
There seemed to be no persons present anywhere, and at one point, when we were confronted by a closed gate, the doctor said: ‘Sorry, old chap, but if you wouldn't mind doing the honours.’

我从车上下来，刚要举步朝那扇门走去，附近的一个谷仓里就传出一阵狂怒的狗吠声，我把门打开，再度回到大夫的路虎车上时，不禁长出了一口气。
Getting out, I went to the gate, and as soon as I did so, a furious chorus of barking erupted in one of the barns near by, so that it was with some relief that I rejoined Dr Carlisle again in the front of his Rover.

汽车沿着被大树夹在中间的狭窄山路往上攀爬时，我们交换了几句客套话，他问了我几句昨晚在泰勒家睡得可好之类的话。
We exchanged a few pleasantries as we climbed a narrow road between tall trees, he inquiring after how I had slept at the Taylors and so forth.

然后他相当突然地说道：
Then he said quite abruptly:

“我说，希望你不会认为我太过失礼。
‘I say, I hope you don't think me very rude.

不过你该不会是某户人家的男仆之类的人吧？”
But you aren't a manservant of some sort, are you?’

我得承认，听他这么说，我真是长出了一口气。
I must confess, my overwhelming feeling on hearing this was one of relief.

“您说得没错，先生。
‘I am indeed, sir.

事实上，我是位于牛津附近的达林顿府的管家。”
In fact, I am the butler of Darlington Hall, near Oxford.’

“我想也是。
‘Thought so.

所有那些见过温斯顿·丘吉尔等等的说法。
All that about having met Winston Churchill and so on.

当时我心里想，要么这个家伙是在大吹牛皮，要么就是—然后我突然想到，这倒是个简单的解释。”
I thought to myself, well, either the chap's been lying his head off, or – then it occurred to me, there's one simple explanation.’

卡莱尔大夫继续驾驶着汽车沿陡峭蜿蜒的山路往前开，一边转头向我微微一笑。
Dr Carlisle turned to me with a smile as he continued to steer the car up the steep winding road.

我说：
I said:

“我并没有有意欺骗任何人，先生。
‘It wasn't my intention to deceive anyone, sir.

可是……”
However …’

“哦，无须解释，老伙计。
‘Oh, no need to explain, old fellow.

我很明白那是怎么回事。
I can quite see how it happened.

我的意思是说，你是那种一见之下就会给人深刻印象的样本。
I mean to say, you are a pretty impressive specimen.

本地的这些村民肯定至少要把你当成一位勋爵或是公爵了。”
The likes of the people here, they're bound to take you for at least a lord or a duke.’

大夫开怀大笑。
The doctor gave a hearty laugh.

“时不时地被人误认为一位爵爷，那感觉想必也不坏吧。”
‘It must do one good to be mistaken for a lord every now and then.’

继续往前行驶的过程中，有段时间我们都没再说话。
We travelled on in silence for a few moments.

然后卡莱尔大夫又对我说：“喔，希望你在这段跟我们短暂相处的时间内过得还算愉快。”
Then Dr Carlisle said to me: ‘Well, I hope you enjoyed your little stay with us here.’

“的确非常愉快，谢谢您，先生。”
‘I did very much, thank you, sir.’

“那你觉得莫斯科姆的这些居民怎么样？
‘And what did you make of the citizens of Moscombe?

都还不坏吧，呃？”
Not such a bad bunch, are they?’

“非常迷人，先生。
‘Very engaging, sir.

泰勒先生和太太待人尤其亲切善良。”
Mr and Mrs Taylor were extremely kind.’

“希望你别总是这么叫我‘先生’了，史蒂文斯先生。
‘I wish you wouldn't call me “sir” like that all the time, Mr Stevens.

确实，他们真是相当地不赖。
No, they're not such a bad bunch at all around here.

就我而言，我很乐于就在这里安度余生。”
As far as I'm concerned, I'd happily spend the rest of my life out here.’

我感觉从卡莱尔说这番话的语气当中听出了一丝古怪的意味。
I thought I heard something slightly odd in the way Dr Carlisle said this.

他再度发问的时候，口吻中也流露出一种有些奇怪的审慎意味：
There was, too, a curiously deliberate edge to the way he went on to inquire again:

“这么说，你觉得他们都挺迷人的，呃？”
‘So you found them an engaging bunch, eh?’

“的确，大夫。
‘Indeed, Doctor.

非常意气相投。”
Extremely congenial.’

“那么他们昨晚都跟你说了些什么呢？
‘So what were they all telling you about last night?

希望他们没有用村里那些愚蠢的飞短流长惹得你不胜其烦。”
Hope they didn't bore you silly with all the village gossip.’

“绝对没有，大夫。
‘Not at all, Doctor.

事实上，昨晚的谈话显得相当真诚，还发表了一些非常有趣的观点。”
As a matter of fact, the conversation tended to be rather earnest in tone and some very interesting viewpoints were expressed.’

“哦，你说的是哈里·史密斯，”大夫笑道。
‘Oh, you mean Harry Smith,’ the doctor said with a laugh.

“别把他放在心上。
‘You shouldn't mind him.

他的话听上一小会儿还是挺好玩儿的，不过他的脑子真是乱成了一锅粥。
He's entertaining enough to listen to for a while, but really, he's all in a muddle.

有时候你会觉得他像个共产党，可是他紧接着发表的那些言论，又让他听起来像是个极端保守反动的铁杆托利党。
At times you'd think he was some sort of Communist, then he comes out with something that makes him sound true blue Tory.

而事实是他的脑子就像是一锅粥。”
Truth is, he's all in a muddle.’

“啊，他那些言论听起来非常有趣。”
‘Ah, that is very interesting to hear.’

“昨晚上他对你做的是什么样的演讲？
‘What did he lecture you on last night?

大英帝国？
The Empire?

还是国民医疗？”
The National Health?’

“史密斯先生将自己限制在了更为普遍性的话题上。”
‘Mr Smith restricted himself to more general topics.’

“哦？
‘Oh?

比如说？”
For instance?’

我轻咳了一声。
I gave a cough.

“史密斯先生对于尊严的本质有些自己的思考。”
‘Mr Smith had some thoughts on the nature of dignity.’

“啊哈。
‘I say.

哈里·史密斯居然开始谈论哲理性的话题了。
Now that sounds rather philosophical for Harry Smith.

他怎么会说到这上面去的？”
How the devil did he get on to that?’

“我相信史密斯先生是在强调他在村里开展的竞选工作的重要性。”
‘I believe Mr Smith was stressing the importance of his campaigning work in the village.’

“啊，是吗？”
‘Ah, yes?’

“他一直在向我强调这样一个观点，即莫斯科姆村的居民们对于各种各样的重大政治事件均持有非常明确的主见。”
‘He was impressing upon me the point that the residents of Moscombe held strong opinions on all manner of great affairs.’

“啊，那就对了。
‘Ah, yes.

这听起来才像是哈里·史密斯其人。
Sounds like Harry Smith.

你大概也猜得到，那当然全都是一派胡言。
As you probably guessed, that's all nonsense, of course.

哈里一天到晚地四处鼓动每个人都来关注各种重大议题。
Harry's always going around trying to work everybody up over issues.

不过事实上，大家都宁肯不受他这个打扰。”
But the truth is, people are happier left alone.’

我们又有了片刻的沉默。
We were silent again for a moment or two.

最后，我说：
Eventually, I said:

“恕我冒昧问一句，先生。
‘Excuse me for asking, sir.

不过我可否认为史密斯先生在某种程度上被大家视为了丑角？”
But may I take it Mr Smith is considered something of a comic figure?’

“呣。
‘Hmm.

这么说的话就有点过了，依我看。
That's taking it a little too far, I'd say.

这儿的老百姓的确还有拥有某种政治良知的。
People do have a political conscience of sorts here.

他们感觉他们应该对这对那拥有明确的态度，正如哈里敦促他们去做的那样。
They feel they ought to have strong feelings on this and that, just as Harry urges them to.

可是其实，他们跟任何地方的老百姓没什么两样。
But really, they're no different from people anywhere.

他们只想平平静静地过他们的日子。
They want a quiet life.

哈里总有一大堆主意，想要改变这个那个的，可是说实话，村里头没有一个人希望发生什么剧烈的变动，即便是这些变动有可能会给他们带来好处。
Harry has a lot of ideas about changes to this and that, but really, no one in the village wants upheaval, even if it might benefit them.

这里的老百姓只想不受打扰地去过他们平静的小日子。
People here want to be left alone to lead their quiet little lives.

他们不想受到这样或是那样问题的烦扰。”
They don't want to be bothered with this issue and that issue.’

大夫的语气中带出来的那种厌恶的腔调让我有些吃惊。
I was surprised by the tone of disgust that had entered the doctor's voice.

不过他马上就恢复了常态，短促地一笑，道：
But he recovered himself quickly with a short laugh and remarked:

“从你那侧望去，村子相当漂亮。”
‘Nice view of the village on your side.’

的确，在那一路段，下方不远处的村庄已经清晰可见。
Indeed, the village had become visible some way below us.

当然了，晨光赋予了村庄一种非常不同的面貌，但除此之外，那景色就跟昨天我在傍晚熹微的暮色中第一次看到它时相差无几，从这一点上我也可以猜想得出，我们距离我丢下福特车的地方已经非常近了。
Of course, the morning sunshine gave it a very different aspect, but otherwise it looked much the same view as the one I had first encountered in the evening gloom, and I supposed from this that we were now close to the spot where I had left the Ford.

“史密斯先生的观点似乎是，”我说，“一个人的尊严端赖于是否具有明确的主见之类的。”
‘Mr Smith seemed to be of the view,’ I said, ‘that a person's dignity rested on such things. Having strong opinions and such.’

“啊，不错，尊严。
‘Ah, yes, dignity.

我都忘了。
I was forgetting.

不错，这么说来哈里是想给它下一个哲学上的定义了。
Yes, so Harry was trying to tackle philosophical definitions.

我的天哪。
My word.

我想肯定全都是一派胡言。”
I take it it was a lot of rot.’

“他的那些结论也不一定都能得到大家的认可，先生。”
‘His conclusions were not necessarily those that compelled agreement, sir.’

卡莱尔大夫点了点头，不过似乎已经沉浸在了自己的思绪当中。
Dr Carlisle nodded, but seemed to have become immersed in his own thoughts.

“你知道吗，史蒂文斯先生，”终于，他说道，“我刚来到这个乡下地方的时候，我还是个坚定的社会主义者。
‘You know, Mr Stevens,’ he said, eventually, ‘when I first came out here, I was a committed socialist.

信奉要全心全意地为全体人民服务这类的信条。
Believed in the best services for all the people and all the rest of it.

那时候是四九年。
First came here in ’forty-nine.

社会主义能让老百姓活得有尊严。
Socialism would allow people to live with dignity.

这就是我初来乍到时的信念。
That's what I believed when I came out here.

对不起，你肯定不想听这样的蠢话。”
Sorry, you don't want to hear all this rot.’

他快活地转向我。
He turned to me cheerily.

“那么你呢，老伙计？”
‘What about you, old chap?’

“对不起，您指的是什么，先生？”
‘I'm sorry, sir?’

“你认为尊严到底是怎么一回事。”
‘What do you think dignity's all about?’

我不得不说，这样直截了当的询问还是让我颇感意外的。
The directness of this inquiry did, I admit, take me rather by surprise.

“这是很难用几句话就解释清楚的，先生，”我说。
‘It's rather a hard thing to explain in a few words, sir,’ I said.

“不过我想，这个问题归结为一点，无非就是不要当众宽衣解带。”
‘But I suspect it comes down to not removing one's clothing in public.’

“对不起。
‘Sorry.

什么意思？”
What does?’

“尊严啊，先生。”
‘Dignity, sir.’

“啊。”
‘Ah.’

大夫点了点头，不过看起来有点茫然。
The doctor nodded, but looked a little bemused.

然后他说：“喏，这段路你应该觉得有些熟悉了吧。
Then he said: ‘Now, this road should be familiar to you.

白天看来也可能大为不同了。
Probably looks rather different in the daylight.

啊，这就是那辆车啦？
Ah, is that it there?

我的天哪，实在是太漂亮了！”
My goodness, what a handsome vehicle!’

卡莱尔大夫把车停在福特车的正后方，从车上下来后再次说道：“天哪，多漂亮的车。”
Dr Carlisle pulled up just behind the Ford, got out and said again: ‘My, what a handsome vehicle.’

话音未落，他已经从车上拿出一个漏斗和一桶汽油，非常友善地帮我将汽油注入福特车的油箱。
The next moment he had produced a funnel and a can of petrol and was most kindly assisting me in filling the tank of the Ford.

我原本还担心车子出了更严重的毛病，等我试着点火发动，听到引擎马上发出健康的突突声苏醒了过来，所有的担心也就烟消云散了。
Any fears I had that some deeper trouble was afflicting the Ford were laid to rest when I tried the ignition and heard the engine come to life with a healthy murmur.

我向卡莱尔大夫道了谢，彼此别过，不过之后仍旧跟在他的路虎车后面又沿着蜿蜒的山路走了约莫一英里路，这才分道扬镳。
At this point, I thanked Dr Carlisle and we took leave of each other, though I was obliged to follow the back of his Rover along the twisting hill road for a further mile or so before our routes separated.

大约在九点左右，我越过郡界，进入了康沃尔郡。
It was around nine o’ clock that I crossed the border into Cornwall.

这时距离暴雨倾盆至少还有三个钟头的时间，天空中的云彩仍旧是一片雪白。
This was at least three hours before the rain began and the clouds were still all of a brilliant white.

事实上，今天上午我途经的很多景色都堪称迄今为止我所见到的最为迷人的美景。
In fact, many of the sights that greeted me this morning were among the most charming I have so far encountered.

可不幸的是，我在大部分的时间里却不曾好好地给予它们应得的关注；因为我不妨直说，由于在当天之内我就将与肯顿小姐久别重逢—那些无法预知的意外状况姑且不谈—一念及此，我就不由得有些心神不定。
It was unfortunate, then, that I could not for much of the time give to them the attention they warranted; for one may as well declare it, one was in a condition of some preoccupation with the thought that – barring some unseen complication – one would be meeting Miss Kenton again before the day's end.

还有就是，在开阔的田野间飞速行驶，一连好几英里都不见一个人影和一部车辆，要么就是小心地从那些妙不可言的小村庄中穿村而过，有的只不过是几幢石砌的村舍凑在一起，我发现自己重又沉溺于某些陈年旧事的回忆中不能自拔了。
So it was, then, that while speeding along between large open fields, no human being or vehicle apparent for miles, or else steering carefully through marvellous little villages, some no more than a cluster of a few stone cottages, I found myself yet again turning over certain recollections from the past.

眼下，我坐在小康普顿这家舒适的旅社的餐厅里，手上还有一点时间可供消磨，我一边望着窗外村镇广场人行道上溅起的雨滴，一边忍不住在那些回忆往事的同一轨迹上继续低回徜徉。
And now, as I sit here in Little Compton, here in the dining room of this pleasant hotel with a little time on my hands, watching the rain splashing on the pavements of the village square outside, I am unable to prevent my mind from continuing to wander along these same tracks.

有一个回忆尤其已经在我的脑海中翻腾了整整一上午—或者应该说只是个记忆的片段，记忆中的那一刻出于某种原因在这些年间一直异常鲜明地印刻在我的脑海中。
One memory in particular has preoccupied me all morning – or rather, a fragment of a memory, a moment that has for some reason remained with me vividly through the years.

那个记忆是我独自一人站在肯顿小姐起坐间门外的后廊上；门是关着的，我也并没有正对着那扇门，而是半对着它，为是否应该敲门而举棋不定；因为我记得，我就在那时突然间确信一门之隔、距我仅几码之遥的肯顿小姐实际上正在伤心地哭泣。
It is a recollection of standing alone in the back corridor before the closed door of Miss Kenton's parlour; I was not actually facing the door, but standing with my person half turned towards it, transfixed by indecision as to whether or not I should knock; for at that moment, as I recall, I had been struck by the conviction that behind that very door, just a few yards from me, Miss Kenton was in fact crying.

如我所说的那样，这一刻已经牢牢地嵌入了我的记忆中，同样难以忘怀的还有当时我站在那里内心深处升腾而起的那种特别的感受。
As I say, this moment has remained firmly embedded in my mind, as has the memory of the peculiar sensation I felt rising within me as I stood there like that.

然而，我现在却记不清到底是什么原因导致我那样站在后廊之上了。
However, I am not at all certain now as to the actual circumstances which had led me to be standing thus in the back corridor.

现在看来，之前我在试图理清类似回忆的时候，很有可能将这一幕情景归到了肯顿小姐刚刚收到姨妈死讯之后了；也就是说我将她一个人留在房间里独自悲伤，来到走廊的时候才意识到我并没有向她致以应有的慰唁那一次。
It occurs to me that elsewhere in attempting to gather such recollections, I may well have asserted that this memory derived from the minutes immediately after Miss Kenton's receiving news of her aunt's death; that is to say, the occasion when, having left her to be alone with her grief, I realized out in the corridor that I had not offered her my condolences.

可是如今在经过仔细的思量以后，我相信在这件事上我极有可能有些搞混了；这个记忆当中的片段实际上是源自肯顿小姐的姨妈去世至少几个月后的某个晚上—事实上就是小卡迪纳尔先生相当意外地突然造访达林顿府的那一晚。
But now, having thought further, I believe I may have been a little confused about this matter; that in fact this fragment of memory derives from events that took place on an evening at least a few months after the death of Miss Kenton's aunt – the evening, in fact, when the young Mr Cardinal turned up at Darlington Hall rather unexpectedly.

卡迪纳尔先生的父亲大卫·卡迪纳尔爵士多年来一直都是爵爷的挚友兼同僚，但在我此刻正在讲述的那天晚上，爵士因为一次骑马的事故不幸去世已经有三四年时间了。
Mr Cardinal's father, Sir David Cardinal, had been for many years his lordship's close friend and colleague, but had been tragically killed in a riding accident some three or four years prior to the evening I am now recalling.

与此同时，小卡迪纳尔先生已经开始成为知名的专栏作家，专擅以警言妙句来评论国际事务。
Meanwhile, the young Mr Cardinal had been building something of a name as a columnist, specializing in witty comments on international affairs.

显然，达林顿勋爵颇不喜欢这样的专栏，因为我就记得有好几次，他放下手里的报纸，特意对我说出这样的话来：“小雷吉又在写这些哗众取宠的玩意儿了。
Evidently, these columns were rarely to Lord Darlington's liking, for I can recall numerous instances of his looking up from a journal and saying something like: ‘Young Reggie writing such nonsense again.

幸好他父亲是眼不见心不烦了。”
Just as well his father's not alive to read this.’

不过卡迪纳尔先生的专栏倒是并没有妨碍他在府里常来常往；的确，爵爷从未忘记这位年轻人是他的教子，一直将他视如己出。
But Mr Cardinal's columns did not prevent him being a frequent visitor at the house; indeed, his lordship never forgot that the young man was his godson and always treated him as kin.

尽管如此，卡迪纳尔先生倒也谨守礼仪，从来都不会不提前打个招呼就跑过来用餐，所以那天傍晚我去应门的时候，发现是他双臂抱着公文包站在门外，还是有点吃惊的。
At the same time, it had never been Mr Cardinal's habit to turn up to dinner without any prior warning, and I was thus a little surprised when on answering the door that evening I found him standing there, his briefcase cradled in both arms.

“哦，哈啰，史蒂文斯，你好吗？”
‘Oh, hello, Stevens, how are you?’ he said.

他说。“今晚不巧碰上了点小麻烦，不知道达林顿勋爵会不会许我借宿一夜。”
‘Just happened to be in a bit of a jam tonight and wondered if Lord Darlington would put me up for the night.’

“很高兴再次见到您，先生。
‘It's very nice to see you again, sir.

我这就去禀报爵爷您来了。”
I shall tell his lordship you are here.’

“原本打算住在罗兰先生府上的，可是好像是有了些误会，他们已经去了别的什么地方。
‘I’d intended to stay at Mr Roland's place, but there seems to have been some misunderstanding and they've gone away somewhere.

希望这个时候贸然前来不会造成太大的不便。
Hope it's not too inconvenient a time to call.

我是说，今晚没有任何特别的安排，对吧？”
I mean, nothing special on tonight, is there?’

“我相信，先生，晚饭后爵爷是有几位客人要前来造访的。”
‘I believe, sir, his lordship is expecting some gentlemen to call after dinner.’

“哦，真不走运。
‘Oh, that's bad luck.

我好像来得不是时候。
I seem to have chosen a bad night.

我最好还是低调小心为上。
I'd better keep my head low.

反正今晚我还有几篇稿子要赶出来。”
I've got some pieces I have to work on tonight anyway.’

卡迪纳尔先生指了指他的公文包。
Mr Cardinal indicated his briefcase.

“我这就启禀爵爷说您来了，先生。
‘I shall tell his lordship you are here, sir.

不管怎么说，您正好可以跟他一起用餐。”
You are, in any case, in good time to join him for dinner.’

“那太好了，我正希望如此。
‘Jolly good, I was hoping I might have been.

不过我想莫蒂默太太应该不会很高兴见到我这时候过来蹭饭的。”
But I don't expect Mrs Mortimer's going to be very pleased with me.’

我把小卡迪纳尔先生一个人留在会客室里，前往书房去禀告爵爷，发现他正全神贯注地阅读某一本书。
I left Mr Cardinal in the drawing room and made my way to the study, where I found his lordship working through some pages with a look of deep concentration.

我向他禀告卡迪纳尔先生刚刚到访的时候，意外地发现有一抹不耐烦的神色从他脸上闪过。
When I told him of Mr Cardinal's arrival, a look of surprised annoyance crossed his face.

然后他往椅背上一靠，就像是想弄清楚某个难题。
Then he leaned back in his chair as though puzzling something out.

“告诉卡迪纳尔先生我马上就下去，”他终于道。
‘Tell Mr Cardinal I'll be down shortly,’ he said finally.

“他可以先自己随意消遣一小会儿。”
‘He can amuse himself for a little while.’

我回到楼下后，发现卡迪纳尔先生正相当烦躁不安地在会客室里走来走去，没事找事地细细查看着那些他想必早就已经再熟悉不过的小摆件。
When I returned downstairs, I discovered Mr Cardinal moving rather restlessly around the drawing room examining objects he must long ago have become familiar with.

我传达了爵爷的口信，问他需要我给他送些什么酒水茶点过来。
I conveyed his lordship's message and asked him what refreshment I might bring him.

“哦，眼下就给我来点茶吧，史蒂文斯。
‘Oh, just some tea for now, Stevens.

今晚爵爷要会什么客？”
Who's his lordship expecting tonight?’

“抱歉，先生，这个问题恐怕我帮不到您。”
‘I'm sorry, sir, I'm afraid I am unable to help you.’

“什么都不知道？”
‘No idea at all?’

“很抱歉，先生。”
‘I'm sorry, sir.’

“呣，奇了怪了。
‘Hmm, curious.

哦，好吧。
Oh, well.

今晚最好还是低调小心为上。”
Better keep my head low tonight.’

我记得此后没过多久，我下楼来到了肯顿小姐的起坐间。
It was not long after this, I recall, that I went down to Miss Kenton's parlour.

她正坐在桌前，但她面前的桌子上空空如也，她手上也没有任何的活计；的确，从她的行为举止上可以看得出来，恐怕在我敲门前她已经这个样子坐了有段时间了。
She was sitting at her table, though there was nothing before her and her hands were empty; indeed, something in her demeanour suggested she had been sitting there like that for some time prior to my knocking.

“卡迪纳尔先生来了，肯顿小姐，”我说。
‘Mr Cardinal is here, Miss Kenton,’ I said.

“今晚要睡在他通常使用的那间客房。”
‘He'll be requiring his usual room tonight.’

“好的，史蒂文斯先生。
‘Very good, Mr Stevens.

我外出前会安排好的。”
I shall see to it before I leave.’

“啊，您晚上要外出吗，肯顿小姐？”
‘Ah. You are going out this evening, Miss Kenton?’

“确实要外出，史蒂文斯先生。”
‘I am indeed, Mr Stevens.’

也许是我脸上流露出一丝惊讶，因为她继续道：“您应该记得，史蒂文斯先生，我们半个月前就讨论过的。”
Perhaps I looked a little surprised, for she went on: ‘You will recall, Mr Stevens, we discussed this a fortnight ago.’

“是的，当然了，肯顿小姐。
‘Yes, of course, Miss Kenton.

请您原谅，我只是一时间把这件事给忘了。”
I beg your pardon, it had just slipped my mind for the moment.’

“有什么问题吗，史蒂文斯先生？”
‘Is something the matter, Mr Stevens?’

“没有，肯顿小姐。
‘Not at all, Miss Kenton.

今晚有几位客人要来，不过您没有理由为此就留在府内。”
Some visitors are expected this evening, but there is no reason why your presence will be required.’

“我们确实半个月前就说好我今晚要外出的，史蒂文斯先生。”
‘We did agree to my taking this evening off a fortnight ago, Mr Stevens.’

“那是当然，肯顿小姐。
‘Of course, Miss Kenton.

我必须请您原谅。”
I do beg your pardon.’

我转身要离开，不过在门口又因为肯顿小姐的话停了下来：
I turned to leave, but then I was halted at the door by Miss Kenton saying:

“史蒂文斯先生，我有件事想告诉您。”
‘Mr Stevens, I have something to tell you.’

“是吗，肯顿小姐？”
‘Yes, Miss Kenton?’

“跟我那位旧识相关。
‘It concerns my acquaintance.

今晚我就是要去见他的。”
Who I am going to meet tonight.’

“是这样啊，肯顿小姐。”
‘Yes, Miss Kenton.’

“他已经向我求了婚。
‘He has asked me to marry him.

我想您有权知道这件事。”
I thought you had a right to know that.’

“的确，肯顿小姐。
‘Indeed, Miss Kenton.

这是件很让人高兴的事。”
That is very interesting.’

“我还在考虑是否答应。”
‘I am still giving the matter thought.’

“是吗。”
‘Indeed.’

她低头望了一眼自己的双手，不过目光几乎马上又转回到我的身上。
She glanced down a second at her hands, but then almost immediately her gaze returned to me.

“我那位旧识下个月就要去西南部担任一个新职了。”
‘My acquaintance is to start a job in the West Country as of next month.’

“是吗。”
‘Indeed.’

“我也说了，史蒂文斯先生，求婚的事情我还在考虑。
‘As I say, Mr Stevens, I am still giving the matter some thought.

不过，我想还是应该让您知道这件事。”
However, I thought you should be informed of the situation.’

“对此我非常感激，肯顿小姐。
‘I'm very grateful, Miss Kenton.

衷心祝您度过一个愉快的夜晚。
I do hope you have a pleasant evening.

我这就先告退了。”
Now if you will excuse me.’

应该是在大约二十分钟以后，我又再次碰到了肯顿小姐，而这个时候我正忙着准备晚餐。
It must have been twenty minutes or so later that I encountered Miss Kenton again, this time while I was busy with preparations for dinner.

事实上，我当时捧着一个摆得满满的托盘，正走到后楼梯的中间，突然听到楼下一阵怒冲冲的脚步踩得地板砰砰直响。
In fact, I was half-way up the back staircase, carrying a fully laden tray, when I heard the sound of angry footsteps rattling the floorboards somewhere below me.

我转过身去，看到肯顿小姐正从楼梯下面瞪着眼睛望着我。
Turning, I saw Miss Kenton glaring up at me from the foot of the stairs.

“史蒂文斯先生，据我的理解，您是不是希望今天晚上我留下来当班？”
‘Mr Stevens, do I understand that you are wishing me to remain on duty this evening?’

“没有的事，肯顿小姐。
‘Not at all, Miss Kenton.

正如您指出的，您的确早就已经知会过我了。”
As you pointed out, you did notify me some time ago.’

“可我看得出来，您对于我今晚外出表现得很不高兴。”
‘But I can see you are very unhappy about my going out tonight.’

“恰恰相反，肯顿小姐。”
‘On the contrary, Miss Kenton.’

“你以为在厨房里弄得这么一连片鸡飞狗跳，在我门外头来回这么砰砰砰地跺脚就能让我改变主意了吗？”
‘Do you imagine that by creating so much commotion in the kitchen and by stamping back and forth like this outside my parlour you will get me to change my mind?’

“肯顿小姐，厨房里的那一点点小骚动只不过是因为卡迪纳尔先生最后一刻才赶了来用餐。
‘Miss Kenton, the slight excitement in the kitchen is solely on account of Mr Cardinal coming to dinner at the last moment.

绝对不存在任何您今晚不该外出的理由。”
There is absolutely no reason why you should not go out this evening.’

“我希望把话跟你讲清楚，史蒂文斯先生，不管有没有你的恩准我横竖都是要去的。
‘I intend to go with or without your blessing, Mr Stevens, I wish to make this clear.

我几个礼拜前就已经安排好了。”
I made arrangements weeks ago.’

“的确如此，肯顿小姐。
‘Indeed, Miss Kenton.

而且我想再次向您表明，希望您今晚过得非常愉快。”
And once again, I would wish you a very pleasant evening.’

用餐的时候，两位绅士之间的气氛似乎有点古怪。
At dinner, an odd atmosphere seemed to hang in the air between the two gentlemen.

好一阵子，两人只是一言不发地默默用餐，爵爷尤其显得心不在焉。
For long moments, they ate in silence, his lordship in particular seeming very far away.

有一次，卡迪纳尔先生问道：
At one point, Mr Cardinal said:

“今晚有什么特别之处吗，先生？”
‘Something special tonight, sir?’

“嗯？”
‘Eh?’

“您今晚的客人啊。
‘Your visitors this evening.

不同寻常吗？”
Special?’

“恐怕我不能奉告，我的孩子。
‘Afraid I can't tell you, my boy.

事关绝密。”
Strictly confidential.’

“老天爷。
‘Oh dear.

我想这也就意味着我不该列席打扰了。”
I suppose this means I shouldn't sit in on it.’

“列席什么，我的孩子？”
‘Sit in on what, my boy?’

“今晚将要发生的不论什么事呀！”
‘Whatever it is that's going to take place tonight?’

“哦，那些事你是丝毫都不会感兴趣的。
‘Oh, it wouldn't be of any interest to you.

总之，今晚的事情是最高机密。
In any case, confidentiality is of the utmost.

你是不能与闻的。
Can't have someone like you around.

哦，不，绝对不行。”
Oh no, that wouldn't do at all.’

“哦，老天爷。
‘Oh, dear.

听起来这可真是非同寻常。”
This does sound very special.’

卡迪纳尔先生非常热切地望着爵爷，可是爵爷却自顾继续用起餐来，再没多说一句话。
Mr Cardinal was watching his lordship very keenly, but the latter simply went back to his food without saying anything further.

饭毕，两位绅士退席来到吸烟室喝波尔图、抽雪茄。
The gentlemen retired to the smoking room for port and cigars.

在收拾餐厅同时也为迎接今晚的客人整理会客室的过程中，我不得不几次三番经过吸烟室的大门，于是我也就不可避免地注意到两位绅士跟刚才用餐时的不言不语大为不同，而是开始用相当激烈的语气交谈起来。
In the course of clearing the dining room, and also in preparing the drawing room for the arrival of the evening's visitors, I was obliged to walk repeatedly past the smoking-room doors. It was inevitable, then, that I would notice how the gentlemen, in contrast to their quiet mood at dinner, had begun to exchange words with some urgency.

一刻钟以后，甚至响起了怒气冲冲的声音。
A quarter of an hour later, angry voices were being raised.

当然了，我并没有驻足细听，不过也免不了听到爵爷的喊叫：“可是这不关你的事，我的孩子！
Of course, I did not stop to listen, but I could not avoid hearing his lordship shouting: ‘But that's not your business, my boy!

不关你的事！”
That's not your business!’

两位绅士终于从吸烟室出来的时候，我正在餐厅里。
I was in the dining room when the gentlemen eventually came out.

两人似乎都已经冷静了下来，走过门厅时只听见爵爷对卡迪纳尔先生说：“给我记住了，我的孩子。
They seemed to have calmed themselves, and the only words exchanged as they walked across the hall were his lordship's: ‘Now remember, my boy.

我是信任你的。”
I'm trusting you.’

对此，卡迪纳尔先生恼怒地嘟囔了一声：“是，是，我向您保证。”
To which Mr Cardinal muttered with irritation: ‘Yes, yes, you have my word.’

随后两人的脚步声就分开了，爵爷返回自己的书房，卡迪纳尔先生则走向藏书室。
Then their footsteps separated, his lordship's going towards his study, Mr Cardinal's towards the library.

差不多正好八点半的时候，院子里传来汽车停下的声音。
At almost precisely eight thirty, there came the sound of motor cars pulling up in the courtyard.

我打开大门，迎面是个司机，越过他的肩膀我能看到几位警员正分散到庭院四处不同的位置。
I opened the door to a chauffeur, and past his shoulder I could see some police constables dispersing to various points of the grounds.

下一刻，我就将两位显贵的绅士迎进屋内，爵爷在门厅里迎接，然后马上将来客引入会客室。
The next moment, I was showing in two very distinguished gentlemen, who were met by his lordship in the hall and ushered quickly into the drawing room.

约莫十分钟以后，又传来一辆汽车的声音，我开门迎接的客人是里宾特洛甫先生，德国大使，那时候已经是达林顿府的常客了。
Ten minutes or so later came the sound of another car and I opened the door to Herr Ribbentrop, the German Ambassador, by now no stranger to Darlington Hall.

爵爷前来迎接，两位绅士交换了一个尽在不言中的眼神，然后一起走进了会客室。
His lordship emerged to meet him and the two gentlemen appeared to exchange complicit glances before disappearing together into the drawing room.

几分钟后，我被叫进去为客人提供茶点酒水，四位绅士正在讨论不同种类的香肠各自的优点，至少表面上看来气氛还是挺欢快友好的。
When a few minutes later I was called in to provide refreshments, the four gentlemen were discussing the relative merits of different sorts of sausage, and the atmosphere seemed on the surface at least quite convivial.

这之后，我就在会客室外面的门厅里坚守自己的岗位—也就是门厅的拱门入口处，每逢重要会谈我照例都守在这里—一直到大约两个钟头以后，后门的门铃响了，我才不得不离开那里。
Thereafter I took up my position out in the hall – the position near the entrance arch that I customarily took up during important meetings – and was not obliged to move from it again until some two hours later, when the back door bell was rung.

下楼后，我发现一位警员和肯顿小姐站在一起，要求我证实后者的身份。
On descending, I discovered a police constable standing there with Miss Kenton, requesting that I verify the latter's identity.

“完全是为了安全起见，小姐，绝无冒犯之意，”警官这么嘟囔了一句，重又回到了户外的夜色当中。
‘Just security, miss, no offence meant,’ the officer muttered as he wandered off again into the night.

我在给后门上闩的时候，注意到肯顿小姐在等着我，就说：
As I was bolting the door, I noticed Miss Kenton waiting for me, and said:

“相信您肯定度过了一个愉快的夜晚，肯顿小姐。”
‘I trust you had a pleasant evening, Miss Kenton.’

她没有搭腔，于是，在我们一起穿过黑暗的厨房时我又重复了一遍：“相信您肯定度过了一个愉快的夜晚，肯顿小姐。”
She made no reply, so I said again, as we were making our way across the darkened expanse of the kitchen floor: ‘I trust you had a pleasant evening, Miss Kenton.’

“确实如此，谢谢您，史蒂文斯先生。”
‘I did, thank you, Mr Stevens.’

“听您这么说我很高兴。”
‘I'm pleased to hear that.’

在我身后，肯顿小姐的脚步声突然停了下来，我听到她说：
Behind me, Miss Kenton's footsteps came to a sudden halt, and I heard her say:

“你就没有一丁点的兴趣，想知道今晚在我的旧识和我之间发生过什么事吗，史蒂文斯先生？”
‘Are you not in the least interested in what took place tonight between my acquaintance and I, Mr Stevens?’

“我不是有意要有所怠慢，肯顿小姐，不过我真的必须马上回到楼上去了。
‘I do not mean to be rude, Miss Kenton, but I really must return upstairs without further delay.

事实是，具有全球性重要意义的事件此时就正在府内进行当中呢。”
The fact is, events of a global significance are taking place in this house at this very moment.’

“府里又何曾发生过不重要的事呢，史蒂文斯先生？
‘When are they not, Mr Stevens?

好吧，既然你这么匆忙，我也就直接告诉你得了：我已经接受了我那位旧识的求婚。”
Very well, if you must be rushing off, I shall just tell you that I accepted my acquaintance's proposal.’

“您说什么，肯顿小姐？”
‘I beg your pardon, Miss Kenton?’

“我已经答应嫁给他了。”
‘His proposal of marriage.’

“啊，真的吗，肯顿小姐？
‘Ah, is that so, Miss Kenton?

那就请您允许我向您道贺了。”
Than may I offer you my congratulations.’

“谢谢你，史蒂文斯先生。
‘Thank you, Mr Stevens.

当然，我会很高兴服务至合约期满。
Of course, I will be happy to serve out my notice.

不过，如果您能够稍早些许我离职的话，我们都将不胜感激。
However, should it be that you are able to release me earlier, we would be very grateful.

我的旧识两周后就得前往西南部就任他的新工作了。”
My acquaintance begins his new job in the West Country in two weeks’ time.’

“我将尽我所能及早找到顶替您的人选，肯顿小姐。
‘I will do my best to secure a replacement at the earliest opportunity, Miss Kenton.

现在，我就先失陪了，我必须回到楼上去了。”
Now if you will excuse me, I must return upstairs.’

我重又开始迈步向前，可就在我已经来到通往走廊的门口时，我听见肯顿小姐叫了一声：“史蒂文斯先生，”于是我再度转过身来。
I started to walk away again, but then when I had all but reached the doors out to the corridor, I heard Miss Kenton say: ‘Mr Stevens,’ and thus turned once more.

她仍旧原地未动，因此在跟我讲话时不得不稍稍提高了一下嗓门，结果在黑暗而又空寂如洞窟的厨房内造成了一种相当诡异的回声。
She had not moved, and consequently she was obliged to raise her voice slightly in addressing me, so that it resonated rather oddly in the cavernous spaces of the dark and empty kitchen.

“我是不是该这样认为，”她说，“在我为府里服务这么多年以后，除了你刚才的那句话以外，对于我可能离开的消息你就再没别的可说了？”
‘Am I to take it,’ she said, ‘that after the many years of service I have given in this house, you have no more words to greet the news of my possible departure than those you have just uttered?’

“肯顿小姐，您已经得到了我最为热忱的道贺。
‘Miss Kenton, you have my warmest congratulations.

不过我要再重复一遍，楼上正在进行事关全球意义的重要会谈，我必须回到我的岗位上去了。”
But I repeat, there are matters of global significance taking place upstairs and I must return to my post.’

“你知道吗，史蒂文斯先生，在我的旧识和我的心目当中你一直都是个非常重要的人物。”
‘Did you know, Mr Stevens, that you have been a very important figure for my acquaintance and I?’

“真的吗，肯顿小姐？”
‘Really, Miss Kenton?’

“是的，史蒂文斯先生。
‘Yes, Mr Stevens.

我们经常拿有关于你的逸闻趣事来自娱自乐，消磨时间。
We often pass the time amusing ourselves with anecdotes about you.

比如说，我的旧识就总是喜欢让我向他展示你在往膳食上撒胡椒时把鼻孔捏起来的样子，真是乐此不疲，我的演示总能逗得他哈哈大笑。”
For instance, my acquaintance is always wanting me to show him the way you pinch your nostrils together when you put pepper on your food. That always get him laughing.’

“是吗。”
‘Indeed.’

“他还很是喜欢你对员工们的‘鼓气讲话’。
‘He's also rather fond of your staff “pep-talks”.

我必须说，我已经成为模仿你那些讲话的行家里手了。
I must say, I've become quite expert in re-creating them.

我只消模仿你的口吻说上个两三句，就能让我们俩全都笑破了肚皮。”
I only have to do a few lines to have the pair of us in stitches.’

“是吗，肯顿小姐。
‘Indeed, Miss Kenton.

请您原谅，我必须得告退了。”
Now you will please excuse me.’

我上楼来到门厅里，重又回到我的岗位上。
I ascended to the hall and took up my position again.

不过，还没过五分钟时间，卡迪纳尔先生就出现在藏书室的门口，招手叫我过去。
However, before five minutes had passed, Mr Cardinal appeared in the doorway of the library and beckoned me over.

“真不想麻烦你，史蒂文斯，”他说。
‘Hate to bother you, Stevens,’ he said.

“不过能不能请你再给我拿点白兰地来？
‘But I couldn't trouble you to fetch a little more brandy, could I?

先前你送进来的那一瓶像是已经喝完了。”
The bottle you brought in earlier appears to be finished.’

“您想要什么酒水点心请尽管吩咐，先生。
‘You are very welcome to whatever refreshments you care for, sir.

不过，有鉴于您还有专栏文章须要完成，我很怀疑再喝更多的白兰地是否妥当。”
However, in view of the fact that you have your column to complete, I wonder if it is entirely wise to partake further.’

“我的专栏不会有什么问题的，史蒂文斯。
‘My column will be fine, Stevens.

你就行行好，再给我拿点白兰地来吧。”
Do get me a little more brandy, there's a good fellow.’

“那就好，先生。”
‘Very well, sir.’

过了一会儿，当我回到藏书室的时候，卡迪纳尔先生正在书架前往来徘徊，仔细查看着架上藏书的书脊。
When I returned to the library a moment later, Mr Cardinal was wandering around the shelves, scrutinizing spines.

我能看到旁边的一张书桌上胡乱地散放着好几张稿纸。
I could see papers scattered untidily over one of the writing desks nearby.

我走上前来的时候，卡迪纳尔先生感激地轻呼了一声，扑通一声坐在一把皮质扶手椅上。
As I approached, Mr Cardinal made an appreciative sound and slumped down into a leather armchair.

我走上去，往杯里倒了点白兰地，给他递了过去。
I went over to him, poured a little brandy and handed it to him.

“你知道，史蒂文斯，”他说，“咱们已经是多年的老朋友了，对不对？”
‘You know, Stevens,’ he said, ‘we’ve been friends for some time now, haven't we?’

“的确，先生。”
‘Indeed, sir.’

“每次到这儿来，我都期望着能跟你好好聊一聊。”
‘I always look forward to a little chat with you whenever I come here.’

“是的，先生。”
‘Yes, sir.’

“你愿意跟我一起喝一杯吗？”
‘Won't you care to join me in a little drink?’

“非常感谢您的好意，先生。
‘That's very kind of you, sir.

可是不行，谢谢您，我不能那么做。”
But no, thank you, I won't.’

“我说，史蒂文斯，你在这儿过得好吗？”
‘I say, Stevens, are you all right there?’

“非常之好，谢谢您，先生，”我说着，轻轻一笑。
‘Perfectly all right, thank you, sir,’ I said with a small laugh.

“没觉得有什么不舒服的吗？”
‘Not feeling unwell, are you?’

“有点累吧，也许，不过我身体很好，谢谢您，先生。”
‘A little tired, perhaps, but I'm perfectly fine, thank you, sir.’

“既然如此，你就该坐下来。
‘Well, then, you should sit down.

不管怎么说，我刚才也说了，咱们是多年的老朋友了。
Anyway, as I was saying. We've been friends for some time.

所以我真是应该跟你以诚相待。
So I really ought to be truthful with you.

你无疑也该猜到了，今晚我到这儿来并非纯粹是出于凑巧。
As you no doubt guessed, I didn't happen by tonight just by accident.

是有人向我通风报信的，你知道。
I had a tip-off, you see.

关于今晚这儿将有什么事情发生。就在此刻，就在门厅的那一侧。”
About what's going on. Over there across the hall at this very moment.’

“是的，先生。”
‘Yes, sir.’

“我真心希望你能坐下来，史蒂文斯。
‘I do wish you'd sit down, Stevens.

希望咱们能像朋友那样说说话，你站在那里端着那个该死的托盘就像是随时都打算走开似的。”
I want us to talk as friends, and you're standing there holding that blasted tray looking like you're about to wander off any second.’

“对不起，先生。”
‘I'm sorry, sir.’

我把托盘放下，在卡迪纳尔先生指给我的那把扶手椅上坐下—以一种谦恭得体的坐姿。
I put down my tray and seated myself – in an appropriate posture – on the armchair Mr Cardinal was indicating.

“这样就好些了，”卡迪纳尔先生道。
‘That's better,’ Mr Cardinal said.

“听我说，史蒂文斯，我猜想首相现在就在会客室里吧，是不是？”
‘Now, Stevens, I don't suppose the Prime Minister is presently in the drawing room, is he?’

“首相吗，先生？”
‘The Prime Minister, sir?’

“哦，没关系，你不必告诉我的。
‘Oh, it's all right, you don't have to tell me.

我很理解你的位置相当微妙。”
I understand you're in a tricky position.’

卡迪纳尔先生长叹一声，厌倦地看了一眼散置在书桌上的稿件。
Mr Cardinal heaved a sigh, and looked wearily towards his papers scattered over the desk.

然后他说：
Then he said:

“我应该都无须向你说明我对爵爷怀有的是种什么样的感情，是不是，史蒂文斯？
‘I hardly need to tell you, do I, Stevens, what I feel towards his lordship.

我是说，他对我来说一直就是我的另一位父亲。
I mean to say, he's been like a second father to me.

我都无须向你说明，史蒂文斯。”
I hardly need to tell you, Stevens.’

“是的，先生。”
‘No, sir.’

“我对他关切备至。”
‘I care deeply for him.’

“是的，先生。”
‘Yes, sir.’

“我知道你也一样。
‘And I know you do too.

对他关切备至。
Care deeply for him.

是不是，史蒂文斯？”
Don't you, Stevens?’

“的确如此，先生。”
‘I do indeed, sir.’

“那就好。
‘Good.

这么一来我们也就知道彼此的立场了。
So we both know where we stand.

可是我们必须面对现实。
But let's face facts.

爵爷正身处险境。
His lordship is in deep waters.

而且我眼看着他越陷越深，不瞒你说，我真是忧心忡忡。
I've watched him swimming further and further out and let me tell you, I'm getting very anxious.

他已经深陷其中无法自拔了，你知道吗，史蒂文斯？”
He's out of his depth, you see, Stevens.’

“真的吗，先生？”
‘Is that so, sir?’

“史蒂文斯，你知道就在我们坐在这里闲话的同时正在发生什么吗？
‘Stevens, do you know what is happening at this very moment as we sit here talking?

距我们只有几码之外的地方正在发生什么吗？
What's happening just several yards from us?

就在那个房间里—我并不需要你来证实—英国的首相和德国的大使此刻正共处一室。
Over in that room – and I don't need you to confirm it – there is gathered at this moment the British Prime Minister, the Foreign Secretary and the German Ambassador.

爵爷真是神通广大，居然能促成这样的会谈，而他相信—衷心地相信—他这是在做一件高尚的好事，善莫大焉。
His lordship has worked wonders to bring this meeting about, and he believes – faithfully believes – he's doing something good and honourable.

你可知道爵爷今晚为什么会将这几位大人物邀请到这里吗？
Do you know why his lordship has brought these gentlemen here tonight?

你可知道有什么样的事情正在这里发生吗，史蒂文斯？”
Do you know, Stevens, what is going on here?’

“恐怕我并不知道，先生。”
‘I'm afraid not, sir.’

“恐怕你并不知道。
‘You're afraid not.

告诉我，史蒂文斯，难道你根本就不关心吗？
Tell me, Stevens, don't you care at all?

你就不好奇吗？
Aren't you curious?

老天爷，伙计，这幢房子里正在发生一件至关重要的大事。
Good God, man, something very crucial is going on in this house.

你就一点都不感到好奇吗？”
Aren't you at all curious?’

“处在我这样的位置上是不宜于对这样的事感到好奇的，先生。”
‘It is not my place to be curious about such matters, sir.’

“可是你关心爵爷啊。
‘But you care about his lordship.

你对爵爷关心备至，你刚刚告诉我的。
You care deeply, you just told me that.

如果你真心关心爵爷的话，难道你不该感到担心吗？
If you care about his lordship, shouldn't you be concerned?

不该至少有那么一丁点好奇吗？
At least a little curious?

英国首相和德国大使经由你的雇主的撮合，深夜来到这里进行密谈，你就一点都不感到好奇吗？”
The British Prime Minister and the German Ambassador are brought together by your employer for secret talks in the night, and you're not even curious?’

“我并不是说我不感到好奇，先生。
‘I would not say I am not curious, sir.

可是我的职责本分是不允许我对这类事情表现出好奇的。”
However, it is not my position to display curiosity about such matters.’

“你的职责本分不允许？
‘It's not your position?

啊，我想你肯定是认为这才叫忠心耿耿。
Ah, I suppose you believe that to be loyalty.

对不对？
Do you?

你认为这就是忠心耿耿吗？
Do you think that's being loyal?

如此说来，到底是对爵爷，还是对王国政府忠心耿耿呢？”
To his lordship? Or to the Crown, come to that?’

“很抱歉，先生，我不明白您这话到底是什么意思。”
‘I'm sorry, sir, I fail to see what it is you are proposing.’

卡迪纳尔先生再次长叹一声，摇了摇头。
Mr Cardinal sighed again and shook his head.

“我没什么意思，史蒂文斯。
‘I'm not proposing anything, Stevens.

坦白说吧，我不知道应该怎么做才对。
Quite frankly, I don't know what's to be done.

可是你至少可以感到好奇吧。”
But you might at least be curious.’

他沉吟半晌，在此期间，他像是一直在茫然地紧盯着我们脚边的那一圈地毯。
He was silent for a moment, during which time he seemed to be gazing emptily at the area of carpet around my feet.

“你确定不想跟我一起喝一杯吗，史蒂文斯？”他终于开口说道。
‘Sure you won't join me in a drink, Stevens?’ he said eventually.

“不了，谢谢您，先生。”
‘No, thank you, sir.’

“我还是告诉你吧，史蒂文斯。
‘I'll tell you this, Stevens.

爵爷正被人玩弄于股掌之上呢。
His lordship is being made a fool of.

我已经做了大量的调查，我对于德国当下情势的了解不亚于国内的任何一个人，我告诉你吧，爵爷正在被人愚弄和利用呢。”
I've done a lot of investigating, I know the situation in Germany now as well as anyone in this country, and I tell you, his lordship is being made a fool of.’

我没有搭腔，卡迪纳尔先生则继续茫然地盯着地面。
I gave no reply, and Mr Cardinal went on gazing emptily at the floor.

过了半晌，他才继续道：
After a while, he continued:

“爵爷是个高尚的大好人。
‘His lordship is a dear, dear man.

但事实是，现在的局势他根本就玩不转了。
But the fact is, he is out of his depth.

他被人算计了。
He is being manoeuvred.

纳粹拿他当个小卒子一样摆布。
The Nazis are manoeuvring him like a pawn.

你注意到没有，史蒂文斯？
Have you noticed this, Stevens?

至少这三四年以来情况一直都是这样，你注意到没有？”
Have you noticed this is what has been happening for the last three or four years at least?’

“很抱歉，先生，我并没有注意到曾出现过任何类似的情况。”
‘I'm sorry, sir, I have failed to notice any such development.’

“难道你就从来都没有产生过怀疑？
‘Haven't you ever had a suspicion?

哪怕一丝一毫的疑心：那位希特勒先生，通过我们亲爱的朋友里宾特洛甫先生，一直都把爵爷当作一个小卒子一样摆布利用，就像他摆布柏林他眼皮子底下的其他任何一个小卒子一样易如反掌吗？”
The smallest suspicion that Herr Hitler, through our dear friend Herr Ribbentrop, has been manoeuvring his lordship like a pawn, just as easily as he manoeuvres any of his other pawns back in Berlin?’

“很抱歉，先生，我恐怕并没有注意到曾出现过任何类似的情况。”
‘I'm sorry, sir, I'm afraid I have not noticed any such development.’

“不过我也猜到你大概是不会注意到的，史蒂文斯，因为你从来都不会感到好奇。
‘But I suppose you wouldn't, Stevens, because you're not curious.

你只是任由一切在你眼皮子底下发生，从来也没想过要去看看那正在发生的到底是什么。”
You just let all this go on before you and you never think to look at it for what it is.’

卡迪纳尔先生调整了一下在扶手椅上的坐姿，以便坐得稍微端正一点，有一度他像是一心专注于旁边书桌上尚未完成的文稿。
Mr Cardinal adjusted his position in the armchair so that he was a little more upright, and for a moment he seemed to be contemplating his unfinished work on the desk near by.

然后他又说道：
Then he said:

“爵爷是个真正的绅士。
‘His lordship is a gentleman.

这正是问题的症结所在。
That's what's at the root of it.

他是个绅士，他跟德国人打了一场战争，他出于本能就要对那已经败北的敌人表现出慷慨和友谊。
He's a gentleman, and he fought a war with the Germans, and it's his instinct to offer generosity and friendship to a defeated foe.

这是他的本能。
It's his instinct.

而这就因为他是个绅士，一个货真价实的英国老绅士。
Because he's a gentleman, a true old English gentleman.

这一点你肯定已经看到了，史蒂文斯。
And you must have seen it, Stevens.

你怎么可能看不到呢？
How could you not have seen it?

他们也正是一直都在利用这一点，对他的这种本能进行操控，将这种善良高贵的本能转变成了另一种东西—某种他们可以用来为自己邪恶的目的服务的东西，这一点你怎么可能看不到呢？
The way they've used it, manipulated it, turned something fine and noble into something else – something they can use for their own foul ends?

你肯定已经看到了，史蒂文斯。”
You must have seen it, Stevens.’

卡迪纳尔先生再次紧盯着地板。
Mr Cardinal was once again staring at the floor.

沉吟良久之后才说：
He remained silent for a few moments, then he said:

“我还记得好几年前来这儿的那次，那位美国老兄在这儿的那次。
‘I remember coming here years ago, and there was this American chap here.

我们举行了一次盛大的会议，家父亲自参加了筹备工作。
We were having a big conference, my father was involved in organizing it.

我还记得那位美国老兄比我现在醉得还厉害，他当着所有来宾的面，在宴会上站起来致辞。
I remember this American chap, even drunker than I am now, he got up at the dinner table in front of the whole company.

他指着爵爷的鼻子说他是个外行。
And he pointed at his lordship and called him an amateur.

说他是个拙劣的外行，成事不足败事有余，说他根本就是书生意气不自量力。
Called him a bungling amateur and said he was out of his depth.

唉，我不得不说，史蒂文斯，那位美国老兄还真是说到了点子上。
Well, I have to say, Stevens, that American chap was quite right.

这还真是无可否认的事实。
It's a fact of life.

当今的世界太过险恶，是容不得你那些善良高贵的本能的。
Today's world is too foul a place for fine and noble instincts.

你自己也亲眼看到了，是不是，史蒂文斯？
You've seen it yourself, haven't you, Stevens?

他们是如何操控那些善良和高贵的力量，将它们玩弄于股掌之上的。
The way they've manipulated something fine and noble.

你自己也亲眼看到了，是也不是？”
You've seen it yourself, haven't you?’

“很抱歉，先生，可我不觉得自己已经看到您说的这些情况。”
‘I'm sorry, sir, but I can't say I have.’

“你不觉得已经看到了。
‘You can't say you have.

哦，我真不知道你到底是怎么了，可我一定得采取点行动了。
Well, I don't know about you, but I'm going to do something about it.

要是家父还在的话，他绝对不会袖手旁观，肯定会出面阻止的。”
If Father were alive, he would do something to stop it.’

卡迪纳尔先生再次陷入沉默，而且一度显得极度伤感—可能因为重又勾起了对亡父的回忆。
Mr Cardinal fell silent again and for a moment – perhaps it was to do with his having evoked memories of his late father – he looked extremely melancholy.

“你难道就心安理得吗，史蒂文斯，”他终于道，“眼看着爵爷就这么走到了悬崖边上？”
‘Are you content, Stevens,’ he said finally, ‘to watch his lordship go over the precipice just like that?’

“很抱歉，先生，我不是很明白您到底是什么意思。”
‘I'm sorry, sir, I don't fully understand what it is you're referring to.’

“你不明白，史蒂文斯？
‘You don't understand, Stevens.

好吧，既然我们是朋友，我就把话挑明了吧。
Well, we're friends and so I'll put it to you frankly.

在过去这几年当中，爵爷可能是希特勒先生在本国为他摇旗呐喊，助他实施其宣传诡计最为得力的一枚棋子了。
Over the last few years, his lordship has probably been the single most useful pawn Herr Hitler has had in this country for his propaganda tricks.

尤其是因为他为人真诚、品德高尚，根本认识不到他所作所为的真实性质，那效果就更好了。
All the better because he's sincere and honourable and doesn't recognize the true nature of what he's doing.

仅仅在过去的三年当中，柏林已经跟我国六十余位最有影响力的人士建立起了卓有成效的联系，而爵爷就是最为关键的推动者。
During the last three years alone, his lordship has been crucially instrumental in establishing links between Berlin and over sixty of the most influential citizens of this country.

这对于德方起到的作用可是大了去了。
It's worked beautifully for them.

里宾特洛甫先生几乎可以完全绕过我们的外交部门，直接接触到我们的最高层。
Herr Ribbentrop's been able virtually to bypass our foreign office altogether.

就好像他们搞过那次卑鄙的纽伦堡集会又举办了那届卑鄙的奥运会还嫌不够似的，你知道他们现在正撮弄着爵爷鼓捣什么吗？
And as if their wretched Rally and their wretched Olympic Games weren't enough, do you know what they've got his lordship working on now?

你知道他们现在正在讨论什么吗？”
Do you have any idea what is being discussed now?’

“恐怕我并不知道，先生。”
‘I'm afraid not, sir.’

“爵爷之前一直试图劝说首相本人接受邀请，访问德国与希特勒先生会面。
‘His lordship has been trying to persuade the Prime Minister himself to accept an invitation to visit Herr Hitler.

他真心诚意地认为首相对于德国的现政权存在着严重的误解。”
He really believes there's a terrible misunderstanding on the Prime Minister's part concerning the present German regime.’

“我看不出对于这件事有什么好反对的，先生。
‘I cannot see what there is to object to in that, sir.

爵爷一贯都致力于促进国与国之间更好地相互理解。”
His lordship has always striven to aid better understanding between nations.’

“还不止于此，史蒂文斯。
‘And that's not all, Stevens.

就在这一刻，除非是我大错特错了，就在这一刻，爵爷正在讨论请陛下亲自访德，与希特勒先生会面的构想。
At this very moment, unless I am very much mistaken, at this very moment, his lordship is discussing the idea of His Majesty himself visiting Herr Hitler.

我们的新国王一直都很热衷于纳粹思想，这也不是秘密了。
It's hardly a secret our new king has always been an enthusiast for the Nazis.

哼，显然陛下本人现在都很急切地想接受希特勒先生的邀请呢。
Well, apparently he's now keen to accept Herr Hitler's invitation.

就在这一刻，史蒂文斯，爵爷正在尽一切努力想排除外交部对这一骇人听闻的提议所持的反对意见。”
At this very moment, Stevens, his lordship is doing what he can to remove Foreign Office objections to this appalling idea.’

“很抱歉，先生，可是我看不出爵爷的所作所为当中哪怕有一丝一毫不够高尚的地方。
‘I'm sorry, sir, but I cannot see that his lordship is doing anything other than that which is highest and noblest.

毕竟，他在尽其所能，确保欧洲能继续维持既有的和平。”
He is doing what he can, after all, to ensure that peace will continue to prevail in Europe.’

“告诉我，史蒂文斯，你当真就从没想到过我有可能是对的吗，不管这种可能性有多小？
‘Tell me, Stevens, aren't you struck by even the remote possibility that I am correct?

难道你对我这长篇大套的说法就没有一丝一毫的好奇吗？”
Are you not, at least, curious about what I am saying?’

“很抱歉，先生，可我不得不说，我毫无保留地信任爵爷的判断是最为明智的。”
‘I'm sorry, sir, but I have to say that I have every trust in his lordship's good judgement.’

“任何一个具有明智判断力的人，都不会在莱茵兰事件之后对希特勒先生说的每一句话仍旧坚信不疑了。
‘No one with good judgement could persist in believing anything Herr Hitler says after the Rhineland, Stevens.

爵爷真是螳臂当车，不自量力啊。
His lordship is out of his depth.

哦，老天，这么一来我算是彻底得罪你了。”
Oh dear, now I've really offended you.’

“没有的事，先生，”我说，因为我已经听到会客室传来了叫人的铃声，立刻站起身来。
‘Not at all, sir,’ I said, for I had risen on hearing the bell from the drawing room.

“看来爵爷有事要吩咐。
‘I appear to be required by the gentlemen.

恕我告退了。”
Please excuse me.’

会客室里弥漫着浓厚的雪茄烟雾。
In the drawing room, the air was thick with tobacco smoke.

的确，那几位无比显贵的绅士还在不停地抽着雪茄，每个人的表情都异常肃穆，而且一言不发，爵爷吩咐我去酒窖里取一瓶特别年份的上好波尔图葡萄酒来。
Indeed, the distinguished gentlemen continued to smoke their cigars, solemn expressions on their faces, not uttering a word, while his lordship instructed me to bring up a certain exceptionally fine bottle of port from the cellar.

时值夜静更深，这个时候从后楼梯下楼的脚步声肯定会显得格外响亮，无疑也因此而惊醒了肯顿小姐。
At such a time of night, one's footsteps descending the back staircase are bound to be conspicuous and no doubt they were responsible for arousing Miss Kenton.

因为当我摸黑沿着走廊往前走的时候，通往她起坐间的门打开了，她出现在门口，屋内的灯光照亮了她的身影。
For as I was making my way along the darkness of the corridor, the door to her parlour opened and she appeared at the threshold, illuminated by the light from within.

“没想到您还在这儿，肯顿小姐，”我走近她的时候说。
‘I am surprised to find you still down here, Miss Kenton,’ I said as I approached.

“史蒂文斯先生，我刚才的举动真是太傻了。”
‘Mr Stevens, I was very foolish earlier on.’

“请原谅，肯顿小姐，不过我现在实在没有时间跟您交谈。”
‘Excuse me, Miss Kenton, but I have not time to talk just now.’

“史蒂文斯先生，您千万别把我刚才说的任何话放在心上。
‘Mr Stevens, you mustn't take anything I said earlier to heart.

我真是一时犯了傻。”
I was simply being foolish.’

“您说的任何一句话我都没往心里去，肯顿小姐。
‘I have not taken anything you have said to heart, Miss Kenton.

事实上，我都不记得您指的到底是什么了。
In fact, I cannot recall what it is you might be referring to.

极端重大的事件正在楼上进行当中，我实在没时间停下来跟您闲话客套了。
Events of great importance are unfolding upstairs and I can hardly stop to exchange pleasantries with you.

我建议您还是早点休息吧。”
I would suggest you retire for the night.’

说完后我就忙不迭地继续往前走去，一直等我都快走到厨房大门口的时候，走廊上才重新陷入一片黑暗，这说明肯顿小姐已经关上了她起坐间的房门。
With that I hurried on, and it was not until I had all but reached the kitchen doors that the darkness falling again in the corridor told me Miss Kenton had closed her parlour door.

我在酒窖里没花多长时间就找到那瓶要找的葡萄酒，并为把酒端给客人做好了必要的准备工作。
It did not take me long to locate the bottle in question down in the cellar and to make the necessary preparations for its serving.

如此，就在我跟肯顿小姐短暂邂逅之后不过几分钟的时间，我就再次沿着同样那条走廊往回走了，这次是用托盘端着那瓶酒。
It was, then, only a few minutes after my short encounter with Miss Kenton that I found myself walking down the corridor again on my return journey, this time bearing a tray.

当我走近肯顿小姐的房门时，我从门框的缝隙中透出的灯光知道她还在里面。
As I approached Miss Kenton's door, I saw from the light seeping around its edges that she was still within.

而就是那一刻—我现在可以肯定了—这些年来一直牢牢地铭刻在了我的记忆当中：就是那一刻，我在黑暗的走廊中停下脚步，手里端着托盘，内心深处涌起一种越来越肯定的感觉，就在几码开外、房门的另一侧，肯顿小姐正在哭泣。
And that was the moment, I am now sure, that has remained so persistently lodged in my memory – that moment as I paused in the dimness of the corridor, the tray in my hands, an ever-growing conviction mounting within me that just a few yards away, on the other side of that door, Miss Kenton was at that moment crying.

据我的记忆所及，我的这种确信并没有任何确凿的证据可以证实—我当然也并没有听到任何的哭泣声—然而我记得当时我非常肯定，如果我敲门进去的话，一定会发现她正满面泪痕。
As I recall, there was no real evidence to account for this conviction – I had certainly not heard any sounds of crying – and yet I remember being quite certain that were I to knock and enter, I would discover her in tears.

我不知道我在那儿站立了多久；当时的感觉似乎很久很久，可事实上我想也只不过几秒钟罢了。
I do not know how long I remained standing there; at the time it seemed a significant period, but in reality, I suspect, it was only a matter of a few seconds.

因为，当然了，我的职责是赶快回到楼上去为国内那几位至尊至贵的绅士上酒，我认为自己是不可能耽搁太久的。
For, of course, I was required to hurry upstairs to serve some of the most distinguished gentlemen of the land and I cannot imagine I would have delayed unduly.

我回到会客室的时候，发现那几位绅士的神情仍旧相当严肃。
When I returned to the drawing room, I saw that the gentlemen were still in a rather serious mood.

不过除此之外，我也没有机会对当时的气氛产生其他印象了，因为我刚刚把酒送进去，爵爷就亲自接过托盘，对我说：“谢谢你，史蒂文斯，交给我就行了。
Beyond this, however, I had little chance to gain any impression of the atmosphere, for no sooner had I entered than his lordship was taking the tray from me, saying: ‘Thank you, Stevens, I'll see to it.

这里没你的事了。”
That'll be all.’

再次穿过门厅，我又回到拱门下我惯常的位置，在接下来的一个钟头左右的时间里，也就是直到客人最终离去之前，再没有任何需要我离开这个守望的位置的事情发生。
Crossing the hall again, I took up my usual position beneath the arch, and for the next hour or so, until, that is, the gentlemen finally departed, no event occurred which obliged me to move from my spot.

不过，我侍立在那里的那一个钟头的时间，这些年来却一直异常鲜明地留在我的记忆当中。
Nevertheless, that hour I spent standing there has stayed very vividly in my mind throughout the years.

起先，我的心情—我并不介意承认这一点—是有些低落的。
At first, my mood was – I do not mind admitting it – somewhat downcast.

不过就在我继续伫立在那里的过程中，一件有些奇怪的事情就开始发生了；也就是说，我的内心深处开始涌起一种深切的成就感。
But then as I continued to stand there, a curious thing began to take place; that is to say, a deep feeling of triumph started to well up within me.

我不记得当时我对这种感觉是如何认识的了，不过如今回顾起来，这其中的缘由也就并不难解释了。
I cannot remember to what extent I analysed this feeling at the time, but today, looking back on it, it does not seem so difficult to account for.

毕竟，我刚刚经历了一个极端煎熬的夜晚，而在此期间我竭尽所能，始终都保持了一种“与我的职位相称的高尚尊严”—不仅如此，我还是以一种就连家父也会引以为傲的方式做到这一点的。
I had, after all, just come through an extremely trying evening, throughout which I had managed to preserve a ‘dignity in keeping with my position’ – and had done so, moreover, in a manner even my father might have been proud of.

在门厅的对面，就在我的目光一直停驻其上的那两扇大门后面，就在我刚刚履行过职责的那个房间里，欧洲几位最有权势的绅士正在商讨着我们这块大陆的终极命运。
And there across the hall, behind the very doors upon which my gaze was then resting, within the very room where I had just executed my duties, the most powerful gentlemen of Europe were conferring over the fate of our continent.

有谁还能怀疑，就在那一刻，我已经真真切切地靠近了所有管家都梦寐以求的那个决定着世界运行的轴心？
Who would doubt at that moment that I had indeed come as close to the great hub of things as any butler could wish?

我可以这样认为，当我伫立在那里思量着当晚的那些重大事件时—那些已经发生以及仍在进行当中的事件—在我看来，它们就是我这一生所能达到的所有成就的一个总结。
I would suppose, then, that as I stood there pondering the events of the evening – those that had unfolded and those still in the process of doing so – they appeared to me a sort of summary of all that I had come to achieve thus far in my life.

除此以外，我看不出还能有别的什么原因，可以解释那晚我何以会感受到那种令我如此振奋昂扬的成就感了。
I can see few other explanations for that sense of triumph I came to be uplifted by that night.

# 第六天—傍晚 | DAY SIX–EVENING

韦茅斯
Weymouth

这座海边小镇是多年来我一直都很想来看看的地方。
This seaside town is a place I have thought of coming to for many years.

我已经听很多人谈起曾在这里度过了多么愉快的假期，而西蒙斯太太也在《英格兰奇景》中称其为“连续多日都能让游客游兴不减的小镇”。
I have heard various people talk of having spent a pleasant holiday here, and Mrs Symons too, in The Wonder of England, calls it a ‘town that can keep the visitor fully entertained for many days on end’.

事实上，她还特别提到了这个我流连漫步了半个钟头的码头，尤其推荐游客在傍晚时分码头被各色彩灯照亮的时候前来游赏。
In fact, she makes special mention of this pier, upon which I have been promenading for the past half-hour, recommending particularly that it be visited in the evening when it becomes lit up with bulbs of various colours.

刚刚我才从一位管理人员那里得知，彩灯“很快”就要亮起了，所以我已经决定就坐在这张长椅上，等待这一刻的到来。
A moment ago, I learnt from an official that the lights would be switched on ‘fairly soon’, and so I have decided to sit down here on this bench and await the event.

从我坐的位置可以尽情欣赏海上落日的奇景，尽管还余留着不少的日光—那天是个响晴的好天—我能看到沿海岸一线，这里那里已经开始亮起了灯光。
I have a good view from here of the sun setting over the sea, and though there is still plenty of daylight left – it has been a splendid day – I can see, here and there, lights starting to come on all along the shore.

与此同时，码头上依旧人群熙攘；在我背后，无数脚步踩在木板栈道上发出的咚咚声不绝于耳，从来就没有间断过。
Meanwhile, the pier remains busy with people; behind me, the drumming of numerous footsteps upon these boards continues without interruption.

我是昨天下午来到这个小镇的，决定在这儿多住一晚，好让自己能够从容悠闲地在这儿享受这一整天的时光。
I arrived in this town yesterday afternoon, and have decided to remain a second night here so as to allow myself this whole day to spend in a leisurely manner.

我得说，有一整天的时间不用再开着车在路上走，对我来说委实是种解脱；因为自己开车虽说也是种颇有乐趣的活动，但开久了也是会让人觉得有点疲累的。
And I must say, it has been something of a relief not to be motoring; for enjoyable though the activity can be, one can also get a little weary of it after a while.

不管怎么说，我还有充足的时间可以在这儿多待这么一天；明天一早动身的话，就能确保在下午茶之前返回达林顿府。
In any case, I can well afford the time to remain this further day here; an early start tomorrow will ensure that I am back at Darlington Hall by teatime.

从我和肯顿小姐在小康普顿玫瑰花园旅店的茶室见面到现在，已经有整整两天的时间了。
It is now fully two days since my meeting with Miss Kenton in the tea lounge of the Rose Garden Hotel in Little Compton.

的确，结果我们是在那里见的面，是肯顿小姐主动来旅店找的我，这完全出乎了我的意料。
For indeed, that was where we met, Miss Kenton surprising me by coming to the hotel.

用过午餐以后，我正在无所事事地消磨时间的时候—我也不过就是坐在原地，望着窗外不绝如缕的雨滴—一名旅店的员工来通知我说，前台有位女士想要见我。
I had been whiling away some time after finishing my lunch – I was, I believe, simply staring at the rain from the window by my table – when a member of the hotel staff had come to inform me that a lady was wishing to see me at the reception.

我起身来到外面的大堂，却没有见到任何我认识的人。
I rose and went out into the lobby, where I could see no one I recognized.

这时前台的接待员才跟我说：“那位女士在茶室里等您呢，先生。”
But then the receptionist had said from behind her counter: ‘The lady's in the tea lounge, sir.’

走进接待员指示的那扇门，我发现那间茶室里摆满了各不匹配的扶手椅和临时凑合的茶桌。
Going in through the door indicated, I discovered a room filled with ill-matching armchairs and occasional tables.

除了肯顿小姐以外就再没有别的客人了，我一走进去，她就站起身来，面带微笑把手伸给了我。
There was no one else present other than Miss Kenton, who rose as I entered, smiled and held out her hand to me.

“啊，史蒂文斯先生。
‘Ah, Mr Stevens.

真高兴再次见到您。”
How nice to see you again.’

“本恩太太，非常高兴。”
‘Mrs Benn, how lovely.’

由于下雨的缘故，室内的光线特别昏暗，于是我们就将两把扶手椅挪到了那扇凸窗前。
The light in the room was extremely gloomy on account of the rain, and so we moved two armchairs up close to the bay window.

在灰蒙蒙的天光中肯顿小姐和我就这样谈了两个小时左右的时间，在此期间雨仍旧毫不停歇地落在外面的广场上。
And that was how Miss Kenton and I talked for the next two hours or so, there in the pool of grey light while the rain continued to fall steadily on the square outside.

当然，她是有些显老了，不过起码在我看来，她老得还是非常优雅的。
She had, naturally, aged somewhat, but to my eyes at least, she seemed to have done so very gracefully.

她的身材仍旧很苗条，她的身姿也一如既往地挺拔。
Her figure remained slim, her posture as upright as ever.

她仍旧保持着跟过去一样的姿态，把头高高地仰起，几乎带一点挑衅的神气。
She had maintained, too, her old way of holding her head in a manner that verged on the defiant.

当然了，由于惨淡的日光正落在她的脸上，我也不由得注意到那到处出现的皱纹。
Of course, with the bleak light falling on her face, I could hardly help but notice the lines that had appeared here and there.

不过总体说来，坐在我面前的肯顿小姐看起来还是与这些年来一直留驻在我记忆中的那个人惊人地相似。
But by and large the Miss Kenton I saw before me looked surprisingly similar to the person who had inhabited my memory over these years.

也就是说，总的来说，能够再次见到她真是极其让人高兴的一件事。
That is to say, it was, on the whole, extremely pleasing to see her again.

刚见面的那二十分钟左右，我们的交谈就跟初次见面的陌生人差不多；她礼貌地问起我旅途一路上的情况，我的假期过得是否愉快，我都经过了哪些市镇，参观了哪些名胜，等等。
For the first twenty or so minutes, I would say we exchanged the sort of remarks strangers might; she inquired politely about my journey thus far, how I was enjoying my holiday, which towns and landmarks I had visited and so on.

继续深谈下去的时候，必须说，我想我才开始注意到岁月的流逝对她造成的更大的影响，给她带来的更加微妙的变化。
As we continued to talk, I must say I thought I began to notice further, more subtle changes which the years had wrought on her.

比如说，肯顿小姐显得，在某种程度上，更加迟钝了。
For instance, Miss Kenton appeared, somehow, slower.

也可能这只是随着年岁渐长而变得更加沉静了，在一段时间内我的确也尽量想这样来看待她的这一变化。
It is possible this was simply the calmness that comes with age, and I did try hard for some time to see it as such.

可是我心下仍旧不免觉得，我看到的其实是一种对于生活的厌倦；那曾经让她显得那么生机勃勃，有时甚至显得激动易怒的火花，现在看来已经不复存在了。
But I could not escape the feeling that what I was really seeing was a weariness with life; the spark which had once made her such a lively, and at times volatile person seemed now to have gone.

事实上，时不时地，在她停下话头，在她面色平静下来的时候，我想我在她的面容当中瞥见的是一种类似忧伤的神情。
In fact, every now and then, when she was not speaking, when her face was in repose, I thought I glimpsed something like sadness in her expression.

不过话又说回来了，这也可能完全是我的误解。
But then again, I may well have been mistaken about this.

过了一小会儿，我们乍一相逢，最初那几分钟内出现的那种小小的不自在就已经涣然冰释了，我们的交谈也就转向了更为私人性的话题。
After a little while, what little awkwardness as existed during the initial minutes of our meeting had dissipated completely, and our conversation took a more personal turn.

我们先是叙旧，回忆起过去的众多旧相识，交换了一些有关他们的后续的消息，我得说，这真是最为愉快的时刻。
We spent some time reminiscing about various persons from the past, or else exchanging any news we had concerning them, and this was, I must say, most enjoyable.

不过，与其说是我们交谈的内容，倒不如说是她讲完一段话后的浅浅一笑，她不时流露出来的淡淡的反讽口吻，她肩膀和双手的习惯性姿态，开始明白无误地让我们渐渐重拾起多年前我们交谈时的节奏和习惯。
But it was not so much the content of our conversation as the little smiles she gave at the end of utterances, her small ironic inflexions here and there, certain gestures with her shoulders or her hands, which began to recall unmistakably the rhythms and habits of our conversations from all those years ago.

也大约正是到了这个阶段，我才能够对她的现状有了些确切的认识。
It was around this point, also, that I was able to establish some facts concerning her present circumstances.

比如说，我得知她的婚姻状态并非如她的来信让人感觉到的那般岌岌可危；虽然她的确曾经离家在外住了四五天时间—我收到的来信就是在那期间写的—她其实已经搬回去了，而本恩先生也是非常高兴她终于已经回心转意。
For instance, I learnt that her marriage was not in quite as parlous a state as might have been supposed from her letter; that although she had indeed left her home for a period of four or five days – during which time the letter I had received had been composed – she had returned home and Mr Benn had been very pleased to have her back.

“幸好我们当中至少有一个人能够理智地对待这类事情，”她微笑着说道。
‘It's just as well one of us is sensible about these things,’ she said with a smile.

当然了，我也知道，这种事情我本是无缘置喙的，而且我也应该澄清一下，若不是出于非常重要的工作方面的考虑，您也许还记得，我是做梦也不会想去打探这方面的私事的；我之所以如此不揣冒昧，完全是为解决目前达林顿府里人手缺乏的问题。
I am aware, of course, that such matters were hardly any of my business, and I should make clear I would not have dreamt of prying into these areas were it not that I did have, you might recall, important professional reasons for doing so; that is to say, in respect of the present staffing problems at Darlington Hall.

不管怎么说，肯顿小姐倒似乎完全不介意向我倾诉这方面的私事，而我也将此视为一种令人愉快的证据，足以充分证明我们当年的工作关系是何等密切而又深厚。
In any case, Miss Kenton did not seem to mind at all confiding in me over these matters and I took this as a pleasing testimony to the strength of the close working relationship we had once had.

我记得，那之后肯顿小姐又继续泛泛地谈了几句有关她丈夫的一些情况，他很快就要退休了，时间是早了一点，主要是因为他健康状况欠佳，也因为她女儿已经结了婚，今年秋天就要生孩子了。
For a little while after that, I recall, Miss Kenton went on talking more generally about her husband, who is to retire soon, a little early on account of poor health, and of her daughter, who is now married and expecting a child in the autumn.

事实上，肯顿小姐把她女儿在多塞特郡的地址也给了我，我必须得说，看到她如此热切地要我在返程的途中一定去看看她，我真有点受宠若惊。
In fact, Miss Kenton gave me her daughter's address in Dorset, and I must say, I was rather flattered to see how keen she was that I call in on my return journey.

虽然我向她解释了我不大会途经多塞特郡的那一部分，肯顿小姐却仍竭力敦促于我，说：“凯瑟琳久闻您的大名，史蒂文斯先生。
Although I explained that it was unlikely I would pass through that part of Dorset, Miss Kenton continued to press me, saying: ‘Catherine's heard all about you, Mr Stevens.

她要是能见到您一定会高兴坏了的。”
She'd be so thrilled to meet you.’

我这方面，我则尽我所能向她讲述了一下达林顿府的现状。
For my own part, I tried to describe to her as best I could the Darlington Hall of today.

我试着向她说明法拉戴先生是位多么蔼然可亲的雇主；讲述了宅第本身发生的一些变化，我们做出的一些调整和变更，哪些部分干脆盖上防尘布暂时关闭起来，还有就是目前员工的配置安排。
I attempted to convey to her what a genial employer Mr Farraday is; and I described the changes to the house itself, the alterations and the dust-sheetings, as well as the present staffing arrangements.

我感觉我一谈到达林顿府，肯顿小姐的兴致就明显更高了，很快，我们就一起回忆起各种各样的陈年旧事，一边说一边忍不住开怀畅笑。
Miss Kenton, I thought, became visibly happier when I talked about the house and soon we were recollecting together various old memories, frequently laughing over them.

我记得我们只有一次提到了达林顿勋爵。
Only once do I recall our touching upon Lord Darlington.

我们很开心地回忆起跟小卡迪纳尔先生有关的一两件往事，我也就不得不告诉肯顿小姐，这位年轻的绅士后来在大战当中在比利时阵亡了。
We had been enjoying some recollection or other concerning the young Mr Cardinal, so that I was then obliged to go on to inform Miss Kenton of the gentleman's being killed in Belgium during the war.

而且我也顺势说到了爵爷对这一噩耗的反应：“当然了，爵爷一直将卡迪纳尔先生视若己出，这一噩耗真是让他悲痛欲绝。”
And I had gone on to say: ‘Of course, his lordship was very fond of Mr Cardinal and took it very badly.’

我本不想让令人难过的话题破坏了融洽愉悦的气氛，所以几乎立刻就想把话头转开。
I did not wish to spoil the pleasant atmosphere with unhappy talk, so tried to leave the topic again almost immediately.

可是正如我所担心的，肯顿小姐早已经读到了报刊上对于爵爷的那些诋毁和中伤，尽管它们的意图并没有得逞；不可避免地，她也就借着这个话题稍稍问了我一些具体的情况。
But as I had feared, Miss Kenton had read of the unsuccessful libel action, and inevitably, took the opportunity to probe me a little.

我记得自己原本很不愿意接这个茬儿的，不过最终还是这么对她说：
As I recall, I rather resisted being drawn in, though in the end I did say to her:

“事实上，本恩太太，整个大战期间一直都有不少对于爵爷的可怕的诋毁—尤其是那家报社。国难当头之际，爵爷也就一直都隐忍不发，可是战争结束后，那些含沙射影的攻击仍旧持续不断，喔，爵爷也就觉得没有理由再继续默默地承受下去了。
‘The fact is, Mrs Benn, throughout the war, some truly terrible things had been said about his lordship – and by that newspaper in particular. He bore it all while the country remained in peril, but once the war was over, and the insinuations simply continued, well, his lordship saw no reason to go on suffering in silence.

现在回过头来再看，也许一眼就能看出在那种时候、那样的气候之下跟媒体对簿公堂的风险之大。
It's easy enough to see now, perhaps, all the dangers of going to court just at that time, what with the climate as it was.

可是你也了解爵爷的为人，他真心诚意地相信他一定能讨回公道。
But there you are. His lordship sincerely believed he would get justice.

当然了，其结果反而使那份报纸的发行量激增。
Instead, of course, the newspaper simply increased its circulation.

而爵爷的令名却彻底给毁了。
And his lordship's good name was destroyed for ever.

真的，本恩太太，官司打完以后，爵爷整个人完全垮了。
Really, Mrs Benn, afterwards, well, his lordship was virtually an invalid.

达林顿府里也变得无比萧索。
And the house became so quiet.

那天我把茶点为他端进会客室，结果，唉……那景况真是惨不忍睹。”
I would take him tea in the drawing room and, well … It really was most tragic to see.’

“我非常难过，史蒂文斯先生。
‘I'm very sorry, Mr Stevens.

我根本就不知道情况糟到了这个分上。”
I had no idea things had been so bad.’

“哦，是呀，本恩太太。
‘Oh yes, Mrs Benn.

可是不谈这个了吧。
But enough of this.

我知道你记忆中的达林顿府，还是当初经常举办盛大聚会、贵客盈门的样子。
I know you remember Darlington Hall in the days when there were great gatherings, when it was filled with distinguished visitors.

那才是爵爷应该被记住的样子。”
Now that's the way his lordship deserves to be remembered.’

就像我说的，这是我们唯一提到达林顿勋爵的地方。
As I say, that was the only time we mentioned Lord Darlington.

总的来说，我们谈到的都是非常令人愉快的往事，我们一起在茶室里度过的这两个钟头，应该说是极为愉快的。
Predominantly, we concerned ourselves with very happy memories, and those two hours we spent together in the tea lounge were, I would say, extremely pleasant ones.

我依稀记得在我们畅谈期间还有不少别的客人进来，坐上一会儿就又走了，不过我们的注意力丝毫都没有因此而受到一点分散。
I seem to remember various other guests coming in while we were talking, sitting down for a few moments and leaving again, but they did not distract us in any way at all.

的确，当肯顿小姐抬头看了一眼壁炉架上的时钟，说她必须得回去了的时候，你简直都不敢相信时间已经过去了整整两个钟头。
Indeed, one could hardly believe two whole hours had elapsed when Miss Kenton looked up at the clock on the mantelshelf and said she would have to be returning home.

得知肯顿小姐得冒着雨走到村外还有点距离的公共汽车站以后，我坚持开车送她过去，我们从前台借了一把雨伞，一起来到了外面。
On establishing that she would have to walk in the rain to the bus stop a little way out of the village, I insisted on running her there in the Ford, and so it was that after obtaining an umbrella from the reception desk, we stepped outside together.

我停放福特车的地方，周围已经形成了好几个大水洼，我不得不略为搀扶了一下肯顿小姐，送她来到副驾驶那边的车门前。
Large puddles had formed on the ground around where I had left the Ford, obliging me to assist Miss Kenton a little to allow her to reach the passenger door.

不过，很快我们便沿着村里的主要街道开了下去，途经几家店铺后，我们就来到了开阔的乡野中间。
Soon, however, we were motoring down the village high street, and then the shops had gone and we found ourselves in open country.

坐在我身边的肯顿小姐原本一直都安静地望着车窗外的景色，这时转向我说：
Miss Kenton, who had been sitting quietly watching the passing view, turned to me at this point, saying:

“你干吗那样子顾自微笑呢，史蒂文斯先生？”
‘What are you smiling to yourself about like that, Mr Stevens?’

“哦……你一定要原谅我，本恩太太，不过我正好想起你信上写到的某些事。
‘Oh … You must excuse me, Mrs Benn, but I was just recalling certain things you wrote in your letter.

一开始读到的时候，我还真有点担心，不过现在看来应该是没什么担心的理由了。”
I was a little worried when I read them, but I see now I had little reason to be.’

“哦？
‘Oh?

你指的具体是哪些事呢，史蒂文斯先生？”
What things in particular do you mean, Mr Stevens?’

“哦，倒也没什么特别的，本恩太太。”
‘Oh, nothing in particular, Mrs Benn.’

“哦，史蒂文斯先生，你真的一定要告诉我。”
‘Oh, Mr Stevens, you really must tell me.’

“喔，比方说，本恩太太，”我说着轻轻一笑，“在信上的某一处，你写道—让我想想看—‘我的余生在我面前伸展为一片虚空’。
‘Well, for instance, Mrs Benn,’ I said with a laugh, ‘at one point in your letter, you write – now let me see – “the rest of my life stretches out like an emptiness before me”.

大概是这个意思。”
Some words to that effect.’

“真的吗，史蒂文斯先生？”她说，也轻轻一笑。
‘Really, Mr Stevens,’ she said, also laughing a little.

“我不可能写过这样的话呀。”
‘I couldn't have written any such thing.’

“哦，我敢保证你确实写了，本恩太太。
‘Oh, I assure you you did, Mrs Benn.

我记得非常清楚。”
I recall it very clearly.’

“哦，天哪。
‘Oh dear.

好吧，也许有那么几天我的确有那样的感受。
Well, perhaps there are some days when I feel like that.

不过那很快也就过去了。
But they pass quickly enough.

我可以向你保证，史蒂文斯先生，伸展在我面前的人生并非是一片虚空。
Let me assure you, Mr Stevens, my life does not stretch out emptily before me.

首先，我们的外孙就要出生了。
For one thing, we are looking forward to the grandchild.

这是头一个，后面也许还有好几个呢。”
The first of a few perhaps.’

“是呀，的确。
‘Yes, indeed.

对你们来说真是好极啦。”
That will be splendid for you.’

我们默不作声地又朝前开了几分钟。
We drove on quietly for a few further moments.

然后肯顿小姐道：
Then Miss Kenton said:

“那么你呢，史蒂文斯先生？
‘And what about you, Mr Stevens?

你回到达林顿府以后又会有什么样的未来在等着你呢？”
What does the future hold for you back at Darlington Hall?’

“喔，不管等着我的到底是什么，本恩太太，我知道那都不可能是一片虚空。
‘Well, whatever awaits me, Mrs Benn, I know I'm not awaited by emptiness.

如果是的话倒好了。
If only I were.

可是不会的，只有工作，工作，做不完的工作。”
But oh no, there's work, work and more work.’

说到这里我们俩都笑了。
We both laughed at this.

接着，肯顿小姐指了指前面不远处已经可以望见的一个有顶棚的公共汽车候车亭。
Then Miss Kenton pointed out a bus shelter visible further up the road.

我们驶近以后，她说：
As we approached it, she said:

“你能陪我一起等一会儿吗，史蒂文斯先生？
‘Will you wait with me, Mr Stevens?

公共汽车只要几分钟就会到的。”
The bus will only be a few minutes.’

从车上下来的时候，雨仍不住点地下个不停，我们赶紧钻进了候车亭。
The rain was still falling steadily as we got out of the car and hurried towards the shelter.

那候车厅是石砌的，上面有个瓦顶，看起来相当牢靠，它也确实需要建得牢靠些，因为它毫无遮蔽地矗立在那里，背后就是空旷的田地。
This latter – a stone construct complete with a tiled roof – looked very sturdy, as indeed it needed to be, standing as it did in a highly exposed position against a background of empty fields.

候车亭里面，处处油漆剥落，不过倒是挺干净的。
Inside, the paint was peeling everywhere, but the place was clean enough.

肯顿小姐在候车的长椅上坐下，我则一直在看得见公共汽车驶来的地方站着。
Miss Kenton seated herself on the bench provided, while I remained on my feet where I could command a view of the approaching bus.

公路的对面，目光所及也只有更多的农田；一排电线杆将我的视线一直引向遥远的天边。
On the other side of the road, all I could see were more farm fields; a line of telegraph poles led my eye over them into the far distance.

我们默不作声地等了几分钟以后，我终于还是鼓起勇气说：
After we had been waiting in silence for a few minutes, I finally brought myself to say:

“恕我冒昧，本恩太太。
‘Excuse me, Mrs Benn.

可事实上我们可能很长时间都再也不能见面了。
But the fact is we may not meet again for a long time.

不知道你是否允许我问你一个相当私人性的问题？
I wonder if you would perhaps permit me to ask you something of a rather personal order.

这个问题已经困扰了我相当一段时间了。”
It is something that has been troubling me for some time.’

“当然可以，史蒂文斯先生。
‘Certainly, Mr Stevens.

毕竟我们是有多年交情的老朋友了。”
We are old friends after all.’

“的确，就像你说的，我们是有多年交情的老朋友了。
‘Indeed, as you say, we are old friends.

我就是想问问你，本恩太太—如果你感觉不该告诉我的话，那就不必回答我了。
I simply wished to ask you, Mrs Benn.

可事实是，这些年来你写给我的那些信，尤其是最近这一封，似乎一直在暗示你过得—这话该怎么说呢？
Please do not reply if you feel you shouldn't.

—很不幸福。
But the fact is, the letters I have had from you over the years, and in particular the last letter, have tended to suggest that you are – how might one put it? – rather unhappy.

我就是想知道，你是不是在某种程度上一直都在受到虐待。
I simply wondered if you were being ill-treated in some way.

原谅我这么冒昧直言，可就像我说的，这个问题已经让我担了很长时间的心。
Forgive me, but as I say, it is something that has worried me for some time.

如果我这么大老远地特地来看你，结果却连问都没问你一声，我会感觉非常愚蠢的。”
I would feel foolish had I come all this way and seen you and not at least asked you.’

“史蒂文斯先生，你根本没必要这么难为情。
‘Mr Stevens, there's no need to be so embarrassed.

毕竟我们都是老朋友了，不是吗？
We're old friends, after all, are we not?

事实上，你竟然这么关心我，我真是深受感动。
In fact, I'm very touched you should be so concerned.

在这件事上，你尽可以大放宽心。
And I can put your mind at rest on this matter absolutely.

外子从来没有以任何方式错待过我。
My husband does not mistreat me at all in any way.

他压根儿就不是个性情残忍、脾气暴躁的人。”
He is not in the least a cruel or ill-tempered man.’

“我必须说，本恩太太，听你这么一说真是让我如释重负。”
‘I must say, Mrs Benn, that does take a load from my mind.’

我朝雨中探身出去，寻找公共汽车的踪影。
I leaned forward into the rain, looking for signs of the bus.

“我能看出你并没有非常满意，史蒂文斯先生，”肯顿小姐道。
‘I can see you are not very satisfied, Mr Stevens,’ Miss Kenton said.

“你不相信我的话吗？”
‘Do you not believe me?’

“哦，并非如此，本恩太太，完全不是这么回事。
‘Oh, it's not that, Mrs Benn, not that at all.

只不过事实并没有改变，这些年来你过得好像并不幸福。
It's just that the fact remains, you do not seem to have been happy over the years.

我的意思是说—请恕我直言—你已经有好几次离开你丈夫了。
That is to say – forgive me – you have taken it on yourself to leave your husband on a number of occasions.

如果他并不曾错待于你，那么，喔……这可就真让人想不通，你的不幸福到底是什么原因导致的了。”
If he does not mistreat you, then, well … one is rather mystified as to the cause of your unhappiness.’

我再次望向外面的蒙蒙细雨。
I looked out into the drizzle again.

过了半晌，终于，我听到身后的肯顿小姐说：“史蒂文斯先生，我该如何解释才好呢？
Eventually, I heard Miss Kenton say behind me: ‘Mr Stevens, how can I explain?

连我自己都不太清楚我为什么会做出这样的事情来的。
I hardly know myself why I do such things.

可这是事实，我已经有过三次离家出走了。”
But it's true, I've left three times now.’

她沉吟了片刻，在此期间我继续呆望着马路对面的农田。
She paused a moment, during which time I continued to gaze out towards the fields on the other side of the road.

然后她说道：“我想，史蒂文斯先生，你是想问我是否爱我的丈夫。”
Then she said: ‘I suppose, Mr Stevens, you're asking whether or not I love my husband.’

“说真的，本恩太太，我绝不会自以为是地……”
‘Really, Mrs Benn, I would hardly presume …’

“我觉得我还是应该回答你，史蒂文斯先生。
‘I feel I should answer you, Mr Stevens.

正如你所说，我们可能很多年都无缘再见了。
As you say, we may not meet again for many years.

是的，我确实爱我丈夫。
Yes, I do love my husband.

一开始我并不爱他。
I didn't at first.

一开始我有很长一段时间都并不爱他。
I didn't at first for a long time.

多年前我在离开达林顿府的时候，我其实并没有真切地意识到我的的确确是离开了它。
When I left Darlington Hall all those years ago, I never realized I was really, truly leaving.

我想我只不过是把它当作了又一种激怒你的伎俩，史蒂文斯先生。
I believe I thought of it as simply another ruse, Mr Stevens, to annoy you.

来到这里并且发现自己已经嫁为人妻以后，对我来说不啻于一记晴空霹雳。
It was a shock to come out here and find myself married.

在很长很长的一段时间里面，我都很不幸福，确实是非常不幸福。
For a long time, I was very unhappy, very unhappy indeed.

可是一年一年地就这么过去了，爆发了战争，凯瑟琳也渐渐长大了，有一天我猛然惊觉我是爱我丈夫的。
But then year after year went by, there was the war, Catherine grew up, and one day I realized I loved my husband.

你跟某个人一起生活了这么长时间，你发现你已经习惯跟他在一起了。
You spend so much time with someone, you find you get used to him.

他是个善良、可靠的好人，所以是的，史蒂文斯先生，我已经渐渐爱上了他。”
He's a kind, steady man, and yes, Mr Stevens, I've grown to love him.’

肯顿小姐再一次陷入沉默，过了一会儿她才继续道：
Miss Kenton fell silent again for a moment. Then she went on:

“不过，当然了，这也并不意味着偶尔就不会有这种的时候—在极其孤独的时刻—你会想要对自己说：‘我的人生中犯了个多么可怕的错误。’
‘But that doesn't mean to say, of course, there aren't occasions now and then – extremely desolate occasions – when you think to yourself: “What a terrible mistake I've made with my life.”

而且你会开始想象一种不同的生活，一种你原本可能拥有的更好的生活。
And you get to thinking about a different life, a better life you might have had.

比方说吧，我开始想象一种本来可以跟你在一起的生活，史蒂文斯先生。
For instance, I get to thinking about a life I might have had with you, Mr Stevens.

而我想正是在这样的时候，我会为一些琐事而怒不可遏，而离家出走。
And I suppose that's when I get angry over some trivial little thing and leave.

不过我每次这样做了以后，要不了多久我也就会明白过来—我的本分就是跟我丈夫在一起。
But each time I do so, I realize before long – my rightful place is with my husband.

毕竟，时光是不能倒流的。
After all, there's no turning back the clock now.

一个人是不能永远沉溺在可能的状况中无法自拔的。
One can't be forever dwelling on what might have been.

你应该明白你所拥有的并不比大多数人更差，或许还更好些，应该要心存感激才是。”
One should realize one has as good as most, perhaps better, and be grateful.’

我想当时我并没有马上做出回应，因为我是颇花了一点时间才完全消化了肯顿小姐所说的这一番话的。不仅如此，您应该也能体会，这番话里隐含的深意也真是让我心有戚戚。
I do not think I responded immediately, for it took me a moment or two to fully digest these words of Miss Kenton. Moreover, as you might appreciate, their implications were such as to provoke a certain degree of sorrow within me.

的确—我又何必再遮遮掩掩？—在那一刻，我的心都碎了。
Indeed – why should I not admit it? – at that moment, my heart was breaking.

不过，很快地，我还是转向她，面带微笑地说：
Before long, however, I turned to her and said with a smile:

“你说得对，本恩太太。
‘You're very correct, Mrs Benn.

诚如你所说的，时光是不能倒流的，已经来不及了。
As you say, it is too late to turn back the clock.

的确，我要是知道正是这样的想法造成了你和你丈夫的不幸的话，我是绝对没办法心安理得的。
Indeed, I would not be able to rest if I thought such ideas were the cause of unhappiness for you and your husband.

我们每个人都应该，正如你指出的，对我们实际上拥有的东西心怀感激。
We must each of us, as you point out, be grateful for what we do have.

而且从你告诉我的情况来看，本恩太太，你是有理由感到满意的。
And from what you tell me, Mrs Benn, you have reason to be contented.

事实上，容我冒昧多嘴，随着本恩先生即将退休，还有马上就要降生的小外孙，你跟本恩先生以后还有好多无比幸福的岁月在等着你们。
In fact I would venture, what with Mr Benn retiring, and with grandchildren on the way, that you and Mr Benn have some extremely happy years before you.

你可千万不要再让任何这类愚蠢的想法横亘在你自己和你应得的幸福之间了。”
You really mustn't let any more foolish ideas come between yourself and the happiness you deserve.’

“那是当然，你说得对，史蒂文斯先生。
‘Of course, you're right, Mr Stevens.

真是感谢你的良苦用心。”
You're so kind.’

“啊，本恩太太，公共汽车好像开过来了。”
‘Ah, Mrs Benn, that appears to be the bus coming now.’

我走出候车亭招手示意停车，肯顿小姐站起身来到候车亭边。
I stepped outside and signalled, while Miss Kenton rose and came to the edge of the shelter.

直到汽车停了下来，我才又偷觑了肯顿小姐一眼，结果发现她眼里盈满了泪水。
Only as the bus pulled up did I glance at Miss Kenton and perceived that her eyes had filled with tears.

我微笑着说：
I smiled and said:

“好了，本恩太太，你自己一定要好好保重。
‘Now, Mrs Benn, you must take good care of yourself.

大家都说，退休以后才是夫妻生活中最美好的那一段。
Many say retirement is the best part of life for a married couple.

你一定要尽你的所能使这些岁月成为你自己和尊夫的幸福时光。
You must do all you can to make these years happy ones for yourself and your husband.

我们也许再也无缘见面了，本恩太太，所以我请求你务必把我的这番话记在心上。”
We may never meet again, Mrs Benn, so I would ask you to take good heed of what I am saying.’

“我会的，史蒂文斯先生，谢谢你。
‘I will, Mr Stevens, thank you. And thank you for the lift.

也谢谢你特意开车送我这一程。
It was so very kind of you.

这次能再次见到你真是太高兴了。”
It was so nice to see you again.’

“再次见到你真是非常非常高兴，本恩太太。”
‘It was a great pleasure to see you again, Mrs Benn.’

码头上的彩灯已经亮了起来，我身后的人群刚刚发出一阵大声的欢呼表示欢迎。
The pier lights have been switched on and behind me a crowd of people have just given a loud cheer to greet this event.

还有不少天光尚存—海面上的天空已经变为浅红色—不过看来过去半个钟头之内聚集在码头上的人群都希望夜色快点降临。
There is still plenty of daylight left – the sky over the sea has turned a pale red – but it would seem that all these people who have been gathering on this pier for the past half-hour are now willing night to fall.

我想，这倒正好印证了刚才还跟我坐在一条长凳上的那个人的观点，我们之间曾有过一段略显奇特的交谈。
This confirms very aptly, I suppose, the point made by the man who until a little while ago was sitting here beside me on this bench, and with whom I had my curious discussion.

他的说法是，对于好多人而言，傍晚是一天当中最好的部分，是他们最期盼的一段时光。
His claim was that for a great many people, the evening was the best part of the day, the part they most looked forward to.

依我看来，这种说法似乎也不无几分道理，要不然的话，码头上的这些人又怎么会只不过因为灯光亮起，就不约而同地欢呼雀跃呢？
And as I say, there would appear to be some truth in this assertion, for why else would all these people give a spontaneous cheer simply because the pier lights have come on?

当然了，那人也只是拿黄昏来打个比方，不过眼看着他的话这么快就在现实中得到了应验，也实在有趣得紧。
Of course, the man had been speaking figuratively, but it is rather interesting to see his words borne out so immediately at the literal level.

我想在我注意到他之前，他应该已经在我旁边坐了有一会儿了，因为我只顾沉溺在两天前跟肯顿小姐见面的回忆当中难以自拔了。
I would suppose he had been sitting here next to me for some minutes without my noticing him, so absorbed had I become with my recollections of meeting Miss Kenton two days ago.

事实上，一直到他大声地开口说话，我才觉察到原来旁边还坐着他这么个人：
In fact, I do not think I registered his presence on the bench at all until he declared out loud:

“海边的空气对人可是大有裨益啊。”
‘Sea air does you a lot of good.’

我抬起头来，看到一位体格健壮、年近七旬的男人，穿了件已经很旧了的花呢夹克，衬衣的领口敞着。
I looked up and saw a heavily built man, probably in his late sixties, wearing a rather tired tweed jacket, his shirt open at the neck.

他正凝望着海面，也许是在看远处的几只海鸥，所以根本就闹不清他到底是不是在我说话。
He was gazing out over the water, perhaps at some seagulls in the far distance, and so it was not at all clear that he had been talking to me.

不过既然没有别人回应，既然附近也看不到还有其他的人可能会做出回应，我最后还是回了一句：
But since no one else responded, and since I could see no other obvious persons close by who might do so, I eventually said:

“是呀，我相信肯定是大有裨益的。”
‘Yes, I'm sure it does.’

“医生都说这对你有好处。
‘The doctor says it does you good.

所以只要天气允许，我就尽可能多地到这儿来。”
So I come up here as much as the weather will let me.’

那人接着又跟我絮叨起了他的各种小病小灾，只是为了对我点个头、笑一笑，才会偶尔把一直凝视着落日的目光掉转过来。
The man went on to tell me about his various ailments, only very occasionally turning his eyes away from the sunset in order to give me a nod or a grin.

我也是在他无意间提及直到三年前正式退休，他一直都是附近一户人家的管家，这才真正开始注意去听他讲话。
I really only started to pay any attention at all when he happened to mention that until his retirement three years ago, he had been a butler of a nearby house.

经过询问以后，我得知他担任管家的那户人家的宅第规模很小，也只有他这么一个全职的雇员。
On inquiring further, I ascertained that the house had been a very small one in which he had been the only full-time employee.

当我问到他手底下可曾有过专职的员工跟他一起工作时—或许在大战前—他回答道：
When I asked him if he had ever worked with a proper staff under him, perhaps before the war, he replied:

“哦，那个时候，我还只不过是个男仆。
‘Oh, in those days, I was just a footman.

那个时候啊，我还压根儿都不知道当管家的窍门儿呢。
I wouldn't have had the know-how to be a butler in those days.

要真想成为那些大户人家的管家，对你的要求得有多高，你真是做梦都想不到呢。”
You'd be surprised what it involved when you had those big houses you had then.’

话已至此，我想也该向他表明我的身份了，虽说我不太确定他是不是明白“达林顿府”的斤两，我这位伴当看起来倒是肃然起敬。
At this point, I thought it appropriate to reveal my identity, and although I am not sure ‘Darlington Hall’ meant anything to him, my companion seemed suitably impressed.

“我还一本正经地想向你解说其中的窍门儿呢，”他笑道。
‘And here I was trying to explain it all to you,’ he said with a laugh.

“幸亏你及早告诉了我，要不然我可真是关公面前耍大刀了。
‘Good job you told me when you did before I made a right fool of myself.

这也正好说明，你在跟一位陌生人攀谈的时候，永远都不知道你到底是在跟谁讲话。
Just shows you never know who you're addressing when you start talking to a stranger.

这么说来，你手底下肯定有过一大帮子雇员吧，我想。
So you had a big staff, I suppose.

我是说战前。”
Before the war, I mean.’

他是个性情开朗的伙计，又像是真的很感兴趣，所以我坦诚我的确花了点时间跟他讲了讲昔日达林顿府的盛况。
He was a cheerful fellow and seemed genuinely interested, so I confess I did spend a little time telling him about Darlington Hall in former days.

主要的我是想告诉他，在筹备和监管我们过去经常举办的那些盛大活动时，需要掌握哪些—用他的话来说—“窍门儿”。
In the main, I tried to convey to him some of the ‘know-how’, as he put it, involved in overseeing large events of the sort we used often to have.

的确，我相信我甚至还向他透露了我的好几个用以调动员工额外潜能的“秘诀”，以及当管家需要掌握的各种“戏法儿”—就跟变魔术的没什么两样—靠这些戏法儿，一个管家就能让某一样东西在合适的时间出现在合适的地点，而根本不会让客人们窥见这样的操作背后那经常是庞大而又复杂的运作机巧。
Indeed, I believe I even revealed to him several of my professional ‘secrets’ designed to bring that extra bit out of staff, as well as the various ‘sleights-of-hand’ – the equivalent of a conjuror's – by which a butler could cause a thing to occur at just the right time and place without guests even glimpsing the often large and complicated manoeuvre behind the operation.

我也说过，我这位伴当看起来是真的很感兴趣，但在说了一阵以后我也觉得应该见好就收了，于是就以这样一句话做了个归结：
As I say, my companion seemed genuinely interested, but after a time I felt I had revealed enough and so concluded by saying:

“当然了，在我现在的雇主手下，情况可就大不相同了。
‘Of course, things are quite different today under my present employer.

他是位美国绅士。”
An American gentleman.’

“美国人，呃？
‘American, eh?

说起来，现在也只有他们才能摆得起这个谱儿了。
Well, they're the only ones can afford it now.

这么说来你还继续留在那个府里。
So you stayed on with the house.

大概也是一揽子交易的组成部分吧。”
Part of the package.’

他转过脸来冲我咧嘴一笑。
He turned and gave me a grin.

“是呀，”我说，也轻声一笑。
‘Yes,’ I said, laughing a little.

“就像你说的，是一揽子交易的一部分。”
‘As you say, part of the package.’

那人又把凝视的目光再次转回到海面上，深吸了一口气，又心满意足地叹了口气。
The man turned his gaze back to the sea again, took a deep breath and sighed contentedly.

然后，我们又默不作声地一起在那儿坐了好一会儿。
We then proceeded to sit there together quietly for several moments.

“事实上，当然了，”半晌后我又说，“我把我全副的精力都献给了达林顿勋爵。
‘The fact is, of course,’ I said after a while, ‘I gave my best to Lord Darlington.

我把所能奉献的一切全都奉献给了他，而现在—喔—我真是发现我还可以奉献的已经所剩无几了。”
I gave him the very best I had to give, and now – well – I find I do not have a great deal more left to give.’

那人没有言语，不过点了点头，于是我继续道：
The man said nothing, but nodded, so I went on:

“自打我的新雇主法拉戴先生来到以后，我一直都非常努力，真的是非常努力地想向他提供我希望他能享受到的那种服务。
‘Since my new employer Mr Farraday arrived, I've tried very hard, very hard indeed, to provide the sort of service I would like him to have.

我已经竭尽了全力，可是不管我怎么做，我都发现距离我当初为自己制定的标准还差了一大截。
I've tried and tried, but whatever I do I find I am far from reaching the standards I once set myself.

我的工作中也开始出现了越来越多的失误。
More and more errors are appearing in my work.

尽管这些失误本身都无足轻重—至少到目前为止是这样。
Quite trivial in themselves – at least so far.

可它们都是我以前从来都不会犯的那种失误，而且我知道它们意味着什么。
But they're of the sort I would never have made before, and I know what they signify.

老天作证，我真是已经竭尽了全力，可就是没有用。
Goodness knows, I've tried and tried, but it's no use.

我能够付出的已经全都付出了。
I've given what I had to give.

而我把它们全都奉献给了达林顿勋爵。”
I gave it all to Lord Darlington.’

“哎呀，朋友。
‘Oh dear, mate.

我说，要不要块手绢儿？
Here, you want a hankie?

我应该揣着一条来着。
I've got one somewhere.

找到了。
Here we are.

还挺干净的。
It's fairly clean.

今天早上只拿它来擤了一次鼻子，仅此而已。
Just blew my nose once this morning, that's all.

你拿去用吧，朋友。”
Have a go, mate.’

“哦天哪，不用，谢谢你，我没事了。
‘Oh dear, no, thank you, it's quite all right.

很抱歉，恐怕是因为这次旅行让我太累了。
I'm very sorry, I'm afraid the travelling has tired me.

非常抱歉。”
I'm very sorry.’

“你肯定是非常依恋这位什么勋爵。
‘You must have been very attached to this Lord whatever.

你说他已经过世三年了？
And it's three years since he passed away, you say?

我看得出你真是对他情深义重啊，朋友。”
I can see you were very attached to him, mate.’

“达林顿勋爵并不是个坏人。
‘Lord Darlington wasn't a bad man.

他绝不是个坏人。
He wasn't a bad man at all.

至少他还有勇气在他生命的最后阶段承认是他自己犯了错误。
And at least he had the privilege of being able to say at the end of his life that he made his own mistakes.

爵爷是个勇敢的人。
His lordship was a courageous man.

他在人生中选择了一条自己的道路，结果却发现他是误入了歧途，但他至少可以说，那是他自己的选择。
He chose a certain path in life, it proved to be a misguided one, but there, he chose it, he can say that at least.

而至于我，我连这样的话都不能说。
As for myself, I cannot even claim that.

你知道吗，我信赖他。
You see, I trusted.

我信赖爵爷的智慧。
I trusted in his lordship's wisdom.

在我为他服务的所有这些年间，我一直坚信我所做的全都是有价值的。
All those years I served him, I trusted I was doing something worthwhile.

我甚至都不能说是我自己犯了错。
I can't even say I made my own mistakes.

说真的—你不得不扪心自问—在这其中到底又有什么样的尊严呢？”
Really – one has to ask oneself – what dignity is there in that?’

“听我说，朋友，我不敢保证听明白了你说的每一句话。
‘Now, look, mate, I'm not sure I follow everything you're saying.

可如果你问我的话，我得说，你的态度可是完全不对头，知道吗？
But if you ask me, your attitude's all wrong, see?

人不能总是朝后看，要不然肯定是要意气消沉的。
Don't keep looking back all the time, you're bound to get depressed.

好吧，你的工作是不能做得像当年一样好了。
And all right, you can't do your job as well as you used to.

可我们不全都是这样吗，对不对？
But it's the same for all of us, see?

到了某个时候，我们全都得把脚搁起来休息了。
We've all got to put our feet up at some point.

你看看我。
Look at me.

自打我退休的那天起，我就快活得像只云雀一样。
Been happy as a lark since the day I retired.

好吧，就算是你我都已经不再是精力充沛的青春盛年，可是你仍旧得继续往前看。”
All right, so neither of us are exactly in our first flush of youth, but you've got to keep looking forward.’

我相信就是在这个时候他又说：“你得学会享受你的人生。
And I believe it was then that he said: ‘You've got to enjoy yourself.

傍晚是一天当中最美好的时光。
The evening's the best part of the day.

你已经做完了一天的工作。
You've done your day's work.

该是你搁起脚来好好享受一下的时候了。
Now you can put your feet up and enjoy it.

我就是这么看的。
That's how I look at it.

随便找个人问问，他们也都会这么说的。
Ask anybody, they'll all tell you.

傍晚是一天当中最美好的时光。”
The evening's the best part of the day.’

“我确信你说得很有道理，”我说。
‘I'm sure you're quite correct,’ I said.

“真抱歉，我真是非常失态。
‘I'm so sorry, this is so unseemly.

我想我是有些累过头了。
I suspect I'm over-tired.

这些天来我一直都在路上奔波，你知道。”
I've been travelling rather a lot, you see.’

那个人离开已经有二十分钟左右了，不过我仍旧坐在长椅上没动，等着观看当晚那刚刚已经开始的余兴活动—即码头彩灯亮起—的进展情况。
It is now some twenty minutes since the man left, but I have remained here on this bench to await the event that has just taken place – namely, the switching on of the pier lights.

像我已经说过的，特意聚集到码头的那些寻欢作乐的人群为迎接这个小小的节目表现出来的欢快之情，似乎再次印证了我刚才那位伴当所言的真确性；因为对于这么多人来说，傍晚确是一天当中最令人享受的时光。
As I say, the happiness with which the pleasure-seekers gathering on this pier greeted this small event would tend to vouch for the correctness of my companion's words; for a great many people, the evening is the most enjoyable part of the day.

如此看来，他的建议或许果真是有点道理的，我的确应该不要再这么频繁地回顾往事，而应该采取一种更为积极的人生态度，把我剩余的这段人生尽量过好。
Perhaps, then, there is something to his advice that I should cease looking back so much, that I should adopt a more positive outlook and try to make the best of what remains of my day.

毕竟，总是这样没完没了地往回看，总是自责我们当初的生活并没有尽如人意，终究又有什么好处呢？
After all, what can we ever gain in forever looking back and blaming ourselves if our lives have not turned out quite as we might have wished?

而且对于你我这样的人来说，现实的残酷肯定还在于，除了将我们的命运交付到身处这个世界的轴心、雇佣我们的服务的那些伟大绅士们的手中之外，归根结底，我们别无选择。
The hard reality is, surely, that for the likes of you and me, there is little choice other than to leave our fate, ultimately, in the hands of those great gentlemen at the hub of this world who employ our services.

整日地自寻烦恼，忧心于当初究竟该怎么做又不该怎么做方是人生之正途，又有什么意义呢？
What is the point in worrying oneself too much about what one could or could not have done to control the course one's life took?

你我之辈，只要是至少曾为了某项真实而有价值的事业而竭尽绵薄、稍作贡献，谅必就已经尽够了。
Surely it is enough that the likes of you and me at least try to make a small contribution count for something true and worthy.

我们当中若是有人准备将大部分的生命奉献给这样的理想和抱负，那么毋庸置疑，值得为之自豪和满足的就在于这献身的过程本身，而不应计较其结果究竟如何。
And if some of us are prepared to sacrifice much in life in order to pursue such aspirations, surely that is in itself, whatever the outcome, cause for pride and contentment.

顺带说一句，几分钟前，就在彩灯刚刚亮起后不久，我还特意从坐着的长椅上转过身去，更仔细地研究了一会儿在我背后那些有说有笑的人群。
A few minutes ago, incidentally, shortly after the lights came on, I did turn on my bench a moment to study more closely these throngs of people laughing and chatting behind me.

在码头上漫步徜徉的人各种年龄段都有：有带着小孩的一家人；有手挽手一起散步的夫妻，小夫妻老夫妻都有。
There are people of all ages strolling around this pier: families with children; couples, young and elderly, walking arm in arm.

我背后不远处聚在一起的那六七个人稍稍引起了我的好奇心。
There is a group of six or seven people gathered just a little way behind me who have aroused my curiosity a little.

我一开始想当然地以为他们是趁此良宵结伴外出的一帮朋友。
I naturally assumed at first that they were a group of friends out together for the evening.

可是听了一会儿他们的谈话以后，这才发现他们不过是碰巧在我身后的这个地方偶遇的一帮陌生人。
But as I listened to their exchanges, it became apparent they were strangers who had just happened upon one another here on this spot behind me.

显然，他们刚才全都一时间驻足观望，等待彩灯初上的那一刻，随后才又继续友好地攀谈起来。
Evidently, they had all paused a moment for the lights coming on, and then proceeded to fall into conversation with one another.

此刻他们就在我的注视之下，一起开心地大笑。
As I watch them now, they are laughing together merrily.

真是奇怪，人们相互间居然能这么快就建立起热络的感情。
It is curious how people can build such warmth among themselves so swiftly.

可能只是因为对于即将到来的夜晚的共同期待，才将这几个人联系在一起的。
It is possible these particular persons are simply united by the anticipation of the evening ahead.

不过呢，我倒也觉得这其实是跟揶揄打趣的本事有更大的关系。
But, then, I rather fancy it has more to do with this skill of bantering.

眼下听着他们的谈话，听得出来他们相互间玩笑逗趣个不断。
Listening to them now, I can hear them exchanging one bantering remark after another.

想来，这正是很多人都会喜欢的搭话和交谈方式。
It is, I would suppose, the way many people like to proceed.

事实上，刚才跟我坐一条凳子的那位伴当恐怕原本也期望我能跟他玩笑打趣一番的—果真如此的话，我可真是扫了他的兴了。
In fact, it is possible my bench companion of a while ago expected me to banter with him – in which case, I suppose I was something of a sorry disappointment.

也许我当真应该开始更加热心地看待戏谑打趣这件事了。
Perhaps it is indeed time I began to look at this whole matter of bantering more enthusiastically.

毕竟，认真想来，热衷于开开玩笑也并非什么要不得的蠢行—尤其是在它真能成为联络人际关系的锁钥的情况下。
After all, when one thinks about it, it is not such a foolish thing to indulge in – particularly if it is the case that in bantering lies the key to human warmth.

不仅如此，我还想到，雇主期望他的雇员能跟他说两句俏皮话，也真不能算是不合情理的要求。
It occurs to me, furthermore, that bantering is hardly an unreasonable duty for an employer to expect a professional to perform.

我当然是已经花了很多时间来提高自己说俏皮话的本领了，不过也许之前我还没有做到全情投入的程度。
I have of course already devoted much time to developing my bantering skills, but it is possible I have never previously approached the task with the commitment I might have done.

这么看来，也许在我明天返回达林顿府以后—法拉戴先生本人还要再过一周才回来—我就该重新开始更加努力地加以练习了。
Perhaps, then, when I return to Darlington Hall tomorrow – Mr Farraday will not himself be back for a further week – I will begin practising with renewed effort.

如此一来，我有理由希望到我雇主回来的时候，我就能让他感到一种愉快的惊喜了。
I should hope, then, that by the time of my employer's return, I shall be in a position to pleasantly surprise him.
