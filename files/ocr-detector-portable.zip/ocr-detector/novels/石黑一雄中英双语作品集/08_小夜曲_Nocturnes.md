# 伤心情歌手 | Crooner

我发现托尼·加德纳坐在游客当中的那天早上，春天刚刚降临威尼斯这里。
THE MORNING I spotted Tony Gardner sitting among the tourists, spring was just arriving here in Venice.

我们搬到外面广场上来刚好一个星期——跟你说，真是松了口气，在咖啡厅的最里面演奏又闷又挡着要用楼梯的客人的路。
We'd completed our first full week outside in the piazza – a relief, let me tell you, after all those stuffy hours performing from the back of the cafe, getting in the way of customers wanting to use the staircase.

那天早上微风习习，崭新的帐篷在我们身边啪啪作响，我们都觉得比平时更加愉悦和精神，我想这种心情一定反映在我们的音乐里了。
There was quite a breeze that morning, and our brand-new marquee was flapping all around us, but we were all feeling a little bit brighter and fresher, and I guess it showed in our music.

瞧我说得好像我是乐队的固定成员似的。
But here I am talking like I'm a regular band member.

事实上，我只是那些个“吉卜赛人”中的一个，别的乐手这么称呼我们，我只是那些个奔走于广场、三个咖啡厅的管弦乐队里哪个缺人，就去哪里帮忙的人中的一个。
Actually, I'm one of the ‘gypsies’, as the other musicians call us, one of the guys who move around the piazza, helping out whichever of the three cafe orchestras needs us.

我主要在这家拉弗娜咖啡厅演奏，但若遇上忙碌的下午，我就要先和夸德里的小伙子们演奏一组，然后到弗洛里安去，再穿过广场回到拉弗娜。
Mostly I play here at the Caffé Lavena, but on a busy afternoon, I might do a set with the Quaddri boys, go over to the Florian, then back across the square to the Lavena.

我和这三支乐队都相处得很好——和咖啡厅的服务生们也是——在别的哪个城市，我早就有固定职位了。
I get on fine with them all – and with the waiters too – and in any other city I'd have a regular position by now.

可是在这里，传统和历史根深蒂固，事情都倒过来了。
But in this place, so obsessed with tradition and the past, everything's upside down.

在其他地方，吉他手可是受人欢迎的。
Anywhere else, being a guitar player would go in a guy's favour.

可是在这里？
But here?

吉他手！
A guitar!

咖啡厅的经理们不自在了。
The cafe managers get uneasy.

吉他太现代了，游客不会喜欢的。
It looks too modern, the tourists won't like it.

去年秋天，我弄来了一把老式椭圆形音孔的爵士吉他，像强哥·莱恩哈特弹的那种，这样大家就不会把我当成摇滚乐手了。
Last autumn I got myself a vintage jazz model with an oval sound-hole, the kind of thing Django Reinhardt might have played, so there was no way anyone would mistake me for a rock-and-roller.

事情容易了些，可经理们还是不喜欢。
That made things a little easier, but the cafe managers, they still don't like it.

总之，实话告诉你吧：倘若你是个吉他手，就算你是吉他大师乔·帕斯，也甭想在这个广场找到一份固定工作。
The truth is, if you're a guitarist, you can be Joe Pass, they still wouldn't give you a regular job in this square.

当然了，还有另外一个小小的原因：我不是意大利人，更别说是威尼斯人。
There's also, of course, the small matter of my not being Italian, never mind Venetian.

那个吹中音萨克斯风的捷克大个子情况和我一样。
It's the same for that big Czech guy with the alto sax.

大伙儿都喜欢我们，乐队需要我们，可我们就是不符合正式要求。
We're well liked, we're needed by the other musicians, but we don't quite fit the official bill.

咖啡厅的经理们总是告诉你：闭上你的嘴，只管演奏就是了。
Just play and keep your mouth shut, that's what the cafe managers always say.

这样游客们就不会知道你不是意大利人了。
That way the tourists won't know you're not Italian.

穿上你的制服，戴上你的太阳镜，头发往后梳，没有人看得出来，只要别开口说话。
Wear your suit, sunglasses, keep the hair combed back, no one will know the difference, just don't start talking.

可是我混得还不错。
But I don't do too bad.

三支乐队都需要吉他手，特别是当他们与竞争对手同时演奏的时候，他们需要一个轻柔、纯净，但是传得远的声音作背景和弦。
All three cafe orchestras, especially when they have to play at the same time from their rival tents, they need a guitar – something soft, solid, but amplified, thumping out the chords from the back.

我猜你会想：三支乐队同时在一个广场上演奏，听起来多混乱啊。
I guess you're thinking, three bands playing at the same time in the same square, that would sound like a real mess.

可是圣马可广场很大，没有问题。
But the Piazza San Marco's big enough to take it.

在广场上溜达的游客会听见一个曲子渐渐消失，另一个曲子渐渐大声，就好像他在调收音机的台。
A tourist strolling across the square will hear one tune fade out, another fade in, like he's shifting the dial on a radio.

会让游客们受不了的是你演奏太多古典的东西，这些乐器演奏版的著名咏叹调。
What tourists can't take too much of is the classical stuff, all these instrumental versions of famous arias.

得了，这里是圣马可，游客们不想听最新的流行音乐。
Okay, this is San Marco, they don't want the latest pop hits.

可是他们时不时要一些他们认得的东西，比如朱莉·安德鲁斯的老歌，或者某个著名电影的主题曲。
But every few minutes they want something they recognise, maybe an old Julie Andrews number, or the theme from a famous movie.

我记得去年夏天有一次，我奔走于各个乐队间，一个下午演奏了九遍《教父》。
I remember once last summer, going from band to band and playing ‘The Godfather’ nine times in one afternoon.

总之就是在这样一个春天的早晨，当我们在一大群游客面前演出的时候，我突然看见托尼·加德纳，独自一人坐在那里，面前放着一杯咖啡，差不多就在我们的正前方，离我们的帐篷大概只有六米远。广场上总是能看见名人，我们从来不大惊小怪。
Anyway there we were that spring morning, playing in front of a good crowd of tourists, when I saw Tony Gardner, sitting alone with his coffee, almost directly in front of us, maybe six metres back from our marquee. We get famous people in the square all the time, we never make a fuss.

只在演奏完一曲后，乐队成员间私下小声说几句。
At the end of a number, maybe a quiet word will go around the band members.

看，是沃伦·比蒂。
Look, there's Warren Beatty.

看，是基辛格。
Look, it's Kissinger.

那个女人就是在讲两个男人变脸的电影里出现过的那个。
That woman, she's the one who was in the movie about the men who swap their faces.

我们对此习以为常。毕竟这里是圣马可广场。
We're used to it. This is the Piazza San Marco after all.

可是当我发现坐在那里的是托尼·加德纳时，情况就不一样了，我激动极了。
But when I realised it was Tony Gardner sitting there, that was different. I did get excited.

托尼·加德纳是我母亲最喜爱的歌手。
Tony Gardner had been my mother's favourite.

在我离开家之前，在那个共产主义时代，那样的唱片是很难弄到的，可我母亲有他几乎所有的唱片。
Back home, back in the communist days, it had been really hard to get records like that, but my mother had pretty much his whole collection.

小时候我刮坏过一张母亲的珍贵收藏。
Once when I was a boy, I scratched one of those precious records.

我们住的公寓很挤，可像我那个年纪的男孩子有时就是好动，尤其是在冬天不能出去的时候。
The apartment was so cramped, and a boy my age, you just had to move around sometimes, especially during those cold months when you couldn't go outside.

所以我就从家里的小沙发跳到扶手椅上这样玩，有一次，我不小心撞到了唱片机。
So I was playing this game jumping from our little sofa to the armchair, and one time I misjudged it and hit the record player.

唱针“嗞”的一声划过唱片——那时还没有CD——母亲从厨房里出来，冲我大声嚷嚷。
The needle went across the record with a zip – this was long before CDs – and my mother came in from the kitchen and began shouting at me.

我很伤心，不是因为她冲我大声嚷嚷，而是因为我知道那是托尼·加德纳的唱片，我知道那张唱片对她来说多么重要。
I felt so bad, not just because she was shouting at me, but because I knew it was one of Tony Gardner's records, and I knew how much it meant to her.

我还知道从此以后，当加德纳轻声吟唱那些美国歌曲时，唱片就会发出“嗞嗞”的声音。
And I knew that this one too would now have those popping noises going through it while he crooned those American songs.

多年以后，我在华沙工作时得知了黑市唱片，我给母亲买了所有的托尼·加德纳的唱片，代替旧的那些，包括我刮坏的那一张。
Years later, when I was working in Warsaw and I got to know about black-market records, I gave my mother replacements of all her worn-out Tony Gardner albums, including that one I scratched.

我花了三年才买齐，可我坚持不懈地买，一张张地买，每次回去看望她都带回去一张。
It took me over three years, but I kept getting them, one by one, and each time I went back to see her I'd bring her another.

现在你知道当我认出托尼·加德纳时为什么会那么激动了吧，就在六米以外啊。
So you see why I got so excited when I recognised him, barely six metres away.

起初我不敢相信，我换一个和弦时一定慢了一拍。
At first I couldn't quite believe it, and I might have been a beat late with a chord change.

是托尼·加德纳！
Tony Gardner!

我亲爱的母亲要是知道了会说什么啊！
What would my dear mother have said if she'd known!

为了她，为了她的回忆，我一定要去跟托尼·加德纳说句话，才不管其他乐手会不会笑话我，说我像个小听差。
For her sake, for the sake of her memory, I had to go and say something to him, never mind if the other musicians laughed and said I was acting like a bellboy.

但是我当然不可能推开桌椅，朝他冲过去。
But of course I couldn't just rush over to him, pushing aside the tables and chairs.

我还得把演出演完。
There was our set to finish.

跟你说，真是痛苦极了，还有三四首歌，每一秒钟我都以为他要起身离开了。
It was agony, I can tell you, another three, four numbers, and every second I thought he was about to get up and walk off.

可是他一直坐在那里，独自一人，盯着眼前的咖啡，搅呀搅，好像搞不清楚服务生给他端来的到底是什么东西。
But he kept sitting there, by himself, staring into his coffee, stirring it like he was really puzzled by what the waiter had brought him.

他的装扮与一般的美国游客一样，浅蓝色的套头运动衫、宽松的灰裤子。
He looked like any other American tourist, dressed in a pale-blue polo shirt and loose grey trousers.

以前唱片封面上又黑又亮的头发如今几乎都白了，但还挺浓密，而且梳得整整齐齐，发型也没有变。
His hair, very dark, very shiny on those record covers, was almost white now, but there was still plenty of it, and it was immaculately groomed in the same style he'd had back then.

我刚认出他时，他把墨镜拿在手里——他要是戴着墨镜我不一定能认出来——但是后来我一边演奏一边盯着他，他一会儿把墨镜戴上，一会儿拿下来，一会儿又戴上。
When I'd first spotted him, he'd had his dark glasses in his hand – I doubt if I'd have recognised him otherwise – but as our set went on and I kept watching him, he put them on his face, took them off again, then back on again.

他看上去心事重重，而且没有认真在听我们演奏，让我很是失望。
He looked preoccupied and it disappointed me to see he wasn't really listening to our music.

这组歌曲终于演完了。
Then our set was over.

我什么也没有对其他人说，匆匆走出帐篷，朝托尼·加德纳的桌子走去，突然想到不知如何与他攀谈，心里紧张了一下。
I hurried out of the tent without saying anything to the others, made my way to Tony Gardner's table, then had a moment's panic not knowing how to start the conversation.

我站在他的身后，他的第六感却让他转过身来，看着我——我想这是出于多年来有歌迷来找他的习惯——接着我就介绍自己，告诉他我多么崇拜他，我在他刚刚听的那个乐队里，我母亲是他热情的歌迷等等，一古脑儿全都说了。
I was standing behind him, but some sixth sense made him turn and look up at me – I guess it was all those years of having fans come up to him – and next thing I was introducing myself, explaining how much I admired him, how I was in the band he'd just been listening to, how my mother had been such a fan, all in one big rush.

他表情严肃地听着，时不时点点头，好像他是我的医生。
He listened with a grave expression, nodding every few seconds like he was my doctor.

我不停地讲，他只偶尔说一声：“是吗？”
I kept talking and all he said every now and then was:‘Is that so?’

过了一会儿我想我该走了，转身要离开，突然听见他说：
After a while I thought it was time to leave and I'd started to move away when he said:

“你说你是从波兰来的。
‘So you come from one of those communist countries.

日子一定不好过吧？”
That must have been tough.’

“都过去了。”
‘That's all in the past.’

我笑笑，耸了耸肩。
I did a cheerful shrug.

“如今我们是个自由的国家了。
‘We're a free country now.

一个民主的国家。”
A democracy.’

“那太好了。
‘That's good to hear.

那就是刚刚为我们演奏的你的同仁吧。
And that was your crew playing for us just now.

坐下。
Sit down.

来杯咖啡？”
You want some coffee?’

我说我不想叨扰他，可是加德纳先生的语气里有丝丝温和的坚持。
I told him I didn't want to impose, but there was now something gently insistent about Mr Gardner.

“不会，不会，坐下。
‘No, no, sit down.

你刚才说你母亲喜欢我的唱片。”
Your mother liked my records, you were saying.’

于是我就坐了下来，接着说。
So I sat down and told him some more.

说我的母亲、我们住的公寓、黑市上的唱片。
About my mother, our apartment, the black-market records.

我记不得那些唱片的名字，但我能够描述我印象中那些唱片套子的样子，每当我这么做时，他就会举起一根手指说“哦，那张是《独一无二》。
And though I couldn't remember what the albums were called, I started describing the pictures on their sleeves the way I remembered them, and each time I did this, he'd put his finger up in the air and say something like:‘Oh, that would be Inimitable.

《独一无二的托尼·加德纳》”之类的。
The Inimitable Tony Gardner.’

我觉得我们俩都很喜欢这个游戏，突然我注意到加德纳先生的视线从我身上移开了，我转过头去，刚好看见一个女人朝我们走来。
I think we were both really enjoying this game, but then I noticed Mr Gardner's gaze move off me, and I turned just in time to see a woman coming up to our table.

她是那种非常优雅的美国女人，头发优美，衣服漂亮，身材姣好，不仔细看的话不会发现她们已经不年轻了。
She was one of those American ladies who are so classy, with great hair, clothes and figure, you don't realise they're not so young until you see them up close.

远远地看，我还以为是从光鲜的时尚杂志里走出来的模特儿呢。
Far away, I might have mistaken her for a model out of those glossy fashion magazines.

可是当她在加德纳先生身旁坐下，把墨镜推到额头上去时，我发现她至少五十了，甚至不止。
But when she sat down next to Mr Gardner and pushed her dark glasses onto her forehead, I realised she must be at least fifty, maybe more.

加德纳先生对我说：“这位是我的妻子琳迪。”
Mr Gardner said to me:‘This is Lindy, my wife.’

加德纳太太朝我敷衍地笑了笑，问她丈夫：“这位是谁？
Mrs Gardner flashed me a smile that was kind of forced, then said to her husband:‘So who's this?

你交了个朋友。”
You've made yourself a friend.’

“是的，亲爱的。
‘That's right, honey.

我们聊得正欢呢，我和……抱歉，朋友，我还不知道你的名字呢。”
I was having a good time talking here with . . . I'm sorry, friend, I don't know your name.’

“扬，”我立刻答道。
‘Jan,’ I said quickly.

“但朋友们都叫我雅内克。”
‘But friends call me Janeck.’

琳迪·加德纳说：“你是说你的小名比真名长？
Lindy Gardner said:‘You mean your nickname's longer than your real name?

怎么会这样呢？”
How does that work?’

“别对人家无礼，亲爱的。”
‘Don't be rude to the man, honey.’

“我没有无礼。”
‘I'm not being rude.’

“别取笑人家的名字，亲爱的。
‘Don't make fun of the man's name, honey.

这样才是好姑娘。”
That's a good girl.’

琳迪·加德纳无助地转向我说：“你瞧瞧他说些什么？
Lindy Gardner turned to me with a helpless sort of expression. ‘You know what he's talking about?

我冒犯你了吗？”
Did I insult you?’

“不，不，”我说，“一点也没有，加德纳太太。”
‘No, no,’ I said, ‘not at all, Mrs Gardner.’

“他总是说我对歌迷无礼。
‘He's always telling me I'm rude to the public.

可是我没有无礼。
But I'm not rude.

我刚刚对你无礼了吗？”
Was I rude to you just now?’

然后她转向加德纳先生，“我很正常地在跟歌迷讲话，亲爱的。
Then to Mr Gardner:‘I speak to the public in a natural way, sweety.

我就是这样讲话的。
It's my way.

我从来没有无礼。”
I'm never rude.’

“好了，亲爱的，”加德纳先生说，“别小题大做了。
‘Okay, honey,’ Mr Gardner said, ‘let's not make a big thing of it.

而且，这位先生也不是什么歌迷。”
Anyhow, this man here, he's not the public.’

“哦，他不是歌迷？
‘Oh, he's not?

那他是谁？
Then what is he?

失散多年的侄子？”
A long-lost nephew?’

“别这么说话，亲爱的。
‘Be nice, honey.

这位先生是我的同行。
This man, he's a colleague.

一位职业乐手。
A musician, a pro.

刚刚他在为我们演奏呢。”
He's just been entertaining us all.’

他指了指我们的帐篷。
He gestured towards our marquee.

“哦，对！”
‘Oh right!’

琳迪·加德纳再次转向我，“刚刚你在那里演奏来着？
Lindy Gardner turned to me again. ‘You were playing up there just now?

啊，很好听。
Well, that was pretty.

你是拉手风琴的？
You were on the accordion, right?

拉得真好！”
Real pretty!’

“谢谢。
‘Thank you very much.

其实我是弹吉他的。”
Actually, I'm the guitarist.’

“弹吉他的？
‘Guitarist?

少来了。
You're kidding me.

一分钟之前我还在看着你呢。
I was watching you only a minute ago.

就坐在那里，坐在那个拉低音提琴的旁边，手风琴拉得真好。”
Sitting right there, next to the double bass man, playing so beautifully on your accordion.’

“抱歉，拉手风琴的是卡洛。
‘Pardon me, that was in fact Carlo on the accordion.

秃头、个大的……”
The big bald guy . . .’

“真的？
‘Are you sure?

你不是在骗我？”
You're not kidding me?’

“亲爱的，我说了，别对人家无礼。”
‘Honey, I've told you. Don't be rude to the man.’

加德纳先生并没有提高音量，可是他的声音突然变得严厉和气愤，接着，出现了一阵异样的沉默。
He hadn't shouted exactly, but his voice was suddenly hard and angry, and now there was a strange silence.

最后，是加德纳先生自己打破了沉默，温柔地说：
Then Mr Gardner himself broke it, saying gently:

“对不起，亲爱的。
‘I'm sorry, honey.

我不是有意要训你的。”
I didn't mean to snap at you.’

他伸出一只手去拉妻子的手。
He reached out a hand and grasped one of hers.

我本以为加德纳太太会推开他，没想到她在椅子上挪了挪身子，好靠近加德纳先生一点，然后把另一只手搭在他们握紧的手上。
I'd kind of expected her to shake him off, but instead, she moved in her chair so she was closer to him, and put her free hand over their clasped pair.

一时间他们就那么坐着，加德纳先生低着头，他妻子的视线越过他的肩膀，出神地看着广场那头的大教堂。她的眼睛虽然看着那里，但却好像并没有真的在看什么。
They sat there like that for a few seconds, Mr Gardner, his head bowed, his wife gazing emptily past his shoulder, across the square towards the Basilica, though her eyes didn't seem to be seeing anything.

那几秒钟，他们好像不仅忘了同桌的我，甚至忘了整个广场的人。
For those few moments it was like they'd forgotten not just me sitting with them, but all the people in the piazza.

最后加德纳太太轻声说：
Then she said, almost in a whisper:

“没关系，亲爱的。
‘That's okay, sweety.

是我错了。
It was my fault.

惹你生气了。”
Getting you all upset.’

他们又这样手拉着手对坐了一会儿。最后她叹了口气，放开加德纳先生的手，看着我。
They went on sitting like that a little longer, their hands locked. Then she sighed, let go of Mr Gardner and looked at me.

这次她看我的样子和之前不一样。
She'd looked at me before, but this time it was different.

这次我能感觉到她的魅力，就好像她心里有这么个刻度盘，从一到十，此时，对我，她决定拨到六或七，可我已经觉得够强烈的了，如果此时她叫我为她做些什么——比如说到广场对面帮她买花——我会欣然从命。
This time I could feel her charm. It was like she had this dial, going zero to ten, and with me, at that moment, she'd decided to turn it to six or seven, but I could feel it really strong, and if she'd asked some favour of me – if say she'd asked me to go across the square and buy her some flowers – I'd have done it happily.

“你说你叫雅内克，是吗？”
‘Janeck,’ she said.

她说。
‘That's your name, right?

“对不起，雅内克。
I'm sorry, Janeck.

托尼说得对。
Tony's right.

我不应该那样子跟你说话。”
I'd no business speaking to you the way I did.’

“加德纳太太，您真的不用担心……”
‘Mrs Gardner, really, please don't worry . . .’

“我还打扰了你们的谈话。
‘And I disturbed the two of you talking.

音乐家之间的谈话，我想。
Musicians'talk, I bet. You know what?

好吧，我走了，你们继续聊。”
I'm gonna leave the two of you to get on with it.’

“你用不着离开，亲爱的，”加德纳先生说。
‘No reason to go, honey,’ Mr Gardner said.

“用得着，亲爱的。
‘Oh yes there is, sweety.

我很想去那家普拉达专卖店看看。
I'm absolutely yearning to go look in that Prada store.

我刚刚过来就是要跟你说我会晚一点。”
I only came over just now to tell you I'd be longer than I said.’

“好，亲爱的。”
‘Okay, honey.’

托尼·加德纳第一次直了直身子，深吸了一口气。
Tony Gardner straightened for the first time and took a deep breath.

“只要你喜欢就好。”
‘So long as you're sure you're happy doing that.’

“我在那家店里会过得很愉快的。
‘I'm gonna have a good time in that store.

你们俩，好好聊吧。”
So you two fellas, you have yourselves a good talk.’

她站起来，拍了一下我的肩膀。
She got to her feet and touched me on the shoulder.

“保重，雅内克。”
‘You take care, Janeck.’

我们看着她走远，接着加德纳先生问了我一些在威尼斯当乐手的事情，特别是夸德里乐队的事，因为他们刚好开始演出。
We watched her walk away, then Mr Gardner asked me a few things about being a musician in Venice, and about the Quaddri orchestra in particular, who'd started playing just at that moment.

他好像不是特别认真在听我回答，我正准备告辞时，他突然说道：
He didn't seem to listen so carefully to my answers and I was about to excuse myself and leave, when he said suddenly:

“我要跟你说一些事，朋友。
‘There's something I want to put to you, friend.

我想说说我心里的事，你不想听的话我就不说了。”
Let me tell you what's on my mind and you can turn me down if that's what you want.’

他俯过身来，降低了音量。
He leaned forward and lowered his voice.

“事情是这样。
‘Can I tell you something?

我和琳迪第一次到威尼斯来是我们蜜月的时候。
The first time Lindy and I came here to Venice, it was our honeymoon.

二十七年前。
Twenty-seven years ago.

为了那些美好的回忆，我们没有再回到这里来过，没有一起回来过。
And for all our happy memories of this place, we'd never been back, not together anyway.

所以当我们计划这次旅行，这次特别的旅行时，我们对自己说我们一定要来威尼斯住几天。”
So when we were planning this trip, this special trip of ours, we said to ourselves we've got to spend a few days in Venice.’

“是你们的结婚周年纪念啊，加德纳先生？”
‘It's your anniversary, Mr Gardner?’

“周年纪念？”
‘Anniversary?’

他很吃惊的样子。
He looked startled.

“抱歉，”我说。
‘I'm sorry,’ I said.

“我以为，因为您说是特别的旅行。”
‘I just thought, because you said this was your special trip.’

他还是吃惊地看着我，突然大笑起来，高声、响亮的笑。我突然想起我母亲以前经常放的一首歌，在那首歌里加德纳先生有一段独白，说什么不在乎恋人已经离他而去之类的，中间就有这种冷笑。
He went on looking startled for a while, then he laughed, a big, booming laugh, and suddenly I remembered this particular song my mother used to play all the time where he does a talking passage in the middle of the song, something about not caring that this woman has left him, and he does this sardonic laugh.

现在同样的笑声回荡在广场上。
Now the same laugh was booming across the square.

他接着说道：
Then he said:

“周年纪念？
‘Anniversary?

不，不，不是我们的周年纪念。
No, no, it's not our anniversary.

可是我正在酝酿的这件事，也差不离。
But what I'm proposing, it's not so far off.

因为我要做一件非常浪漫的事。
Because I want to do something very romantic.

我要给她唱小夜曲。
I want to serenade her.

地地道道威尼斯式的。
Properly, Venice style.

这就需要你的帮助。
That's where you come in.

你弹吉他，我唱歌。
You play your guitar, I sing.

我们租条刚朵拉，划到她的窗户下，我在底下唱给她听。
We do it from a gondola, we drift under the window, I sing up to her.

我们在这附近租了一间房子。
We're renting a palazzo not far from here.

卧室的窗户就临着运河。
The bedroom window looks over the canal.

天黑以后就万事俱备了，有墙上的灯把景物照亮。
After dark, it'll be perfect. The lamps on the walls light things up just right.

我和你乘着刚朵拉，她来到窗前。
You and me in a gondola, she comes to the window.

所有她喜欢的歌。
All her favourite numbers.

我们用不着唱很久，夜里还是有点冷。
We don't need to do it for long, the evenings are still kinda chilly.

三四首歌就好，这些就是我心里想的。
Just three or four songs, that's what I have in mind.

我会给你优厚的报酬。
I'll see you're well compensated.

你觉得呢？”
What do you say?’

“加德纳先生，我荣幸至极。
‘Mr Gardner, I'd be absolutely honoured.

正如我对您说的，您是我心中的一个大人物。
As I told you, you've been an important figure for me.

您想什么时候进行呢？”
When were you thinking of doing this?’

“如果不下雨，就今晚如何？
‘If it doesn't rain, why not tonight?

八点半左右？
Around eight-thirty?

我们晚饭吃得早，那会儿就已经回去了。
We eat dinner early, so we'll be back by then.

我找个借口离开房间，来找你。
I'll make some excuse, leave the apartment, come and meet you.

我安排好刚朵拉，我们沿着运河划回来，停在窗户下。
I'll have a gondola fixed up, we'll come back along the canal, stop under the window.

不会有问题的。
It'll be perfect.

你觉得呢？”
What do you say?’

你或许可以想象：这就像美梦成真一样。
You can probably imagine, this was like a dream come true.

而且这主意多甜蜜啊，这对夫妇——一个六十几岁，一个五十几岁——还像热恋中的年轻人似的。
And besides, it seemed such a sweet idea, this couple – he in his sixties, she in her fifties – behaving like teenagers in love.

这甜蜜的想法差点儿让我忘了刚才所见的那一幕。
In fact it was so sweet an idea it almost, but not quite, made me forget the scene I'd just witnessed between them.

可我没忘，因为即便在那时，我心里深知事情一定不完全像加德纳先生说的那样。
What I mean is, even at that stage, I knew deep down that things wouldn't be as straightforward as he was making out.

接下来我和加德纳先生坐在那里讨论所有的细节——他想唱哪些歌，要什么音高，等等之类。
For the next few minutes Mr Gardner and I sat there discussing all the details – which songs he wanted, the keys he preferred, all those kinds of things.

后来时间到了，我该回帐篷去进行下一场演出了。我站起来，和他握了握手，告诉他今天晚上他完全可以信任我。
Then it was time for me to get back to the marquee and our next set, so I stood up, shook his hand and told him he could absolutely count on me that evening.

那天晚上我去见加德纳先生时，漆黑的街道十分安静。
The streets were dark and quiet as I went to meet Mr Gardner that night.

那个时候，一到离圣马可广场较远的地方我就会迷路，所以尽管我早早出发，尽管我知道加德纳先生告诉我的那座小桥，我还是晚了几分钟。
In those days I'd always get lost whenever I moved much beyond the Piazza San Marco, so even though I'd allowed myself plenty of time, even though I knew the little bridge where Mr Gardner had told me to be, I was still a few minutes late.

加德纳先生站在路灯底下，穿着一件皱皱的深色西装，衬衫敞到第三四个扣子处，所以能看见胸口的毛。
He was standing right under a lamp, wearing a crumpled dark suit, and his shirt was open down to the third or fourth button, so you could see the hairs on his chest.

我为迟到的事向他道歉，他说道：
When I apologised for being late, he said:

“几分钟算什么？
‘What's a few minutes?

我和琳迪已经结婚二十七年了。
Lindy and I have been married twenty-seven years.

几分钟算什么？”
What's a few minutes?’

他没有生气，但似乎心情沉重——一点儿也不浪漫。
He wasn't angry, but his mood seemed grave and solemn – not at all romantic.

他身后的刚朵拉轻轻地在水里摇晃，我看见刚朵拉上的船夫是维托里奥，我很讨厌的一个人。
Behind him was the gondola, gently rocking in the water, and I saw the gondolier was Vittorio, a guy I don't like much.

他当着我的面总是一副友好的样子，可是我知道——我知道在我背后——他到处说些难听的话，说像我一样的人的闲话，他把我们这种人称为“新国家来的外地人”。
To my face, Vittorio's always friendly, but I know – I knew back then – he goes around saying all kinds of foul things, all of it rubbish, about people like me, people he calls ‘the foreigners from the new countries’.

所以那天晚上，当他像兄弟似的跟我打招呼时，我只是点点头，静静地看着他扶加德纳先生上船。
That's why, when he greeted me that evening like a brother, I just nodded, and waited silently while he helped Mr Gardner into the gondola.

然后我把我的吉他递给他——我带了一把西班牙吉他，而不是有椭圆形音孔的那把——自己上了船。
Then I passed him my guitar – I'd brought my Spanish guitar, not the one with the oval sound-hole – and got in myself.

加德纳先生在船头不停变换着姿势，然后突然用力地坐下去，船差点翻了。
Mr Gardner kept shifting positions at the front of the boat, and at one point sat down so heavily we nearly capsized.

可是他似乎并没有注意到。我们开船了，他一直盯着水面。
But he didn't seem to notice and as we pushed off, he kept staring into the water.

我们静静地在水上漂着，经过黑色的建筑，穿过低矮的小桥。
For a few minutes we drifted in silence, past dark buildings and under low bridges.

就这么过了好一会儿，加德纳先生从沉思中回过神来，说道：
Then he came out of his deep thoughts and said:

“听着，朋友。
‘Listen, friend.

我知道下午我们已经说好了今晚要唱哪几首歌。
I know we agreed on a set for this evening.

但是我在想，琳迪喜欢《当我到达凤凰城的时候》这首歌。
But I've been thinking. Lindy loves that song, “By the Time I Get to Phoenix”.

我很久以前录的一首歌。”
I recorded it once a long time ago.’

“我知道，加德纳先生。
‘Sure, Mr Gardner.

以前我母亲总说你唱的版本比辛纳特拉的，或者那个家喻户晓的格伦·坎贝尔版的都好听。”
My mother always said your version was better than Sinatra's. Or that famous one by Glenn Campbell.’

加德纳先生点点头，接着有一小会儿我看不见他的脸。
Mr Gardner nodded, then I couldn't see his face for a while.

维托里奥吆喝了一声，船转弯了，吆喝声在墙壁间回响。
Vittorio sent his gondolier's cry echoing around the walls before steering us round a corner.

“以前我经常唱给她听，”加德纳先生说。
‘I used to sing it to her a lot,’ Mr Gardner said.

“所以我想今晚她一定乐意听到这首歌。
‘You know, I think she'd like to hear it tonight.

你记得调子吗？”
You're familiar with the tune?’

此时我已经把吉他拿出来了，我就弹了几小节。
My guitar was out of the case by this time, so I played a few bars of the song.

“高一点，”他说。
‘Take it up,’ he said.

“升到降E调。
‘Up to E-flat.

我在唱片里就是这么唱的。”
That's how I did it on the album.’

于是我就用降E调弹了起来，弹了差不多整个主歌的部分以后，加德纳先生唱了起来，很轻很柔地，像是只记得一部分歌词。
So I played the chords in that key, and after maybe a whole verse had gone by, Mr Gardner began to sing, very softly, under his breath, like he could only half remember the words.

可是他的声音还是清晰地回响在安静的运河上。
But his voice resonated well in that quiet canal.

而且真是太好听了。
In fact, it sounded really beautiful.

一时间我仿佛又回到了童年，回到了那个公寓，躺在地毯上，而我母亲坐在沙发上，筋疲力尽，或者伤心无比地听着托尼·加德纳的唱片在房间的角落里旋转着。
And for a moment it was like I was a boy again, back in that apartment, lying on the carpet while my mother sat on the sofa, exhausted, or maybe heart-broken, while Tony Gardner's album spun in the corner of the room.

加德纳先生突然停下来，说道：“很好。
Mr Gardner broke off suddenly and said:‘Okay.

《凤凰城》我们就用降E调。
We'll do “Phoenix” in E-flat.

然后是《我太易坠入爱河》，如我们计划的那样。
Then maybe “I Fall in Love Too Easily”, like we planned.

最后是《给我的宝贝》。
And we'll finish with “One for My Baby”.

这样就够了。
That'll be enough.

她不会想听再多的了。”
She won't listen to any more than that.’

说完，加德纳先生又陷入了沉思，我们在黑暗中慢慢地往前漂去，只听见维托里奥轻轻泼溅起的水声。
He seemed to sink back into his thoughts after that, and we drifted along through the darkness to the sound of Vittorio's gentle splashes.

“加德纳先生，”我终于忍不住问道，“希望您别介意我这么问，可是加德纳太太知道今晚的表演吗？
‘Mr Gardner,’ I said eventually, ‘I hope you don't mind me asking. But is Mrs Gardner expecting this recital?

还是说这会是个惊喜？”
Or is this going to be a wonderful surprise?’

他深深地叹了口气，说道：“我想应该是属于惊喜这一类的。”
He sighed heavily, then said:‘I guess we'd have to put this in the wonderful surprise category.’

他停了一下，又说道，“天晓得她会有什么反应。
Then he added:‘Lord knows how she'll react.

兴许我们唱不到《给我的宝贝》。”
We might not make it all the way to “One for My Baby”.’

维托里奥又转了一个弯，突然传来了音乐声和笑声，我们正漂过一家灯火通明的大餐厅。
Vittorio steered us round another corner, and suddenly there was laughter and music, and we were drifting past a large, brightly lit restaurant.

好像客满了，侍者忙碌地穿梭其间，食客们都很开心的样子，尽管那时运河边上还不是非常暖和。
Every table seemed taken, the waiters were rushing about, the diners looked very happy, even though it couldn't have been so warm next to the canal at that time of year.

我们刚刚一直在宁静和黑暗中行驶，现在看见餐厅显得有些纷乱。
After the quiet and the darkness we'd been travelling through, the restaurant was kind of unsettling.

感觉好像我们是静止不动的，站在码头上，看着这只闪闪发光的开着派对的船驶过。
It felt like we were the stationary ones, watching from the quay, as this glittering party boat slid by.

我注意到有几张脸朝我们这里看了看，可是没有人太在意我们。
I noticed a few faces look our way, but no one paid us much attention.

把餐厅甩在身后以后，我说道：
Then the restaurant was behind us, and I said:

“真有意思。
‘It's funny.

要是那些游客发现一条载着著名的托尼·加德纳的船刚刚开了过去，不知他们会有什么反应？”
Can you imagine what those tourists would do if they realised a boat had just gone by containing the legendary Tony Gardner?’

维托里奥英语懂的不多，但是他听懂了这句话的大意，笑了一下。
Vittorio, who doesn't understand much English, got the gist of this and gave a little laugh.

而加德纳先生却没有反应。
But Mr Gardner didn't respond for some time.

直到我们又驶入黑暗，驶进一条狭窄的河道，驶过沿岸灯光昏暗的门口时，他才说道：
We were back in the dark again, going along a narrow canal past dimly lit doorways, when he said:

“我的朋友，你是从波兰来的，所以你不知道是怎么一回事。”
‘My friend, you come from a communist country. That's why you don't realise how these things work.’

“加德纳先生，”我说，“我的祖国现在是自由的民族了。”
‘Mr Gardner,’ I said, ‘my country isn't communist any more. We're free people now.’

“抱歉。
‘I'm sorry.

我没有侮辱你们国家的意思。
I didn't mean to denigrate your nation.

你们是勇敢的民族。
You're a brave people.

我希望你们赢得和平和繁荣。
I hope you win peace and prosperity.

可是朋友，我想告诉你的是。我想说的是从你来的地方，自然还有很多东西是你不明白的。
But what I intended to say to you, friend, what I meant was that coming from where you do, quite naturally, there are many things you don't understand yet.

正如在你们国家也有很多事情我不会明白。”
Just like there'd be many things I wouldn't understand in your country.’

“我想是这样的，加德纳先生。”
‘I guess that's right, Mr Gardner.’

“我们刚刚经过的那些人。
‘Those people we passed just now.

要是你过去问他们：‘嘿，你们还有人记得托尼·加德纳吗？’也许当中一些人，甚至是大部分人，会说记得。
If you'd gone up to them and said, “Hey, do any of you remember Tony Gardner?” then maybe some of them, most of them even, might have said yes.

谁知道呢？
Who knows?

但是像我们刚才那样子经过，就算他们认出了我，他们会兴奋不已吗？
But drifting by the way we just did, even if they'd recognised me, would they get excited?

我想不会。
I don't think so.

他们不会放下他们的叉子，不会停下他们的烛光晚餐。为什么要呢？
They wouldn't put down their forks, they wouldn't interrupt their candlelit heart-tohearts.

只不过是一个已经过时了的歌手。”
Why should they? Just some crooner from a bygone era.’

“我不相信，加德纳先生。
‘I can't believe that, Mr Gardner.

您是经典。
You're a classic.

就像辛纳特拉或者迪安·马丁一样。
You're like Sinatra or Dean Martin.

一些一流的大师是不会过时的。
Some class acts, they never go out of fashion.

不像那些流行歌星。”
Not like these pop stars.’

“谢谢你这么说，朋友。
‘You're very kind to say that, friend.

我知道你是好意。
I know you mean well.

可是唯独今晚，不要开我的玩笑。”
But tonight of all nights, it's no time to be kidding me.’

我正想反驳，但加德纳先生举止里的某些东西让我放开了这个话题。
I was about to protest, but something in his manner told me to drop the whole subject.

于是我们继续前进，没有人说话。
So we kept moving, no one speaking.

说实话，我开始纳闷自己是不是搅和进了一件什么事，这整个小夜曲到底是怎么一回事。
To be honest, I was now beginning to wonder what I'd got myself into, what this whole serenade thing was about.

他们毕竟是美国人啊。
And these were Americans, after all.

说不定当加德纳先生开始唱时，加德纳太太会拿着枪走到窗前，朝我们开火。
For all I knew, when Mr Gardner started singing, Mrs Gardner would come to the window with a gun and fire down at us.

也许维托里奥跟我想到了一块儿，因为当我们驶过一面墙上的路灯下时，他朝我递了个眼色，像是在说：“他真是个怪人，不是吗，朋友？”
Maybe Vittorio's thoughts were moving along the same lines, because as we passed under a lantern on the side of a wall, he gave me a look as though to say:‘We've got a strange one here, haven't we, amico?’

可是我没有理他。
But I didn't respond.

我不会跟他那种人一起反对加德纳先生的。
I wasn't going to side with the likes of him against Mr Gardner.

在维托里奥看来，像我这种外地人，成天敲诈游客，弄脏河水，总之就是破坏了这座该死的城市。
According to Vittorio, foreigners like me, we go around ripping off tourists, littering the canals, in general ruining the whole damn city.

哪天遇上他心情不好，他会说我们是强盗——甚至是强奸犯。
Some days, if he's in a bad mood, he'll claim we're muggers – rapists, even.

有一次，我当面问他是不是真的说过这样的话，他赌誓说全是一派胡言。
I asked him once to his face if it was true he was going around saying such things, and he swore it was all a pack of lies.

他有一个他敬如母亲的阿姨是犹太人，他怎么可能是个种族主义者呢？
How could he be a racist when he had a Jewish aunt he adored like a mother?

可是一天下午幕间休息的时候，我靠在多尔索杜罗的一座桥上打发时间，一条刚朵拉从桥下经过。
But one afternoon I was killing time between sets, leaning over a bridge in Dorsoduro, and a gondola passed underneath.

船上有三名游客，维托里奥摇着桨站在他们身后，高谈阔论，讲的正是这些垃圾。
There were three tourists sitting in it, and Vittorio standing over them with his oar, holding forth for the world to hear, coming out with this very same rubbish.

所以他尽可以看着我，但别想从我这里得到伙伴情谊。
So he can meet my eye all he likes, he'll get no camaraderie from me.

“我来教你一个秘诀，”加德纳先生突然说道。
‘Let me tell you a little secret,’ Mr Gardner said suddenly.

“一个表演的小秘诀。
‘A little secret about performance.

给同行的你。
One pro to another.

很简单。
It's quite simple.

你要多少了解你的观众，不管是哪个方面，你得知道一点儿。
You've got to know something, doesn't matter what it is, you've got to know something about your audience.

一件让你心里觉得今晚的观众跟昨晚的不同的事。
Something that for you, in your mind, distinguishes that audience from the one you sang to the night before.

比如说你在密尔沃基演出。
Let's say you're in Milwaukee.

你就得问问自己，有什么不同，密尔沃基的观众有何特别之处？
You've got to ask yourself, what's different, what's special about a Milwaukee audience?

他们跟麦迪逊的观众有何不同？
What makes it different from a Madison audience?

想不出来也要一直想，直到想到为止。
Can't think of anything, you just keep on trying till you do.

密尔沃基，密尔沃基。
Milwaukee, Milwaukee.

密尔沃基有上好的猪排。
They have good pork chops in Milwaukee.

这就行了，当你走上台时心里就想着这个。
That'll work, that's what you use when you step out there.

不用说出来让观众知道，你唱歌的时候心里知道就行。
You don't have to say a word about it to them, it's what's in your mind when you sing to them.

你面前的这些人吃上好的猪排。
These people in front of you, they're the ones who eat good pork chops.

他们对猪排非常讲究。
They have high standards when it comes to pork chops.

你明白我的意思吗？
You understand what I'm saying?

这样观众就成了你知道的人了，成了你可以为之演出的人。
That way the audience becomes someone you know, someone you can perform to.

这就是我的秘诀。
There, that's my secret.

给同行的你。”
One pro to another.’

“谢谢，加德纳先生。
‘Well, thank you, Mr Gardner.

我以前从没这样想过。
I'd never thought about it that way.

像您这样的人的指点，我永生难忘。”
A tip from someone like you, I won't forget it.’

“那么今晚，”他接着说，“我们是为琳迪表演。
‘So tonight,’ he went on, ‘we're performing for Lindy.

琳迪是我们的观众。
Lindy's the audience.

所以现在我要告诉你一些琳迪的事情。
So I'm going to tell you something about Lindy.

你想听吗？”
You want to hear about Lindy?’

“当然，加德纳先生，”我说。
‘Of course, Mr Gardner,’ I said.

“我很想听听她的事情。”
‘I'd like to hear about her very much.’

接下来二十分钟左右的时间，我们坐在刚朵拉里，顺着水流漂，听加德纳先生讲。
For the next twenty minutes or so, we sat in that gondola, drifting round and round, while Mr Gardner talked.

他的声音时而低得近乎耳语，像是在自言自语。
Sometimes his voice went down to a murmur, like he was talking to himself.

而当路灯或者沿途窗户的灯光照到船上时，他就会突然想起我，提高音量，然后问“你明白我的意思吗，朋友？”之类的。
Other times, when a lamp or a passing window threw some light across our boat, he'd remember me, raise his voice, and say something like:‘You understand what I'm saying, friend?’

他说，他妻子来自美国中部明尼苏达州的一个小镇。中学时，学校的老师让她的日子很不好过，因为她老看电影明星的杂志，不学习。
His wife, he told me, had come from a small town in Minnesota, in the middle of America, where her schoolteachers gave her a hard time because she was always looking at magazines of movie stars instead of studying.

“老师们不知道琳迪有远大的计划。
‘What these ladies never realised was that Lindy had big plans.

看看现在的她。
And look at her now.

富有、美丽、周游世界。
Rich, beautiful, travelled all over the world.

而那些学校里的老师呢，他们如今有什么成就？
And those schoolteachers, where are they today?

过得怎么样呢？
What kind of lives have they had?

他们要是多看些电影杂志，多些梦想，也许也能够拥有一些琳迪今日的成就。”
If they'd looked at a few more movie magazines, had a few more dreams, they too might have a little of what Lindy has today.’

十九岁时，她搭便车到了加州，想进好莱坞，却在洛杉矶郊外的一家路边餐厅当起了服务生。
At nineteen, she'd hitch-hiked to California, wanting to get to Hollywood. Instead, she'd found herself in the outskirts of Los Angeles, working as a waitress in a roadside diner.

“意想不到啊，”加德纳先生说。
‘Surprising thing,’ Mr Gardner said.

“这家餐厅，这个高速公路旁不起眼的小地方，却成了她最好的去处。
‘This diner, this regular little place off the highway.

因为这里是所有野心勃勃的姑娘来的地方，从早到晚。
It turned out to be the best place she could have wound up.

她们在这里见面，七个、八个、十来个。
Because this was where all the ambitious girls came in, morning till night.

她们吃啊喝啊，坐在那里聊上好几个钟头。”
They used to meet there, seven, eight, a dozen of them, they'd order their coffees, their hot-dogs, sit in there for hours and talk.’

这些姑娘都比琳迪大一些，来自美国的四面八方，在洛杉矶待了至少两三年了。
These girls, all a little older than Lindy, had come from every part of America and had been in the LA area for at least two or three years.

她们聚在餐厅里聊八卦，聊倒霉事，讨论计策，汇报大家的进展。
They came into the diner to swap gossip and hard-luck stories, discuss tactics, keep a check on each other's progress.

可是这里最引人注目的是一个叫梅格的女人，一个四十多岁的女招待。
But the main draw of the place was Meg, a woman in her forties, the waitress Lindy worked with.

“梅格是这群姑娘的大姐头，智囊袋。
‘To these girls Meg was their big sister, their fountain of wisdom.

因为以前她就和她们一样。
Because once upon a time, she'd been exactly like them.

你得明白，她们是一群正经的姑娘，野心勃勃、意志坚定的姑娘。
You've got to understand, these were serious girls, really ambitious, determined girls.

她们是不是和其他女孩子一样谈论衣服、鞋子、化妆品？
Did they talk about clothes and shoes and make-up like other girls?

是，她们也谈这些。
Sure they did.

但是她们只关心哪些衣服、鞋子、化妆品能帮助她们嫁给明星。
But they only talked about which clothes and shoes and make-up would help them marry a star.

她们谈不谈论电影？
Did they talk about movies?

她们谈不谈论歌坛？
Did they talk about the music scene?

当然了。
You bet.

但是她们谈的是哪个电影明星或者歌星还是单身，哪个婚姻不幸，哪个离了婚。
But they talked about which movie stars and singers were single, which ones were unhappily married, which ones were getting divorced.

而所有这些，梅格都能告诉她们，还有其他很多、很多的东西。
And Meg, you see, she could tell them all this, and much, much more.

梅格走过她们要走的路。
Meg had been down that road before them.

她知道钓到大腕的所有规矩和门道。
She knew all the rules, all the tricks, when it came to marrying a star.

琳迪和她们坐在一起，一字不落地听着。
And Lindy sat with them and took everything in.

这家小小的热狗店就是她的哈佛、她的耶鲁。
That little hot-dog diner was her Harvard, her Yale.

明尼苏达来的一个十九岁的小姑娘？
A nineteen-year-old from Minnesota?

现在想想她可能会变成什么样，都让我哆嗦。
Makes me shudder now to think what could have happened to her.

可是她是走运的。”
But she got lucky.’

“加德纳先生，”我说道，“请原谅我打断您。
‘Mr Gardner,’ I said, ‘excuse me for interrupting.

可要是这个梅格这么神通广大，她干吗不自己嫁个明星？
But if this Meg was so wise about everything, how come she wasn't married to a star herself?

她干吗还在餐厅里端盘子？”
Why was she serving hot-dogs in this diner?’

“问得好，可你不太明白这些事情到底是怎么一回事。
‘Good question, but you don't quite see how these things work.

好，这位女士，梅格，她自己没有成功。
Okay, this lady, Meg, she hadn't made it.

可是重点是，她看过别人是怎么成功的。
But the point is, she'd watched the ones who had.

你明白吗，朋友？
You understand, friend?

她曾经和这些姑娘一样，她目睹谁成功了，谁失败了。
She'd been just like those girls once, and she'd watched some succeed, others fail.

她见过圈套陷阱，也见过阳关大道。她把所有的故事都讲给她们听，而其中一些人学进去了。
She'd seen the pitfalls, she'd seen the golden stairways. She could tell them all the stories and those girls listened.

琳迪就是其中一个。
And some of them learned.

就像我说的，这里是她的哈佛。
Lindy, for one. Like I say, that was her Harvard.

这里成就了后来的她。
It made her what she is.

这里给了她日后需要的力量，天啊，她确实需要。
It gave her the strength she needed later on, and boy, did she need it.

她等了六年才交了第一次好运。
It took her six years before her first break came along.

你想象得到吗？六年的处心积虑，六年的如履薄冰。
Can you imagine it? Six years of manoeuvring, planning, putting yourself on the line like that.

一次次地遇到挫折。
Getting knocked back over and over again.

可是就跟我们的事业一样。
But it's just like in our business.

你不能因为最初的一些小挫折就打退堂鼓。
You can't roll over and give up after the first few knocks.

大部分人做不到，这样的姑娘随处可见，在默默无闻的地方嫁给默默无闻的人。
The girls who do, you can see them any place, married to nobodies in nowhere towns.

而有一些人，有一些像琳迪这样的人，她们从每一次的挫折中吸取经验教训，变得越来越坚强，她们屡败屡战，却越战越勇。
But just a few of them, the ones like Lindy, they learn from every knock, they come back stronger, tougher, they come back fighting and mad.

你以为琳迪没有蒙过羞？像她这么漂亮，这么有魅力的人？
You think Lindy didn't suffer humiliation? Even with her beauty and charm?

人们不明白美丽不是最主要的，一半都不到。
What people don't realise is that beauty isn't the half of it.

用得不对，人们就视你为娼妇。
Use it wrong, you get treated like a whore.

总之，六年之后，琳迪终于有了好运。”
Anyway, after six years, she finally got her break.’

“她遇到您了是吗，加德纳先生？”
‘That's when she met you, Mr Gardner?’

“我？
‘Me?

不，不是。
No, no.

我没有这么快出现。
I didn't come on the scene for a while longer.

她嫁给了迪诺·哈特曼。
She married Dino Hartman.

没听说过迪诺？”
You've never heard of Dino?’

说到这里加德纳先生微微冷笑了一下。
Mr Gardner did a slightly unkind laugh here.

“可怜的迪诺。
‘Poor Dino.

我想他的唱片没有流传到共产主义国家去。
I guess Dino's records wouldn't have made it to the communist countries.

不过那时他很有些名气。
But Dino had quite a name for himself in those days.

当时他频频在维加斯演出，出了几张金唱片。
He sang in Vegas a lot, had a few gold records.

我刚才说了，琳迪交了好运。
Like I said, that was Lindy's big break.

我初次见到琳迪时，她是迪诺的妻子。
When I first met her, she was Dino's wife.

这种情况老梅格早跟她们解释过了。
Old Meg had explained that's how it happens all the time.

诚然有的姑娘能第一次就撞了大运，一步登天，钓上辛纳特拉或者白兰度这样的人。
Sure, a girl can get lucky first time, go straight to the top, marry a Sinatra or a Brando.

可是这种事情并不多见。
But it doesn't usually happen like that.

姑娘们得准备好在二楼就出电梯，走出来。
A girl's got to be prepared to get out of the elevator at the second floor, walk around.

她得习惯二楼的空气。
She needs to get used to the air on that floor.

也许将来有一天，她会在二楼这里遇见一个从顶楼公寓下来的人，也许是下来取一下东西。
Then maybe, one day, on that second floor, she'll run into someone who's come down from the penthouse for a few minutes, maybe to fetch something.

这人对她说，嘿，要不要跟我一起回去，一起上顶楼去。
And this guy says to her, hey, how about coming back up with me, up to the top floor.

琳迪清楚游戏规则。
Lindy knew that's how it usually played out.

她的战斗力没有因为嫁给了迪诺而减退，她的雄心也没有因此而大打折扣。
She wasn't weakening when she married Dino, she wasn't cutting her ambition down to size.

迪诺是个正派人。
And Dino was a decent guy.

我一直都喜欢他。
I always liked him.

所以虽然我第一次见到琳迪就深深地爱上了她，但我没有采取行动。
That's why, even though I fell badly for Lindy the moment I first saw her, I didn't make a move.

我是个绝对的绅士。
I was the perfect gentleman.

后来我得知琳迪因此而更加下定决心。
I found out later that was what made Lindy all the more determined.

啊，你应该钦佩这样的姑娘！
Man, you've got to admire a girl like that!

我得告诉你，朋友，我那个时候非常非常红。
I have to tell you, friend, I was a bright, bright star around this time.

我猜你母亲就是在那个时期听我的歌的。
I guess this would be around when your mother was listening to me.

然而迪诺却开始迅速走下坡路。
Dino, though, his star was starting to go down fast.

那段时期很多歌手的日子都不好过。
It was tough for a lot of singers just around then.

时代变了。
Everything was changing.

孩子们都听披头士、滚石。
Kids were listening to the Beatles, the Rolling Stones.

可怜的迪诺，他的歌太像平·克劳斯贝了。
Poor Dino, he sounded too much like Bing Crosby.

他尝试做了一张巴萨诺瓦的唱片，却被大家耻笑。
He tried a bossa nova album folks just laughed at.

这时琳迪肯定不能再跟着他了。
Definitely time for Lindy to get out.

当时的情况没有人能指责我们。
No one could have accused us of anything in that situation.

我想就是迪诺也没有真的责怪我们。
I don't think even Dino really blamed us.

所以我行动了。
So I made my move.

她就这样到了顶楼公寓。
That's how she got up to the penthouse.

“我们在维加斯结了婚，我们把酒店的浴缸装满香槟。
‘We got married in Vegas, we had the hotel fill the bathtub with champagne.

今晚我们要唱的那首《我太易坠入爱河》，知道我为什么选这首歌吗？
That song we're gonna do tonight, “I Fall in Love Too Easily”. You know why I chose that one?

想知道吗？
You want to know?

新婚后不久，有一次我们在伦敦。
We were in London once, not long after we got married.

吃完早饭以后我们回到客房，女佣正在打扫我们的套房。
We came up to our room after break-fast and the maid's in there cleaning our suite.

可是我们欲火烧身。于是我们进了房间，我们可以听见女佣在用吸尘器打扫客厅的声音，可是我们看不见她，隔着隔板墙。
But Lindy and I are horny as rabbits. So we go in, and we can hear the maid vacuuming our lounge, but we can't see her, she's through the partition.

我们踮着脚尖偷偷地溜进去，像孩子似的，你瞧。
So we sneak through on tip-toes, like we're kids, you know?

我们悄悄地溜回卧室，把门关上。
We sneak through to the bedroom, close the door.

我们看得出卧室已经打扫完了，所以女佣应该不用再回到卧室来了，但我们也不是很肯定。
We can see the maid's finished the bedroom already, so maybe she doesn't need to come back, but we don't know that for sure.

管他呢，我们才不在乎。
Either way, we don't care.

我们脱掉衣服，在床上大干起来，女佣一直都在隔壁，在套房里走来走去，不晓得我们已经回来了。
We tear off our clothes, we make love on the bed, and all the time the maid's on the other side, moving around our suite, no idea we've come in.

我说了，我们欲火烧身，可是过了一会儿，我们突然觉得整件事情太好玩了，我们开始笑个不停。后来我们完事了，躺在床上拥抱着对方，女佣还在外面，你知道吗，她居然唱起歌来了！
I tell you, we were horny, but after a while, we found the whole thing so funny, we just kept laughing. Then we'd finished and we were lying there in each other's arms, and the maid was still out there and you know what, she starts singing!

她用完吸尘器，开始放声高歌，天啊，她的声音太难听了！
She's finished with the vacuum, so she starts singing at the top of her voice, and boy, did she have one lousy voice!

我们笑个不停，当然是尽量不发出声音。
We were laughing and laughing, but trying to keep it silent.

你猜接下来怎么着，她不唱了，打开收音机。
Then what do you know, she stops singing and turns on the radio.

我们突然听见切特·贝克的声音，在唱《我太易坠入爱河》，优美、舒缓、柔和。
And suddenly we hear Chet Baker. He's singing “I Fall in Love Too Easily”, nice and slow and mellow.

我和琳迪躺在床上，听着切特的歌声。过了一会儿，我也唱了起来，很轻地，跟着收音机里的切特·贝克唱，琳迪偎依在我怀里。
And Lindy and me, we just lay there across the bed together, listening to Chet singing. And after a while, I'm singing along, really soft, singing along with Chet Baker on the radio, Lindy curled up in my arms.

事情就是这样。
That's how it was.

这就是为什么今晚我选了这首歌。
That's why we're gonna do that song tonight.

我不知道她会不会想起这件事。
I don't know if she'll remember though.

天晓得。”
Who the hell knows?’

加德纳先生不说了，我看见他擦去眼泪。
Mr Gardner stopped talking and I could see him wiping away tears.

船又转了个弯，我发现我们第二次经过那家餐厅了。
Vittorio brought us around another corner and I realised we were going past the restaurant a second time.

餐厅似乎比先前更加热闹，有个人，我知道他叫安德烈亚，正在角落里弹钢琴。
It looked even more lively than before, and a pianist, this guy I know called Andrea, was now playing in the corner.

当我们再次驶入黑暗之中时，我说道：“加德纳先生，我知道这不关我的事，可我看得出眼下您和加德纳太太的关系不是很好。
As we drifted again into the dark, I said:‘Mr Gardner, it's none of my business, I know. But I can see maybe things haven't been so good between you and Mrs Gardner lately.

我想让您知道我是明白这些事的。
I want you to know I understand about things like that.

以前我母亲经常悲伤，大概就和您现在一样。
My mother often used to get sad, maybe just the way you are now.

她以为这次她找到了一个好人，她高兴极了，告诉我这个人要做我的新爸爸了。
She'd think she'd found someone, she'd be so happy and tell me this guy was going to be my new dad.

头几次我相信了。可后来，我知道事情不会尽如人意的。
The first couple of times I believed her. After that, I knew it wouldn't work out.

可是我母亲从来没有停止相信。
But my mother, she never stopped believing it.

每当她伤心的时候，大概就像您今晚这样，你猜她怎么着？
And every time she felt down, maybe like you are tonight, you know what she did?

她会放你的唱片，跟着唱。
She put on your records and sang along.

那些漫长的冬天，在我们住的小公寓里，她坐在那里，蜷起膝盖，手里头拿着一杯喝的，轻轻地跟着唱。
All those long winters, in that tiny apartment of ours, she'd sit there, knees tucked up under her, glass of something in her hand, and she'd sing along softly.

有时候，我还记得，加德纳先生，楼上的邻居会用力地敲天花板，特别是当你放一些大声的快歌时，比如《希翼》、《他们都笑话》之类的。
And sometimes, I remember this, Mr Gardner, our neighbours upstairs would bang on the ceiling, especially when you were doing those big up-tempo numbers, like “High Hopes” or “They All Laughed”.

我仔细地看着母亲，可是她好像什么也没听见，专心地听着你的歌，头跟着拍子一点一点，嘴唇跟着歌词一张一合。
I used to watch my mother carefully, but it was like she hadn't heard a thing, she'd be listening to you, nodding her head to the beat, her lips moving with the lyrics.

加德纳先生，我想说的是，您的音乐帮助我母亲度过那些伤心的日子，也一定帮助了其他成千上万的人。
Mr Gardner, I wanted to say to you. Your music helped my mother through those times, it must have helped millions of others.

所以也一定能帮助您自己的。”
And it's only right it should help you too.’

说完我笑了笑，本想作为鼓励，没想到笑得大声了点。“今晚您可以信任我，加德纳先生。
I did a little laugh, which I meant to be encouraging, but it came out louder than I'd meant it to. ‘You can count on me tonight, Mr Gardner.

我会全力以赴。今晚我的演出不会输给任何一个管弦乐队的，您等着瞧吧。
I'm going to put everything I've got into it. I'll make it as good as any orchestra, you just see.

加德纳太太听了以后，天晓得？也许你们就会重归于好。
And Mrs Gardner will hear us and who knows? Maybe things will start going fine between you again.

夫妻间都会有不愉快的时候。”
Every couple goes through difficult times.’

加德纳先生微微一笑。
Mr Gardner smiled.

“你是个好人儿。
‘You're a sweet guy.

我很感激你今晚的帮助。
I appreciate you helping me out tonight.

但是我们没有时间再聊了。
But we don't have any more time to talk.

琳迪回到房里了。
Lindy's in her room now.

我看见灯亮了。”
I can see the light on.’

说话间我们正经过一座我们至少已经路过两次的公寓。现在我明白了为什么维托里奥带着我们兜圈子。
We were going by a palazzo we'd passed at least twice before, and I now realised why Vittorio had been taking us round in circles.

加德纳先生在等某个窗户的灯光，每次他看见灯还没亮，我们就再绕一圈。
Mr Gardner had been watching for the light to come on in a particular window, and each time he'd found it still dark, we'd moved on to do another circle.

但是这一次，三楼的窗户亮了，百叶窗打开着，从我们这里可以看见屋里的一小块带黑色木梁的天花板。
This time, though, the third-storey window was lit, the shutters were open, and from down where we were, we could see a small part of the ceiling with its dark wooden beams.

加德纳先生示意维托里奥停下，维托里奥早已经停下桨，让船慢慢漂到窗户的正下方。
Mr Gardner signalled to Vittorio, but he'd already stopped rowing and we drifted slowly till the gondola was directly beneath the window.

加德纳先生站起身来，又一次把船弄得激烈地摇晃起来，维托里奥赶紧把船稳住。
Mr Gardner stood up, making the boat rock alarmingly again, and Vittorio had to move quickly to steady us.

加德纳先生朝上面轻轻地喊道：“琳迪？
Then Mr Gardner called up, much too softly:‘Lindy?

琳迪？”
Lindy?’

然后他终于大声叫道：“琳迪！”
Finally he called out much louder:‘Lindy!’

一只手推开百叶窗，接着一个身影出现在狭小的阳台上。
A hand pushed the shutters out wider, then a figure came onto the narrow balcony.

虽然公寓墙上不远的地方有一盏灯，但是灯光昏暗，看不清加德纳太太的样子。
A lantern was fixed to the palazzo wall not far above us, but the light wasn't good, and Mrs Gardner wasn't much more than a silhouette.

然而我依稀看出她把头发梳起来了，和上午在广场上不一样，大概是为了刚刚的晚餐。
I could see though that she'd put up her hair since I'd met her in the piazza, maybe for their dinner earlier on.

“是你吗，亲爱的？”
‘That you, sweety?’

她靠在阳台的栏杆上问。
She leaned over the balcony rail.

“我还以为你被绑架之类了呢。
‘I thought you'd been kidnapped or something.

你害我担心死了。”
You had me all anxious.’

“别傻了，亲爱的。
‘Don't be foolish, honey.

在这种地方会出什么事呢？
What could happen in a town like this?

再说，我给你留了纸条。”
Anyway, I left you that note.’

“我没有看见什么纸条，亲爱的。”
‘I didn't see any note, sweety.’

“我给你留了纸条。
‘I left you a note.

让你别担心。”
Just so you wouldn't get anxious.’

“纸条在哪儿呢？
‘Where is it, this note?

上面写什么？”
What did it say?’

“我不记得了，亲爱的。”
‘I don't remember, honey.’

加德纳先生生气了。
Mr Gardner now sounded irritated.

“只是张普通的纸条，说我要去买烟之类的。”
‘It was just a regular note. You know, saying I'd gone to buy cigarettes or something.’

“你现在在那里就是干这个吗？
‘Is that what you're doing down there now?

买烟？”
Buying cigarettes?’

“不是，亲爱的。
‘No, honey.

这是另外一件事。
This is something different.

我要唱歌给你听。”
I'm gonna sing to you.’

“是在开什么玩笑吗？”
‘Is this some sort of joke?’

“不，亲爱的，不是开玩笑。
‘No, honey, it isn't a joke.

这里是威尼斯。
This is Venice.

这里的人就是这么干的。”
It's what people do here.’

说着指了指我和维托里奥，像是要证明他的话。
He gestured around to me and Vittorio, like our being there proved his point.

“我觉得外面有点冷，亲爱的。”
‘It's kind of chilly for me out here, sweety.’

加德纳先生重重地叹了口气。
Mr Gardner did a big sigh.

“那你进屋里去听吧。
‘Then you can listen from inside the room.

进屋里去，亲爱的，舒舒服服地坐好。
Go back in the room, honey, make yourself comfortable.

只要把窗户开着就能听得很清楚。”
Just leave those windows open and you'll hear us fine.’

加德纳太太仍旧低头看着他，他也抬头往上看，两个人都没有说话。
She went on gazing down at him for a while, and he went on gazing back up, neither of them saying anything.

片刻后，加德纳太太进屋里去了，加德纳先生好像很失望的样子，即便是他自己劝她这么做的。
Then she'd gone inside, and Mr Gardner seemed disappointed, even though this was exactly what he'd suggested she should do.

他低下头，又叹了口气，我能感觉到加德纳先生正在犹豫还要不要做。
He lowered his head with another sigh, and I could tell he was hesitating about going ahead.

于是我说道：
So I said:

“来吧，加德纳先生，我们开始吧。
‘Come on, Mr Gardner, let's do it.

第一首《当我到达凤凰城的时候》。”
Let's do “By the Time I Get to Phoenix”.’

我轻轻地弹了几个开始的音符，拍子还没有出来，只是一些音符，可以是歌曲的导入，也可以就这么渐渐退去。
And I played gently a little opening figure, no beat yet, the sort of thing that could lead into a song or just as easily fade away.

我试着弹得美国一点，伤心的路边酒吧，长长的高速公路。我还想起了我母亲，想我以前是怎么走进屋里，看见她坐在沙发上，盯着唱片的封面，封面上画着一条美国公路，或者一个歌手坐在一辆美国车里。
I tried to make it sound like America, sad roadside bars, big long highways, and I guess I was thinking too of my mother, the way I'd come into the room and see her on the sofa gazing at her record sleeve with its picture of an American road, or maybe of the singer sitting in an American car.

我的意思是，我试着要弹得让我母亲能听出就是那个国家，她唱片封面上的那个国家。
What I mean is, I tried to play it so my mother would have recognised it as coming from that same world, the world on her record sleeve.

还没等我反应过来，还没等我弹出什么连续的拍子来，加德纳先生就唱了起来。
Then before I realised it, before I'd picked up any steady beat, Mr Gardner started to sing.

他站在摇摇晃晃的刚朵拉上，我担心他随时会掉下去。
His posture, standing in the gondola, was pretty unsteady, and I was afraid he'd lose his balance any moment.

然而他的声音和我记忆里的一模一样——温柔、近乎沙哑，但是集结了全身的力量，像是从一个看不见的麦克风里传出来的。
But his voice came out just the way I remembered it – gentle, almost husky, but with a huge amount of body, like it was coming through an invisible mike.

而且和所有一流的美国歌手一样，他的声音略带疲倦，甚至是丝丝的犹豫，仿佛他并非一个惯于如此敞开心扉的人。
And like all the best American singers, there was that weariness in his voice, even a hint of hesitation, like he's not a man accustomed to laying open his heart this way.

所有的大师都是这样。
That's how all the greats do it.

我弹着，他唱着，一首充满漂泊和离别的歌。
We went through that song, full of travelling and goodbye.

一个美国人离开他的情人。
An American man leaving his woman.

歌曲一节节，城镇一座座，凤凰城、阿尔伯克基、俄克拉何马，他一路不停地思念着情人。车子沿着大路一直开，这是我母亲永远不可能做到的。
He keeps thinking of her as he passes through the towns one by one, verse by verse, Phoenix, Albuquerque, Oklahoma, driving down a long road the way my mother never could.

要是我们能像这样子将事情抛在身后——我猜母亲听这首歌的时候是这么想的。
If only we could leave things behind like that – I guess that's what my mother would have thought.

要是我们能像这样子将悲伤抛在身后。
If only sadness could be like that.

这首歌结束了，加德纳先生说：“好，直接唱下一首吧。
We came to the end and Mr Gardner said:‘Okay, let's go straight to the next one.

《我太易坠入爱河》。”
“I Fall in Love Too Easily”.’

这是我第一次为加德纳先生演奏，我小心翼翼地弹每一个音，结果我们配合得还不错。
This being my first time playing with Mr Gardner, I had to feel my way around everything, but we managed okay.

听了他给我讲的这首歌的故事以后，我不停地抬头看窗户，然而加德纳太太那里一点儿反应也没有，没有动静，没有声音，什么都没有。
After what he'd told me about this song, I kept looking up at that window, but there was nothing from Mrs Gardner, no movement, no sound, nothing.

歌唱完了，宁静和黑暗包围了我们。
Then we'd finished, and the quiet and the dark settled around us.

我听见不远处有人推开百叶窗，估计是住在附近的人想听得清楚些。
Somewhere nearby, I could hear a neighbour pushing open shutters, maybe to hear better.

可是加德纳太太的窗户什么情况也没有。
But nothing from Mrs Gardner's window.

我们慢慢地唱起了《给我的宝贝》，慢到几乎没有拍子，然后一切又归于平静。
We did ‘One for My Baby’ very slow, virtually no beat at all, then everything was silent again.

我们一直抬头看着窗户，过了许久，大概足足有一分钟的时间，我们终于听见了。
We went on looking up at the window, then at last, maybe after a full minute, we heard it.

声音若隐若现，但是绝对错不了，是加德纳太太在啜泣。
You could only just make it out, but there was no mistaking it. Mrs Gardner was up there sobbing.

“我们成功了，加德纳先生！”
‘We did it, Mr Gardner!’

我轻声说。
I whispered.

“我们成功了。
‘We did it.

我们打动她了。”
We got her by the heart.’

可是加德纳先生的样子并不高兴。
But Mr Gardner didn't seem pleased.

他疲倦地摇摇头，坐了下来，朝维托里奥摆了摆手。
He shook his head tiredly, sat down and gestured to Vittorio.

“把船划到另一边去吧。
‘Take us round the other side.

我该进去了。”
It's time I went in.’

当船再次开动时，我觉得加德纳先生一直在避开我的眼睛，几乎像是在为今晚的事情感到羞愧。我不禁想到这整件事情也许是一个恶作剧。
As we started to move again, I thought he was avoiding looking at me, almost like he was ashamed of what we'd just done, and I began thinking maybe this whole plan had been some kind of malicious joke.

因为就我我我我我所知，这些歌对加德纳太太都有讨厌的含义。
For all I knew, these songs all held horrible meanings for Mrs Gardner.

于是我收起吉他，坐在那里，或许有点儿闷闷不乐，我们就这么往前划去。
So I put my guitar away and sat there, maybe a bit sullen, and that's how we travelled for a while.

船到了开阔一些的水面，突然一艘观光游艇迎面从我们身边疾驶而过，在刚朵拉边溅起不小的波浪。
Then we came out to a much wider canal, and immediately a water-taxi coming the other way rushed past us, making waves under the gondola.

然而我们快到加德纳先生公寓的门口了。维托里奥把船慢慢靠近岸边时，我说道：
But we were nearly up to the front of Mr Gardner's palazzo, and as Vittorio let us drift towards the quay, I said:

“加德纳先生，您是我成长过程中重要的一部分。
‘Mr Gardner, you've been an important part of my growing up.

今晚对我来说太特别了。
And tonight's been a very special night for me.

如果我们就此告别，以后我不会再见到您，那么我余生都会一直琢磨。
If we just said goodbye now and I never saw you again, I know for the rest of my life I'll always be wondering.

所以加德纳先生，请您告诉我。
So Mr Gardner, please tell me.

刚才，加德纳太太是因为喜悦而哭泣，还是因为伤心？”
Just now, was Mrs Gardner crying because she was happy or because she was upset?’

我以为他不会回答我。
I thought he wasn't going to answer.

昏暗的灯光下，我只能看见船头加德纳先生弓着背的身影。
In the dim light, his figure was just this hunched-up shape at the front of the boat.

可是当维托里奥系缆绳时，加德纳先生静静说道：
But as Vittorio was tying the rope, he said quietly:

“我想我以这种方式唱歌给她听，她很高兴。
‘I guess she was pleased to hear me sing that way.

但当然了，她很伤心。
But sure, she was upset.

我们俩都很伤心。
We're both of us upset.

漫长的二十七年，这次旅行之后，我们就要分开了。
Twenty-seven years is a long time and after this trip we're separating.

这是我们最后一次一起旅行了。”
This is our last trip together.’

“听您这么说我真的很难过，加德纳先生，”我轻轻地说。
‘I'm really sorry to hear that, Mr Gardner,’ I said gently.

“我想很多婚姻最后都走到了尽头，即便是一起过了二十七年。
‘I guess a lot of marriages come to an end, even after twenty-seven years.

但至少你们能以这种方式分开。
But at least you're able to part like this.

一起到威尼斯度假，在刚朵拉上唱歌。
A holiday in Venice. Singing from a gondola.

很少有夫妻能这么友好地分手。”
There can't be many couples who split up and stay so civilised.’

“我们为什么不友好呢？
‘But why wouldn't we be civilised?

我们仍然深爱着对方。
We still love each other.

这就是她为什么哭了。
That's why she's crying up there.

她还像我爱着她一样地爱着我。”
Because she still loves me as much as I still love her.’

维托里奥已经上岸了，可是加德纳先生和我都还坐在黑暗里。
Vittorio had stepped up onto the quay, but Mr Gardner and I kept sitting in the darkness.

我等着他往下讲，果然，过了一会儿，他接着说道：
I was waiting for him to say more, and sure enough, after a moment, he went on:

“就像我说的，我对琳迪一见钟情。
‘Like I told you, the first time I laid eyes on Lindy I fell in love with her.

可是她也爱我吗？
But did she love me back then?

我想她根本没考虑过这个问题。
I doubt if the question ever crossed her mind.

我是个明星，她只关心这一点。
I was a star, that's all that mattered to her.

我是她梦寐以求的，是她在那家小餐厅里处心积虑想要得到的。
I was what she'd dreamt of, what she'd planned to win for herself back in that little diner.

她爱不爱我不是问题。
Whether she loved me or not didn't come into it.

可是二十七年的婚姻会发生很多有趣的事情。
But twenty-seven years of marriage can do funny things.

很多夫妻，他们渐渐地越来越不喜欢对方，厌倦对方，最后憎恨对方。
Plenty of couples, they start off loving each other, then get tired of each other, end up hating each other.

而有时候情况刚好相反。
Sometimes though it goes the other way.

过了很多年，琳迪逐渐慢慢地开始喜欢我。
It took a few years, but bit by bit, Lindy began to love me.

一开始我不敢相信，可是后来没什么可怀疑的了。
I didn't dare believe it at first, but after a while there was nothing else to believe.

离开餐桌时轻轻碰一下我的肩膀。
A little touch on my shoulder as we were getting up from a table.

在房间那一头莫名其妙地微微一笑，没什么好笑的事，只是她自己不知道在乐什么。
A funny little smile across the room when there wasn't anything to smile about, just her fooling around.

我敢说她自己也很惊讶，但事实如此。
I bet she was as surprised as anyone, but that's what happened.

五六年后，我们发现我们在一起非常惬意。
After five or six years, we found we were easy with each other.

我们关心对方，在乎对方。
That we worried about each other, cared about each other.

总而言之，我们爱对方。
Like I say, we loved each other.

而如今我们仍旧爱着对方。”
And we still love each other today.’

“我不明白，加德纳先生。
‘I don't get it, Mr Gardner.

那您和加德纳太太为什么要分开呢？”
So why are you and Mrs Gardner separating?’

他又叹了一口气。
He did another of his sighs.

“你怎么可能明白呢，朋友，从那样的国家来的？
‘How would you understand, my friend, coming from where you do?

但是今天晚上你对我太好了，我试着解释给你听吧。
But you've been kind to me tonight, so I'm gonna try and explain it.

事实是，我的名声已经不如从前了。
Fact is, I'm no longer the major name I once was.

你尽可以反对，但在美国，这是不可否认的事实。我不再是大明星了。
Protest all you like, but where we come from, there's no getting round something like that.

如今的我可以接受现实，慢慢隐退，生活在过去的荣誉之上。
I'm no longer a major name. Now I could just accept that and fade away. Live on past glories.

但我也可以说，不，我还没玩完呢。
Or I could say, no, I'm not finished yet.

换句话说，我的朋友，我可以重返歌坛。很多像我这样的人，甚至还不如我的人，都这么做了。
In other words, my friend, I could make a come-back. Plenty have from my position and worse.

但是重返歌坛并非易事。
But a come-back's no easy game.

你得做好做出种种改变的心理准备，有些改变是很困难的。
You have to be prepared to make a lot of changes, some of them hard ones.

你得改变你的做法，甚至改变一些你喜欢的东西。”
You change the way you are. You even change some things you love.’

“加德纳先生，您的意思是，因为您要重返歌坛，您和加德纳太太不得不分开？”
‘Mr Gardner, are you saying you and Mrs Gardner have to separate because of your come-back?’

“看看其他人，看看那些成功重返歌坛的人，看看那些至今仍活跃在歌坛的我这一辈人。
‘Look at the other guys, the guys who came back successfully. Look at the ones from my generation still hanging round.

他们每一个，每一个都再婚了。
Every single one of them, they've re-married.

两次，甚至三次。
Twice, sometimes three times.

他们每一个都牵着年轻的妻子。
Every one of them, young wives on their arms.

我和琳迪会成为笑柄的。
Me and Lindy are getting to be a laughing-stock.

而且，现在有一个我看上眼的姑娘，她也看上了我。
Besides, there's been this particular young lady I've had my eye on, and she's had her eye on me.

琳迪明白这其中的道理，比我还早明白，也许在餐厅里听梅格讲各种奇闻轶事时就明白了。
Lindy knows the score. She's known it longer than I have, maybe ever since those days in that diner listening to Meg.

我们商量过了。
We've talked it over.

她明白我们该各走各的了。”
She understands it's time to go our separate ways.’

“我还是不明白，加德纳先生。
‘I still don't get it, Mr Gardner.

您和加德纳太太来的地方不会和其他地方相差到哪儿去。
This place you and Mrs Gardner come from can't be so different from everywhere else.

所以，加德纳先生，这些年来您唱的歌能感动各个地方的人。
That's why, Mr Gardner, that's why these songs you've been singing all these years, they make sense for people everywhere.

甚至是我生长的地方。
Even where I used to live.

这些歌里头都唱些什么呢？
And what do all these songs say?

两个人不再相爱了，只好分开，所以伤心。
If two people fall out of love and they have to part, then that's sad.

可要是两人还彼此相爱，就应该永远在一起。
But if they go on loving each other, they should stay together forever.

这就是那些歌里唱的。”
That's what these songs are saying.’

“我明白你的意思，朋友。
‘I understand what you're saying, friend.

我知道你很难明白这件事情。
And it might sound hard to you, I know.

但事实如此。
But that's the way it is.

而且，这对琳迪也好。
And listen, this is about Lindy too.

我们现在就分开对她来说最好。
It's best for her we do this now.

她还不老。
She's nowhere near old yet.

你见过她，她依旧美丽动人。
You've seen her, she's still a beautiful woman.

她得趁现在还来得及的时候抽身。
She needs to get out now, while she has time.

还来得及再找一个爱人，再结一次婚。
Time to find love again, make another marriage.

她得趁还为时未晚赶紧抽身。”
She needs to get out before it's too late.’

我不知道该回答什么，加德纳先生突然问道：“我猜你母亲始终没能再找到一个好人吧。”
I don't know what I would have said to that, but then he caught me by surprise, saying:‘Your mother. I guess she never got out.’

我被这个问题吓了一跳。我想了想，轻声说：“没有，加德纳先生。
I thought about it, then said quietly:‘No, Mr Gardner. She never got out.

她始终没能再婚。她没能活着看见我们国家的变化。”
She didn't live long enough to see the changes in our country.’

“太遗憾了。
‘That's too bad.

我相信她是个好女人。
I'm sure she was a fine woman.

如果真像你说的那样，我的歌真的让她感到幸福，那对我而言意义重大。
If what you say is true, and my music helped make her happy, that means a lot to me.

很遗憾她最终没能再找到一个好人。我不希望我的琳迪会这样。
Too bad she didn't get out. I don't want that to happen to my Lindy.

不，我的琳迪不会的。
No, sir. Not to my Lindy.

我要我的琳迪再找到一个好人。”
I want my Lindy to get out.’

刚朵拉轻轻地敲打着河岸。
The gondola was bumping gently against the quay.

维托里奥轻声唤着，伸出一只手，几秒钟后，加德纳先生站起来，爬上岸去。
Vittorio called out softly, reaching out his hand, and after a few seconds, Mr Gardner got to his feet and climbed out.

等我也拿着吉他爬上岸时——我不想求维托里奥让我白搭一程——加德纳先生已经掏出了钱包。
By the time I too had climbed out with my guitar – I wasn't going to beg any free rides from Vittorio – Mr Gardner had his wallet out.

看来维托里奥对自己的酬劳非常满意，他带着一贯的彬彬有礼，说着一贯的恭维话，回到刚朵拉上，划走了。
Vittorio seemed pleased with what he was given, and with his usual fine phrases and gestures, he got back in his gondola and set off down the canal.

我们看着船消失在黑暗之中。加德纳先生往我手里塞进一大把钞票。
We watched him disappear into the dark, then next thing, Mr Gardner was pushing a lot of notes into my hand.

我对他说太多了，而且今晚是我极大的荣幸。可他一点儿也不肯收回去。
I told him it was way too much, that anyway it was a huge honour for me, but he wouldn't hear of taking any of it back.

“不，不，”他边说边在眼前摆了摆手，像是要了结这件事，不仅是钱，还包括我、包括这个夜晚，或许还包括他人生的这整个阶段。
‘No, no,’ he said, waving his hand in front of his face, like he wanted to be done, not just with the money, but with me, the evening, maybe this whole section of his life.

他迈步朝公寓走去，可才走了几步，他就停下来，回头看着我。
He started to walk off towards his palazzo, but after a few paces, he stopped and turned back to look at me.

我们所在的小街，运河，一切都很安静，只有远方模糊的电视的声音。
The little street we were in, the canal, everything was silent now except for the distant sound of a television.

“今天晚上你弹得很好，我的朋友，”他说。
‘You played well tonight, my friend,’ he said.

“你的指法很好。”
‘You have a nice touch.’

“谢谢您，加德纳先生。
‘Thank you, Mr Gardner.

您唱得也很好，和以前一样好。”
And you sang great. As great as ever.’

“也许在我们离开之前我会再到广场去一次。
‘Maybe I'll come by the square again before we leave.

去听听你和同事们的演出。”
Listen to you playing with your crew.’

“我希望如此，加德纳先生。”
‘I hope so, Mr Gardner.’

可是我没有再见到他。
But I never saw him again.

几个月后，秋天的时候，我听说加德纳先生和加德纳太太离婚了——弗洛里安的一个侍者在哪里看到，告诉我的。
I heard a few months later, in the autumn, that Mr and Mrs Gardner got their divorce – one of the waiters at the Florian read it somewhere and told me.

那天晚上的情景再次浮现在我的脑海里，而且回想起这件事情，我黯然神伤。
It all came back to me then about that evening, and it made me feel a little sad thinking about it again.

因为加德纳先生看上去是个很正派的人，不管你怎么看，无论复出与否，他都是伟大的歌手之一。
Because Mr Gardner had seemed a pretty decent guy, and whichever way you look at it, come-back or no come-back, he'll always be one of the greats.

# 不论下雨或晴天 | COME RAIN OR COME SHINE

埃米莉和我一样喜欢美国百老汇的老歌。
LIKE ME, EMILY loved old American Broadway songs.

她比较喜欢节奏快一点的曲子，像欧文·伯林的《脸贴着脸》、科尔·波特的《当他们跳起比津舞》，而我倾向于半苦半甜的伤心情歌——《今天下雨天》啦、《我从未想到》啦。
She'd go more for the up-tempo numbers, like Irving Berlin's ‘Cheek to Cheek’ and Cole Porter's ‘Begin the Beguine’, while I'd lean towards the bitter-sweet ballads – ‘Here's That Rainy Day’ or ‘It Never Entered My Mind’.

但还是有很多歌是我们都喜欢的，而且在那个时候，在英格兰南部的大学校园里，发现有人跟你一样喜欢百老汇算得上是奇迹。
But there was a big overlap, and anyway, back then, on a university campus in the south of England, it was a near-miracle to find anyone else who shared such passions.

现在的年轻人什么歌都听。
Today, a young person's likely to listen to any sort of music.

我侄子今年秋天开始上大学，最近喜欢上了阿根廷探戈。
My nephew, who starts university this autumn, is going through his Argentinian tango phase.

他也喜欢最新的独立乐队的随便什么歌，还喜欢艾迪特·皮雅芙。
He also likes Edith Piaf as well as any number of the latest indie bands.

可是在我们那个时候，口味比较单一。
But in our day tastes weren't nearly so diverse.

我的同学分为两大阵营：嬉皮士型的，留着长发，穿着飘逸的衣服，喜爱“前卫摇滚”；另一类穿着整齐、高雅，认为古典音乐以外的东西都是可怕的噪音。
My fellow students fell into two broad camps: the hippie types with their long hair and flowing garments who liked ‘progressive rock’, and the neat, tweedy ones who considered anything other than classical music a horrible din.

偶尔也会碰到声称喜欢爵士乐的人，但你每每会发现这种人都是半路出家型的——只知道即兴，不懂得应该从认真打造优美的歌曲开始。
Occasionally you'd bump into someone who professed to be into jazz, but this would always turn out to be of the so-called crossover kind – endless improvisations with no respect for the beautifully crafted songs used as their starting points.

所以发现有人也喜欢美国爵士金曲，还是个女生，真是欣慰。
So it was a relief to discover someone else, and a girl at that, who appreciated the Great American Songbook.

和我一样，埃米莉也喜欢收集敏感、坦率的声音翻唱的经典曲目的唱片——这类唱片要么在旧货店里慢慢贬值，要么被父辈们丢弃。
Like me, Emily collected LPs with sensitive, straightforward vocal interpretations of the standards – you could often find such records going cheap in junk shops, discarded by our parents' generation.

她喜欢萨拉·沃恩和切特·贝克。
She favoured Sarah Vaughan and Chet Baker.

我偏好朱莉·伦敦和佩吉·李。
I preferred Julie London and Peggy Lee.

我们俩都对辛纳特拉或埃拉·菲茨杰拉德不太感冒。
Neither of us was big on Sinatra or Ella Fitzgerald.

第一年埃米莉住在学校里，她的宿舍里有一台便携式唱片机，当时很常见的那种。
In that first year, Emily lived in college, and she had in her room a portable record player, a type that was quite common then.

长得像个大帽盒，浅蓝色人造皮的面，一个内嵌式喇叭。
It looked like a large hat box, with pale-blue leatherette surfaces and a single built-in speaker.

打开盖子以后才能看见里面的唱机转盘。
Only when you raised its lid would you see the turntable sitting inside.

按今天的标准来讲，它发出来的声音够原始的，可我记得我们常常一连几个小时愉快地蹲在唱片机旁，把一张唱片拿下来，再小心翼翼地把唱针放到另一张上面。
It gave out a pretty primitive sound by today's standards, but I remember us crouching around it happily for hours, taking off one track, carefully lowering the needle down onto another.

我们喜欢放同一首歌的不同版本，然后争论歌词或歌手的演绎。
We loved playing different versions of the same song, then arguing about the lyrics, or about the singers' interpretations.

那句歌词是应该唱得这么讽刺吗？
Was that line really supposed to be sung so ironically?

唱《乔治亚在我心》这歌应该把乔治亚当作个女人还是美国的一个地方？
Was it better to sing ‘Georgia on My Mind’ as though Georgia was a woman or the place in America?

若发现一首歌——比如雷·查尔斯演唱的《不论下雨或晴天》——歌词本身是快乐的，而演唱成十分悲伤，我们会特别高兴。
We were especially pleased when we found a recording – like Ray Charles singing ‘Come Rain or Come Shine’ – where the words themselves were happy, but the interpretation was pure heartbreak.

埃米莉太喜欢这些唱片了，每次我无意中撞见她在和别的同学讲某个自命不凡的摇滚乐队或某个空虚无物的加利福尼亚创作歌手，我都会吓一跳。
Emily's love of these records was obviously so deep that I'd be taken aback each time I stumbled on her talking to other students about some pretentious rock band or vacuous Californian singer-songwriter.

有时，她会像在和我谈论格什温或哈罗德·阿伦那样开始谈论一张“概念”唱片，我得咬紧嘴唇才不把愤怒表现出来。
At times, she'd start arguing about a ‘concept’ album in much the way she and I would discuss Gershwin or Howard Arlen, and then I'd have to bite my lip not to show my irritation.

那时候的埃米莉苗条、漂亮，要不是她早早就和查理在一起，我相信会有一大堆人追求她。
Back then, Emily was slim and beautiful, and if she hadn't settled on Charlie so early in her university career, I'm sure she'd have had a whole bunch of men competing for her.

可她从来不风骚、放荡，所以她和查理在一起后，其他追求者就撤退了。
But she was never flirty or tarty, so once she was with Charlie, the other suitors backed off.

“所以我才把查理留在身边，”有一次她一脸严肃地这样对我说，看见我很吃惊的样子她扑哧笑了出来。
‘That's the only reason I keep Charlie around,’ she told me once, with a dead straight face, then burst out laughing when I looked shocked.

“开玩笑的，傻瓜。
‘Just a joke, silly.

我爱他，爱他，爱他。”
Charlie is my darling, my darling, my darling.’

查理是我大学时最好的朋友。一年级时我们成天在一起，因此我才认识了埃米莉。
Charlie was my best friend at university. During that first year, we hung around together the whole time and that was how I'd come to know Emily.

第二年，查理和埃米莉在城里找了间房子同居。虽然我常常去他们那，但是那些与埃米莉在唱片机旁的交谈已经成为往事。
In the second year, Charlie and Emily got a house-share down in town, and though I was a frequent visitor, those discussions with Emily around her record-player became a thing of the past.

一来，我每次去，都有几个其他同学坐在那里又说又笑。再者，如今有了一台漂亮的立体声音响大声地播放着摇滚乐，说话都得用喊的。
For a start, whenever I called round to the house, there were several other students sitting around, laughing and talking, and there was now a fancy stereo system churning out rock music you had to shout over.

这些年来查理和我还是好朋友。
Charlie and I have remained close friends through the years.

确实我们不如以前那样常见面，但这主要是因为距离太远。
We may not see each other as much as we once did, but that's mainly down to distances.

我在意大利、葡萄牙，还有西班牙这里待了好几年，而查理则一直待在伦敦。
I've spent years here in Spain, as well as in Italy and Portugal, while Charlie's always based himself in London.

要是这么说让你觉得好像我是个空中飞人，他是个宅男，那就好笑了。
Now if that makes it sound like I'm the jet-setter and he's the stay-at-home, that would be funny.

因为查理才是整天飞来飞去的人——得克萨斯、东京、纽约——参加一个个高端会议，而我则年复一年困在潮湿的房子里，安排拼写测试，或者重复着一成不变的慢速英语谈话：“我叫雷。”
Because in fact Charlie's the one who's always flying off – to Texas, Tokyo, New York – to his high-powered meetings, while I've been stuck in the same humid buildings year after year, setting spelling tests or conducting the same conversations in slowed-down English. My-name-is-Ray.

“你叫什么？”
What-is-your-name?

“你有孩子吗？”
Do-you-have-children?

大学毕业后我选择了教英语，刚开始貌似还不错——很像大学生活的延伸。
When I first took up English teaching after university, it seemed a good enough life – much like an extension of university.

语言学校在欧洲如雨后春笋般涌现。若说教书很无聊、课酬很低，那个年纪的你不会太在乎。
Language schools were mushrooming all over Europe, and if the teaching was tedious and the hours exploitative, at that age you don't care too much.

你泡在酒吧里，很容易就交到朋友，感觉自己是一个遍布全球的巨大网络的一部分。
You spend a lot of time in bars, friends are easy to make, and there's a feeling you're part of a large network extending around the entire globe.

你会遇见刚从秘鲁或泰国教了一阵子书回来的人，你会觉得只要你愿意就可以满世界跑，就可以利用你的关系在哪个你向往的遥远的角落找到一份工作。
You meet people fresh from their spells in Peru or Thailand, and this gets you thinking that if you wanted to, you could drift around the world indefinitely, using your contacts to get a job in any faraway corner you fancied.

而且你永远是这个舒适的巡回教师大家庭的一分子，一边喝酒一边聊着以前的同事、神经质的学校主管、英国文化协会里的怪人。
And always you'd be part of this cosy, extended family of itinerant teachers, swapping stories over drinks about former colleagues, psychotic school directors, eccentric British Council officers.

八十年代末期听说去日本教书很赚钱，我认真地计划要去，但最终没去成。
In the late '80s, there was talk of making a lot of money teaching in Japan, and I made serious plans to go, but it never worked out.

我还想过去巴西，甚至读了一些介绍那里的文化的书，要了申请表。
I thought about Brazil too, even read a few books about the culture and sent off for application forms.

可不知为什么我从来没有去那么远的地方。
But somehow I never got away that far.

我只去意大利南部、葡萄牙教了一阵子书，又回到西班牙。
Southern Italy, Portugal for a short spell, back here to Spain.

不知不觉就到了四十七岁，身边共事的人早就变成了聊不同话题、嗑不同药、听不同音乐的另一代人。
Then before you know it, you're forty-seven years old, and the people you started out with have long ago been replaced by a generation who gossip about different things, take different drugs and listen to different music.

与此同时，查理和埃米莉结了婚，在伦敦定居下来。
Meanwhile, Charlie and Emily had married and settled down in London.

有一次查理对我说，等他们有了孩子以后，要我做一个孩子的教父。
Charlie told me once, when they had children I'd be godfather to one of them.

可到现在都还没有。
But that never happened.

我的意思是他们一直没有孩子，我想如今要孩子已经太迟了。
What I mean is, a child never came along, and now I suppose it's too late.

我必须承认，我一直觉得有点失望。
I have to admit, I've always felt slightly let down about this.

也许我一直幻想给他们的孩子做教父能让他们在英国的生活与我在这里的生活有了正式的联系，不管这种联系多么微小。
Perhaps I always imagined that being godfather to one of their children would provide an official link, however tenuous, between their lives in England and mine out here.

总而言之，今年初夏，我去了伦敦待在他们那里。
Anyway, at the start of this summer, I went to London to stay with them.

事情已经事先安排妥当，动身前两天，我打电话确认时，查理说他们俩都“很好”。
It had been arranged well in advance, and when I'd phoned to check a couple of days beforehand, Charlie had said they were both ‘superbly well’.

所以我一心只想着在经历了肯定不是我人生最美好的几个月后好好休息、放松一下，根本没想到别的。
That's why I'd no reason to expect anything other than pampering and relaxation after a few months that hadn't exactly been the best in my life.

事实上，那个阳光灿烂的早晨，当我走出伦敦地铁站时，脑子里想着：不知自从我上次来了以后，他们会对“我的”房间做怎样的改进。
In fact, as I emerged out of their local Underground that sunny day, my thoughts were on the possible refinements that might have been added to ‘my’ bedroom since the previous visit.

这些年来，几乎每次都有不一样的东西。
Over the years, there's almost always been something or other.

有一次，房间的角落里摆着一个闪着光的电子小玩意儿；还有一次，整个房间都重新装修过了。
One time it was some gleaming electronic gadget standing in the corner; another time the whole place had been redecorated.

但不管怎样，几乎有一条基本原则，他们按着高级旅馆的样子为我布置房间：摆好毛巾，床头放着一小罐饼干，梳妆台上备着几张CD。
In any case, almost as a point of principle, the room would be prepared for me the way a posh hotel would go about things: towels laid out, a bedside tin of biscuits, a selection of CDs on the dressing table.

几年前，查理带我走进房间，若无其事地炫耀着打开各种开关，各种巧妙地隐藏起来的灯开了关、关了开：床头板后面、衣橱上面等等。
A few years ago, Charlie had led me in and with nonchalant pride started flicking switches, causing all sorts of subtly hidden lights to go on and off: behind the headboard, above the wardrobe and so on.

还有一个开关按了以后，隆隆隆，两扇窗户上的百叶窗慢慢放了下来。
Another switch had triggered a growling hum and blinds had begun to descend over the two windows.

“查理，我要百叶窗干吗？”
‘Look, Charlie, why do I need blinds?’

那一次我问道。
I'd asked that time.

“醒来的时候我想看见外面。
‘I want to see out when I wake up.

窗帘就可以了。”
Just the curtains will do fine.’

“这些百叶窗是瑞士的，”他这么回答，好像这就说明了一切。
‘These blinds are Swiss,’ he'd said, as though this were explanation enough.

可是这一次带我上楼时，查理一直小声咕哝着，等到了我的房间，我才明白他是在道歉。
But this time Charlie led me up the stairs mumbling to himself, and as we got to my room, I realised he was making excuses.

眼前的景象我从未见过。
And then I saw the room as I'd never seen it before.

床上空荡荡的，床垫污渍点点、歪歪斜斜。
The bed was bare, the mattress on it mottled and askew.

地上一堆堆的杂志、书和旧衣服，还散落着一支曲棍和一个喇叭。
On the floor were piles of magazines and paperbacks, bundles of old clothes, a hockey stick and a loudspeaker fallen on its side.

我吃惊地站在门口，查理则清理出一个地方放下我的包。
I paused at the threshold and stared at it while Charlie cleared a space to put down my bag.

“你那样子好像要见经理，”他挖苦地说。
‘You look like you're about to demand to see the manager,’ he said, bitterly.

“没有，没有。
‘No, no.

只是这里看上去和以前不太一样。”
It's just that it's unusual to see it this way.’

“乱糟糟的，我知道。
‘It's a mess, I know.

乱糟糟的。”
A mess.’

他在床垫上坐下，叹了口气。
He sat down on the mattress and sighed.

“我以为清洁工会来打扫。
‘I thought the cleaning girls would have sorted all this.

结果没有。
But of course they haven't.

鬼知道怎么没来。”
God knows why not.’

他好像很沮丧，可突然他腾地站了起来。
He seemed very dejected, but then he suddenly sprang to his feet again.

“走，我们去外面吃午饭吧。
‘Look, let's go out for some lunch.

我给埃米莉留个信。
I'll leave a note for Emily.

我们慢慢吃，等我们回来，你的房间——这整间公寓——就都收拾好了。”
We can have a long leisurely lunch and by the time we come back, your room – the whole flat – will be sorted out.’

“可我们不能叫埃米莉收拾。”
‘But we can't ask Emily to tidy everything.’

“哦，她不会自己收拾的。
‘Oh, she won't do it herself.

她会去叫清洁工。
She'll get on to the cleaners.

她知道怎么烦他们。
She knows how to harass them.

我，我连他们的电话都没有。
Me, I don't even have their number.

午饭，我们吃午饭吧。
Lunch, let's have lunch.

点它三道菜，来瓶红酒什么的。”
Three courses, bottle of wine, everything.’

查理所说的公寓其实是一栋四层楼高的排屋的最顶上两层，位于一条繁华而忙碌的大街上。
What Charlie called their flat was in fact the top two floors of a four-storey terrace in a well-to-do but busy street.

一出大门就是川流的人群和车辆。
We came out of the front door straight into a throng of people and traffic.

我跟着查理走过一家家商店、办公室，到了一家小巧的意大利餐厅。
I followed Charlie past shops and offices to a smart little Italian restaurant.

我们没有订座，但餐馆的招待像朋友一样招呼查理，领我们到了一张桌子。
We didn't have a reservation, but the waiters greeted Charlie like a friend and led us to a table.

我看了看四周，发现周围都是西装领带的商务人士，所以很高兴查理和我一样一副脏兮兮的样子。
Looking around I saw the place was full of business types in suits and ties, and I was glad Charlie looked as scruffy as I did.

他好像猜到了我在想什么，我们坐下时，他说道：
He must have guessed my thoughts, because as we sat down he said:

“哦，你真是乡巴佬，雷。
‘Oh, you're so home counties, Ray.

如今都变了。
Anyway, it's all changed now.

你离开这个国家太久了。”
You've been out the country too long.’

接着他突然提高音量，很大声地说：“我们看上去才是成功人士。
Then in an alarmingly loud voice:‘We look like the ones who've made it.

这儿的其他人看上去都像中层管理。”
Everyone else here looks like middle management.’

说完他倾向我，轻声说：“听着，我们得谈谈。
Then he leant towards me and said more quietly:‘Look, we've got to talk.

我要你帮我一个忙。”
I need you to do me a favour.’

我不记得上一次查理叫我帮忙是什么时候，但我装作随意地点点头，等他开口。
I couldn't remember the last time Charlie had asked my help for anything, but I managed a casual nod and waited.

他摆弄了一会儿菜单，然后放下。
He played with his menu for a few seconds, then put it down.

“是这样的，我和埃米莉正在闹别扭。
‘The truth is, Emily and I have been going through a bit of a sticky patch.

事实上，最近，我们完全避开对方。
In fact, just recently, we've been avoiding one another altogether.

所以刚刚她没有来迎接你。
That's why she wasn't there just now to welcome you.

如今恐怕你得从我们两个中选一个。
Right now, I'm afraid, you get a choice of one or the other of us.

有我就没有她，有她就没有我。
A bit like those plays when the same actor's playing two parts.

有点像戏里一人分饰两角。
You can't get both me and Emily in the same room at the same time.

很幼稚，是不是？”
Rather childish, isn't it?’

“显然我来的不是时候。
‘This is obviously a bad time for me to have come.

我走，吃完午饭就走。
I'll go away, straight after lunch.

我去芬奇利找我姑妈凯蒂。”
I'll stay with my Auntie Katie in Finchley.’

“你说什么啊？
‘What are you talking about?

你没有在听我说话。
You're not listening.

我说了，我要你帮我一个忙。”
I just told you. I want you to do me a favour.’

“我以为你指的是……”
‘I thought that was your way of saying ...’

“不是，你这个白痴，该离开的人是我。我得去法兰克福开会，今天下午的飞机。
‘No, you idiot, I'm the one who has to clear out. I've got to go to a meeting in Frankfurt, I'm flying out this afternoon.

两天以后回来，最迟星期四。而你留在这里善后，让一切恢复原样。
I'll be back in two days, Thursday at the latest. Meanwhile, you stay here.

等我回来的时候，我愉快地说声‘哈罗’，亲吻亲爱的妻子，就当过去的两个月没发生过，我们又和好如初。”
You bring things round, make everything okay again. Then I come back, say a cheerful hello, kiss my darling wife like the last two months haven't happened, and we pick up again.’

这时服务生过来点单，她走了以后，查理似乎不愿接着刚才的话茬，而是开始一个劲儿地问我在西班牙过得怎么样。
At this point the waitress came to take our order, and after she'd gone Charlie seemed reluctant to take up the subject again.

每次我说了件什么事情，不管好事坏事，他都会微微地苦笑一下，摇摇头，好像我说的都验证了他最担心的。
Instead, he fired questions at me about my life in Spain, and each time I told him anything, good or bad, he'd do this sour little smile and shake his head, like I was confirming his worst fears.

我正说到我的厨艺大有进步——我几乎是独自一人为四十多名师生准备了一顿圣诞自助餐——他打断我的话。
At one point I was trying to tell him how much I'd improved as a cook – how I'd prepared the Christmas buffet for over forty students and teachers virtually single-handed – but he just cut me off in mid-sentence.

他说：“听我说，你这样子下去不行。
‘Listen to me,’ he said. ‘Your situation's hopeless.

把工作辞了。
You've got to hand in your notice.

但辞职之前你得先找到新工作。
But first, you have to get your new job lined up.

用那个愁眉苦脸的葡萄牙人当中间人。
This Portuguese depressive, use him as a go-between.

保住马德里的职位，然后丢掉那个公寓，另找一个。
Secure the Madrid post, then ditch the apartment.

好，你要这样，首先。”
Okay, here's what you do. One.’

他扳起手指头，开始一条条罗列应该做些什么。
He held up his hand and began counting off each instruction as he made it.

我们的菜来了，他还没数完，可他不管，接着数到完。
Our food arrived when he still had a couple of fingers to go, but he ignored it and carried on till he'd finished.

开始吃饭时，他说道：
Then as we began to eat, he said:

“我敢说你一条都不会去做。”
‘I can tell you won't do any of this.’

“不，不，你说的每一条都很有道理。”
‘No, no, everything you say is very sound.’

“你回去以后还是一切照旧。
‘You'll go back and carry on just the same.

一年以后我们再见时，你又抱怨一模一样的事情。”
Then we'll be here again in a year's time and you'll be moaning about exactly the same things.’

“我没有在抱怨……”
‘I wasn't moaning ...’

“要知道，雷，别人只能建议你这么多。
‘You know, Ray, there's only so much other people can suggest to you.

到了一定的时候，你得学会自主自己的生活。”
After a certain point, you've got to take charge of your life.’

“好，我会的。
‘Okay, I will, I promise.

我答应你。但是刚才你说有事要我帮忙。”
But you were saying earlier, something about a favour.’

“啊，对。”
‘Ah yes.’

他若有所思地嚼着嘴里的食物。
He chewed his food thoughtfully.

“说实话，这才是我叫你来的真正目的。
‘To be honest, this was my real motive in inviting you over.

当然，我也很想见到你什么的。
Of course, it's great to see you and all of that.

但是最主要的是，我想请你帮我一个忙。
But for me, the main thing, I wanted you to do something for me.

毕竟你是我认识最久的朋友，一辈子的朋友……”
After all you're my oldest friend, a life-long friend . . .’

突然他又低头吃饭，我惊讶地发现他在轻声啜泣。
Suddenly he began eating again, and I realised with astonishment he was sobbing quietly.

我伸手去拍拍他的肩膀，但他只是低着头、一个劲儿地往嘴里塞意面。
I reached across the table and prodded his shoulder, but he just kept shovelling pasta into his mouth without looking up.

就这样过了一分钟左右，我又伸手去拍拍他的肩头，但跟第一次一样没有什么效果。
When this had gone on for a minute or so, I reached over and gave him another little prod, but this had no more effect than my first one.

这时服务生微笑着走过来问我们今天的菜怎么样，我俩都说菜好极了。
Then the waitress appeared with a cheerful smile to check on our food.

她走了以后，查理好像情绪稳定了一些。
We both said everything was excellent and as she went off, Charlie seemed to become more himself again.

“好，雷，听着。
‘Okay, Ray, listen.

我要你做的事简单得不得了。
What I'm asking you to do is dead simple.

我要你这几天跟埃米莉待在一起，在我们家好好做客。
All I want is for you to hang about with Emily for the next few days, be a pleasant guest.

就这样。
That's all.

直到我回来。”
Just until I get back.’

“就这样？
‘That's all?

你要我在你不在的时候照顾她？”
You're just asking me to look after her while you're gone?’

“没错。
‘That's it.

或者说，让她照顾你。
Or rather, let her look after you.

你是客人。
You're the guest.

我给你找了些事做，看戏什么的。
I've lined up some things for you to do.

我最迟星期四就回来了。
Theatre tickets and so on.

你的任务就是让她一直保持好心情。
I'll be back Thursday at the latest.

这样当我回来的时候，我说‘哈罗，亲爱的’，拥抱她，她就回答说，‘哦，哈罗，亲爱的，欢迎回来，这几天好吗？’
Your mission's just to get her in a good mood and keep her that way.

然后拥抱我。
So when I come in and say, “Hello darling,” and hug her, she'll just reply, “Oh hello, darling, welcome home, how was everything,” and hug me back.

这样我们就和好如初。
Then we can carry on as before.

如同当初噩梦开始以前。
Before all this horrible stuff began.

这就是你的任务。
That's your mission.

很简单。”
Quite simple really.’

“我很乐意尽我所能，”我说。
‘I'm happy to do anything I can,’ I said.

“可是，查理，你确定她现在有心情招待客人？
‘But look, Charlie, are you sure she's in the mood to entertain visitors?

你们显然出现了什么危机。
You're obviously going through some sort of crisis.

她一定和你一样心烦意乱。
She must be as upset as you are.

老实说，我不理解为什么你这个时候叫我来。”
Quite honestly, I don't understand why you asked me here right now.’

“你不理解？什么意思？
‘What do you mean, you don't understand?

我叫你来是因为你是我认识最久的朋友。
I've asked you because you're my oldest friend.

对，没错，我有很多朋友。
Yes, all right, I've got a lot of friends.

可是在这件事情上，我想来想去，发现只有你能行。”
But when it comes down to it, when I thought hard about it, I realised you're the only one who'd do.’

我承认听了他的话我很感动。
I have to admit I was rather moved by this.

但同时，我能察觉到这里头有什么事不对劲，有什么事他没有告诉我。
All the same, I could see there was something not quite right here, something he wasn't telling me.

“要是你们俩都在这里的话，我能理解你叫我来住，”我说。
‘I can understand you inviting me to stay if you were both going to be here,’ I said.

“我能理解那样做的用意。
‘I can see how that would work.

你们互相不说话，找个客人来转移目标，你们俩都拿出最好的表现来，事情就慢慢缓和了。
You're not talking to each other, you invite a guest as a diversion, you both put on your best behaviour, things start to thaw.

可现在不是这样的，你不在这里。”
But it's not going to work in this case, because you're not going to be here.’

“帮帮我吧，雷。
‘Just do it for me, Ray.

我想能行的。
I think it might work.

你总是能让埃米莉开心起来。”
Emily's always cheered up by you.’

“我让她开心？
‘Cheered up by me?

查理，你知道我想帮你。
You know, Charlie, I want to help.

可是你肯定哪里搞错了。
But it's possible you've got this a bit wrong.

因为我印象中，说实话，我根本不能让埃米莉开心，即便是在最美好的时候。
Because I get the impression, quite frankly, Emily isn't cheered up by me at all, even at the best of times.

最近几次我到这里来，她……呃，她显然对我不耐烦。”
The last few visits here, she was . . . well, distinctly impatient with me.’

“听着，雷，相信我。
‘Look, Ray, just trust me.

我知道自己在做什么。”
I know what I'm doing.’

我们回去时，埃米莉在公寓里。
Emily was at the flat when we returned.

我得承认我被她的老态吓了一跳。
I have to admit, I was taken aback at how much she'd aged.

她不仅比我上次见到她时胖了许多：她过去那张自然而美丽的脸，如今赘肉明显，嘴角上还挂着怒气。
It wasn't just that she'd got significantly heavier since my last visit: her face, once so effortlessly graceful, was now distinctly bulldoggy, with a displeased set to the mouth.

她正坐在客厅的沙发上阅读《金融时报》，看见我进来，闷闷不乐地站了起来。
She was sitting on the living-room sofa reading the Financial Times, and got up rather glumly as I came in.

“见到你真好，雷蒙德。”她说，敷衍地吻了吻我的脸颊，然后又坐了下去。
‘Nice to see you, Raymond,’ she said, kissing me quickly on the cheek, then sitting down again.

她的这种态度让我忍不住想说抱歉，深深地抱歉在这个时候打扰他们。
The whole way she did this made me want to blurt out a profuse apology for intruding at such a bad time.

可不等我开口，埃米莉就拍了拍身旁的沙发，说：“来，雷蒙德，坐这里，回答我的问题。
But before I could say anything, she thumped the space beside her on the sofa, saying:‘Now, Raymond, sit down here and answer my questions.

我想知道你所有的近况。”
I want to know all about what you've been up to.’

我坐了下来，她开始不停地问我问题，跟刚刚查理在饭馆里一样。
I sat down and she began to interrogate me, much as Charlie had done in the restaurant.

而这时候查理在收拾他的行李，在屋子里进进出出，找这找那。
Charlie, meanwhile, was packing for his journey, drifting in and out of the room in search of various items.

我注意到他们避开对方的视线，可并没有像查理说的那样，因为待在同一个屋子里而感觉不自在。
I noticed they didn't look at each other, but neither did they seem so uncomfortable being in the same room, despite what he'd claimed.

他们没有直接交谈，但是查理用一种奇怪的、间接的方式参与谈话。
And although they never spoke directly to each other, Charlie kept joining in the conversation in an odd, once-removed manner.

比如说，当我在跟埃米莉解释为什么很难找到一个室友分担房租时，查理在厨房里大声说道：
For instance, when I was explaining to Emily why it was so difficult to find a flat-mate to share my rent burden, Charlie shouted from the kitchen:

“他住的地方不适合两人合住！
‘The place he's in, it's just not geared up for two people!

适合一个人住，一个比他收入高一些的人住！”
It's for one person, and one person with a bit more money than he'll ever have!’

埃米莉没有回答，但她显然是听进去了，因为她接着说道：“雷蒙德，你不应该找那样的公寓。”
Emily made no response to this, but must have absorbed the information, because she then went on:‘Raymond, you should never have chosen an apartment like that.’

接下来至少二十分钟，我们都是这样子交谈。查理在楼梯上或者要去厨房时说上几句，通常是大声地从第三者的角度说说我的事情。
This sort of thing continued for at least the next twenty minutes, Charlie making his contributions from the stairs or as he passed through to the kitchen, usually by shouting out some statement that referred to me in the third person.

讲着讲着，埃米莉突然说道：
At one point, Emily suddenly said:

“哦，说真的，雷蒙德。
‘Oh, honestly Raymond.

你处处被那所可恶的语言学校剥削，傻傻地让房东多收你的钱，而你做了什么？
You let yourself be exploited left, right and centre by that ghastly language school, you let your landlord rip you off silly, and what do you do?

跟爱喝酒、还没有工作的傻姑娘混在一起。
Get in tow with some airhead girl with a drink problem and not even a job to support it.

你好像故意要跟这些还关心你的人过不去！”
It's like you're deliberately trying to annoy anyone who still gives a shit about you!’

“这些人不多了！”
‘He can't expect many of that tribe to survive!’

查理在走廊里大声说道。
Charlie boomed from the hall.

我听见他已经把箱子拖到外面去了。
I could hear he had his suitcase out there now.

“你二十几岁时像个愣头青没有问题。
‘It's all very well behaving like an adolescent ten years after you've ceased to be one.

可你都已经快五十了还这样！”
But to carry on like this when you're nearly fifty!’

“我只有四十七……”
‘I'm only forty-seven ...’

“什么叫你只有四十七？”
‘What do you mean, you're only forty-seven?’

埃米莉嚷了起来，虽然我就坐在她身边。
Emily's voice was unnecessarily loud given I was sitting right next to her.

“只有四十七。
‘Only forty-seven.

就是这个‘只有’毁了你的人生，雷蒙德。
This “only”, this is what's destroying your life, Raymond.

只有，只有，只有。
Only, only, only.

只不过尽力了。
Only doing my best.

只有四十七。
Only forty-seven.

很快你就只有六十七，只不过在到处找一个安身之处！”
Soon you'll be only sixty-seven and only going round in bloody circles trying to find a bloody roof to keep over your head!’

“他得振作些才行！”
‘He needs to get his bloody arse together!’

查理在楼梯上吼道。
Charlie yelled down the staircase.

“别人把他逼急了他才会努力！”
‘Fucking well pull his socks up till they're touching his fucking balls!’

“雷蒙德，难道你不曾停下来问问自己是什么人？”
‘Raymond, don't you ever stop and ask yourself who you are?’

埃米莉问道。
Emily asked.

“想想你的潜力，你不觉得羞愧吗？
‘When you think of all your potential, aren't you ashamed?

看看你现在过的是什么生活！
Look at how you lead your life!

这种生活……这种生活怎么让人受得了！
It's . . . it's simply infuriating!

简直欺人太甚！”
One gets so exasperated!’

查理穿着雨衣出现在门口。一时间，他们两个同时朝我开火，各骂各的。
Charlie appeared in the doorway in his raincoat, and for a moment they were shouting different things at me simultaneously.

最后查理先收声，说他要走了——像是因为讨厌我似的——接着就离开了。
Then Charlie broke off, announced he was leaving – as though in disgust at me – and vanished.

查理的离开使埃米莉的谩骂暂告一段落。我利用这个机会站起来，说：“抱歉，我去帮查理拿行李。”
His departure brought Emily's diatribe to a halt, and I took the opportunity to get to my feet, saying:‘Excuse me, I'll just go and give Charlie a hand with his luggage.’

“我干吗要你帮我拿行李？”
‘Why do I need help with my luggage?’

查理在走廊里说。
Charlie said from the hall.

“我只有一个包。”
‘I've only got the one bag.’

可他还是让我跟他下了楼，我看着包，他自己到路边去拦的士。
But he let me follow him down into the street and left me with the suitcase while he went to the edge of the kerb to hail a cab.

路上没有一辆的士，他担心地探出身去，举着一只胳膊。
There didn't seem to be any to hand, and he leaned out worriedly, an arm half-raised.

我走上前去，说：“查理，我想行不通。”
I went up to him and said:‘Charlie, I don't think it's going to work.’

“什么行不通？”
‘What's not going to work?’

“埃米莉绝对是讨厌我。
‘Emily absolutely hates me.

她见了我几分钟就这个样子，三天以后会成什么样呢？
That's her after seeing me for a few minutes. What's she going to be like after three days?

你到底凭什么觉得你回来的时候会雨过天晴呢？”
Why on earth do you think you'll come back to harmony and light?’

说着说着，我心里好像豁然开朗，我不做声了。
Even as I was saying this, something was dawning on me and I fell silent.

查理发觉到不对劲，转过身来，仔细地打量着我。
Noticing the change, Charlie turned and looked at me carefully.

我终于说道：“我想我知道你为什么选我，而不选别人了。”
‘I think’, I said, eventually, ‘I have an idea why it had to be me and no one else.’

“啊哈。
‘Ah ha.

雷突然开窍了？”
Can it be Ray sees the light?’

“对，可能是。”
‘Yes, maybe I do.’

“但是那又怎么样？没有变，我要你做的事没有变。”
‘But what does it matter? It remains the same, exactly the same, what I'm asking you to do.’

这时他的眼睛里又有了泪水。
Now there were tears in his eyes again.

“雷，你还记得以前埃米莉常说她相信我时的模样吗？
‘Do you remember, Ray, the way Emily always used to say she believed in me?

她说了一年又一年。
She said it for years and years.

我相信你，查理，你前途无量，你那么有才华。
I believe in you, Charlie, you can go all the way, you're really talented.

直到三四年前，她都还一直这么说。你知道这话变得多让人难受吗？
Right up until three, four years ago, she was still saying it. Do you know how trying that got?

我混得不错。
I was doing all right.

现在还混得不错。
I am doing all right.

很不错。
Perfectly okay.

可她以为我应该成为……天晓得，成为这个世界的总统，天晓得！
But she thought I was destined for . . . God knows, president of the fucking world, God knows!

我只是一个混得不错的普通人。
I'm just an ordinary bloke who's doing all right.

可她不这么认为。
But she doesn't see that.

这就是核心，所有问题的核心。”
That's at the heart of it, at the heart of everything that's gone wrong.’

查理开始沿着人行道慢慢往前走，陷入沉思。
He began to walk slowly along the pavement, very preoccupied.

我赶忙转回身去拿他的箱子，拖动轮子。
I hurried back to get his suitcase and began pulling it along on its rollers.

街上人还很多，我很难一面跟上他，一面注意不让箱子撞到行人。
The street was still fairly crowded, so it was a struggle to keep up with him without crashing the bag into other pedestrians.

可查理还是一步步朝前走去，全然不顾我的难处。
But Charlie kept walking at a steady pace, oblivious to my difficulties.

“她觉得我不够努力，”他边走边说。
‘She thinks I've let myself down,’ he was saying.

“可我没有。
‘But I haven't.

我做得很不错。
I'm doing perfectly okay.

年轻时有无尽的梦想是好的。
Endless horizons are all very well when you're young.

可是到了我们这个年纪，你就得……你就得现实点了。
But get to our age, you've got to . . . you've got to get some perspective.

每当埃米莉实在不可理喻时，我脑子里都这么想。
That's what kept going round in my head whenever she got unbearable about it.

现实，她应该面对现实。
Perspective, she needs perspective.

我一直对自己说，看，我做得不错。
And I kept saying to myself, look, I'm doing okay.

看看其他人，我们认识的人。
Look at loads of other people, people we know.

看看雷。
Look at Ray.

看看他过得像什么鸟样。
Look what a pig's arse he's making of his life.

埃米莉应该面对现实。”
She needs perspective.’

“所以你就把我叫来了。
‘So you decided to invite me for a visit.

来当‘现实先生’。”
To be Mr Perspective.’

查理终于停下脚步，回过头来看着我。
At last, Charlie stopped and met my eye. ‘Don't get me wrong, Ray.

“别误会，雷。不是说你真的一无是处。
I'm not saying you're an awful failure or anything.

你既不是瘾君子也不是杀人犯。
I realise you're not a drug addict or a murderer.

可实话实说，跟我比起来，你不像是最成功的。
But beside me, let's face it, you don't look the highest of achievers.

所以我叫你来，叫你来帮帮我。
That's why I'm asking you, asking you to do this for me.

我们的关系快完了，我已经无计可施了。我需要你的帮助。
Things are on their last legs with us, I'm desperate, I need you to help.

而且老天啊，我叫你做什么？
And what am I asking, for God's sake?

只不过是做你自己。你平时怎么样，现在还怎么样。
Just that you be your usual sweet self. Nothing more, nothing less.

不多也不少。帮帮我吧，雷蒙德。
Just do it for me, Raymond.

帮帮我和埃米莉。
For me and Emily.

我们还没结束，我知道还没有。
It's not over between us yet, I know it isn't.

我不在这几天好好在我们家做客。
Just be yourself for a few days until I get back.

这个要求不过分吧？”
That's not so much to ask, is it?’

我深吸了一口气，说：“好，好，要是你觉得这样能行。
I took a deep breath and said:‘Okay, okay, if you think it'll help.

可埃米莉迟早都会发现的，不是吗？”
But isn't Emily going to see through all this sooner or later?’

“发现什么？
‘Why should she?

她知道我要去法兰克福开一个很重要的会。
She knows I've got an important meeting in Frankfurt.

对她来说，这事再简单不过了。她就是接待一个客人。
To her the whole thing's straightforward. She's just looking after a guest, that's all.

她很乐意，她喜欢你。
She likes to do that and she likes you.

啊，的士。”
Look, a taxi.’

他拼命挥手，车朝我们开过来。这时，他抓住我的手臂。
He waved frantically and as the driver came towards us, he grasped my arm.

“谢谢你，雷。
‘Thanks, Ray.

你要替我们扭转局面，我知道你能行。”
You'll swing it for us, I know you will.’

我回到公寓，发现埃米莉的态度全变了。
I returned to find Emily's manner had undergone a complete transformation.

她像欢迎一个年老体衰的亲戚一样把我迎进屋。
She welcomed me into the apartment the way she might a very aged and frail relative.

她面带和蔼的微笑，轻轻地拍拍我的手臂。
There were encouraging smiles, gentle touches on the arm.

她问我要不要喝茶，我说好，她就带我进了厨房，让我在桌子旁坐下，然后站在一旁关切地看了我一会儿。
When I agreed to some tea, she led me into the kitchen, sat me down at the table, then for a few seconds stood there regarding me with a concerned expression.

末了，她轻声说道：
Eventually she said, softly:

“我很抱歉刚才那样子说你，雷蒙德。
‘I'm so sorry I went on at you like that earlier, Raymond.

我没有权利那样子说你。”
I've got no right to talk to you like that.’

她转过身去泡茶，接着说：“我老是忘记我们已经离开大学好多年了。
Then turning away to make the tea, she went on:‘It's years now since we were at university together.

我做梦也想不到我会那样子说其他的朋友。
I always forget that. I'd never dream of talking to any other friend that way.

可如果是你，咳，我想我看见你就以为又回到了过去，回到了从前，忘了早就离开大学了。
But when it's you, well, I suppose I look at you and it's like we're back there, the way we all were then, and I just forget.

你千万别往心里去。”
You really mustn't take it to heart.’

“没，没有。
‘No, no.

我根本没放在心上。”
I haven't taken it to heart at all.’

我还在想着刚才查理说的话，有点心不在焉的样子。
I was still thinking about the conversation I'd just had with Charlie, and probably seemed distant.

我想埃米莉以为我在生气，她的声音更温柔了。
I think Emily misinterpreted this, because her voice became even more gentle.

“很抱歉我惹你生气了。”
‘I'm so sorry I upset you.’

她仔细地把一排排饼干摆在我面前的盘子里。
She was carefully laying out rows of biscuits on a plate in front of me.

“记得吗，雷蒙德，以前我们对你几乎是想说什么就说什么，你只是笑笑，我们也笑笑，什么事情都是玩笑一场。
‘The thing is, Raymond, back in those days, we could say virtually anything to you, you'd just laugh and we'd laugh, and everything would be a big joke.

我真是太傻了，以为你还可以像从前那样。”
It's so silly of me, thinking you could still be like that.’

“啊，其实我现在还和以前差不多。
‘Well, actually, I am more or less still like that.

我一点儿也不介意。”
I didn't think anything of it.’

她显然没有听见我的话，接着说：“我没想到现在的你不一样了。
‘I didn't realise’, she went on, apparently not hearing me, ‘how different you are now.

你已经快走投无路了。”
How close to the edge you must be.’

“听着，埃米莉，说真的，我还没有到……”
‘Look, really Emily, I'm not so bad . . .’

“我想这些年的生活已经把你折磨得够呛了。
‘I suppose the passing years have just left you high and dry.

你像个到了悬崖边的人，再轻轻一推就会崩溃了。”
You're like a man on the precipice. One more tiny push and you'll crack.’

“你是说掉下去吧。”
‘Fall, you mean.’

她刚刚在摆弄水壶，这会儿再次转过身来注视着我。
She'd been fiddling with the kettle, but now turned round to stare at me again.

“别这样，雷蒙德，别说这种话。
‘No, Raymond, don't talk like that.

开玩笑也不要。
Not even in fun.

我永远不要听见你说这种话。”
I don't ever want to hear you talking like that.’

“不，你误会了。
‘No, you misunderstand.

你说我会崩溃，可要是我站在悬崖边，我应该掉下去，而不是崩溃。”
You said I'd crack, but if I'm on a precipice, then I'd fall, not crack.’

“哦，可怜的人儿。”
‘Oh, you poor thing.’

她好像还是没有理解我的话。
She still didn't seem to take in what I was saying.

“只剩下一副外壳。”
‘You're only a husk of the Raymond from those days.’

这次我决定还是别应的好，我们就静静地等水开。
I decided it might be best not to respond this time, and for a few moments we waited quietly for the kettle to boil.

一会儿，水开了，她给我泡了一杯茶放在面前，没有给自己也倒一杯。
She prepared a cup for me, though not for herself, and placed it in front of me.

“很抱歉，雷，我得回办公室去了。
‘I'm so sorry, Ray, but I've got to get back to the office now.

有两个会我一定得去。
There are two meetings I absolutely can't miss.

我要是知道你会这样，我是不会把你一个人留下的。
If only I'd known how you'd be, I wouldn't have deserted you.

我会另做安排的。
I'd have made other arrangements.

可现在我得回去。
But I haven't, I'm expected back.

可怜的雷蒙德。
Poor Raymond.

你一个人在这里怎么好呢？”
What will you do here, all by yourself?’

“我没问题的，真的。
‘I'll be terrific. Really.

其实我在想，你不在时我干吗不来准备晚餐呢？
In fact, I was thinking. Why don't I get our dinner ready while you're gone?

你可能不信，可是我最近厨艺大有长进。
You probably won't believe this, but I've become a pretty good cook these days.

事实上，圣诞节前我们的自助餐……”
In fact, we had this buffet just before Christmas . . .’

“你想帮忙真是太好了。
‘That's terribly sweet of you, wanting to help.

但我想你还是休息吧。
But I think it's best you rest just now.

毕竟在一个不熟悉的厨房很容易会手忙脚乱。
After all, an unfamiliar kitchen can be the source of so much stress.

你就把这里当作自己家，泡个药澡，听听音乐。
Why don't you just make yourself completely at home, have a herbal bath, listen to some music.

我回来以后再来做晚饭。”
I'll take care of dinner when I come in.’

“可是你工作了一整天不会想再操心晚饭的事。”
‘But you don't want to worry about food after a long day at the office.’

“不，雷，你就休息吧。”
‘No, Ray, you're just to relax.’

她拿出一张名片，放在桌上。
She produced a business card and placed it on the table.

“这上面有我的直线电话和手机。
‘This has got my direct line on it, my mobile too.

我得走了，但你随时可以打电话给我。
I've got to go now, but you can call me any time you want.

记住，我不在时别给自己找难题。”
Now remember, don't take on anything stressful while I'm gone.’

一段时间以来，我发现我在自己家里没办法好好休息。
For some time now I've been finding it hard to relax properly in my own apartment.

我要是一个人在家就会越来越焦躁不安，总觉得外头有什么重要的邂逅在等着我。
If I'm alone at home, I get increasingly restless, bothered by the idea that I'm missing some crucial encounter out there somewhere.

可我要是一个人在别人家里反而常常能得到安宁。
But if I'm left by myself in someone else's place, I often find a nice sense of peace engulfing me.

我喜欢窝在陌生的沙发里，随手拿本书来看。
I love sinking into an unfamiliar sofa with whatever book happens to be lying nearby.

这正是埃米莉走了以后我做的事情。
And that's exactly what I did this time, after Emily had left.

或者说，我至少看了两章《曼斯菲尔德庄园》才打了个二十来分钟的盹。
Or at least, I managed to read a couple of chapters of Mansfield Park before dozing off for twenty minutes or so.

一觉醒来，午后的太阳正照进公寓。
When I woke up, the afternoon sun was coming into the flat.

我从沙发上起来，开始东看看西看看。
Getting off the sofa, I began a little nose-around.

可能是清洁工在我们外出吃午饭的时候真的来过了，也可能是埃米莉自个儿打扫了，总之现在偌大的客厅看上去一尘不染。
Perhaps the cleaners had indeed been in during our lunch, or maybe Emily had done the tidying herself; in any case, the large living room was looking pretty immaculate.

客厅不仅是干净，还很有品位，摆设着时髦的家具和艺术品——虽然刻薄的人可能会说太做作了。
Tidiness aside, it had been stylishly done up, with modern designer furniture and arty objects – though someone being unkind might have said it was all too obviously for effect.

我扫了一眼摆着的图书，然后是CD。
I took a browse through the books, then glanced through the CD collection.

基本上全是摇滚和古典乐，可经过一番搜寻，我在角落里找到了几张弗雷德·阿斯泰尔、切特·贝克和萨拉·沃恩的CD。
It was almost entirely rock or classical, but finally, after some searching, I found tucked away in the shadows a small section devoted to Fred Astaire, Chet Baker, Sarah Vaughan.

我奇怪埃米莉怎么没有把其他她珍爱的唱片也换成CD，但我没有在CD这里停留太久，而是溜达去了厨房。
It puzzled me that Emily hadn't replaced more of her treasured vinyl collection with their CD reincarnations, but I didn't dwell on this, and wandered off into the kitchen.

我打开碗橱找饼干、巧克力什么的，突然看见厨房的桌子上有一本小记事本。
I was opening up a few cupboards in search of biscuits or a chocolate bar when I noticed what seemed to be a small notebook on the kitchen table.

带衬垫的紫色封面在光滑而极其简洁的厨房里特别显眼。
It had purple cushioned covers, which made it stand out amidst the sleek minimalist surfaces of the kitchen.

刚刚我喝茶时，埃米莉匆匆忙忙地准备出门，把包里的东西统统倒到桌子上，再重新装进去。
Emily, in a big hurry just before she'd left, had been emptying and re-filling her bag on the table while I'd been drinking my tea.

一定是那个时候落下的。
Obviously she'd left the notebook behind by mistake.

可马上另一种念头出现在我脑子里：这个紫色的小本子是一本私密日记，是埃米莉故意留下来要我看的；出于某种原因，她无法公开表达她的感受，于是用这种方式来倾诉她内心的混乱。
But then in almost the next instant another idea came to me: that this purple book was some kind of intimate diary, and Emily had left it there on purpose, fully intending for me to have a peek; that for whatever reason, she'd felt unable to confide more openly, so had resorted to this way of sharing her inner turmoil.

我站在那儿盯着记事本。
I stood there for a while, staring at the notebook.

过了一会儿，我走上前去，把食指伸进记事本当中，小心翼翼地翻开。
Then I reached forward, inserted my forefinger into the pages at the mid-way point and gingerly levered it up.

埃米莉挤挤挨挨的字映入我的眼帘，我一下子把手收了回来，离开餐桌，告诉自己我不应该偷看埃米莉的本子，不管她一时昏了头想干什么。
The sight of Emily's closely-packed handwriting inside made me pull my finger out, and I moved away from the table, telling myself I had no business nosing in there, never mind what Emily had intended in an irrational moment.

我回到客厅，在沙发上坐下，又看了几页《曼斯菲尔德庄园》。
I went back into the living room, settled into the sofa and read a few more pages of Mansfield Park.

可现在我集中不了精神。
But now I found I couldn't concentrate.

我的脑子一直回想着那个紫色的记事本。
My mind kept going back to the purple notebook.

那会不会不是一时冲动，而是她计划了好几天的呢？
What if it hadn't been an impulsive action at all? What if she'd planned this for days?

她会不会认真地写了一些东西要我读呢？
What if she'd composed something carefully for me to read?

十分钟后，我又回到厨房，盯着紫色记事本。
After another ten minutes, I went back into the kitchen and stared some more at the purple notebook.

然后，我在刚刚喝茶的椅子上坐下来，把本子拉到面前，打开。
Then I sat down, where I'd sat before to drink my tea, slid the notebook towards me, and opened it.

很快我就弄清楚了一个问题：埃米莉要是有一本记录内心深处秘密的日记本的话，一定在别处。
One thing that became quickly apparent was that if Emily confided her innermost thoughts to a diary, then that book was elsewhere.

我面前的这个本子顶多只是一本顶漂亮的日志，每天埃米莉都潦草地记着些提醒自己记得去做的事情，有些字写得超大。
What I had before me was at best a glorified appointments diary; under each day she'd scrawled various memos to herself, some with a distinct aspirational dimension.

比如有一条用粗的毡头墨水笔写着：“还没给马蒂尔达打电话，怎么又忘了？？？
One entry in bold felt-tip went:‘If still not phoned Mathilda, WHY THE HELL NOT???

记得打！！！”
DO IT!!!’

还有一条写着：“他妈的菲利普·罗斯读完了。
Another one ran:‘Finish Philip Bloody Roth.

还给马里恩！”
Give back to Marion!’

我一页页地翻过去，突然，我看见：“雷蒙德星期一来。
Then, as I kept turning the pages, I came across:‘Raymond coming Monday.

痛苦啊，痛苦。”
Groan, groan.’

我又翻了两页，发现：“雷明天就来了。
I turned a couple more pages to find:‘Ray tomorrow.

怎么活？”
How to survive?’

最后，在今天早上刚记的几件琐事中有一条：“牢骚王子要来了，记得买酒。”
Finally, written that very morning, amidst reminders for various chores:‘Buy wine for arrival of Prince of Whiners.’

牢骚王子？
Prince of Whiners?

我犹豫了好一会儿才不得不承认这个称呼指的是我。
It took me some time to accept this really could be referring to me.

我设想了种种可能——客户？水管工人？——可是最后，看看日期，看看前前后后，我不得不承认不可能有其他更靠谱的候选人了。
I tried out all sorts of possibilities – a client? a plumber? – but in the end, given the date and the context, I had to accept there was no other serious candidate.

突然间，一股无名的怒火涌了上来：她怎么可以给我安一个如此不公平的头衔？我一气之下把那张讨厌的纸捏作一团。
Then suddenly the sheer unfairness of her giving me such a title hit me with unexpected force, and before I knew it, I'd screwed up the offending page in my hand.

我的动作并不是很用力：连纸都没有撕下来。
It wasn't a particularly fierce action: I didn't even tear the page.

我只是一把捏紧了拳头，转眼我就恢复了理智，可是当然了，为时已晚。
I'd simply closed my fist on it in a single motion, and the next second I was in control again, but of course, by then, it was too late.

我放开手，发现不单单那张纸被我一气之下捏坏了，连底下两页也遭了殃。
I opened my hand to discover not only the page in question but also the two beneath it had fallen victim to my wrath.

我拼命把纸张弄平，可它们还是皱起来，好像它们就是很想被捏成一团垃圾。
I tried to flatten the pages back to their original form, but they simply curled back up again, as though their deepest wish was to be transformed into a ball of rubbish.

尽管如此，我还是继续固执地想把被我捏坏的纸张弄平，心里忐忑不安。
All the same, for quite some time, I carried on performing a kind of panicked ironing motion on the damaged pages.

正当我准备放弃的时候——我现在不管做什么都掩盖不了我的失误——我听见屋子里有电话在响。
I was just about coming to accept that my efforts were pointless – that nothing I now did could successfully conceal what I'd done – when I became aware of a phone ringing somewhere in the apartment.

我决定不理睬电话，继续想搞清楚我刚刚的失误会有什么后果。
I decided to ignore it, and went on trying to think through the implications of what had just happened.

但是不一会儿电话答录机响了，我听见查理在留言的声音。
But then the answering machine came on and I could hear Charlie's voice leaving a message.

也许我觉得抓到了救命稻草，也许我只是想找人倾诉一下，总之是我发现自己冲到了客厅，抓起玻璃咖啡桌上的电话听筒。
Perhaps I sensed a lifeline, perhaps I just wanted someone to confide in, but I found myself rushing into the living room and grabbing the phone off the glass coffee table.

“哦，你在啊。”
‘Oh, you are there.’

查理好像有点生气我打断了他的留言。
Charlie sounded slightly cross I'd interrupted his message.

“查理，听着。
‘Charlie, listen.

我刚刚做了一件蠢事。”
I've just done something rather stupid.’

“我在机场，”他说。
‘I'm at the airport,’ he said.

“飞机晚点了。
‘The flight's been delayed.

我想给要在法兰克福接我的汽车服务公司打个电话，可我没带他们的电话。
I want to call the car service that's picking me up in Frankfurt, but I didn't bring their number.

所以我要你给我念一下。”
So I need you to read it over to me.’

接着他开始指示我到哪里去找电话本，但是我打断他的话，说道：
He began to issue instructions about where I'd find the phone book, but I interrupted him, saying:

“听着，我刚刚做了一件蠢事。
‘Look, I've just done something stupid.

我不知道怎么办才好。”
I don't know what to do.’

几秒钟的沉默后，查理说道：“你可能在想，雷。
There was quiet for a few seconds. Then he said:‘Maybe you're thinking, Ray.

你可能在想有第三者。
Maybe you're thinking there's someone else.

想说我现在是要飞去见她。我猜你是这样想的。
That I'm going off now to see her. It occurred to me that might be what you were thinking.

跟你看到的一切对得上。刚刚我出门的时候埃米莉的样子，等等。
After all, it would fit with everything you've observed. The way Emily was when I left, all of that.

可是你错了。”
But you're wrong.’

“是，我知道你的意思。
‘Yes, I take your point.

可是你听着，我有事要跟你说……”
But look, there's something I have to talk to you about . . .’

“承认吧，雷。
‘Just accept it, Ray.

你错了。
You're wrong.

没有第三者。
There's no other woman.

我现在是要去法兰克福开一个有关更换我们波兰代理的会。
I'm going now to Frankfurt to attend a meeting about changing our agency in Poland.

我只是要去干这个。”
That's where I'm going right now.’

“是，我知道。”
‘Right, I've got you.’

“从来就没有什么第三者。
‘There's never been another woman in any of this.

我是不会看其他女人的，起码不会正经地看。
I wouldn't look at anyone else, at least not in any serious way.

是真的。
That's the truth.

是他妈的真的，没有第三者！”
It's the bloody truth and there's nothing else to it!’

他说着说着就嚷了起来，可能是因为出发大厅里太吵了。
He'd started to shout, though possibly this was because of all the noise around him in the departure lounge.

现在他不说话了，我仔细听他是不是又哭了，但是只能听见机场里的嘈杂声。
Now he went quiet, and I listened hard to work out if he was crying again, but all I heard were airport noises.

突然，他说道：
Suddenly he said:

“我知道你在想什么。
‘I know what you're thinking.

你在想，好吧，没有其他女人。
You're thinking, all right, there's no other woman.

但会不会是其他男人呢？
But is there another man?

你就认了吧，你是这么想的，对吧？
Go on, admit it, that's what you're thinking, isn't it?

快说！”
Go on, say it!’

“没有。
‘Actually, no.

我从没想过你会是同性恋。
It's never occurred to me you might be gay.

即便是那次期末考以后，你喝得酩酊大醉，假装……”
Even that time after finals when you got really drunk and pretended to . . .’

“闭嘴，你这个白痴！
‘Shut up, you fool!

我是说其他男人，埃米莉的情人！
I meant another man, as in Lover of Emily!

会不会有一个他妈的埃米莉的情人？
Lover of Emily, does this figure bloody exist?

我是这个意思。
That's what I'm getting at.

而我的回答是，根据我的判断，没有，没有，没有。
And the answer, in my judgement, is no, no, no.

在一起这么多年，我很了解她。
After all these years, I can read her pretty well.

可问题就在于，就因为我太了解她了，我还能看见些别的。
But the trouble is, precisely because I know her so well, I can tell something else too.

我能看出她开始想找个情人了。
I can tell she's started to think about it.

没错，雷，她在物色男人。
That's right, Ray, she's looking at other guys.

比如说大卫·科里！”
Guys like David bloody Corey!’

“大卫·科里是谁？”
‘Who's that?’

“大卫·科里是一个虚情假意的饭桶，一个混得不错的律师。
‘David bloody Corey is a smarmy git of a barrister who's doing well for himself.

我知道怎么不错，因为她告诉我怎么不错，很他妈的详细。”
I know exactly how well, because she tells me how well, in excruciating detail.’

“你觉得……他们看上了？”
‘You think ... they're seeing each other?’

“没有，我说了！
‘No, I just told you!

还没有，什么都没有！
There's nothing, not yet!

大卫·科里根本不会理她。
Anyway, David bloody Corey wouldn't give her the time of day.

他娶了一个在康泰纳仕出版集团工作的漂亮妞儿。”
He's married to a glamourpuss who works for Condé Nast.’

“那你不用担心……”
‘Then you're okay ...’

“我要担心，还有个迈克尔·艾迪生。
‘I'm not okay, because there's also Michael Addison.

还有美林银行的新星罗杰·范德伯格，年年都参加世界经济论坛……”
And Roger Van Den Berg who's a rising star at Merrill Lynch who gets to go to the World Economic Forum every year . . .’

“听着，查理，听我说。
‘Look, Charlie, please listen.

我有麻烦了。
I've got this problem here.

不是大麻烦，可总归是个麻烦。
Small by most standards, I admit. But a problem all the same.

你听我说。”
Please just listen.’

我终于把刚才的事情讲给他听，尽量忠实地叙述一切，虽说我把我觉得埃米莉给我留了秘密信息的想法轻轻带过。
At last I got to tell him what had happened. I recounted everything as honestly as I could, though maybe I went easy on the bit about my thinking Emily had left a confidential message for me.

“我知道我很蠢，”末了，我说道。
‘I know it was really stupid,’ I said, as I came to the end.

“可本子就放在那里，在厨房的桌子上。”
‘But she'd left it sitting there, right there on the kitchen table.’

“是。”
‘Yes.’

查理现在听上去冷静了许多。
Charlie was now sounding much calmer.

“是。
‘Yes.

你有麻烦了。”
You've rather let yourself in for it there.’

突然他笑了。
Then he laughed.

我受到鼓舞，也跟着笑了。
Encouraged by this, I laughed too.

“我想我反应过度了。”
‘I suppose I'm over-reacting,’ I said.

我说。
‘After all, it's not like her personal diary or anything.

“毕竟那不像是她的私人日记什么的。
It's just a memo book. . .’

只是个记事本……”我说不下去了，因为查理还在笑，笑声有点歇斯底里。
I trailed off because Charlie had continued to laugh, and there was something a touch hysterical in his laughter.

他不笑了，冷冷地说：
Then he stopped and said flatly:

“她要是知道了，会把你的蛋蛋割下来的。”
‘If she finds out, she'll want to saw your balls off.’

一阵短暂的沉默，我只听见机场里的嘈杂声。
There was a short pause while I listened to airport noises.

然后，他接着说道：
Then he went on:

“大概六年前，我自己翻过那本子，应该说是当年的那本日记本。
‘About six years ago, I opened that book myself, or that year's equivalent.

很偶然，我坐在厨房里，她在做饭。
Just casually, when I was sitting in the kitchen, and she was doing some cooking.

你瞧，就是边说话边无意间随手翻开。
You know, just flicked it open absent-mindedly while I was saying something.

她马上就发现了，说她不喜欢人家看她的东西。
She noticed immediately and told me she wasn't happy about it.

就是那次她说她要把我的蛋蛋割下来。
In fact, that's when she told me she would saw my balls off.

那时她挥着根擀面杖，我说用擀面杖可不好干她威胁的那件事。
She was wielding this rolling pin at the time, so I pointed out she couldn't very well do what she was threatening with a rolling pin.

她就说擀面杖是蛋蛋割下来以后用的。
That's when she said the rolling pin was for afterwards.

蛋蛋割下来以后她要用擀面杖碾碎。”
For what she'd do to them once she'd cut them off.’

电话那头通报了一则航班信息。
A flight announcement went off in the background.

“那我该怎么办？”
‘So what do you suggest I do?’

我问。
I asked.

“你能怎么办？
‘What can you do?

把纸弄平呗。
Just keep smoothing the pages down.

她可能不会注意到。”
Maybe she won't notice.’

“我试了，就是不行。
‘I've been trying that and it just doesn't work.

她不可能不会注意到……”
There's no way she won't notice ...’

“听着，雷，我要操心的事多着呢。
‘Look, Ray, I've got a lot on my mind.

我要告诉你的是埃米莉梦想的这些男人不是真的可能的情人。
What I'm trying to tell you is that all these men Emily dreams about, they're not really potential lovers.

她只是觉得这些人很不错，那么有成就。
They're just figures she thinks are wonderful because she believes they've accomplished so much.

她没有看见他们的缺点。
She doesn't see their warts.

他们根本就是……畜牲。
Their sheer . . . brutality.

总之这些人跟她不是一路的。
They're all out of her league anyway.

关键是，这个关键既让人痛心又讽刺，关键是，归根结底，她爱我。
The point is, and this is what's so pathetically sad and ironic about all this, the point is, at the bottom of it all, she loves me.

她还爱我。
She still loves me.

我知道的，我知道。”
I can tell, I can tell.’

“查理，这么说你没有什么办法咯。”
‘So, Charlie, you don't have any advice.’

“没有！
‘No!

我没有什么他妈的办法！”
I don't have any fucking advice!’

他又开始大嚷起来。
He was shouting full blast again.

“你自己想办法！
‘You figure it out!

你坐你的飞机，我坐我的。
You get on your plane and I'll get on mine.

我们看看哪架会掉下来！”
And we'll see which one crashes!’

说完，查理把电话挂了。
With that, Charlie was gone.

我倒进沙发里，深深地吸了一口气。
I slumped down into the sofa and took a deep breath.

我告诉自己要理智，可是我心里一直感到隐隐的害怕。我想了各种各样的办法。
I told myself I had to keep things in proportion, but all the while I could feel in my stomach a vaguely nauseous sensation of panic.

一种办法是就这么溜之大吉，几年都不再跟查理和埃米莉联系，几年以后我会写一封措词谨慎的信来。
Various ideas ran through my mind. One solution was simply to flee the apartment, and have no contact with Charlie and Emily for several years, after which I'd send them a cautious, carefully-worded letter.

即便事已至此，我也觉得这么做太绝望了。
Even in my current state, I dismissed this plan as being a touch too desperate.

好一点的办法是我把他们柜子里的酒一瓶瓶喝掉，等埃米莉回来的时候就会发现我烂醉如泥了。
A better plan was that I steadily work through the bottles in their drinks cabinet, so that when Emily arrived home, she'd find me pathetically drunk.

那时我就告诉她我看了她的日记，在酒精的作用下把纸张给捏了。
Then I could claim to have looked through her diary and attacked the pages in an alcoholic delirium.

而且，我还可以借着酒疯扮演受害者的角色。我可以冲她嚷嚷，指指点点，告诉她看了她写的话我受了多么深的伤害。我是多么珍视她的爱意和友谊，是她支撑我在孤独的异乡度过那些最难过的日子。
In fact, in my drunken unreasonableness, I could even adopt the role of the injured party, shouting and pointing, telling her how bitterly hurt I'd been to read those words about me, written by someone whose love and friendship I'd always counted on, the thought of which had helped sustain me through my lousiest moments in strange and lonely countries.

可她却那样子说我。虽然这个计划挺可行的，但我隐隐觉得这里头——在这个计划的底下，有什么东西是我不敢去碰的——所以这个计划对我来说也行不通。
But while this plan had points to recommend it from a practical aspect, I could sense something there – something near the bottom of it, something I didn't care to examine too closely – that I knew would make it an impossibility for me.

过了一会儿，电话响了，答录机里又传来查理的声音。
After a time, the phone began to ring and Charlie's voice came onto the machine again.

我拿起电话，查理的声音显然比刚才平静了许多。
When I picked it up he sounded considerably calmer than before.

“我到登机口了，”他说。
‘I'm at the gate now,’ he said.

“很抱歉我刚刚的胡言乱语。
‘I'm sorry if I was a little flustered earlier on.

我到了机场就这样。
Airports always make me that way.

要在登机口坐下来才能觉得安稳。
Can't ever settle until I'm sitting right by the gate.

听着，雷，我突然想到一件事情。
Ray, listen, there's just one thing that occurred to me.

关系到我们的计划。”
Concerning our strategy.’

“我们的计划？”
‘Our strategy?’

“对，我们的全盘计划。
‘Yes, our overall strategy.

当然了，你也已经发现现在不是粉饰形象、让埃米莉对你改观的时候。
Of course, you've realised, this isn't the time for little tweakings of the truth to show yourself in a better light.

绝不是掩盖缺点、炫耀你自己的时候。
Absolutely not the time for the small self-aggrandising white lie.

不是，不是。
No, no.

你还记得我当初为什么会选你吧。
You're remembering, aren't you, why you were given this job in the first place.

雷，我全靠你在埃米莉面前做真实的你。
Ray, I'm depending on you to present yourself to Emily just as you are.

只要你做到这点，我们的计划就没有问题。”
So long as you do that, our strategy stays on course.’

“咳，听着，我现在很难成为埃米莉的大英雄了……”
‘Well, look, I'm hardly on course here to come over like Emily's greatest hero . . .’

“是，你明白目前的情况，我很感激。
‘Yes, you appreciate the situation and I'm grateful.

可我刚刚想到一件事情。
But something's just occurred to me.

就一件事情，你的条件里有一件小事，跟目前的计划有出入。
There's just one thing, one little thing in your repertoire that won't quite do here.

是这样，雷，埃米莉觉得你很有音乐品位。”
You see, Ray, she's got this idea that you have good musical taste.’

“啊……”
‘Ah ...’

“只有一次，只有一次她说我不如你，就是音乐品位。
‘Just about the only time she ever uses you to belittle me is in this area of musical taste.

除了这一条，你就是这个任务十全十美的人选了。
It's the one respect in which you aren't absolutely perfect for your current assignment.

所以，雷，你得答应不提音乐。”
So Ray, you've got to promise not to talk about this topic.’

“哦，天啊……”
‘Oh, for God's sake . . .’

“答应我吧，雷。
‘Just do it for me, Ray.

这个要求不过分。
It's not much to ask.

不要提起那些……那些她喜欢的抒情老歌。
Just don't start going on about that . . . that croony nostalgia music she likes.

要是她提起了，你别搭腔。
And if she brings it up, then you just play it dumb.

我就要求这一点。
That's all I'm asking.

剩下的你只要跟平时一样就可以了。
Otherwise, you just be your natural self.

雷，你能做到这点，对不对？”
Ray, I can count on you about this, can't I?’

“这个，我想可以。
‘Well, I suppose so.

反正这些都只是理论上说说而已。
This is all pretty theoretical anyway.

我想我们今天晚上不会聊什么天。”
I don't see us chatting about anything this evening.’

“很好！
‘Good!

那就没事了。
So that's settled.

现在来说说你那个小问题。
Now, let's move to your little problem.

我想了一下你那事儿，你高兴吧。
You'll be glad to hear I've been giving it some thought.

而且我想出了一个办法。
And I've come up with a solution.

你在听吗？”
Are you listening?’

“在，我在听。”
‘Yes, I'm listening.’

“有一对夫妇经常到我们家来。
‘There's this couple who keep coming round.

安杰拉和索利。
Angela and Solly.

他们人还行，可要不是因为是邻居我们不会跟他们打交道的。
They're okay, but if they weren't neighbours we wouldn't have much to do with them.

反正就是他们经常到我们家来。不事先打招呼就过来喝杯茶。
Anyway they often come round. You know, dropping in without warning, expecting a cup of tea.

然后关键一点是，他们经常是白天什么时候带亨德里克斯出来时，顺便过来。”
Now here's the point. They turn up at various times in the day when they've been taking Hendrix out.’

“亨德里克斯？”
‘Hendrix?’

“亨德里克斯是一只臭烘烘、脾气暴躁，甚至可能杀人的拉布拉多猎狗。
‘Hendrix is a smelly, uncontrollable, possibly homicidal Labrador.

当然了，对安杰拉和索利来说，那畜牲就像他们的孩子。
For Angela and Solly, of course, the foul creature's the child they never had.

他们没有孩子，可能他们还不算太老，还能生孩子。
Or the one they haven't had yet, they're probably still young enough for real children.

可他们更喜欢亲爱、亲爱的亨德里克斯。
But no, they prefer darling, darling Hendrix.

每次过来，亲爱的亨德里克斯都会像个很不爽的小偷一样尽力搞破坏。
And when they call round, darling Hendrix routinely goes about demolishing the place as determinedly as any disaffected burglar.

砰，落地灯倒了。
Down goes the standard lamp.

哦天啊，没关系，亲爱的，你吓到了吗？
Oh dear, never mind, darling, did you have a fright?

你明白吧。
You get the picture.

听好了。
Now listen.

大约一年以前，我们买了一本放在咖啡几上摆设的大画册，花了不少钱，是一帮年轻的男同性恋在北非城堡拍的艺术照片。
About a year ago, we had this coffee-table book, cost a fortune, full of arty pictures of young gay men posing in North African casbahs.

埃米莉就喜欢翻开那页，觉得跟沙发很配。
Emily liked to keep it open at this particular page, she thought it went with the sofa.

你要是翻到别页去她会很生气。
She'd go mad if you turned over the page.

反正就是大约一年以前，亨德里克斯过来的时候把那照片啃了个精光。
Anyway, about a year ago, Hendrix came in and chewed it all up.

没错，就这么把它的牙齿伸到蜡光纸里去，啃啊啃，总共啃了二十来页它妈咪才让它停下来。
That's right, sank his teeth into all that glossy photography, went on to chew up about twenty pages in all before Mummy could persuade him to desist.

知道我为什么跟你说这些吧？”
You see why I'm telling you this, don't you?’

“是。
‘Yes.

我知道你说的办法了，可……”
That is, I see a hint of an escape route, but . . .’

“很好，我来给你解释清楚。
‘All right, I'll spell it out.

你这样跟埃米莉说。
This is what you tell Emily.

有人敲门，你开了门，那对夫妇牵着亨德里克斯站在门口。
The door went, you answered it, this couple are there with Hendrix tugging at the leash.

他们跟你说他们是安杰拉和索利，是我们的好朋友，来喝杯茶。
They tell you they're Angela and Solly, good friends needing their cup of tea.

你让他们进来了，亨德里克斯胡闹起来，咬了日记本。
You let them in, Hendrix runs wild, chews up the diary.

能混过去的。
It's utterly plausible.

怎么了？
What's the matter?

你怎么不谢我？
Why aren't you thanking me?

你不满意？”
Won't quite do for you, sir?’

“我很感激，查理。
‘I'm very grateful, Charlie.

我只是在考虑。
I'm just thinking it through, that's all.

你瞧，比如说，要是他们真的出现怎么办？
Look, for one thing, what if these people really turn up?

我是说在埃米莉回来以后？”
After Emily's home, I mean.’

“我想有这个可能。
‘That's possible, I suppose.

我只能说若真的是这样，你真的是太背、太背了。
All I can say is you'd be very, very unlucky if such a thing happened.

我说他们经常过来，意思是顶多一个月一次。
When I said they came round a lot, I meant maybe once a month at most.

所以别挑刺了，快谢我。”
So stop picking holes and be grateful.’

“可是查理，那狗只咬那本日记本，还刚好咬到了那几页，是不是太牵强了？”
‘But Charlie, isn't it a little far-fetched that this dog would chew just the diary, and exactly those pages?’

我听见他叹了一口气。
I heard him sigh.

“我以为不用说得这么详细的。
‘I assumed you didn't need the rest of it spelt out.

你当然要把整个地方都弄一弄啦。
Naturally, you have to do the place over a bit.

把落地灯弄倒，洒点糖到厨房的地板上。
Knock over the standard lamp, spill sugar over the kitchen floor.

你要弄得好像亨德里克斯把那里弄得乱七八糟的。
You have to make it like Hendrix did this whirlwind job on the place.

听着，在叫登机了。
Look, they're calling the flight.

我得走了。
I've got to go.

我到了德国再跟你联系。”
I'll check in with you once I'm in Germany.’

听查理说话让我感觉像在听一个人絮絮叨叨地讲他做过的梦，或者讲他的车门是怎么被撞到的。
While listening to Charlie, a feeling had come over me similar to the one I get when someone starts on about a dream they had, or the circumstances that led to the little bump on their car door.

他的办法很好——甚至可以说是天才——可是我看不出这跟埃米莉回来以后我想说的或做的有什么关系，我越听越不耐烦。
His plan was all very well – ingenious, even – but I couldn't see how it had to do with anything I was really likely to say or do when Emily got home, and I'd found myself getting more and more impatient.

但是挂了电话以后，我发现查理的话对我有一种催眠的作用。
But once Charlie had gone, I found his call had had a kind of hypnotic effect on me.

尽管我脑子里觉得他的办法很白痴，但我的手脚却开始把他的“办法”付诸实践。
Even as my head was dismissing his idea as idiotic, my arms and legs were setting out to put his ‘solution’ into action.

我把落地灯放倒，小心不撞到其他的东西。我先把灯罩拿掉，把灯放倒，再把灯罩歪歪斜斜地放回去。
I began by putting the standard lamp down on its side. I was careful not to bump anything with it, and I removed the shade first, putting it back on at a cocked angle only once the whole thing was arranged on the floor.

然后我从书架上拿下一个花瓶，把它放到地毯上，把里面的干草洒在旁边。
Then I took down a vase from a bookshelf and laid it down on the rug, spreading around it the dried grasses that had been inside.

接着我选了咖啡几旁的一个好地方把垃圾桶“撞倒”。
Next I selected a good spot near the coffee table to ‘knock over’ the wastepaper basket.

我做这些的时候感觉很奇怪，很不真实。
I went about my work in a strange, disembodied mode.

我不相信这样做能有什么用，可我发现做这些事让我觉得心里好过一些。
I didn't believe any of it would achieve anything, but I was finding the whole procedure rather soothing.

突然我想到我搞这些破坏都是为了那本日记。于是我走进厨房。
Then I remembered all this vandalism was supposed to relate to the diary, and went through into the kitchen.

我想了想，从碗柜里拿出一罐糖，放在桌子上日记本旁边，慢慢倾斜，让糖倒出来。
After a little think, I took a bowl of sugar from a cupboard, placed it on the table not far from the purple notebook, and slowly tilted it until the sugar slid out.

我本来还想让罐子从桌子边掉下去，但最后没有这么做。
I had a bit of a job preventing the bowl rolling off the edge of the table, but in the end got it to stay put.

因为这个时候，一直折磨着我的害怕的感觉挥发殆尽了。
By this time, the gnawing panic I'd been feeling had evaporated.

我并不是恢复了平静，而是觉得这样做实在是太傻了。
I wasn't tranquil, exactly, but it now seemed silly to have got myself in the state I had.

我回到客厅，在沙发上躺下，拿起简·奥斯丁的书，读了几行，感觉累得不行，不知不觉又睡着了。
I went back to the living room, lay down on the sofa and picked up the Jane Austen book. After a few lines, I felt a huge tiredness coming over me and before I knew it, I was slipping into sleep once more.

我被电话吵醒。
I was woken up by the phone.

听见埃米莉的声音出现在答录机里，我坐起来接电话。
When Emily's voice came on the machine, I sat up and answered it.

“哦天啊，雷蒙德，你在啊。
‘Oh goody, Raymond, you are there.

你还好吗，亲爱的？
How are you, darling?

现在感觉怎么样？
How are you feeling now?

有好好休息吗？”
Have you managed to relax?’

我告诉她别担心，我很好，刚刚正在睡觉。
I assured her I had, that in fact I'd been sleeping.

“哦对不起！
‘Oh what a pity!

你可能已经几星期没好好睡觉了，可是你好不容易睡着了，我又把你吵醒！
You probably haven't been sleeping properly for weeks, and now just when you finally get a moment's escape, I go and disturb you!

太对不起了！
I'm so sorry!

还有一件事我也很抱歉，雷，我要让你失望了。
And I'm sorry too, Ray, I'm going to have to disappoint you.

公司里出了要紧的事情，我没办法早回去。
There's an absolute crisis on here and I won't be able to get home quite as quickly as I'd hoped.

我至少还得再过一个钟头。
In fact, I'm going to be another hour at least.

你能坚持一下吧。”
You'll be able to hold out, won't you?’

我重申我现在很好，很舒服。
I reiterated how relaxed and happy I was feeling.

“是啊，听你的声音确实挺好。
‘Yes, you do sound really stable now.

太对不起了，雷，我得挂电话去做事情了。
I'm so sorry, Raymond, but I've got to go and sort this out.

你想要什么就拿什么吧。
Help yourself to anything and everything.

再见，亲爱的。”
Goodbye, darling.’

我放下电话，伸了伸胳膊。
I put down the phone and stretched my arms.

天色渐暗，我起来打开公寓里的灯。
The light was starting to fade now, so I went about the apartment switching on lights.

我看着被我“破坏”了的客厅，越看越觉得不自然。
Then I contemplated my ‘wrecked’ living room, and the more I looked at it, the more it seemed overwhelmingly contrived.

害怕的感觉再次涌上心头。
The sense of panic began to grow once more in my stomach.

电话又响了，这次是查理。
The phone went again, and this time it was Charlie.

他说他现在在法兰克福机场的行李传送带旁。
He was, he told me, beside the luggage carousel at Frankfurt airport.

“真他妈的慢。
‘They're taking bloody ages.

到现在一件行李都没有。
We haven't had a single bag come down yet.

你那里怎么样了？
How are you making out over there?

女主人还没回来吗？”
Madam not home yet?’

“还没。
‘No, not yet.

听着，查理，你的办法行不通。”
Look, Charlie, that plan of yours. It's not going to work.’

“你说行不通是什么意思？
‘What do you mean, it's not going to work?

不要告诉我你到现在还没动手，还在犹豫。”
Don't tell me you've been twiddling your thumbs all this time mulling it over.’

“我照你说的做了。
‘I've done as you suggested.

我把房间弄乱了，可是看着不像那么回事。
I've messed the place up, but it doesn't look convincing.

不像有狗来过，倒像个艺术展。”
It just doesn't look like a dog's been here. It just looks like an art exhibition.’

他没有说话，可能是在注意看行李来了没有。
He was silent for a moment, perhaps concentrating on the carousel.

过了一会儿，他说道：“我理解你的顾虑。
Then he said:‘I can understand your problem.

因为是别人的东西，你一定会缩手缩脚。
It's someone else's property. You're bound to be inhibited.

听好了，我点名几样东西我衷心希望你把它们砸个稀巴烂。
So listen, I'm going to name a few items I'd dearly love to see damaged.

你在听吗，雷？
Are you listening, Ray?

我要你把这些东西砸烂。
I want the following things ruined.

那个垃圾瓷牛。
That stupid china ox thing.

在CD机旁边。
It's by the CD player.

那是王八蛋大卫·科里从拉各斯回来的时候送的。
That's a present from David bloody Corey after his trip to Lagos.

你就从那个开始。事实上，我不在乎你砸什么东西。
You can smash that up for a start. In fact, I don't care what you destroy.

统统都砸了吧！”
Destroy everything!’

“查理，你要冷静。”
‘Charlie, I think you need to calm down.’

“好，好。
‘Okay, okay.

但那个房子里的东西全是破烂。
But that apartment's full of junk.

就像我们现在的婚姻。
Just like our marriage right now.

全是一堆破烂。
Full of tired junk.

那个红色海绵沙发，你知道我说哪个吧，雷？”
That spongy red sofa, you know the one I mean, Ray?’

“是。
‘Yes.

我刚刚还在上面睡觉来着。”
Actually I fell asleep on it just now.’

“早就该扔到垃圾桶里去了。
‘That should have been in a skip ages ago.

把外面的皮撕开，把里面的海绵统统翻出来。”
Why don't you rip open the covering and throw the stuffing around.’

“查理，冷静一下。
‘Charlie, you have to get a grip.

你这根本不是在帮我。
In fact, it occurs to me you're not trying to help me at all.

你只是把我当作发泄你的愤怒和沮丧的工具……”
You're just using me as a tool to express your rage and frustration . . .’

“别胡说八道了！
‘Oh shut up with that bollocks!

我当然是在帮你。
Of course I'm trying to help you.

而且我的办法很好。
And of course my plan's a good one.

我保证能行的。
I guarantee it'll work.

埃米莉恨那条狗，恨安杰拉和索利，她抓住一切机会更恨他们一点。
Emily hates that dog, she hates Angela and Solly, so she'll seize any opportunity to hate them even more.

听着。”
Listen.’

他的声音突然变成近乎耳语。
His voice suddenly dropped to a near-whisper.

“我教你这个最大的秘诀。
‘I'll give you the big tip.

用这个秘密配方一定能让埃米莉相信。
The secret ingredient that'll ensure she's convinced.

我早该想到了。
I should have thought of this before.

你还有多少时间？”
How much time do you have left?’

“大约一个小时……”
‘Another hour or so ...’

“很好。
‘Good.

仔细听好了。
Listen carefully.

味道。
Smell.

没错。
That's right.

在房子里弄出狗的味道。
You make that place smell of dog.

她一进门就会察觉到，即使只是下意识地。
From the moment she walks in, she'll register it, even if it's only subliminally.

然后她走进房间，看见亲爱的大卫的瓷牛在地上摔成粉碎，看见那个破沙发里的海绵到处都是……”
Then she steps into the room, notices darling David's china ox smashed up on the floor, the stuffing from that foul red sofa all over . . .’

“听着，我没有说我……”
‘Now look, I didn't say I'd . . .’

“别插嘴。
‘Just listen!

她看见屋子里乱七八糟的，马上就会有意无意地联想到狗的气味。
She sees all the wreckage, and immediately, consciously or unconsciously, she'll make the connection with the dog smell.

你什么都还没说，她就会想到是亨德里克斯干的。
The whole scene with Hendrix will flash vividly through her head, even before you've said a word to her.

太漂亮了！”
That's the beauty of it!’

“瞎说，查理。
‘You're havering, Charlie.

那好，我怎么把你家弄出狗的味道来呢？”
Okay, so how do I make your home pong of dog?’

“我知道怎么弄。”他的声音还是低低的，但很兴奋。
‘I know exactly how you create a dog smell.’ His voice was still an excited whisper.

“我清楚得很。以前我和托尼·巴顿在中学六年级时干过。
‘I know exactly how you do it, because me and Tony Barton used to do it in the Lower Sixth.

他弄了个配方，我改进了一下。”
He had a recipe, but I refined it.’

“为什么？”
‘But why?’

“为什么？
‘Why?

因为他的配方更像臭白菜，而不是狗，这就是为什么。”
Because it stank more like cabbage than dog, that's why.’

“不是，我是说你们为什么……好了，算了。
‘No, I meant why would you . . . Look, never mind.

你告诉我吧，只要不用出去买一套化学品就行。”
You might as well tell me, so long as it doesn't involve going out and buying a chemistry set.’

“很好。
‘Good.

你转过弯来了。
You're coming round to it.

拿支笔来，雷。
Get a pen, Ray.

记下来。
Write this down.

啊，行李终于来了！”
Ah, here it comes at last.’

他一定是把手机放到口袋里了，我听见一阵窸窸窣窣的声音。
He must have put the phone in his pocket, because for the next few moments I listened to womb noises.

然后他重新拿起电话说道：
Then he came back and said:

“我没时间多说了。
‘I have to go now. So write this down.

记下来。
Are you ready?

准备好了吗？
The middle-sized saucepan.

中等大小的长柄锅一只。
It's probably on the stove already.

可能灶子上已经有了。
Put about a pint of water in it.

放入一品脱左右的水和两块牛肉浓缩汤块、一小勺孜然、一大勺辣椒粉、两大勺醋、一大把月桂叶。
Add two beef stock cubes, one dessertspoon of cumin, one tablespoon of paprika, two tablespoons of vinegar, a generous lot of bay leaves. Got that?

记下来了吗？然后放进一只皮鞋或皮靴，底朝上，别让鞋底完全浸在水里，这样就不会有烧焦橡胶的味道。
Now you put in there a leather shoe or boot, upside down, so the sole's not actually immersed in the liquid. That's so you don't get any hint of burning rubber.

接着就可以打开煤气，把这堆东西放上去煮了，让它慢慢炖。
Then you turn on the gas, bring the concoction to the boil, let it sit there simmering.

很快就会有味道出来了。
Pretty soon, you'll notice the smell.

不是很难闻。
It's not an awful smell.

托尼·巴顿原来的配方里还加了鼻涕虫，可我这个更像狗的臭味。
Tony Barton's original recipe involved garden slugs, but this one's much more subtle. Just like a smelly dog.

我知道你要问我去哪里找这些材料。
I know, you're going to ask me where to find the ingredients.

所有的香料什么的都在厨房的柜子里。楼梯底下的储物柜里有一双旧靴子。
All the herbs and stuff are in the kitchen cupboards. If you go to the understairs cupboard, you'll find a discarded pair of boots in there.

不是那双高筒靴，拿破破烂烂的那双，有点像加长的鞋子。
Not the wellingtons. I mean the battered-up pair, they're more like built-up shoes.

我以前常穿去散步。
I used to wear them all the time on the common.

已经不能穿了，该扔掉了。拿一只。
They've had it and they're waiting for the heave.

怎么了？
Take one of those.

听着，雷，就这么做，好吗？救救你自己。
What's the matter? Look, Ray, you just do this, okay?

因为我告诉你，发飙的埃米莉可不是闹着玩的。
Save yourself. Because I'm telling you, an angry Emily is no joke.

我得挂电话了。
I've got to go now.

哦，对了，记住不要卖弄你的音乐学问。”
Oh, and remember. No showing off your wonderful musical knowledge.’

也许是因为得到了一系列清楚的指示，不管这些指示多么荒唐，我放下电话时，刚才害怕的感觉没有了，变得干劲十足。
Perhaps it was simply the effect of receiving a clear set of instructions, however dubious: when I put the phone down, a detached, business-like mood had come over me.

我很清楚自己该做什么。
I could see clearly just what I needed to do.

我走进厨房，打开电灯。
I went into the kitchen and switched on the lights.

炉子上确实有一只“中等大小的”长柄锅等着执行任务。
Sure enough, the ‘middle-sized’ saucepan was sitting on the cooker, awaiting its next task.

我装了半锅水，然后放回炉子上。
I filled it to halfway with water, and put it back on the hob.

我虽忙活着，但心里清楚，在我往下做之前得先确认一件事：即我到底有多少时间来完成这些事情。
Even as I was doing this, I realised there was something else I had to establish before proceeding any further: namely, the precise amount of time I had to complete my work.

我走回客厅，拿起电话，拨通埃米莉办公室的号码。
I went into the living room, picked up the phone, and called Emily's work number.

助理接的电话，告诉我埃米莉在开会。
I got her assistant, who told me Emily was in a meeting.

我半是亲切半是坚决地要她把埃米莉从会场叫出来，“看看她是否真的在开会”。
I insisted, in a tone that balanced geniality with resolution, that she bring Emily out of her meeting, ‘if indeed she is in one at all’.

不一会儿，埃米莉来了。
The next moment, Emily was on the line.

“怎么了，雷蒙德？
‘What is it, Raymond?

什么事？”
What's happened?’

“没事。
‘Nothing's happened.

我只是想看看你怎么样了。”
I'm just calling to find out how you are.’

“雷，你怪怪的。
‘Ray, you sound odd.

怎么了？”
What is it?’

“什么叫我怪怪的？
‘What do you mean, I sound odd?

我只是想确认你什么时候会回来。
I just called to establish when to expect you back.

我知道你觉得我是个懒人，但我还是想要个时间表什么的。”
I know you regard me as a layabout, but I still appreciate a timetable of sorts.’

“雷蒙德，没必要生气嘛。
‘Raymond, there's no need to get cross like that.

我想想。
Now let me see.

还要一个小时……也可能是一个半小时。
It's going to be another hour . . . Maybe an hour and a half.

我真的很抱歉，公司里出了非常要紧的事情……”
I'm awfully sorry, but there's a real crisis on here . . .’

“一个到一个半小时。
‘One hour to ninety minutes.

好的。
That's fine.

我就想知道这个。
That's all I need to know.

那我们一会儿见。
Okay, I'll see you soon.

你回去工作吧。”
You can get back to your business now.’

埃米莉可能还想说些什么，但我已经把电话挂了，大步走进厨房，决心不让我现在坚定的心情很快消失。
She might have been about to say something else, but I hung up and strode back into the kitchen, determined not to let my decisive mood evaporate.

事实上，我现在慢慢地越来越兴奋，想不通之前怎么会让自己那么绝望。
In fact, I was beginning to feel distinctly exhilarated, and I couldn't understand at all how I'd allowed myself to get into such a state of despondency earlier on.

我搜遍厨房的柜子，把我需要的香料和调味品在炉子旁整整齐齐地摆成一排。
I went through the cupboards and lined up, in a neat row beside the hob, all the herbs and spices I needed.

然后我各取适量倒进水里，很快地搅拌一下，开始找靴子。
Then I measured them out into the water, gave a quick stir, then went off to find the boot.

楼梯底下的储物柜里藏着一大堆破破烂烂的鞋子。
The understairs cupboard was hiding a whole heap of sorry-looking footwear.

我搜寻了一番，发现确实有一只查理方子里的靴子——有一只特别破烂的靴子，脚后跟的边上结着陈年泥土块。
After a few moments of rummaging, I discovered what was certainly one of the boots Charlie had prescribed – a particularly exhausted specimen with ancient mud encrusted along the rim of its heel.

我用指尖捏住鞋，拿到厨房里，小心翼翼地底朝上放进锅里。
Holding it with fingertips, I took it back to the kitchen and placed it carefully in the water with the sole facing up to the ceiling.

接着我打开炉子，开到中火，然后就坐下来，等水开。
Then I lit a medium flame under the pan, sat down at the table and waited for the water to heat.

当电话再次响起时，我真不愿意离开我的锅，但我听见查理在答录机里说啊说，最后我还是把火关小，去接电话。
When the phone rang again, I felt reluctant to abandon the saucepan, but then I heard Charlie on the machine going on and on. So I eventually turned the flame down low and went to answer him.

“你刚刚说什么呢？”
‘What were you saying?’

我问。
I asked.

“听起来一副可怜样。我很忙，没听清。”
‘It sounded particularly self-pitying, but I was busy so I missed it.’

“我到旅馆了。
‘I'm at the hotel.

只有三星级。
It's only a three-star.

你能相信这种厚颜无耻的事吗！
Can you believe the cheek!

那么大一家公司！
A big company like them!

房间也小得要命！”
And it's a poxy little room too!’

“可你就住两三个晚上……”
‘But you're only there for a couple of nights ...’

“听着，雷，之前我没有完全说实话。我觉得对你不公平。
‘Listen, Ray, there's something I wasn't entirely honest about earlier. It's not fair on you.

毕竟你是在帮我，在尽全力帮我，帮我弥补和埃米莉的关系。而我却没有对你诚实。”
After all, you're doing me a favour, you're doing your best for me, trying to heal things with Emily, and here I am, being less than frank with you.’

“你要是想说狗气味的配方，已经太迟了。
‘If you're talking about the recipe for the dog smell, it's too late.

我已经全都弄下去了。
I've got it all going.

我想也许还可以再加一种香料什么的……”
I suppose I might be able to add an extra herb or something . . .’

“我之前没有对你诚实是因为我没有对自己诚实。
‘If I wasn't straight with you before, that's because I wasn't being straight with myself.

可现在离开了家，我的脑子清楚多了。
But now I've come away, I've been able to think more clearly.

雷，之前我跟你说没有第三者不完全正确。
Ray, I told you there wasn't anyone else, but that's not strictly true.

有这么个女生。
There's this girl.

没错，年轻女生，顶多三十出头。
Yes, she is a girl, early thirties at most.

她很关心发展中国家的教育，关心更加公平的全球贸易。
She's very concerned about education in the developing world, and fairer global trade.

她吸引我的不是性，那只能说是副产品。
It wasn't really a sexual attraction thing, that was just a kind of by-product.

是她还未失去光泽的理想主义，让我想起以前的我们。
It was her untarnished idealism. It reminded me of how we all were once.

记得吗，雷？”
You remember that, Ray?’

“对不起，查理，我不记得你以前特别理想主义。
‘I'm sorry, Charlie, but I don't remember you ever being especially idealistic.

说实话，你一直很自私，喜欢享乐……”
In fact, you were always utterly selfish and hedonistic . . .’

“好吧，也许以前我们都是一群没用的笨蛋，我们这些人。
‘Okay, maybe we were all decadent slobs back then, the lot of us.

可是在我心里一直有另一个我想要跳出来。
But there's always been this other person, somewhere inside of me, wanting to come out.

这就是她吸引我的地方……”
That's what drew me to her . . .’

“查理，这是什么时候的事？
‘Charlie, when was this?

什么时候开始的？”
When did this happen?’

“什么什么时候开始的？”
‘When did what happen?’

“婚外情。”
‘This affair.’

“没有什么婚外情！
‘There was no affair!

我没有和她性交，没有。
I didn't have sex with her, nothing.

连一起吃饭都没有。
I didn't even have lunch with her.

我只是……我只是喜欢看见她。”
I just . . . I just made sure I kept seeing her.’

“什么意思，喜欢看见她？”
‘What do you mean, kept seeing her?’

我边说边踱进厨房，盯着那锅东西。
I'd drifted back into the kitchen by this time and was gazing at my concoction.

“啊，我喜欢看见她，”他说。
‘Well, I kept seeing her,’ he said.

“我总是找机会见她。”
‘I kept making appointments to see her.’

“你是说她是应召女郎。”
‘You mean, she's a call girl.’

“不是，不是，我说了，我们没有性交。
‘No, no, I told you, we've never had sex. No, she's a dentist.

不是，她是个牙医。我老去找她，说这里痛，那里不舒服，能多去几次就多去几次。
I kept going back, kept making things up about a pain here, discomfort of the gums there. You know, I spun it out.

当然，最后埃米莉怀疑了。”
And of course, in the end, Emily guessed.’

说到这里，查理好像在强忍着不哭出来。
For a second, Charlie seemed to be choking back a sob.

但大坝还是决堤了。
Then the dam burst.

“她发现了……她发现了……因为我老用牙线清洁牙齿！”
‘She found out . . . she found out . . . because I was flossing so much!’

他现在几乎是在叫嚷。
He was now half-shrieking.

“她说，你从来没有这么勤快地清洁牙齿……”
‘She said, you never, ever floss your teeth that much!’

“可这说不通啊。
‘But that doesn't make sense.

你越保护你的牙，就越没有理由去找她了……”
If you look after your teeth more, you've less reason to go back to her . . .’

“谁管它说得通说不通？
‘Who cares if it makes sense?

我只想取悦她！”
I just wanted to please her!’

“听着，查理，你没有跟她约会，没有跟她性交，那有什么问题？”
‘Look, Charlie, you didn't go out with her, you didn't have sex with her, what's the issue?’

“问题就在于，我太想要这么一个人，一个能把关在我心里的那个自我放出来的人……”
‘The issue is, I so wanted someone like that, someone who'd bring out this other me, the one that's been trapped inside . . .’

“查理，听我说。
‘Charlie, listen to me.

接了你上一次的电话以后，我就大大地振作了。
Since the last time you called, I've pulled myself together considerably.

老实说，我觉得你也应该振作起来。
And quite frankly, I think you should pull yourself together too.

你回来以后我们可以把这整件事好好地谈一谈。
We can discuss all of this when you get back.

可埃米莉再过大概一个小时就回来了，我得把一切都布置好。
But Emily will be here in an hour or so, and I've got to have everything ready.

我这儿正忙着呢，查理。
I'm on top of things here now, Charlie.

我想你可以从我的声音里听出来。”
I suppose you can tell that from my voice.’

“笑死人了！
‘Fucking fantastic!

你正忙着呢。
You're on top of things.

很好！
Great!

他妈的什么朋友……”
Some fucking friend ...’

“查理，我想你是不喜欢那个旅馆才会这么心烦意乱的。但你应该振作起来。
‘Charlie, I think you're upset because you don't like your hotel. But you should pull yourself together.

理智一些。
Get things in perspective.

打起精神。
And take heart.

我这儿正忙着呢。
I'm on top of things here.

我得先解决狗的事，然后我会尽全力帮你。
I'll sort out the dog business, then I'll play my part up to the hilt for you.

我会对埃米莉说：‘埃米莉，看看我，看看我多没用。’
Emily, I'll say. Emily, just look at me, just look how pathetic I am.

其实，很多人都和我一样没用。
The truth is, most people are just as pathetic.

可是查理他不一样。
But Charlie, he's different.

查理比我们优秀。”
Charlie is in a different league.’

“你不能这样说。
‘You can't say that.

太假了。”
That sounds completely unnatural.’

“我当然不是照这样说了，白痴。
‘Of course I won't put it literally like that, idiot.

听着，交给我吧。
Look, just leave it to me.

一切都在我的掌握之中。
I've got the whole situation under control.

你要冷静。
So calm down.

好了，我得挂电话了。”
Now I've got to go.’

我放下电话，查看锅里的东西。
I put the phone down and examined the pot.

锅里的液体已经沸腾了，不断冒着蒸汽，可是还没有什么味道。
The liquid had now come to the boil and there was a lot of steam about, but as yet no real smell of any sort.

我把火开得再大一点，锅里开始不停冒泡。
I adjusted the flame until everything was bubbling nicely.

这时，我突然很想呼吸一下新鲜空气，而我又还没去过他们的天台，于是我打开厨房门，走了出去。
It was around this point I was overcome by a craving for some fresh air, and since I hadn't yet investigated their roof terrace, I opened the kitchen door and stepped out.

对于六月初的英国，今晚特别暖和。
It was surprisingly balmy for an English evening in early June.

只有微风中的少许凉意提醒我现在不是在西班牙。
Only a little bite in the breeze told me I wasn't back in Spain.

天还没有全黑，但已经布满了星星。
The sky wasn't fully dark yet, but was already filling with stars.

越过天台尽头的那堵墙，我能望见数英里内的窗户和几码内邻居屋里的家具。
Beyond the wall that marked the end of the terrace, I could see for miles around the windows and back yards of the neighbouring properties.

很多人家的窗户都亮了；眯起眼，远处的窗户就像星星的延伸。
A lot of the windows were lit, and the ones in the distance, if you narrowed your eyes, looked almost like an extension of the stars.

天台不大，却很有情调。
This roof terrace wasn't large, but there was definitely something romantic about it.

你可以想象一对夫妇在繁忙的都市生活中，在一个温和的夜晚，到天台上来，手挽着手，漫步于盆栽的小树丛里，交换彼此一天的故事。
You could imagine a couple, in the midst of busy city lives, coming out here on a warm evening and strolling around the potted shrubs, in each other's arms, swapping stories about their day.

我本可以再多待一会儿，但我怕我的干劲消失，就回到厨房里，走过冒着泡的锅，走到客厅的入口，端详着我之前的布置。
I could have stayed out there a lot longer, but I was afraid of losing my momentum. I went back into the kitchen, and walking past the bubbling pot, paused at the threshold of the living room to survey my earlier work.

突然，我意识到我犯了一个大错，我完全没有从亨德里克斯的角度来想问题。
The big mistake, it struck me, lay in my complete failure to consider the task from the perspective of a creature like Hendrix.

现在我明白了事情的关键是把自己当作亨德里克斯。
The key, I now realised, was to immerse myself within Hendrix's spirit and vision.

这么一来，我发现不仅我之前的努力全是白费，而且查理的建议大多都没有用。
Once I'd started on this tack, I saw not only the inadequacy of my previous efforts, but how hopeless most of Charlie's suggestions had been.

一只精力过剩的狗怎么会从音响中间把一只小瓷牛拔出来砸碎呢？
Why would an over-lively dog extract a little ox ornament from the midst of hi-fi equipment and smash it?

割开沙发、掏出海绵这事儿也太不现实了。
And the idea of cutting open the sofa and throwing around the stuffing was idiotic.

亨德里克斯得有剃刀般的牙齿才能做到。
Hendrix would need razor teeth to achieve an effect like that.

厨房里弄翻糖罐的主意还行，可是我发现客厅得完全重新布置。
The capsized sugar bowl in the kitchen was fine, but the living room, I realised, would have to be re-conceptualised from scratch.

我弯着腰走进客厅，以便更好地从亨德里克斯的视角来看东西。
I went into the room in a crouched posture, so as to see it from something like Hendrix's eyeline.

我一眼就看见咖啡几上的那堆杂志是最明显的目标。
Immediately, the glossy magazines piled up on the coffee table revealed themselves as an obvious target, and so I pushed them off the surface along a trajectory consistent with a shove from a rampant muzzle.

于是我一把把书扫了出去，就像一只畜牲用嘴甩出去的一样。
The way the magazines landed on the floor looked satisfyingly authentic.

书掉在地板上的样子看起来很真实。
Encouraged, I knelt down, opened one of the magazines and scrunched up a page in a manner, I hoped, would find an echo when eventually Emily came across the diary.

我受到了鼓舞，跪下来，翻开一本杂志，揉碎其中的一页，希望能模仿日记本的效果，但结果并不理想：一看就是人手弄的，不像狗的牙齿弄的。
But this time the result was disappointing: too obviously the work of a human hand rather than canine teeth.

我又犯了之前的错误：我还没有完全把自己当作亨德里克斯。
I'd fallen into my earlier error again: I'd not merged sufficiently with Hendrix.

这次我四脚着地，低下头，把牙齿伸进同一本杂志。
So I got down on all fours, and lowering my head towards the same magazine, sank my teeth into the pages.

味道香香的，不是很糟。
The taste was perfumy, and not at all unpleasant.

我翻开另一本掉在地上的杂志，翻到中间，重复同样的动作。
I opened a second fallen magazine near its centre and began to repeat the procedure.

我渐渐领悟到，最理想的动作跟在露天市场里玩不用手咬起浮在水里的苹果的游戏类似。
The ideal technique, I began to gather, was not unlike the one needed in those fairground games where you try to bite apples bobbing in water without using your hands.

轻轻地咀嚼、下巴不停地轻盈摆动，效果最好：这样书页就会变得乱糟糟、皱巴巴的。
What worked best was a light, chewing motion, the jaws moving flexibly all the time: this would cause the pages to ruffle up and crease nicely.

相反，咬得太用力只会把书页都“钉”在一起，没有明显效果。
Too focused a bite, on the other hand, simply ‘stapled’ pages together to no great effect.

我想我太在意这些细节，才没有早点发现埃米莉站在走廊里，就在门口，看着我。
I think it was because I'd become so absorbed in these finer points that I didn't become aware sooner of Emily standing out in the hall, watching me from just beyond the doorway.

看见她，我的第一反应不是害怕或者尴尬，而是受伤：她居然就那么站在那里，不告诉我说她回来了。
Once I did realise she was there, my first feeling wasn't one of panic or embarrassment, but of hurt that she should be standing there like that without having announced her arrival in some way.

想到几分钟前我为了避免现在这种情况还特意打电话给她，我觉得自己被骗了。
In fact, when I remembered how I'd gone to the trouble of calling her office only several minutes earlier precisely to pre-empt the sort of situation now engulfing me, I felt the victim of a deliberate deception.

这大概就是为什么我的第一个动作只是疲惫地叹了口气，仍旧四脚着地跪在地上，没有起来。
Perhaps that was why my first visible response was simply to give a weary sigh without making any attempt to abandon my all-fours posture.

我看着埃米莉走进屋子，一只手很温柔地搭在我的背上。
My sigh brought Emily into the room, and she laid a hand very gently on my back.

我不确定她有没有跪下来，但她说话时，脸离我很近。
I'm not sure if she actually knelt down, but her face seemed close to mine as she said:

“雷蒙德，我回来了。
‘Raymond, I'm back.

我们坐下来吧，好吗？”
So let's just sit down, shall we?’

说着，她扶我起来，我强忍着不把她推开。
She was easing me up onto my feet, and I had to resist the urge to shake her off.

“真奇怪，”我说。
‘You know, it's odd,’ I said.

“几分钟前你才说要去开会。”
‘No more than a few minutes ago, you were about to go into a meeting.’

“没错。
‘I was, yes.

可是接到你的电话以后，我发现有必要提早回来。”
But after your phone call, I realised the priority was to come back.’

“有必要？什么意思？
‘What do you mean, priority?

埃米莉，你不用这样抓住我的胳膊，我不会摔倒的。你说有必要提早回来是什么意思？”
Emily, please, you don't have to keep holding my arm like that, I'm not about to topple over. What do you mean, a priority to come back?’

“你的电话。
‘Your phone call.

我后来明白你为什么打电话。
I recognised it for what it was.

你打电话找我求救。”
A cry for help.’

“没有的事。
‘It was nothing of the sort.

我只是想……”我停住了，因为我发现埃米莉正好奇地打量着客厅。
I was just trying to . . .’ I trailed off, because I noticed Emily was looking around the room with an expression of wonder.

“哦，雷蒙德，”她轻声说，几乎是自言自语。
‘Oh, Raymond,’ she muttered, almost to herself.

“我刚刚不小心把这里弄乱了，正在收拾，想不到你提早回来了。”
‘I suppose I was being a little clumsy earlier on. I would have tidied up, except you came back early.’

我弯下腰去捡倒在地上的落地灯，但是埃米莉拉住我。
I reached down to the fallen standard lamp, but Emily restrained me.

“没关系，雷。
‘It doesn't matter, Ray.

真的没关系。
It really doesn't matter at all.

待会儿我们可以一起收拾。
We can sort it all out together later.

你先坐下来休息。”
You just sit down now and relax.’

“埃米莉，我知道这儿是你家什么的。
‘Look, Emily, I realise it's your own home and all that.

可是刚刚你为什么不声不响偷偷地进来？”
But why did you creep in so quietly?’

“我没有偷偷地进来，亲爱的。
‘I didn't creep in, darling.

我进门时叫你了，可你好像不在。
I called when I came in, but you didn't seem to be here.

我就赶紧去了下厕所，出来时，咳，发现你在。
So I just popped into the loo and when I came out, well, there you were after all.

好了，别说这些了。
But why go over it?

有什么关系呢？
None of it matters.

现在我回来了，我们可以一起过个轻松愉快的夜晚。
I'm here now, and we can have a relaxing evening together.

坐下来吧，雷蒙德。
Please do sit down, Raymond.

我去泡茶。”
I'll make some tea.’

说着，她朝厨房走去。
She was already going towards the kitchen as she said this.

我正在摆弄落地灯的灯罩，过了一会儿才记起厨房里在煮什么——可为时已晚。
I was fiddling with the shade of the standard lamp and so it took me a moment to remember what was in there – by which time it was too late.

我侧耳倾听她的反应，可是什么声音也没有。
I listened for her reaction, but there was only silence.

最后，我放下灯罩，朝厨房门口走去。
Eventually I put down the lampshade and made my way to the kitchen doorway.

长柄锅还在均匀地冒着气泡，蒸汽从靴子周围冒出来。
The saucepan was still bubbling away nicely, the steam rising around the upheld sole of the boot.

而且味道出来了，在外面没注意，厨房里就很明显。
The smell, which I'd barely registered until this point, was much more obvious in the kitchen itself.

那味道闻起来自然很辛辣，有点像咖喱。
It was pungent, sure enough, and vaguely curryish.

但最主要的是像你走了很长时间的路以后，把臭汗淋淋的脚从靴子里拔出来时的味儿。
More than anything else, it conjured up those times you yank your foot out of a boot after a long sweaty hike.

埃米莉站在离炉子几步远的地方，伸长脖子，从一个安全距离看清锅里的东西。
Emily was standing a few paces back from the cooker, craning her neck to get as good a view of the pot as possible from a safe distance.

她好像完全被眼前的景象迷住了，我苦笑了一声表明我在，她没有转移视线，更没有转身。
She seemed absorbed by the sight of it, and when I gave a small laugh to announce my presence, she didn't shift her gaze, let alone turn around.

我从她身边挤过去，在桌子旁坐下。
I squeezed past her and sat down at the kitchen table.

最后，埃米莉终于亲切地微笑着转向我说：“这主意真是太可爱了，雷蒙德。”
Eventually, she turned to me with a kindly smile. ‘It was a terribly sweet thought, Raymond.’

说完，她的视线又不由自主地回到了炉子上。
Then, as though against her will, her gaze was pulled back to the cooker.

我看见面前放着被我弄倒的糖罐——和日记——突然感到一股巨大的疲惫。
I could see in front of me the tipped-up sugar bowl – and the diary – and a huge feeling of weariness came over me.

一切都完了，我唯一的出路就是放弃所有的把戏，如实交待。
Everything felt suddenly overwhelming, and I decided the only way forward was to stop all the games and come clean.

我深吸了一口气，说道：
Taking a deep breath, I said:

“是这样的，埃米莉。
‘Look, Emily.

事情好像有点古怪，但一切都是因为你的日记本。
Things might look a little odd here. But it was all because of this diary of yours.

就这本。”
This one here.’

我翻开被我捏烂的那一页给她看。
I opened it to the damaged page and showed her.

“我真的很对不起，我真不该这样做。
‘It was really very wrong of me, and I'm truly sorry.

我顺手翻开了你的本子，然后，然后不小心弄坏了这一页。
But I happened to open it, and then, well, I happened to scrunch up the page.

像这样……”我轻轻地把先前的动作又做了一遍，然后看着她。
Like this . . .’ I mimicked a less venomous version of my earlier action, then looked at her.

出人意料的是，她只匆匆扫了一眼本子，就又看着炉子，说：“哦，那只是一本记事本。
To my astonishment, she gave the diary no more than a cursory glance before turning back to the pot, saying:‘Oh, that's just a jotter.

没有什么隐私。
Nothing private.

不用担心，雷。”
Don't you worry about it, Ray.’

说完她向前走了一步，好把锅里的东西看得更清楚些。
Then she moved a step closer to the saucepan to study it all the better.

“什么意思？
‘What do you mean?

不用担心？
What do you mean, don't worry about it?

你怎么能这样说？”
How can you say that?’

“怎么了，雷蒙德？
‘What's the matter, Raymond?

那本子只是用来记一些我怕忘记的事。”
It's just something to jot down stuff I might forget.’

“可是查理跟我说你会发飙！”
‘But Charlie told me you'd go ballistic!’

看来埃米莉全忘了她写了我什么，我更生气了。
My sense of outrage was now being added to by the fact that Emily had obviously forgotten what she'd been writing about me.

“真的？
‘Really?

查理跟你说我会生气？”
Charlie told you I'd be angry?’

“是！
‘Yes!

他说有一次你跟他说，他要是敢看这小本子，你就把他的蛋蛋割下来！”
In fact, he said you'd once told him you'd saw his balls off if he ever peeked inside this little book!’

我不确定埃米莉一脸的疑惑是因为听了我的话，还是还没从那锅东西中缓过来。
I wasn't sure if Emily's puzzled look was due to what I was saying, or still left over from gazing at the saucepan.

她在我旁边坐下，思索起来。
She sat down next to me and thought for a moment.

“没有，”过了好一会儿，她说道。
‘No,’ she said, eventually.

“是别的事。
‘That was about something else.

我现在想起来了。
I remember it clearly now.

去年大概这个时候，查理为了什么事情很沮丧，问我要是他自杀了，我会怎么办。
About this time last year, Charlie got despondent about something and asked what I'd do if he committed suicide.

他只是在探试我，他那么胆小，根本不可能去做那种事。
He was just testing me, he's far too chicken to try anything like that.

可是他问了，我就回答他说要是他自杀了，我就把他的蛋蛋割下来。
But he asked, so I told him if he did anything like that I'd saw his balls off.

我就只有那次跟他说了这个。
That's the only time I've said that to him.

我意思是，这又不是我的口头禅。”
I mean, it's not like a refrain on my part.’

“我不明白。
‘I don't get this.

要是他自杀了，你要割他的蛋蛋？
If he committed suicide, you'd do that to him?

死了以后？”
Afterwards?’

“这只是一个比方，雷蒙德。
‘It was just a figure of speech, Raymond.

我只是想说要是他自杀了，我会多讨厌他。
I was just trying to express how much I'd dislike him topping himself.

我想让他自信起来。”
I was making him feel valued.’

“你没明白我的意思。
‘You're missing my point.

死了才割不算是阻止他吧？
If you do it afterwards, it's not really a disincentive, is it?

也许你说得对，这样会……”
Or maybe you're right, it would be . . .’

“雷蒙德，别说这些了。
‘Raymond, let's forget it.

我们别说这些了。
Let's forget all of this.

我们昨天吃羊肉砂锅，还剩大半锅。
There's a lamb casserole from yesterday, there's over half of it left.

味道很不错，今天再炖一炖味道会更好。
It was pretty good last night, and it'll be even better tonight.

我们还可以开瓶上好的波尔多。
And we can open a nice bottle of Bordeaux.

我很高兴你动手准备晚餐，但是我们今晚吃砂锅吧，你说呢？”
It was awfully sweet of you to start preparing something for us. But the casserole's probably the thing for tonight, don't you think?’

如今我不想再解释了。
All attempts to explain now seemed beyond me.

“好，好。
‘Okay, okay.

羊肉砂锅。
Lamb casserole.

很好。
Terrific.

行，可以。”
Yes, yes.’

“那……把这些扔了吧？”
‘So ... we can put this away for now?’

“嗯，对。
‘Yes, yes. Please do.

扔了吧。”
Please put it away.’

我站起来，走进客厅——客厅还是一团糟，但我没有力气收拾了。
I got up and went into the living room – which of course was still a mess, but I no longer had the energy to start tidying.

我一屁股躺倒在沙发上，盯着天花板。
Instead, I lay down on the sofa and stared at the ceiling.

过了一会儿，我听见埃米莉也到客厅里来了，我以为她要到走廊去，但她走到客厅的另一头，蹲下来摆弄音响。
At one point, I was aware of Emily coming into the room, and I thought she'd gone through to the hall, but then I realised she was crouched in the far corner, fiddling with the hi-fi.

不一会儿，屋里响起了优美、忧郁的管弦乐声，然后是萨拉·沃恩的《爱人》。
The next thing, the room filled with lush strings, bluesy horns, and Sarah Vaughan singing ‘Lover Man’.

我突然感到无比轻松、宽慰，和着缓缓的拍子，闭上眼睛，想起许多年以前，在埃米莉的宿舍里，我们俩争论说这首歌比利·霍利迪是不是每次都唱得比萨拉·沃恩好，争论了一个多小时。
A sense of relief and comfort washed over me. Nodding to the slow beat, I closed my eyes, remembering how all those years ago, in her college room, she and I had argued for over an hour about whether Billie Holiday always sang this song better than Sarah Vaughan.

埃米莉碰了碰我的肩膀，递给我一杯红酒，自己手里也拿着一杯。
Emily touched my shoulder and handed me a glass of red wine.

她的套装外系着一条镶边围裙。
She had a frilly apron on over her business suit, and was holding a glass for herself.

她在沙发的另一头、我的脚边坐下来，抿了一口酒。
She sat down at the far end of the sofa, next to my feet, and took a sip.

然后用遥控器把音量关小。
Then she turned down the volume a little with her remote.

“乱糟糟的一天，”她说。
‘It's been an awful day,’ she said.

“不单单是工作，今天公司里一团糟。
‘I don't mean just work, which is a total mess.

还包括查理离开什么的。
I mean Charlie going, everything.

别以为我不难过，我们还没和好他就这么出国去。
Don't imagine it doesn't hurt me, to have him go off abroad like that when we haven't made up.

最后，你又这个样子。”
Then to cap it all, you finally go and tip over the edge.’

她长长地叹了口气。
She gave a long sigh.

“不，不是的，埃米莉，没有那么糟。
‘No, really, Emily, it's not as bad as that.

首先，查理很爱你。
For a start, Charlie thinks the world of you.

至于我，我很好。
And as for me, I'm fine.

真的很好。”
I'm really fine.’

“胡说。”
‘Bollocks.’

“是真的。
‘No, really.

我感觉很好……”
I feel fine . . .’

“我是说你说查理很爱我。”
‘I meant about Charlie thinking the world of me.’

“哦，这个。
‘Oh, I see.

你要是觉得我是胡说，那你就大错特错了。
Well, if you think that's bollocks, you couldn't be more wrong.

事实上，我知道查理比以前更爱你。”
In fact, I know Charlie loves you more than ever.’

“你怎么知道，雷蒙德？”
‘How can you know that, Raymond?’

“我怎么知道……首先，中午吃饭时，他就是这个意思。
‘I know because . . . well, for a start he more or less told me so, when we were having lunch.

就算他没有直说，我也看得出来。
And even if he didn't spell it out, I can tell.

你瞧，埃米莉，我知道现在事情是不太如意，但你应该记住最重要的一点，那就是查理仍旧非常爱你。”
Look, Emily, I know things are a bit tough right now. But you've got to hang onto the most important thing. Which is that he still loves you very much.’

她又叹了一口气。
She did another sigh.

“知道吗？我好几年没听这张唱片了。
‘You know, I haven't listened to this record for ages.

都是因为查理。
It's because of Charlie.

我一放这些唱片，他立马反对。”
If I put this sort of music on, he immediately starts groaning.’

我们都不说话，静静听着萨拉·沃恩的歌声。
We didn't speak for a few moments, but just listened to Sarah Vaughan.

歌曲间奏的时候，埃米莉说道：“雷蒙德，我想你更喜欢她的另一个版本。
Then as an instrumental break started, Emily said:‘I suppose, Raymond, you prefer her other version of this.

只有钢琴和贝司伴奏的那个。”
The one she did with just piano and bass.’

我没有回答，只是坐直了些，喝了一小口酒。
I didn't reply, but just propped myself up a little more so as to sip my wine better.

“肯定是，”她说，“你更喜欢那个版本，对不对，雷蒙德？”
‘I bet you do,’ she said. ‘You prefer that other version. Don't you, Raymond?’

“这个嘛，”我说，“我不知道。
‘Well,’ I said, ‘I really don't know.

老实说，我不记得那个版本了。”
To tell you the truth, I don't remember the other version.’

我能感觉到埃米莉在沙发那头动了动。
I could feel Emily shift at the end of the sofa.

“开玩笑，雷蒙德。”
‘You're kidding, Raymond.’

“真好笑，可我最近不大听这些东西了。
‘It's funny, but I don't listen to this kind of stuff much these days.

老实说，我已经忘得差不多了。
In fact, I've forgotten almost everything about it.

我都记不得现在这首是什么歌了。”
I'm not even sure what song this is right now.’

说完，我笑了笑，但可能笑得有点奇怪。
I did a little laugh, which perhaps didn't come out very well.

“你那是什么话？”
‘What are you talking about?’

埃米莉突然生气了。
She sounded suddenly cross.

“太荒唐了。
‘That's ridiculous.

除非你把脑子给切了，不然你是不可能忘记的。”
Short of having had a lobotomy, there's no way you could have forgotten.’

“啊。
‘Well.

过去好多年了。
A lot of years have gone by.

变了。”
Things change.’

“你那是什么话？”
‘What are you talking about?’

这次她的声音里透出丝丝的恐惧。
There was now a hint of panic in her voice.

“不可能变那么多。”
‘Things can't change that much.’

我实在不想再说下去，就转移话题：“工作不顺利真是够呛。”
I was pretty desperate to get off the subject. So I said:‘Pity things are such a mess at your work.’

埃米莉根本不理会。
Emily completely ignored this.

“那你是什么意思？
‘So what are you saying?

你是说你不喜欢这个？
You're saying you don't like this?

你要我把它关掉，是不是？”
You want me to turn it off, is that it?’

“不，不是，埃米莉，别这样，很好听。
‘No, no, Emily, please, it's lovely.

而且……而且勾起我的回忆。
It . . . it brings back memories.

拜托，让我们回到刚才，一分钟以前安安静静、轻轻松松的样子。”
Please, let's just get back to being quiet and relaxed, the way we were a minute ago.’

埃米莉又叹了一口气。当她再次开口时，又变得很温柔了。
She did another sigh, and when she next spoke her voice was gentle again.

“对不起，亲爱的。
‘I'm sorry, darling.

我忘了。
I'd forgotten.

你最不希望我朝你大嚷大叫。
That's the last thing you need, me yelling at you.

我很抱歉。”
I'm so sorry.’

“不，不，没关系。”
‘No, no, it's okay.’

我坐了起来。
I heaved myself up to a sitting position.

“要知道，埃米莉，查理是个好人。
‘You know, Emily, Charlie's a decent guy.

很优秀的人。
A very decent guy.

而且他爱你。
And he loves you.

你不可能找到比他更好的了。”
You won't do better, you know.’

埃米莉耸耸肩，喝了口酒。
Emily shrugged and drank some more wine.

“也许你说得对。
‘You're probably right.

而且我们不年轻了。
And we're hardly young any more.

事情变成这样我们双方都有责任。
We're as bad as one another.

我们应该觉得自己是幸运的。
We should count ourselves lucky.

可是我们似乎从来不满足。
But we never seem to be contented.

我不知道为什么。
I don't know why.

因为每当我静下来细想，我知道除了他我不是真的想要其他人。”
Because when I stop and think about it, I realise I don't really want anyone else.’

埃米莉不说话了，只是喝着酒，听着音乐。过了一会儿她接着说：“雷蒙德，就好像你参加派对、舞会。
For the next minute or so, she kept sipping her wine and listening to the music. Then she said:‘You know, Raymond, when you're at a party, at a dance.

正慢慢地跳着舞，跟你最想在一起的人在一起，房间里的其他人就会消失。可不知为什么，不是这样的。
And it's maybe a slow dance, and you're with the person you really want to be with, and the rest of the room's supposed to vanish. But somehow it doesn't.

不是。
It just doesn't.

你很清楚其他人都比不上你怀里这个。
You know there's no one half as nice as the guy in your arms.

可是……可是，房间里都是人。这些人让你不得安宁。
And yet. . . well, there are all these people everywhere else in the room. They don't leave you alone.

不停叫啊喊啊，招呼你啊，做各种蠢事吸引你的注意。
They keep shouting and waving and doing daft things just to attract your attention.

‘哦，你怎么能这样就满足了呢？！
“Oi! How can you be satisfied with that?!

你可以找到更好的！
You can do much better!

看看我！’
Look over here!”

他们好像一直在朝我喊这样的话，越来越让人受不了，结果你没法安安静静地跟你喜欢的人跳舞。
It's like they're shouting things like that all the time. And so it gets hopeless, you can't just dance quietly with your guy.

你懂我的意思吗，雷蒙德？”
Do you know what I mean, Raymond?’

我想了想，才答道：“我没有你和查理幸运。我没有像你们一样找到一个挚爱。
I thought about it for a while, then said:‘Well, I'm not as lucky as you and Charlie. I don't have anyone special like you do.

但从某些方面来说，我懂你的意思。
But yes, in some ways, I know just what you mean.

人很难知道哪里可以安身，何以安身。”
It's hard to know where to settle. What to settle to.’

“太对了。
‘Bloody right.

我希望这些不请自来的人走开。
I wish they'd just lay off, all these gatecrashers.

我希望他们走开，让我们过我们自己的。”
I wish they'd just lay off and let us get on with it.’

“要知道，埃米莉，我刚刚说的不是在开玩笑。
‘You know, Emily, I wasn't kidding just now.

查理很爱你。
Charlie thinks the world of you.

跟你闹得不愉快他也很伤心。”
He's so upset things haven't been going well between you.’

此时埃米莉几乎是背对着我，而且很久都没有说话。
Her back was more or less turned to me, and she didn't say anything for a long time.

萨拉·沃恩缓缓地唱起优美的超慢版《四月的巴黎》。这时，埃米莉突然站了起来，好像萨拉喊了她的名字。
Then Sarah Vaughan started on her beautiful, perhaps excessively slow version of ‘April in Paris’, and Emily started up like Sarah had called her name.

她转向我，摇摇头。
Then she turned to me and shook her head.

“我不相信，雷。
‘I can't get over it, Ray.

我不相信你不再听这些歌了。
I can't get over how you don't listen to this kind of music any more.

以前我们常常一起听这些唱片。
We used to play all these records back then.

用妈妈在我上大学前给我买的那台小电唱机。
On that little record player Mum bought me before I came to university.

你怎么可以忘记了呢？”
How could you just forget?’

我站起来，拿着酒杯，走到落地窗前。
I got to my feet and walked over to the french doors, still holding my glass.

我往天台上望去，发觉眼睛里充满泪水。
When I looked out to the terrace, I realised my eyes had filled with tears.

于是我打开窗子，走了出去，想趁埃米莉不注意把眼泪擦掉。但是她跟了出来，不知道她是不是看到了。
I opened the door and stepped outside so I could wipe them without Emily noticing, but then she was following right behind me, so maybe she noticed, I don't know.

那晚温暖宜人，萨拉·沃恩的歌声和乐队的伴奏声飘到了天台上。
The evening was pleasantly warm, and Sarah Vaughan and her band came drifting out onto the terrace.

星星比刚才更亮了，邻居家的灯光依旧像夜空里的星星一样眨着眼睛。
The stars were brighter than before, and the lights of the neighbourhood were still twinkling like an extension of the night sky.

“我喜欢这首歌，”埃米莉说。
‘I love this song,’ Emily said.

“我想你连这首也忘了吧。
‘I suppose you've forgotten this one too.

但就算你不记得了，我们还是可以跟着音乐跳支舞，对不对？”
But even if you've forgotten it, you can dance to it, can't you?’

“是。
‘Yes.

我想可以。”
I suppose I can.’

“我们可以像弗雷德·阿斯泰尔和金洁·罗杰斯一样。”
‘We could be like Fred Astaire and Ginger Rogers.’

“是，我们可以。”
‘Yes, we could.’

我们把杯子放在石桌上，开始跳舞。
We placed our wine glasses on the stone table and began to dance.

我们跳得不是很好，老撞到对方的膝盖，但是我把埃米莉紧紧地抱着，全身心地感觉着她的衣服、头发、肌肤。
We didn't dance especially well – we kept bumping our knees – but I held Emily close to me, and my senses filled with the texture of her clothes, her hair, her skin.

这样抱着她再次提醒我她胖了不少。
Holding her like this, it occurred to me again how much weight she'd put on.

“你说得对，雷蒙德，”她在我耳边轻声说道。
‘You're right, Raymond,’ she said, quietly in my ear.

“查理是个好人。
‘Charlie's all right.

我们会好起来的。”
We should sort ourselves out.’

“是。
‘Yes.

当然了。”
You should.’

“有你这个朋友太好了，雷蒙德。
‘You're a good friend, Raymond.

没有你我们怎么办？”
What would we do without you?’

“我很高兴我是个好朋友。
‘If I'm a good friend, I'm glad.

除此之外我一无是处。
Because I'm not much good at anything else.

老实说，我真的很没用。”
In fact, I'm pretty useless, really.’

我感到肩膀被重重地拍了一下。
I felt a sharp tug on my shoulder.

“别说这种话，”埃米莉轻声说道。
‘Don't say that,’ she whispered.

“不许说这种话。”
‘Don't talk like that.’

过了一会儿，她又说了一遍：“有你这个朋友真是太好了，雷蒙德。”
Then a moment later, she said again:‘You're such a good friend, Raymond.’

埃米莉放的是萨拉·沃恩1954年版的《四月的巴黎》，克利福德·布朗演奏的小号，所以我知道这首歌很长，至少有八分钟。
This was Sarah Vaughan's 1954 version of ‘April in Paris’, with Clifford Brown on trumpet. So I knew it was a long track, at least eight minutes.

我很高兴，因为我知道歌曲一结束，我们就不会再跳舞了，而是进去吃砂锅。
I felt pleased about that, because I knew after the song ended, we wouldn't dance any more, but go in and eat the casserole.

而且我知道，到时埃米莉就会重新考虑日记本的事，这次她不会再觉得不是什么大不了的事了。
And for all I knew, Emily would re-consider what I'd done to her diary, and decide this time it wasn't such a trivial offence.

谁知道呢？
What did I know?

可是至少还有几分钟我们是安全的，我们就这么在星空下跳舞。
But for another few minutes at least, we were safe, and we kept dancing under the starlit sky.

# 莫尔文山 | MALVERN HILLS

春天，我在伦敦度过。
I'D SPENT THE SPRING in London, and all in all, even if I hadn't achieved everything I'd set out to, it had been an exciting interlude.

总的来说，虽然我没有完成所有的预定任务，但这段日子还是相当激动人心的。
But with the weeks slipping by and summer getting closer, the old restlessness had started to return.

然而，随着日子一天天过去，夏天临近，以往的烦躁不安又回来了。
For one thing, I was getting vaguely paranoid about running into any more of my former university friends.

比方说，我隐隐地害怕再遇见以前的大学同学。
Wandering around Camden Town, or going through CDs I couldn't afford in West End megastores, I'd already had too many of them come up to me, asking how I was getting on since leaving the course to ‘seek fame and fortune’.

当我在卡姆登区闲逛时，当我搜寻着我在西区大商场买不起的CD时，总能遇见以前的同学，问我自从离开学校出来“追求功名利禄”以后，混得怎么样。
It's not that I was embarrassed to tell them what I'd been up to.

我不是不好意思告诉他们我的现状，而是他们没人——除了极少数的几个例外——能理解对现在的我来说，什么才叫“成功的”数个月。
It was just that – with a very few exceptions – none of them was capable of grasping what was or wasn't, for me at this particular point, a ‘successful’ few months.

我说了，我没有完成所有的预定任务，但这些任务更像是长期的奋斗目标。
As I've said, I hadn't achieved every goal I'd set my sights on, but then those goals had always been more like long-term targets.

所有的这些试音，就算是最无聊的，也是很宝贵的经验。
And all those auditions, even the really dreary ones, had been an invaluable experience.

几乎每一次我都不会空手而归，我都能了解到一些伦敦，甚至全世界乐坛的事情。
In almost every case, I'd taken something away with me, something I'd learned about the scene in London, or else about the music business in general.

有的试音挺正式的。你到一个仓库或改装的车库里去，有经理或者乐队成员的女朋友记下你的名字，端茶给你，叫你等一会儿，这时隔壁传来很大声的、乐队时断时续的演奏。
Some of these auditions had been pretty professional affairs. You'd find yourself in a warehouse, or a converted garage block, and there'd be a manager, or maybe the girlfriend of a band member, taking your name, asking you to wait, offering you tea, while the sounds of the band, stopping and starting, thundered out from the adjoining space.

但是大部分试音则很随便。事实上，看了大多数乐队行为处事的方式之后，你就会明白为什么伦敦乐坛每况愈下。
But the majority of auditions happened at a much more shambolic level. In fact, when you saw the way most bands went about things, it was no mystery why the whole scene in London was dying on its feet.

我一次次穿梭于伦敦郊区不知名的街道间，带着我的原声吉他走上楼梯，走进散发着霉味的公寓。屋子里的地板上垫子和睡袋扔得到处都是。乐队的人嘴里一直嘀咕着，几乎不看你的眼睛。
Time and again, I'd walk past rows of anonymous suburban terraces on the city outskirts, carry my acoustic guitar up a staircase, and enter a stale-smelling flat with mattresses and sleeping bags all over the floor, and band members who mumbled and barely looked you in the eye.

我弹唱的时候他们只是两眼空洞地看着你，直到其中一个人叫我停下来，说：“噢，可以了。谢谢你来试音，但这跟我们的风格不太一样。”
I'd sing and play while they stared emptily at me, till one of them might bring it to an end by saying something like:‘Yeah, well. Thanks anyway, but it's not quite our genre.’

我很快就发现这些人其实很多都很害羞，对试音这事儿很不自在。若我和他们聊些别的，他们就放松多了。
I soon worked out that most of these guys were shy or plain awkward about the audition process, and that if I chatted to them about other things, they'd become a lot more relaxed.

我就是这样收集到各种有用的信息的：哪儿有有意思的夜总会，哪个乐队需要吉他手。
That's when I'd pick up all kinds of useful info: where the interesting clubs were, or the names of other bands in need of a guitarist.

或者只是推荐你听听哪里的乐队。
Or sometimes it was just a tip about a new act to check out.

我说了，我从来不会空手而归。
As I say, I never came away empty-handed.

基本上大家都觉得我吉他弹得不错，很多人还说我的声音很适合和声。
On the whole, people really liked my guitar-playing, and a lot of them said my vocals would come in handy for harmonies.

但我很快就发现有两个因素对我不利。
But it quickly emerged there were two factors going against me.

一是我没有装备。
The first was that I didn't have equipment.

很多乐队都希望找到一个自带电吉他、扩音器、喇叭，最好还有交通工具的人，能够马上开始和他们一起表演。
A lot of bands were wanting someone with electric guitar, amps, speakers, preferably transport, ready to slot right into their gigging schedule.

我只有两条腿和一把破破烂烂的原声吉他。
I was on foot with a fairly crappy acoustic.

所以不管他们多喜欢我的演奏或声音，都不得不叫我走人。
So no matter how much they liked my rhythm work or my voice, they'd no choice but to turn me away.

公平得很。
This was fair enough.

另一主要障碍才让人难以接受——而且我得说，这一点是我完全没有预料到的。
Much harder to accept was the other main obstacle – and I have to say, I was completely surprised by this one.

我自己写歌竟然成了问题。
There was actually a problem about me writing my own songs.

真不敢相信。
I couldn't believe it.

我在某个乱糟糟的公寓里，对着一群面无表情的脸孔演奏，弹完了以后，经过十五、甚至三十秒钟的停顿，会有一个人疑惑地问道：“这是谁的歌？”
There I'd be, in some dingy apartment, playing to a circle of blank faces, then at the end, after a silence that could go on for fifteen, thirty seconds, one of them would ask suspiciously:‘So whose number was that?’

我说是我自己的歌，刷的一声，窗子关上了。
And when I said it was one of my own, you'd see the shutters coming down.

耸肩的耸肩，摇头的摇头，还诡异地互相笑一笑，然后送上他们打发人的那套说辞。
There'd be little shrugs, shakes of the head, sly smiles exchanged, then they'd be giving me their rejection patter.

在这种情况发生到第无数次的时候，我实在生气了。
The umpteenth time this happened, I got so exasperated, I said:‘Look, I don't get this.

我说：“我不明白。
Are you wanting to be a covers band forever?

难道你们想永远做一支翻唱乐队？
And even if that's what you want to be, where do you think those songs come from in the first place?

就算是这样，你们以为那些歌打哪儿来的？
Yeah, that's right.

当然是有人写的！”
Someone writes them!’

可是听我说话的那个人一脸茫然地看着我，说：“没有冒犯之意，伙计。
But the guy I was talking to stared at me vacantly, then said:‘No offence, mate.

只是写歌的浑球儿太多了。”
It's just that there are so many wankers going around writing songs.’

似乎整个伦敦乐坛都是这种傻瓜论调。正是这一点使我相信：在这里，就在最根部，有一种就算不是完全腐烂，但至少也是极其肤浅、极其虚伪的东西在蔓延；这种现象无疑直达最上层，反映了整个音乐界的现状。
The stupidity of this position, which seemed to extend right across the London scene, was key to persuading me there was something if not utterly rotten, then at least extremely shallow and inauthentic about what was going down here, right at the grass-roots level, and that this was undoubtedly a reflection of what was happening in the music industry all the way up the ladder.

这一发现，加上夏天临近，使得我再没有地方可以寄居，我决定：虽然伦敦魅力四射——我的大学生活跟它一比，真是暗淡无光——我还是离开一阵子的好。
It was this realisation, and the fact that as the summer came closer I was running out of floors to sleep on, that made me feel for all the fascination of London – my university days looked grey by comparison – it would be good to take a break from the city.

于是我打电话给家姐玛吉。她和丈夫在莫尔文山经营一家小餐厅。就这样，我决定这个夏天和他们一起住。
So I called up my sister, Maggie, who runs a cafe with her husband up in the Malvern Hills, and that's how it came to be decided I'd spend the summer with them.

玛吉比我大四岁，而且老是为我担心，所以我知道她一定赞成我到她那里去。其实，我还知道她很高兴有人帮她。
Maggie's four years older and is always worrying about me, so I knew she'd be all for my coming up. In fact, I could tell she was glad to be getting the extra help.

我说她在莫尔文山开小餐厅，并不是指在大莫尔文镇或一级公路上，而是确确实实在山上。
When I say her cafe is in the Malvern Hills, I don't mean it's in Great Malvern or down on the A road, but literally up there in the hills.

餐厅是一栋维多利亚时期的老房子，面朝西独自屹立在山上，因此天气晴朗时，可以把茶和蛋糕拿到店外的露台上去，俯瞰整个赫里福郡的景色。
It's an old Victorian house standing by itself facing the west side, so when the weather's nice, you can have your tea and cake out on the cafe terrace with a sweeping view over Herefordshire.

冬天的时候只得关门大吉，但夏天则总是忙得不可开交。客人主要是本地人——他们把车停在山下一百米的“西英格兰”停车场，穿着凉鞋和花花绿绿的衣服，气喘吁吁地沿着小路爬上来——有时也有手拿地图、穿戴整齐、徒步登山的游客。
Maggie and Geoff have to close the place in the winter, but in the summer it's always busy, mainly with the locals – who park their cars in the West of England car park a hundred yards below and come panting up the path in sandals and floral dresses – or else the walking brigade with their maps and serious gear.

玛吉说她和杰夫没钱付我工资，这正合我意，因为这样我就不用做得很辛苦。
Maggie said she and Geoff couldn't afford to pay me, which suited me just fine because it meant I couldn't be expected to work too hard for them.

但是既然我在这里吃、在这里住，大家自然把我当作第三名店员。
All the same, since I was getting bed and board, the understanding seemed to be that I'd be a third member of staff.

一开始的时候事情有点乱，特别是杰夫，有时很想揍我一顿，因为我干得太少，有时又不好意思叫我做事情，好像我是客人。
It was all a bit unclear, and at the start, Geoff, in particular, seemed torn between giving me a kick up the arse for not doing enough, and apologising for asking me to do anything at all, like I was a guest.

但情况很快就步入了正轨。
But things soon settled down to a pattern.

工作很简单——我特别会做三明治——但我得时不时提醒自己不要忘了最初决定来乡下的主要目的，是为了写一批新歌，秋天回伦敦的时候用。
The work was easy enough – I was especially good at making sandwiches – and I sometimes had to keep reminding myself of my main objective in coming out to the country in the first place: that's to say, I was going to write a brand-new batch of songs ready for my return to London in the autumn.

我天生就是个早起的人，但是我很快就发现店里的早餐时间真是噩梦：客人要的蛋要做成这样、面包要烤成那样，东西常常煮过头。
I'm naturally an early riser, but I quickly discovered that breakfast at the cafe was a nightmare, with customers wanting eggs done this way, toast like that, everything getting overcooked.

于是我决定十一点之前不出现。
So I made a point of never appearing until around eleven.

当楼下吵吵嚷嚷的时候，我打开房里的凸窗，坐在宽大的窗台上，面向绵延数英里的山丘弹奏吉他。
While all the clatter was going on downstairs, I'd open the big bay window in my room, sit on the broad window sill and play my guitar looking out over miles and miles of countryside.

我刚来的时候，一连几个早上都是大晴天，感觉好极了，景色一望无际。我随意拨弄琴弦，琴声好像能传遍整个英国。
There was a run of really clear mornings just after I arrived, and it was a glorious feeling, like I could see forever, and when I strummed my chords, they were ringing out across the whole nation.

只有当我把脑袋伸出窗外，才会看见底下餐厅的露台，看见人们牵着狗、推着婴儿车进进出出。
Only when I turned and stuck my head right out of the window would I get an aerial view of the cafe terrace below, and become aware of the people coming and going with their dogs and pushchairs.

我对这个地方并不陌生。
I wasn't a stranger to this area.

玛吉和我就在离这里只有几英里的珀肖尔长大，父母经常带我们到山上来散步。
Maggie and I had grown up only a few miles away in Pershore and our parents had often brought us for walks on the hills.

可是那时候我不喜欢这里，等我长大一点，我就不跟他们一起来了。
But I'd never been much up for it in those days, and as soon as I was old enough, I'd refused to go with them.

但是那年夏天，我感到这里是世界上最美的地方；感到从许多方面说来，我来自并且属于这片山丘。
That summer though, I felt this was the most beautiful place in the world; that in many ways I'd come from and belonged to the hills.

这种感觉也许跟我们的父母已经离异有关，多年来，理发店对面的那间灰色小屋不再是“我们的”家了。
Maybe it was something to do with our parents having split up, the fact that for some time now, that little grey house opposite the hairdresser was no longer ‘our’ house.

不管是什么原因，现在我对这里的感觉不再是童年印象中的幽闭、可怕，而是亲切，甚至是怀念。
Whatever it was, this time round, instead of the claustrophobia I remembered from my childhood, I felt affection, even nostalgia, about the area.

我几乎每天都到山上去走一走，要是确定不会下雨的话，还会把吉他带上。
I found myself wandering in the hills practically every day, sometimes with my guitar if I was sure it wouldn't rain.

我特别喜欢位于山脉北端的桌山和尾山，当天来、当天回的人一般不会到这里来。
I liked in particular Table Hill and End Hill, at the north end of the range, which tend to get neglected by day-trippers.

有时候，我在这里坐上好几个小时，独自思考，一个人影也见不到。
There I'd sometimes be lost in my thoughts for hours at a time without seeing a soul.

感觉就好像我是第一次发现这里，有无数的新旋律在我脑子里冒出来。
It was like I was discovering the hills for the first time, and I could almost taste the ideas for new songs welling up in my mind.

然而在店里帮忙就是另一回事了。
Working at the cafe, though, was another matter.

做三明治的时候，总有一个熟悉的声音或面孔，朝柜台这边过来，把我猛地拉回到过去。
I'd catch a voice, or see a face coming up to the counter while I was preparing a salad, that would jerk me back to an earlier part of my life.

父母的老朋友会过来盘问我的近况，我只好瞎扯一通，直到他们不再烦我。
Old friends of my parents would come up and grill me about what I was up to, and I'd have to bluff until they decided to leave me in peace.

离开之前他们常常会一边看我切面包、切西红柿，一边点点头，说“啊，至少你现在有事可做”之类的话，才拿着杯子、碟子蹒跚地回到座位上去。
Usually they'd sign off with something like:‘Well at least you're keeping busy,’ nodding towards the sliced bread and tomatoes, before waddling back to their table with their cup and saucer.

有时是遇见我的老同学，操着一副新学来的“大学”腔跟我搭话，对最新的蝙蝠侠电影评头论足一番，或者侃侃而谈世界贫困的根本原因。
Or someone I'd known at school would come in and start talking to me in their new ‘university’ voice, maybe dissecting the latest Batman film in clever-clever language, or else starting on about the real causes of world poverty.

我不是真的介意这些事，有些人我很高兴见到他们。
I didn't really mind any of this.

可是那年夏天，当这个人走进店里时，我一看见她浑身就僵掉了。
In fact, some of these people I was genuinely quite glad to see.

等我想到我应该躲到厨房里去时，她已经看见我了。
But there was one person who came into the cafe that summer, the instant I saw her, I felt myself freezing up, and by the time it occurred to me to escape into the kitchen, she'd already seen me.

这个人就是弗雷泽太太——或者按照以前我们的叫法：哈格·弗雷泽。
This was Mrs Fraser – or Hag Fraser, as we used to call her.

当她牵着一只脏兮兮的小斗牛犬进来时我一眼就认出了她。我真想告诉她不可以带狗进来，虽说很多人进来点餐时都会把狗带进来。
I recognised her as soon as she came in with a muddy little bulldog. I felt like telling her she couldn't bring the dog inside, though people always did that when they came to get things.

哈格·弗雷泽是我在珀肖尔读书时的一个老师。
Hag Fraser had been one of my teachers at school in Pershore.

谢天谢地，她在我上中学六年级以前就退休了，可是她的阴影却留在了我整个读书阶段。
Thankfully she retired before I went into the sixth form, but in my memory her shadow falls over my entire school career.

除她之外，学校里的日子并不坏，可是她从一开始就讨厌我、处处为难我，面对她这种人，一个十一岁的小孩子只能逆来顺受。
Her aside, school hadn't been that bad, but she'd had it in for me from the start, and when you're just eleven years old, there's nothing you can do to defend yourself from someone like her.

她所用的伎俩是变态老师常用的那种，比如上课时专挑我不会的问题叫我起来回答，让全班同学笑话我。后来就更高明了。
Her tricks were the usual ones twisted teachers have, like asking me in lessons exactly the questions she sensed I wouldn't be able to answer, then making me stand up and getting the class to laugh at me.

记得有一次，我十四岁那年，一个新来的老师，特拉维斯先生，在课堂上跟我互相开玩笑，不是挖苦我的笑话，而是好像我们是朋友，同学们都笑了，我感觉挺好。
Later, it got more subtle. I remember once, when I was fourteen, a new teacher, a Mr Travis, had exchanged jokes with me in class. Not jokes against me, but like we were equals, and the class had laughed, and I'd felt good about it.

可是两天后，我下楼梯时，碰巧特拉维斯先生和她一起说着话，迎面走来。我走过去时，哈格·弗雷泽把我叫住，说我迟交作业还是什么的，把我臭骂一顿。
But a couple of days later, I was going down the corridor and Mr Travis was coming the other way, talking with her, and as I came by she stopped me and gave me a complete bollocking about late homework or something.

她这么做的目的是让特拉维斯先生知道我是个“捣蛋学生”；要是特拉维斯先生以为我是个值得他尊敬的孩子，就大错特错了。
The point is she'd done this just to let Mr Travis know I was a ‘troublemaker’; that if he'd thought for one moment I was one of the boys worthy of his respect, he was making a big mistake.

或许是因为她年纪大，我说不准，但是其他老师好像从来都不怀疑她，都把她的话当真。
Maybe it was because she was old, I don't know, but the other teachers never seemed to see through her. They all took whatever she said as gospel.

那天哈格·弗雷泽进来时显然认出了我，但她既没有笑一笑也没有叫我的名字。
When Hag Fraser came in that day, it was obvious she remembered me, but she didn't smile or call me by name.

她要了一杯茶和一包奶油夹心饼干以后就到露台去了。
She bought a cup of tea and a packet of Custard Creams, then took them outside to the terrace.

我以为事情就这样了，没想到过了一会儿，她又进来，把空茶杯和空碟子放到柜台上，说：“我想你不会去收拾桌子，就自己拿进来了。”
I thought that was that. But then a while later, she came in again, put her empty cup and saucer down on the counter and said:‘Since you won't clear the table, I've brought these in myself.’

她还是用以前那副“真想揍你”的眼神看我，目光在我身上多停留了两三秒钟才离开。
She gave me a look that went on a second or two longer than was normal – her old if-only-I-could-swat-you look – then left.

我对这个老妖婆的仇恨一下子又回来了。几分钟后玛吉下来时，我已经是怒不可遏。
All my old hatred for the old dragon came back, and by the time Maggie came down a few minutes later, I was completely fuming.

她一眼就看出来，问我怎么了。
She saw it straight away and asked what was wrong.

那时只有几个客人在露台上，屋里没人，我就大喊大叫起来，把哈格·弗雷泽骂得狗血淋头。
There were a few customers out on the terrace, but no one inside, so I started shouting, calling Hag Fraser every filthy name she deserved.

玛吉要我冷静下来，然后说：
Maggie got me to calm down, then said:

“她不再是谁的老师了，只是一个丈夫离她而去的可怜的老妇人。”
‘Well, she's not anybody's teacher any more. She's just a sad old lady whose husband's gone and left her.’

“活该。”
‘Not surprised.’

“可你应该稍微同情她一下。
‘But you have to feel a bit sorry for her.

正当她准备享受退休生活时，她的丈夫却为了一个比她年轻的女人而抛弃了她。
Just when she thought she could enjoy her retirement, she's left for a younger woman.

如今她只得自己一个人经营旅馆，人们都说那个地方一天不如一天了。”
And now she has to run that bed-andbreakfast by herself and people say the place is falling apart.’

玛吉的话让我高兴了不少。
This all cheered me up no end.

我很快就把哈格·弗雷泽抛到了脑后，因为来了一群人，要很多金枪鱼沙拉。
I forgot about Hag Fraser soon after that, because a group came in and I had to make a lot of tuna salads.

几天以后，我在厨房里和杰夫闲聊时，知道了更多的细节：比如说她结婚四十多年的丈夫怎么跟他的秘书跑了；又比如他们的旅馆最初经营得还可以，可是后来谣传客人们都要求退钱，或者刚住进去没几个小时就退房。
But a few days later when I was chatting to Geoff in the kitchen, I got a few more details from him; like how her husband of forty-odd years had gone off with his secretary; and how their hotel had got off to a reasonable start, but now all the gossip was of guests demanding their money back, or checking out within hours of arrival.

我亲眼见过那地方一次，一天我帮玛吉去采购东西时开车路过。
I saw the place myself once when I was helping Maggie with the cash-and-carry and we drove past.

哈格·弗雷泽的旅馆就在埃尔加路上，是一栋挺大的花岗岩房子，特大的牌子上写着“莫尔文旅馆”。
Hag Fraser's hotel was right there on the Elgar Route, a fairly substantial granite house with an outsize sign saying ‘Malvern Lodge’.

可是我并不想多说哈格·弗雷泽的事。
But I don't want to go on about Hag Fraser too much.

我对她或她的旅馆不感兴趣。
I'm not obsessed with her or with her hotel.

我在这里说到她是为以后的事——蒂洛和索尼娅的出现——做交待。
I'm only putting this all here now because of what happened later, once Tilo and Sonja came in.

那天杰夫到大莫尔文镇上去了，只有我和玛吉坚守岗位。
Geoff had gone into Great Malvern that day, so it was just me and Maggie holding the fort.

午饭的客流高峰已经差不多过去了，但是“德国佬”进来时，我们还挺忙的。
The main lunch rush was over, but at the point when the Krauts came in, we still had plenty going on.

一听到他们的口音我脑子里马上就想到“德国佬”。
I'd clocked them in my mind as ‘the Krauts’ the moment I heard their accents.

不是种族歧视，而是当你站在柜台后面，要记住谁不要甜菜、谁多要一份面包、谁又多点了什么时，就不得不把客人都区别开来，给他们取外号、记住他们的外貌特征。那个驴子脸要一份面包、腌菜配奶酪和两杯咖啡。
I wasn't being racist. If you have to stand behind a counter and remember who didn't want beetroot, who wanted extra bread, who gets what put on which bill, you've no choice but to turn all the customers into characters, give them names, pick out physical peculiarities.

温斯顿·丘吉尔和他老婆要金枪鱼配蛋黄酱的法式长棍三明治。我就是这么记的。
Donkey Face had a ploughman's and two coffees. Tuna mayo baguettes for Winston Churchill and his wife.

因此，蒂洛和索尼娅就成了“德国佬”。
That's how I was doing it. So Tilo and Sonja were ‘the Krauts’.

那天下午很热，可是大多数客人——都是英国人——还是想坐在外面的露台上，有些还不用遮阳伞，想把皮肤晒得通红。
It was very hot that afternoon, but most of the customers – being English – still wanted to sit outside on the terrace, some of them even avoiding the parasols so they could go bright red in the sun.

那两个“德国佬”却决定坐在里面乘凉。
But the Krauts decided to sit indoors in the shade.

他们穿着普通的宽松驼色裤子、运动鞋和T恤衫，但看上去挺聪明，欧洲大陆来的人常给人这种感觉。
They had on loose, camelcoloured trousers, trainers and T-shirts, but somehow looked smart, the way people from the continent often do.

我猜他们四十多岁，或者五十出头——那时我没太在意。
I supposed they were in their forties, maybe early fifties – I didn't pay too much attention at that stage.

他们一边吃饭一边轻声交谈，跟大多数欧洲来的和蔼的中年夫妇没什么两样。
They ate their lunch talking quietly to each other, and they seemed like any pleasant, middle-aged couple from Europe.

过了一会儿，那个男的站起来，在店里头溜达，走到玛吉挂在墙上的一张褪色老照片前时停下来欣赏，那是这所房子1915年时的照片。
Then after a while, the guy got up and started wandering about the room, pausing to study an old faded photo Maggie has on the wall, of the house as it was in 1915.

然后他伸展了一下胳膊，说道：
Then he stretched out his arms and said:

“你们这儿的景色真漂亮！
‘Your countryside here is so wonderful!

瑞士也有很多漂亮的山，可你们这儿的不一样。
We have many fine mountains in Switzerland. But what you have here is different.

瑞士是高山，你们这儿是小山，但平缓、亲切，有自己独特的魅力。”
They are hills. You call them hills. They have a charm all their own because they are gentle and friendly.’

“哦，您是从瑞士来的，”玛吉礼貌地说。
‘Oh, you're from Switzerland,’ Maggie said in her polite voice.

“我一直想去瑞士。
‘I've always wanted to go there.

阿尔卑斯啊、缆车啊，听上去很棒。”
It sounds so fantastic, the Alps, the cable-cars.’

“是啊，我们国家有很多美景。
‘Of course, our country has many beautiful features.

但是这里，这个地方，有一种特殊的魅力。
But here, in this spot, you have a special charm.

我们很早以前就想到这里来了。
We have wanted to visit this part of England for so long.

说了那么久，现在终于来了！”
We always talked of it, and now finally we are here!’

说着他开怀大笑。
He gave a hearty laugh.

“真高兴啊！”
‘So happy to be here!’

“太好了，”玛吉说道。
‘That's splendid,’ Maggie said.

“祝愿你们玩得开心。
‘I do hope you enjoy it.

你们会在这里待很久吗？”
Are you here for long?’

“我们还可以再待三天，然后就得回去工作。
‘We have another three days before we must return to our work.

很多年前我们看了一部关于埃尔加的纪录片，从那以后就一直想来这里。
We have looked forward to coming here ever since we observed a wonderful documentary film many years ago, concerning Elgar.

显然埃尔加热爱这些山，骑着自行车把这些山都走遍了。
Evidently Elgar loved these hills and explored them thoroughly on his bicycle.

如今我们终于来了！”
And now we are finally here!’

接下来的几分钟，玛吉和他聊起了他们到过的英国景点，在这里哪些地方值得一看，就是你常跟游客聊的那一套。
Maggie chatted with him for a few minutes about places they'd already visited in England, what they should see in the local area, the usual stuff you were supposed to say to tourists.

这些话我听了无数遍了，自己也能不假思索地说一遍，所以渐渐把注意力移开。
I'd heard it loads of times before, and I could do it myself more or less on automatic, so I started to tune out.

我只听见这两个德国佬其实是瑞士人，正在租车旅游。
I just took in that the Krauts were actually Swiss and that they were travelling around by hired car.

那男的反复赞美英国是个很棒的地方，英国人都很友好，有时玛吉插几句玩笑话，他都会哈哈大笑。
He kept saying what a great place England was and how kind everyone had been, and made big laughing noises whenever Maggie said anything halfway jokey.

可是我说了，我把注意力移开了，觉得他们只是一对挺无趣的普通夫妇。
But as I say, I'd tuned out, thinking they were just this fairly boring couple.

过了一会儿我又开始注意他们，因为我发现那男的一直想把他妻子带到谈话里来，可他妻子就是不说话，眼睛直盯着旅游指南，好像根本不知道有人在跟她说话。
I only started paying attention again a few moments later, when I noticed the way the guy kept trying to bring his wife into the conversation, and how she kept silent, her eyes fixed on her guidebook and behaving like she wasn't aware of any conversation at all.

这让我留意他们。
That's when I took a closer look at them.

他们两个的皮肤都被晒黑了，肤色自然、均匀，不像外面那群满头大汗、皮肤红得活像龙虾的当地人。
They both had even, natural suntans, quite unlike the sweaty lobster looks of the locals outside, and despite their age, they were both slim and fit-looking.

尽管上了年纪，两人身材还都很好，身体健康的样子。男的头发灰白，但是浓密，梳得很整齐，虽说有点阿巴乐队的感觉。
His hair was grey, but luxuriant, and he'd had it carefully groomed, though in a vaguely seventies style, a bit like the guys in Abba.

女的是金黄头发，差不多褪成白色的了，表情严肃，嘴角有几道小皱纹，要不然这会是一张美丽的中年女人的脸。而那个男的就像我刚说的那样，一直想把他妻子带到谈话里来。
Her hair was blonde, almost snowy white, and her face was stern-looking, with little lines etched around the mouth that spoilt what would otherwise have been the beautiful older woman look. So there he was, as I say, trying to bring her into the conversation.

“当然了，我妻子很喜欢埃尔加，很想去看看他出生的房子。”
‘Of course, my wife enjoys Elgar greatly and so would be most curious to visit the house in which he was born.’

沉默。
Silence.

或者：“我得承认我不太喜欢巴黎。
Or:‘I am not a great fan of Paris, I must confess.

我更喜欢伦敦。
I much prefer London.

可是索尼娅她喜欢巴黎。”
But Sonja here, she loves Paris.’

没有回答。
Nothing.

每次他说这些话时，都要转头看看坐在角落的妻子，玛吉只好也朝她那里看一看。可他妻子只顾看书，头也不抬一下。
Each time he said something like this, he'd turn towards his wife in the corner, and Maggie would be obliged to look over to her, but the wife still wouldn't glance up from her book.

那男的似乎不觉得有什么不对，仍旧兴高采烈地说个不停。
The man didn't seem especially perturbed by this and went on talking cheerfully.

然后他又一次伸展了一下胳膊，说：“请原谅，我想我要出去欣赏一下你们这里的美丽景色！”
Then he stretched out his arms again and said:‘If you will excuse me, I think I may for a moment go and admire your splendid scenery!’

他走了出去。
He went outside, and we could see him walking around the terrace.

起先我们看见他在露台上溜达，后来就不见了。
Then he disappeared out of our view.

他妻子仍旧坐在角落里读旅游指南。
The wife was still there in the corner, reading her guidebook, and after a while Maggie went over to her table and began clearing up.

一会儿，玛吉过去擦桌子。
The woman ignored her completely until my sister picked up a plate with a tiny bit of roll still left on it.

那女的完全没有理睬玛吉，直到我姐姐要把还剩一小块面包卷的盘子收拾走时，她突然啪地放下书，挺大声地说：“我还没吃完呢！”
Then suddenly she slammed down her book and said, far more loudly than necessary:‘I have not finished yet!’

玛吉向她道歉，放下盘子，走开了——而我看她根本没有去动那盘子。
Maggie apologised and left her with her piece of roll – which I noticed the woman made no move to touch.

玛吉从我身边走过去时看了我一眼，我耸耸肩。
Maggie looked at me as she came past and I gave her a shrug.

过了一会儿，我姐姐很客气地问那女的还要不要别的。
Then a few moments later, my sister asked the woman, very nicely, if there was anything else she'd like.

“不，不要了。”
‘No. I want nothing else.’

我能听出来那女的不想别人去吵她，可是对于玛吉来说，她条件反射地问道（好像她真的想知道）：“食物什么的都还好吗？”
I could tell from her tone she should be left alone, but with Maggie it was a kind of reflex. She asked, like she really wanted to know:‘Was everything all right?’

那女的只是看书，好像没有听见。
For at least five or six seconds, the woman went on reading, like she hadn't heard.

过了五六秒钟，她才放下书，看着我姐姐，说：
Then she put down her book again and glared at my sister.

“既然你问了，我就告诉你。
‘Since you ask,’ she said, ‘I shall tell you.

食物很好，比附近其他鬼地方的好多了。
The food was perfectly okay. Better than in many of the awful places you have around here.

可是，我们只不过要了三明治和沙拉，却等了三十五分钟。
However, we waited thirty-five minutes simply to be served a sandwich and a salad.

三十五分钟。”
Thirty-five minutes.’

突然间我意识到这个女人满腔怒火。
I now realised this woman was livid with anger.

不是突然间来了气，等下就会没了。
Not the sort that suddenly hits you, then drains away.

不是，我看得出这个女人已经憋了一肚子火了。
No, this woman, I could tell, had been in a kind of white heat for some time.

她是那种一旦生气就不会轻易消气的人，怒气会维持在一个固定的水平，类似严重的头痛，不会达到顶点，但也不想发泄出来。
It's the sort of anger that arrives and stays put, at a constant level, like a bad headache, never quite peaking and refusing to find a proper outlet.

玛吉一向脾气好，不会察觉到这些征兆，大概以为对方只是在合情合理地抱怨。
Maggie's always so even-tempered she couldn't recognise the symptoms, and probably thought the woman was complaining in a more or less rational way.

玛吉向她道歉，然后说：“可是您看，刚才客人太多了……”
Because she apologised and started to say:‘But you see, when there's a big rush like we had earlier . . .’

“肯定每天都这样咯？
‘Surely you get it every day, no?

不是吗？
Is that not so?

不是这样？
Every day, in the summer, when the weather is fine, there is just such a big rush?

到了夏天，天气好的时候，才会有这么多客人？
Well?

是吗？
So why can't you be ready?

那你们为什么不能提前准备好呢？
Something that happens every day and it surprises you.

每天都有这么多客人超出你们的预料了，你是想这么说吗？”
Is that what you are telling me?’

那女人本来看着我姐姐，我从柜台后面走出来站在玛吉旁边，她就把目光转移到我身上。
The woman had been glaring at my sister, but as I came out from behind the counter to stand beside Maggie, she transferred her gaze to me.

可能是因为我脸上的表情，我感觉她的怒气又增加了两度。
And maybe it was to do with the expression I had on my face, I could see her anger go up a couple more notches.

玛吉转头看我，轻轻把我推开，可我没动，一直看着那个女人。
Maggie turned and looked at me, and began gently to push me away, but I resisted, and kept gazing at the woman.

我要她明白这不单单是她和玛吉之间的事。
I wanted her to know it wasn't just her and Maggie in this.

谁知道事情可能变成什么样，可就在这时，她丈夫回来了。
God knows where this would have got us, but at that moment the husband came back in.

“这儿的风景太棒了！
‘Such a marvellous view!

很棒的风景，很棒的午餐，很棒的国家！”
A marvellous view, a marvellous lunch, a marvellous country!’

我等着他明白这会儿的情况，可就算他注意到了，也没太在意的样子。
I waited for him to sense what he'd walked into, but if he noticed, he showed no sign of taking it into account.

他微笑着对他妻子说（或许是因为我们的缘故他说英语）：“索尼娅，你真该去看看。
He smiled at his wife and said, presumably for our benefit in English:‘Sonja, you really must go and have a look.

就沿着那边那条小路一直走到头！”
Just walk to the end of the little path out there!’

他妻子则用德语回答他，然后又埋头看书。
She said something in German, then went back to her book.

他往里走了些，对我们说：
He came further into the room and said to us:

“本来我们今天下午要继续开车到威尔士去的。
‘We had considered driving on to Wales this afternoon.

可是你们这儿的莫尔文山太漂亮了，我真想剩下这三天就都待在这里得了。
But your Malvern Hills are so wonderful, I really think we might stay here in this district for the remaining three days of our vacation.

要是索尼娅同意，那就太好了！”
If Sonja agrees, I will be overjoyed!’

他看看他妻子，对方耸耸肩，又说了几句德语。说完，男的开怀大笑。
He looked at his wife, who shrugged and said something else in German, to which he laughed his loud, open laugh.

“太好了！
‘Good!

她同意！
She agrees!

那就这么定了。
So it is settled.

不去威尔士了。
We will no longer drive to Wales.

接下来这三天我们就都待在你们这里！”
We will hang out here in your district for the next three days!’

说完朝我们笑了笑，玛吉应了几句客套话。
He beamed at us, and Maggie said something encouraging.

看见他妻子把书收起来准备离开，我松了口气。
I was relieved to see the wife putting her book away and getting ready to leave.

那男的也走回餐桌，提起一个小背包，搭在肩上。
The man, too, went to the table, picked up a small rucksack and put it on his shoulder.

这时他问玛吉：
Then he said to Maggie:

“我在想不知你能不能介绍一家附近的小旅馆给我们？
‘I wonder. Is there by any chance a small hotel you can recommend for us nearby?

不用太贵的，但要舒适、整洁。
Nothing too expensive, but comfortable and pleasant.

带点英国味儿的就更好了！”
And if possible, with something of the English flavour!’

玛吉一时不知怎么回答，净问些没有用的问题，比如：“你们想要什么样的旅馆？”
Maggie was a bit stumped by this and delayed her answer by saying something meaningless like:‘What sort of place did you want?’

而我马上说道：
But I said quickly:

“这附近最好的旅馆是弗雷泽太太的。
‘The best place around here is Mrs Fraser's.

就在去伍斯特郡的路上。
It's just down along the road to Worcester.

叫莫尔文旅馆。”
It's called Malvern Lodge.’

“莫尔文旅馆！
‘The Malvern Lodge!

好像正是我们需要的！”
That sounds just the ticket!’

玛吉不以为然地转过头去假装继续擦桌子，我则把旅馆的位置详细地告诉他们。
Maggie turned away disapprovingly and pretended to be clearing away more things while I gave them all the details on how to find Hag Fraser's hotel.

然后这对夫妇就离开了，那男的满面笑容感谢我们，那女的没有回头看一眼。
Then the couple left, the guy thanking us with big smiles, the woman not giving a backward glance.

我姐姐疲惫地看了我一眼，摇摇头。
My sister gave me a weary look and shook her head.

我却笑了笑，说：
I just laughed and said:

“你得承认，那女的和哈格·弗雷泽真是天生一对。
‘You've got to admit, that woman and Hag Fraser really deserve one another.

机不可失。”
It was just too good an opportunity to miss.’

“你倒好，给自己找乐子，”玛吉推开我，走到厨房里去。
‘It's all very well for you to amuse yourself like that,’ Maggie said, pushing past me to the kitchen.

“我可得住在这里。”
‘I have to live here.’

“那又怎么样？
‘So what?

听着，你再也不会见到那两个德国佬了。
Look, you'll never see those Krauts again.

而要是哈格·弗雷泽知道我们把她的旅馆介绍给过路的游客，她还有什么好抱怨的？”
And if Hag Fraser finds out we've been recommending her place to passing tourists, she's hardly going to complain, is she?’

玛吉摇摇头，可是这次不再板着一张脸了。
Maggie shook her head, but there was more of a smile about it this time.

德国夫妇走了以后店里安静了许多，后来杰夫回来了，我觉得自己已经做了超出我应做的份儿，就上楼去了。
The cafe got quieter after that, then Geoff came back, so I went off upstairs, feeling I'd done more than my share for the time being.

我回到房间，拿出吉他坐在窗台上，开始全神贯注地继续想一首写到一半的歌。
Up in my room, I sat at the bay window with my guitar and for a while got engrossed in a song I was halfway through writing.

可后来——好像才没过多久——我就听见楼下来喝下午茶的客人渐渐多起来了。
But then – and it seemed like no time – I could hear the afternoon tea rush starting downstairs.

若又像平时一样客人太多，玛吉肯定会叫我下去的。
If it got really mad, like it usually did, Maggie was bound to ask me to come down – which really wouldn't be fair, given how much I'd done already.

我决定我最好偷偷溜出去，到山上继续写歌。
So I decided the best thing would be for me to slip out to the hills and continue my work there.

我从后门出去，没有遇到一个人，一出来就感到到外面来太好了。
I left the back way without encountering anyone, and immediately felt glad to be out in the open.

天还很热，特别是我背着吉他箱，但是微风习习、沁人心脾。
It was pretty warm though, especially carrying a guitar case, and I was glad of the breeze.

我朝上周发现的一处地方走去。
I was heading for a particular spot I'd discovered the previous week.

这个地方在餐厅后面，要先爬一段陡峭的小路，再走一段较平缓的斜坡，走几分钟，就来到了这条长椅跟前。
To get there you climbed a steep path behind the house, then walked a few minutes along a more gradual incline till you came to this bench.

我精心挑选了这个地方，不单单因为这里风景好，还因为这里不在山路的交界处，没有大人带着筋疲力尽的小孩气喘吁吁地走过来坐在你旁边。
It's one I'd chosen carefully, not just because of the fantastic view, but because it wasn't at one of those junctions in the paths where people with exhausted children come staggering up and sit next to you.

但另一方面，这里也不是完全看不见人，偶尔会有散步的人经过，随意地跟你打声招呼，有时还会拿我的吉他开个玩笑，但都不会停下脚步。
On the other hand it wasn't completely isolated, and every now and then, a walker would pass by, saying ‘Hi!’ in the way they do, maybe adding some quip about my guitar, all without breaking stride.

对此我并不介意。
I didn't mind this at all.

这样好像有听众，又好像没有，给了我所需的想象空间。
It was kind of like having an audience and not having one, and it gave my imagination just that little edge it needed.

我在长椅上待了大约半个小时，突然感觉到刚刚有人像平常一样打了声招呼走过去，但现在站在几码远的地方不动了，看着我。
I'd been there on my bench for maybe half an hour when I became aware that some walkers, who'd just gone past with the usual short greeting, had now stopped several yards away and were watching me.

我恼了，略带讥讽地说：
This did rather annoy me, and I said, a little sarcastically:

“好了，你们不用给我钱。”
‘It's okay. You don't have to toss me any money.’

只听一阵熟悉的开怀大笑，我抬起头来，看见那对德国夫妇朝长椅这折回来。
This was answered by a big hearty laugh which I recognised, and I looked up to see the Krauts coming back towards the bench.

我马上想到可能他们去了哈格·弗雷泽的旅馆，发现我骗了他们，现在回来找我算账。
The possibility flashed through my mind that they'd gone to Hag Fraser's, realised I'd pulled a fast one on them, and were now coming to get even with me.

可我又看见不仅是那个男的，连那女的也笑嘻嘻的。
But then I saw that not only the guy, but the woman too, was smiling cheerfully.

他们走回到我面前，那时太阳快落山了，所以有一会儿我只能看见他们的轮廓，身后是一轮巨大的落日。
They retraced their steps till they were standing in front of me, and since by this time the sun was falling, they appeared for a moment as two silhouettes, the big afternoon sky behind them.

他们又走近了些，我看见两个人都惊喜地看着我的吉他——我还在弹着——像在看着一个婴孩。
Then they came closer and I could see they were both gazing at my guitar – which I'd continued to play – with a look of happy amazement, the way people gaze at a baby.

更令人吃惊的是，那女的跟着我的节拍点着脚。
Even more astonishing, the woman was tapping her foot to my beat.

我突然觉得不好意思，便把手停下。
I got self-conscious and stopped.

“嘿，接着弹！”
‘Hey, carry on!’ the woman said.

那女的说。“你弹得真好听。”
‘It's really good what you play there.’

“是啊，”男的说，“太好听了！
‘Yes,’ the husband said, ‘wonderful!

我们远远地听到了。”
We heard it from a distance.’

他指了指。
He pointed.

“刚才我们在那里，在那个山脊上。我对索尼娅说我听见弹琴的声音。”
‘We were right up there, on that ridge, and I said to Sonja, I can hear music.’

“还有唱歌的声音，”女的说。
‘Singing too,’ the woman said.

“我对蒂洛说，听，有人在唱歌。
‘I said to Tilo, listen, there is singing somewhere.

我说对了，不是？
And I was right, yes?

刚刚你还唱了一小段。”
You were singing also a moment ago.’

我一时无法接受面前这个面带微笑的女人就是中午刁难我们的那一个。我把他俩又仔细地打量了一番，生怕认错了人。
I couldn't quite accept that this smiling woman was the same one who'd given us such a hard time at lunch, and I looked at them again carefully, in case this was a different couple altogether.

可是错不了，他们还穿着刚才那身衣服，虽然那男的阿巴头型被风吹得有点乱。
But they were in the same clothes, and though the man's Abba-style hair had come undone a bit in the wind, there was no mistaking it.

不管怎样，只听那男的说道：
In any case, the next moment, he said:

“我想你是中午给我们做了好吃的那家餐厅里的那位先生？”
‘I believe you are the gentleman who served us lunch in the delightful restaurant.’

我说是。
I agreed I was.

那女的又说：
Then the woman said:

“你刚刚唱的那首曲子。
‘That melody you were singing a moment ago.

我们隐隐约约远远地听到了。
We heard it up there, just in the wind at first.

我特别喜欢每一小节结束时的调子。”
I loved the way it fell at the end of each line.’

“谢谢，”我说。
‘Thanks,’ I said.

“这是我的新歌，还没写完。”
‘It's something I'm working on. Not finished yet.’

“你自己写的歌？
‘Your own composition?

真是个天才！
Then you must be very gifted!

请把你的歌再唱一遍，像刚刚那个样子。”
Please do sing your melody again, as you were before.’

“知道吗？”男的说，“你录这首歌的时候，一定要告诉制作人你要这首歌听起来是这种感觉。
‘You know,’ the guy said, ‘when you come to record your song, you must tell the producer this is how you want it to sound.

像这样！”
Like this!’

他转身指了指我们面前一望无际的赫里福郡。
He gestured behind him at Herefordshire stretched out before us.

“你一定要告诉他你要像这样的音响环境。
‘You must tell him this is the sound, the aural environment you require.

你要听众像我们今天这个样子听到这首歌，下山的时候，在风中隐约听见……”
Then the listener will hear your song as we heard it today, caught in the wind as we descend the slope of the hill . . .’

“不过当然要清楚些才行，”女的说。
‘But a little more clearly, of course,’ the woman said.

“不然听众就听不清歌词了。
‘Or else the listener will not catch the words.

但蒂洛说得对。
But Tilo is correct.

一定要让人联想到户外、空气、回声。”
There must be a suggestion of outdoors. Of air, of echo.’

两个人越说越激动，仿佛在山上遇到了又一个埃尔加似的。
They seemed on the verge of getting carried away, like they'd just come across another Elgar in the hills.

虽然我刚刚怀疑他们是来找我麻烦的，但现在禁不住热情以待。
Despite my initial suspicions, I couldn't help but warm to them.

“这个嘛，”我说，“既然我这首歌大部分时间是在这里写的，歌里有些这里的感觉也不奇怪。”
‘Well,’ I said, ‘since I wrote most of the song up here, it's no wonder there's something of this place in it.’

“没错，”两人一齐点点头说道。
‘Yes, yes,’ they both said together, nodding.

那女的又说：“别不好意思。
Then the woman said:‘You must not be shy.

把你的歌拿出来跟我们分享。
Please share your music with us.

很好听。”
It sounded wonderful.’

“好吧，”我随意拨弄着琴弦，说。
‘All right,’ I said, playing a little doodle.

“好吧，你们真想听的话，我就给你们唱一首。
‘All right, I'll sing you a song, if you really want me to.

不唱这首还没写完的。
Not the one I haven't finished.

唱另外一首。
Another one.

但是，你们这样子站在我面前我没法唱。”
But look, I can't do it with you two standing right over me like this.’

“当然了，”蒂洛说。
‘Of course,’ Tilo said.

“是我们失礼了。
‘We are being so inconsiderate.

我和索尼娅经常要在很多奇奇怪怪的场合表演，都忘了要替别的乐手着想了。”
Sonja and I have had to perform in so many strange and difficult conditions, we become insensitive to the needs of another musician.’

他在小路旁找了块矮草地坐下，背对着我，面朝风景。
He looked around and sat down on a patch of stubbly grass near the path, his back to me and facing the view.

索尼娅给了我一个鼓励的微笑，在他身旁坐下。
Sonja gave me an encouraging smile, then sat down beside him.

她一坐下，蒂洛就把手搭在她的肩膀上，两人偎依在一起，好像当我不存在了，只是一对情意绵绵的夫妇在一起欣赏乡村的黄昏。
Immediately, he put an arm around her shoulders, she leaned towards him, then it was almost like I wasn't there any more, and they were having an intimate lovey-dovey moment gazing over the late-afternoon countryside.

“那好，我唱了，”说完，我弹起了试音时经常唱的那首歌。
‘Okay, here goes,’ I said, and went into the song I usually open with at auditions.

我对着远处的地平线唱歌，但眼睛不停地去瞅他们两个。
I aimed my voice at the horizon but kept glancing at Tilo and Sonja.

虽然我看不见他们的脸，但看到他们一直紧紧地靠在一起，没有丝毫不自在，我知道他们很享受我的音乐。
Though I couldn't see their faces, the whole way they remained snuggled up to each other with no hint of restlessness told me they were enjoying what they were hearing.

唱完以后，他们转过来，笑容灿烂，还鼓起了掌，掌声在群山间回荡。
When I finished, they turned to me with big smiles and applauded, sending echoes around the hills.

“太好听了！”
‘Fantastic!’

索尼娅说。
Sonja said.

“真是天才！”
‘So talented!’

“太棒了，太棒了，”蒂洛说。
‘Splendid, splendid,’ Tilo was saying.

我有点不好意思，假装忙着摆弄吉他。
I felt a little embarrassed by this and pretended to be absorbed in some guitar work.

当我再次抬起头来时，他们还坐在那里，但把身子转了过来，好跟我说话。
When I eventually looked up again, they were still sitting on the ground, but had now shifted their positions so they could see me.

“那么说你们是乐手咯？”
‘So you're musicians?’

我问。
I asked.

“我是指职业乐手？”
‘I mean, professional musicians?’

“对，”蒂洛说，“我想你可以说我们是职业的。
‘Yes,’ said Tilo, ‘I suppose you could call us professionals.

索尼娅和我表演二重奏。
Sonja and I, we perform as a duo.

在旅馆啦、酒店啦、婚礼上啦、宴会上表演。
In hotels, restaurants. At weddings, at parties.

满欧洲跑，但还是最喜欢在瑞士和奥地利演出。
All over Europe, though we like best to work in Switzerland and Austria.

我们以此为生，所以，对，可以说我们是职业的。”
We make our living this way, so yes, we are professionals.’

“但是首先在于，”索尼娅说，“我们干这行是因为我们相信音乐。
‘But first and foremost,’ Sonja said, ‘we play because we believe in the music.

我看得出你也一样。”
I can see it is the same for you.’

我答道：“若有一天我不再相信音乐，我就撒手不干了，就这样。”
‘If I stopped believing in my music,’ I said, ‘I'd stop, just like that.’

说完我补充道：“我也想成为职业乐手。
Then I added:‘I'd really like to do it professionally.

那种生活一定很棒。”
It must be a good life.’

“是啊，是很棒，”蒂洛说。
‘Oh yes, it's a good life,’ said Tilo.

“我们很庆幸自己能干这一行。”
‘We're very lucky we are able to do what we do.’

“对了，”我有点唐突地说道，“你们去了我说的那家旅馆了吗？”
‘Look,’ I said, maybe a little suddenly. ‘Did you go to that hotel I told you about?’

“我们真是太失礼了！”
‘How very rude of us!’

蒂洛惊呼道。
Tilo exclaimed.

“我们被你的音乐吸引住了，压根儿忘了要谢谢你。
‘We were so taken by your music, we forgot completely to thank you.

是，我们去了，正是我们想要的旅馆。
Yes, we went there and it is just the ticket.

幸好还有空房间。”
Fortunately there were still vacancies.’

“那旅馆正合我们的意，”索尼娅说。
‘It's just what we wanted,’ said Sonja.

“谢谢你。”
‘Thank you.’

我又假装忙着摆弄琴弦。
I pretended again to become absorbed in my chords.

然后尽量装出很随意的样子，说道：“我突然想到我还知道一家旅馆，比莫尔文旅馆好些。
Then I said as casually as I could:‘Come to think of it, there's this other hotel I know. I think it's better than Malvern Lodge.

我想你们不妨换一下。”
I think you should change.’

“哦，可是我们已经安顿下来了，”蒂洛说。
‘Oh, but we're quite settled now,’ said Tilo.

“我们已经把行李都拿出来了，而且，那旅馆正是我们想要的旅馆。”
‘We have unpacked our things, and besides, it's just what we need.’

“是啊，但是……但是，之前，你们问我有没有旅馆的时候，我不知道你们是乐手。
‘Yeah, but . . . Well, the thing is, earlier on, when you asked me about a hotel, I didn't know you were musicians.

我还以为你们是银行职员什么的。”
I thought you were bankers or something.’

两个人都大笑起来，好像我说了一个很好笑的笑话。
They both burst out laughing, like I'd made a fantastic joke.

接着，蒂洛说道：
Then Tilo said:

“不，不，我们不是银行职员。
‘No, no, we're not bankers.

虽说我们常常希望自己是银行职员！”
Though there have been many times we wished we were!’

“我意思是，”我说，“有其他的旅馆更适合，嗯，搞艺术的人。
‘What I'm saying,’ I said, ‘is there are other hotels much more geared, you know, to artistic types.

很难跟一个你完全不了解的陌生人推荐合适的旅馆。”
It's hard when strangers ask you to recommend a hotel, before you know what sort of people they are.’

“多谢你费心，”蒂洛说。
‘It's kind of you to worry,’ said Tilo.

“可是请别再为我们操心了。
‘But please, don't do so any longer.

我们现在这样很好。
What we have is perfect.

再说了，人与人的差别没那么大。
Besides, people are not so different.

银行家也好，音乐家也罢，我们对生活的基本需求是一样的。”
Bankers, musicians, we all in the end want the same things from life.’

“我想你说的不全对，”索尼娅说道。
‘You know, I'm not sure that is so true,’ Sonja said.

“我们这位年轻朋友，你瞧他没有到银行里去谋职。
‘Our young friend here, you see he doesn't look for a job in a bank.

他的梦想很不一样呢。”
His dreams are different.’

“也许你说得对，索尼娅。
‘Perhaps you are right, Sonja.

总之，我们觉得现在这个旅馆很好。”
All the same, the present hotel is fine for us.’

我低头随意弹了几个小节，一时间没有人说话。
I leant over the strings and practised another little phrase to myself, and for a few seconds nobody spoke.

过了一会儿，我问：“那你们演奏什么类型的音乐呢？”
Then I asked:‘So what sort of music do you guys play?’

蒂洛耸耸肩。
Tilo shrugged.

“索尼娅和我都会几种乐器。
‘Sonja and I play a number of instruments between us.

我们都会弹键盘。
We both play keyboards.

我喜欢单簧管。
I am fond of the clarinet.

索尼娅善于拉小提琴，还很会唱歌。
Sonja is a very fine violinist, and also a splendid singer.

我想我们最喜欢演奏的是传统的瑞士民歌，但是是用现代的方式来演绎。
I suppose what we like to do best is to perform our traditional Swiss folk music, but in a contemporary manner.

有时都称得上是激进的了。
Sometimes even what you might call a radical manner.

我们从类似这样做的大作曲家那里吸取灵感。
We take inspiration from great composers who took a similar path.

比方说扬纳切克。
Janáček, for instance.

你们英国的沃恩·威廉斯。”
Your own Vaughan Williams.’

“但是我们现在不常表演这些了，”索尼娅说。
‘But that kind of music’, Sonja said, ‘we don't play so much now.’

他们递了一下眼色，我想这是紧张的暗示。
They exchanged glances with what I thought was just a hint of tension.

但转眼蒂洛一贯的笑容又回到了脸上。
Then Tilo's usual smile was back on his face.

“是啊，就像索尼娅说的，在这个现实的世界，大部分时候，我们得演观众想听的东西。
‘Yes, as Sonja points out, in this real world, much of the time, we must play what our audience is most likely to appreciate.

所以我们多演一些热门歌曲。
So we perform many hits.

披头士啦，卡彭特啦。
Beatles, the Carpenters.

也有新一点的歌。
Some more recent songs.

观众们很喜欢。”
This is perfectly satisfying.’

“那阿巴乐队呢？”
‘What about Abba?’

我脱口而出，马上就后悔了。
I asked on an impulse, then immediately regretted it.

但蒂洛好像并没有听出我话里的调侃。
But Tilo didn't seem to sense any mockery.

“啊，我们也唱阿巴的。
‘Yes, indeed, we do some Abba.

《舞会皇后》，这歌永远受欢迎。
“Dancing Queen”. That one always goes down well.

其实，在《舞会皇后》里我还自己唱上一段，和声的部分。
In fact, it is on “Dancing Queen” I actually do a little singing myself, a little harmony part.

索尼娅会告诉你我的嗓音有多难听。
Sonja will tell you I have the most terrible voice.

所以我们一定得在听众吃饭吃到一半的时候唱这首歌，这样他们才不会跑掉。”
So we must make sure to perform this song only when our customers are right in the middle of their meal, when there is for them no chance of escape!’

说完他哈哈大笑起来，索尼娅也笑了，但没有他笑得厉害。
He did his big laugh, and Sonja laughed too, though not so loudly.

这时，一个穿着像是黑色潜水衣、职业打扮的自行车手从我们旁边飞驰而过，我们默默地看着他剧烈运动的背影渐渐远去。
A power-cyclist, kitted out in what looked like a black wetsuit, went speeding by us, and for the next few moments, we all watched his frantic, receding shape.

“我去过瑞士一次，”我打破沉默。
‘I went to Switzerland once,’ I said eventually.

“两年前的夏天。
‘A couple of summers ago.

我去了因特拉肯，住在当地的青年旅社。”
Interlaken. I stayed at the youth hostel there.’

“啊是，因特拉肯，漂亮的地方。
‘Ah yes, Interlaken. A beautiful place.

一些瑞士人瞧不起那儿，觉得那里只是给游客观光用的。
Some Swiss people scoff at it. They say it is just for the tourists.

可索尼娅和我都很喜欢在那里表演。
But Sonja and I always love to perform there.

其实，夏天的夜晚，在因特拉肯给来自全世界的欢欢喜喜的人们演出，是一件非常棒的事。
In fact, to play in Interlaken on a summer evening, to happy people from all over the world, it is something very wonderful.

你在那里玩得开心吗？”
I hope you enjoyed your visit there.’

“是，很开心。”
‘Yeah, it was great.’

“我们每年夏天都要去因特拉肯的一个餐厅表演几个晚上。
‘There is a restaurant in Interlaken where we play a few nights every summer.

我们坐在帐篷里表演，面对餐桌，这种晚上餐桌当然是在外面啦。
For our performance, we position ourselves under the restaurant's canopy, so we are facing the dining tables, which of course are outdoors on such an evening.

我们表演时能看见所有的游客在星空下一边吃着一边有说有笑。
And as we perform, we are able to see all the tourists, eating and talking together under the stars.

游客的身后是一大片空地，白天用来给滑翔伞降落，到了晚上就被何维克街的灯火照亮了。
And behind the tourists, we see the big field, where during the day the paragliders are landing, but which at night is lit up by the lamps along the Höheweg.

如果你还能看得更远，可以看见远处耸立的阿尔卑斯山。
And if your eye may travel further, there are the Alps overlooking the field.

艾格尔峰、门希峰、少女峰。
The outlines of the Eiger, the Mönch, the Jungfrau.

而且空气温暖宜人，还洋溢着我们演奏的音乐。
And the air is pleasantly warm and filled with the music we are making.

每次在那里演出我都觉得是特别的荣幸。
I always feel when we are there, this is a privilege.

我心想，啊，干这行真是太好了。”
I think, yes, it is good to be doing this.’

“去年，那家餐厅的经理叫我们演出时穿上全套的传统服装，”索尼娅说。
‘That restaurant,’ Sonja said.

“可天热得不得了，很不舒服。
‘Last year, the manager made us wear full costumes while we performed, even though it was so hot.

我们说有什么差别呢？
It was very uncomfortable, and we said, what difference does it make, why must we have our bulky waistcoats and scarves and hats?

为什么一定要穿上大大的马甲、围围巾、戴帽子？
In just our blouses, we look neat and still very Swiss.

我们就算只是穿衬衫也一样很像瑞士人，又整洁。
But the restaurant manager tells us, we put on the full costumes or we don't play.

可是餐厅经理说我们要么穿上全套衣服，要么走人，自己选，说完就走了，就这样。”
Our choice, he says, and walks away, just like that.’

“可是索尼娅，哪个工作都一样，都有制服，老板都要求你一定要穿。
‘But Sonja, that is the same in any job. There is always a uniform, something the employer insists you must wear.

在银行工作也一样！
It is the same for bankers!

而人家要我们穿的至少是我们所相信的。
And in our case, at least it is something we believe in.

瑞士的文化。
Swiss culture.

瑞士的传统。”
Swiss tradition.’

这时我又一次隐隐感觉到他们之间有什么不愉快，可这种感觉只持续了一两秒钟，他们看着我的吉他，就又都露出了微笑。
Once again something vaguely awkward hovered between them, but it was just for a second or two, and then they both smiled as they fixed their gazes back on my guitar.

我觉得自己该说点什么，就讲道：
I thought I should say something, so I said:

“我想到不同的国家去表演一定很有趣。
‘I think I'd enjoy that. Being able to play in different countries.

你得保持敏感，了解你的听众。”
It must keep you sharp, really aware of your audiences.’

“是，”蒂洛说，“我很高兴我们能给各种各样的人表演。
‘Yes,’ Tilo said, ‘it is good that we perform to all kinds of people.

不单单在欧洲。
And not only in Europe.

总而言之，我们因此得去了解很多的城市。”
All in all, we have got to know so many cities so well.’

“比如说杜塞尔多夫，”索尼娅说。
‘Düsseldorf, for instance,’ said Sonja.

她的口气变了——变的有些硬——我仿佛又见到了中午餐厅里的那个人。
There was something different about her voice now – something harder – and I could see again the person I'd encountered back at the cafe.

可蒂洛似乎并没有察觉出什么异常，愉快地说道：
Tilo, though, didn't seem to notice anything and said to me, in a carefree sort of way:

“我们的儿子现在就住在杜塞尔多夫。
‘Düsseldorf is where our son is now living.

他跟你差不多大，可能比你大一些。”
He is your age. Perhaps a little older.’

“今年初，”索尼娅说，“我们去了杜塞尔多夫。
‘Earlier this year,’ Sonja said, ‘we went to Düsseldorf.

有人邀请我们去表演。
We have an engagement to play there.

不是常有的事，是表演我们自己真正的音乐的机会。
Not the usual thing, this is a chance to play our real music.

所以我们给儿子打了电话，我们的独子，告诉他我们要去他的城市。
So we call him, our son, our only child, we call to say we are coming to his city.

他没有接电话，我们就留了言。
He does not answer his phone, so we leave a message.

我们留了好几次留言。
We leave many messages.

没有回音。
No reply.

我们到了杜塞尔多夫又给他留言，说我们到了，到你这里了。
We arrive in Düsseldorf, we leave more messages. We say, here we are, we are in your city.

还是没有回音。
Still nothing.

蒂洛说别担心，也许他那天晚上会来，来看我们表演。
Tilo says don't worry, perhaps he will come on the night, to our concert.

可是他没有来。
But he does not come.

我们表演完了又去了别的城市，进行下一场演出。”
We play, then we go to another city, to our next engagement.’

蒂洛咯咯地笑了。
Tilo made a chuckling noise.

“我想彼得大概是受够了我们的音乐，从小听到大！
‘I think perhaps Peter heard enough of our music while he was growing up!

可怜的孩子，不得不听我们排练，日复一日。”
The poor boy, you see, he had to listen to us rehearsing, day after day.’

“我想又要带孩子又要搞音乐挺难的。”
‘I suppose it can be a bit tricky,’ I said.

我说。
‘Having children and being musicians.’

“我们只有一个孩子，”蒂洛说，“所以还不算太难。
‘We only had the one child,’ Tilo said, ‘so it was not so bad. Of course we were fortunate.

当然我们是幸运的。我们外出表演不能带着他，他的祖父母总是很乐意帮忙。
When we had to travel, and we couldn't take him with us, his grandparents were always delighted to help.

等他长大一点，我们就把他送到一家很好的寄宿学校。
And when Peter was older, we were able to send him to a good boarding school.

他的祖父母又帮了我们大忙，不然我们付不起那么高的学费。
Again, his grandparents came to the rescue. We could not afford such school fees otherwise.

所以说我们是幸运的。”
So we were very fortunate.’

“是，我们很幸运，”索尼娅说。
‘Yes, we were fortunate,’ Sonja said.

“除了彼得讨厌那所学校。”
‘Except Peter hated his school.’

很显然之前的愉快气氛正在流逝。
The earlier good atmosphere was definitely slipping away.

为了活跃气氛，我赶忙说：“不管怎么说，看样子你们很喜欢你们的工作。”
In an effort to cheer things up, I said quickly:‘Well, anyway, it looks like you both really enjoy your work.’

“哦，没错，我们很喜欢这个工作，”蒂洛说。
‘Oh yes, we enjoy our work,’ said Tilo.

“工作就是我们的一切。
‘It's everything to us.

但即便如此，我们也很想放个假。
Even so, we very much appreciate a vacation.

知道吗？这是我们这三年来头一次像样的假期。”
Do you know, this is our first proper vacation in three years.’

蒂洛的话又一次让我觉得特别不好受，我想再次劝他们换旅馆，但我知道这么做很可笑。
This made me feel really bad all over again, and I thought about having another go at persuading them to change hotels, but I could see how ridiculous this would look.

我只能希望哈格·弗雷泽对他们好一点。
I just had to hope Hag Fraser pulled her finger out.

我心里想着这个，嘴上却说：
Instead, I said:

“瞧，要是你们喜欢的话，我可以把刚刚那首歌再唱一遍给你们听。
‘Look, if you like, I'll play you that song I was working on earlier.

那歌还没写完，我不常演唱还没完成的作品。
I haven't finished it, and I wouldn't usually do this.

可既然你们已经听到了一些，我不妨把已经写出来的部分唱给你们听。”
But since you heard some of it anyway, I don't mind playing you what I've got so far.’

索尼娅的脸上又露出了笑容，说：“好啊，快唱来听。
The smile returned to Sonja's face. ‘Yes,’ she said, ‘please do let us hear.

那歌儿太好听了。”
It sounded so beautiful before.’

我准备演唱的时候，他们把身子转回去，像刚刚那样面对着赫里福郡，背对着我。
As I got ready to play, they shifted again, so they were facing the view like before, their backs to me.

但是这次他们没有拥抱在一起，而是坐得异常的笔直，一只手放在眉毛上挡太阳。
But this time, instead of cuddling, they sat there on the grass with surprisingly upright postures, each with a hand up to the brow to shield away the sun.

我弹的时候他们一直是这个姿势，一动不动，在草地上留下两道长长的夕照的影子，像两尊塑像。
They stayed like that all the time I played, peculiarly still, and what with the way each of them cast a long afternoon shadow, they looked like matching art exhibits.

我慢慢地结束这首还没写完的歌。
I brought my incomplete song to a meandering halt, and for a moment they didn't move.

歌唱完了，他们仍旧一动不动，过了一会儿才放松身子，鼓了鼓掌，虽然没有前一次那么热烈。
Then their postures relaxed, and they applauded, though perhaps not quite as enthusiastically as the last time.

蒂洛一面称赞着一面站起来，然后扶索尼娅起来。
Tilo got to his feet, muttering compliments, then helped Sonja up.

看着他们站起来的样子我才意识到他们的年纪确实不小了。
It was only when you saw how they did this that you remembered they were really quite middle-aged.

也有可能他们只是累了。
Maybe they were just tired.

就我所知，遇到我之前他们已经走了不少的路。
For all I know, they might have done a fair bit of walking before they'd come across me.

总之就是我觉得他们起身的时候挺吃力的。
All the same, it seemed to me they found it quite a struggle to get up.

“你的演出太精彩了，”蒂洛说。
‘You've entertained us so marvellously,’ Tilo was saying.

“今天我们是游客，别人唱歌给我们听！
‘Now we are the tourists, and someone else plays for us!

调了过来，多有意思啊！”
It makes a pleasant change.’

“歌写完了以后要唱给我听，”索尼娅说，很认真的样子。
‘I would love to hear that song when it is finished,’ Sonja said, and she seemed really to mean it.

“说不定有一天我会在电台里听到呢。”
‘Maybe one day I will hear it on the radio. Who knows?’

“是啊，”蒂洛说，“到时索尼娅和我就可以翻唱给客人们听！”
‘Yes,’ Tilo said, ‘and then Sonja and I will play our cover version to our customers!’

他洪亮的笑声在空气中回荡。
His big laugh rang through the air.

接着他礼貌地微微鞠了一躬，说：“今天我们总共欠了你三次人情。
Then he did a polite little bow and said:‘So today we are in your debt three times over. A splendid lunch.

可口的午餐，舒适的旅馆，还有美妙的山上音乐会！”
A splendid choice of hotel. And a splendid concert here in the hills!’

分别的时候，我很想告诉他们真相。
As we said our goodbyes, I had an urge to tell them the truth.

告诉他们我故意给他们推荐了这里最烂的旅馆，希望他们趁还来得及赶紧搬出来。
To confess that I'd deliberately sent them to the worst hotel in the area, and warn them to move out while there was still time.

可是看着他们欢欢喜喜地跟我握手道别，我真是说不出口。
But the affectionate way they shook my hand made it all the harder to come out with this.

就这样，他们下山了，又剩我一个人坐在长椅上。
And then they were going down the hill and I was alone on the bench again.

我从山上下来时餐厅已经关门了。玛吉和杰夫看上去都累坏了。
The cafe had closed by the time I came down from the hills. Maggie and Geoff looked exhausted.

玛吉说这是他们最忙的一天，挺高兴的样子。
Maggie said it had been their busiest day yet and seemed pleased about it.

可是晚餐上——我们的晚饭是店里各种各样的剩菜——杰夫说到同一件事时却是一脸的不高兴，像是在责怪我：他们累得半死的时候，我不帮忙跑哪儿去了？
But when Geoff made the same point over supper – which we ate in the cafe from various left-overs – he put it like it was a negative thing, like it was awful they'd been made to work so hard and where had I been to help?

玛吉问我下午干什么去了，我没有提起蒂洛和索尼娅——说起来太复杂了——只是告诉她我到山上写歌去了。
Maggie asked how my afternoon had gone, and I didn't mention Tilo and Sonja – that seemed too complicated – but told her I'd gone up to the Sugarloaf to work on my song.

她又问我可有进展，我说有，大有进展。这时杰夫闷闷不乐地走了出去，盘子里的东西还没吃完。
And when she asked if I'd made any progress, and I said yes, I was making real headway now, Geoff got up and marched out moodily, even though there was still food on his plate.

玛吉假装没看见，也对，几分钟后杰夫拿着一罐啤酒回来，坐下看报纸，一声不吭。
Maggie pretended not to notice, and fair enough, he came back a few minutes later with a can of beer, and sat there reading his newspaper and not saying much.

我不希望他们俩为了我吵架，便很快离开了餐桌，回到楼上继续写歌。
I didn't want to be the cause of a rift between my sister and brother-inlaw, so I excused myself soon after that and went upstairs to work some more on the song.

白天我的房间很可以给人灵感，但到了晚上就不那么吸引人了。
My room, which was such an inspiration in the daytime, wasn't nearly so appealing after dark.

首先，窗帘不能把整个窗子遮住。
For a start, the curtains didn't pull all the way across, which meant if I opened a window in the stifling heat, insects from miles around would see my light and come charging in.

大热天的时候，我把窗户一打开，数英里以内的蚊虫看到灯光，就会蜂拥而入。
And the light I had was just this one bare bulb hanging down from the ceiling rose, which cast gloomy shadows all round the room, making it look all the more obviously the spare room it was.

其次，房里只有一只赤裸裸的灯泡从天花板的灯线盒垂下来，投下昏暗的灯光，原本简陋的房间看起来更加不堪。
That evening, I was wanting light to work by, to jot down lyrics as they occurred to me.

那天晚上，我本想开灯把脑子里想到的歌词写下来。
But it got far too stuffy, and in the end I switched off the bulb, pulled back the curtains, and opened the windows wide.

可是天实在太热了，最后我关掉灯，拉开窗帘，把窗子开得大大的，像白天那样抱着吉他坐在窗台上。
Then I sat in the bay with my guitar, just the way I did in the day.

我就这样坐了大约一个小时，试验着各种桥段，突然听见敲门声，玛吉的头探了进来。
I'd been there like that for about an hour, playing through various ideas for the bridge passage, when there was a knock and Maggie stuck her head round the door.

房里漆黑一片，但是楼下露台的安全灯亮着，所以我能依稀辨认出她的脸。
Of course everything was in darkness, but outside down on the terrace there was a security light, so I could just about make out her face.

她的脸上挂着不自然的微笑，我心想她又要叫我下去帮忙干活了。
She had on this awkward smile, and I thought she was about to ask me to come and help with yet another chore.

她走到房间里，关上身后的门，说：
She came right in, closed the door behind her and said:

“对不起，亲爱的。
‘I'm sorry, love.

今天实在把杰夫累坏了。
But Geoff's really tired tonight, he's been working so hard.

他说他现在想安安静静地看电影？”
And now he says he wants to watch his movie in peace?’

她的语气像是在发问。我过了一会儿才反应过来她是要我别再弹琴了。
She said it like that, like it was a question, and it took me a moment to realise she was asking me to stop playing my music.

“可我正写到关键的地方呢，”我答道。
‘But I'm working on something important here,’ I said.

“我知道。
‘I know.

可是杰夫今天真的累坏了。他说你的吉他让他没办法休息。”
But he's really tired tonight, and he says he can't relax because of your guitar.’

“杰夫应该知道：他有他的工作，我也有我的。”我说。
‘What Geoff needs to realise,’ I said, ‘is that just as he's got his work to do, I've got mine.’

玛吉像是在掂量我的话，过了一会儿重重地叹了一口气。
My sister seemed to think about this. Then she did a big sigh.

“我想我不该把这话告诉杰夫。”
‘I don't think I ought to report that back to Geoff.’

“为什么？
‘Why not?

为什么不该告诉他？
Why don't you?

他应该知道。”
It's time he got the message.’

“为什么？
‘Why not?

因为他会不高兴，这就是为什么。
Because I don't think he'd be very pleased, that's why not.

而且我想他会认为你的工作跟他的工作根本不是同一个档次。”
And I don't really think he'd accept that his work and your work are quite on the same level.’

一时间我看着玛吉，说不出话来。
I stared at Maggie, for a moment quite speechless.

“你胡说八道什么啊。
Then I said:‘You're talking such rubbish.

你说什么蠢话呢？”
Why are you talking such rubbish?’

玛吉疲惫地摇摇头，没有说什么。
She shook her head wearily, but didn't say anything.

“我不明白你为什么说这种蠢话，”我说。
‘I don't understand why you're talking such rubbish,’ I said.

“而且是正当我进展得很顺利的时候。”
‘And just when things are going so well for me.’

“你进展得很顺利，是吗，亲爱的？”
‘Things are going well for you, are they, love?’

昏暗中她一直看着我，过了好一会儿，她说道，“好了，我不跟你吵。”
She kept looking at me in the half-light. ‘Well, all right,’ she said in the end.

她转身打开门。
‘I won't argue with you.’

“你愿意的话就下来跟我们一起看电影吧，”离开前她说道。
She turned away to open the door. ‘Come down and join us, if you like,’ she said as she left.

我看着在她身后关上的门，气得整个人都僵掉了。
Rigid with rage, I stared at the door that had closed behind her.

楼下隐隐约约传来电视的声音。即便是正在气头上，大脑深处仍旧有一个声音告诉我：我不应该朝玛吉发火，我应该气的人是杰夫，是他从我一到这里就有计划一步步地想要搞我。
I became aware of muffled sounds from the television downstairs, and even in the state I was in, some detached part of my brain was telling me my fury should be directed not at Maggie, but at Geoff, who'd been systematically trying to undermine me ever since I'd got here.

但我还是生我姐姐的气。
Even so, it was my sister I was livid at.

我在她家待了这么久，她从来没有像蒂洛和索尼娅那样要我唱首歌给她听。
In all the time I'd been in her house, she hadn't once asked to hear a song, the way Tilo and Sonja had done.

这个要求对自己的姐姐来说不过分，而且我突然想到，她十几岁的时候也热衷于音乐。
Surely it wasn't too much to ask of your own sister, and one who'd been, I happened to remember, a big music fan in her teens?

可现在，她在我想专心写歌的时候打断我，说些愚不可及的话。我一想到她说“好了，我不跟你吵”的样子，气又上来了。
And now here she was, interrupting me when I was trying to work and talking all this rubbish. Every time I thought of the way she'd said:‘All right, I won't argue with you,’ I felt fresh fury coursing through me.

我从窗台上下来，收起吉他，躺倒在床上，盯着天花板。
I came down off the window sill, put away the guitar, and threw myself down on my mattress.

如今我总算明白了他们叫我来是有目的的，是在旺季找一个廉价的，甚至不用付工资的帮手。
Then for the next little while I stared at the patterns on the ceiling. It seemed clear I'd been invited here on false pretences, that this had all been about getting cheap help for the busy season, a mug they didn't even have to pay.

而玛吉不懂得我现在奋斗的目标比她那个笨蛋老公大得多。
And my sister didn't understand what I was trying to achieve any better than did her moron of a husband.

我真应该明天就离开这里回伦敦去，让他们自己收拾烂摊子。我就这么胡思乱想了大约一个小时以后，冷静了一些，决定脱衣服睡觉。
It would serve them both right if I left them here in the lurch and went back to London. I kept going round and round with this stuff, until maybe an hour or so later, I calmed down a bit and decided I'd just turn in for the night.

第二天早上，我像往常一样在早餐的高峰过后下楼去，没有怎么跟玛吉和杰夫说话。
I didn't speak much to either of them when I came down as usual just after the breakfast rush.

我烤了几片面包，泡了咖啡，还吃了些剩下的炒鸡蛋，然后在店内的角落坐下。
I made some toast and coffee, helped myself to some left-over scrambled eggs, and settled down in the corner of the cafe.

吃早饭的时候，我脑子里一直在想今天会不会在山上再次遇到蒂洛和索尼娅。
All through my breakfast the thought kept occurring to me I might run into Tilo and Sonja again up in the hills.

虽说见到他们我可能得面对旅馆的事情，但我发现我还是想再遇到他们。
And though this might mean having to face the music about Hag Fraser's place, even so, I realised I was hoping it would happen.

再说，就算哈格·弗雷泽的旅馆真的很糟糕，他们也不会想到我是故意耍他们的。
Besides, even if Hag Fraser's was truly awful, they'd never suppose I'd recommended it out of malice.

我有好些理由替自己开脱。
There'd be any number of ways for me to get out of it.

玛吉和杰夫可能想要我在午餐的时候帮忙，但我决定应该给他们一个教训，他们不应该不把别人当一回事。
Maggie and Geoff were probably expecting me to help again with the lunch rush, but I decided they needed a lesson about taking people for granted.

于是吃完早饭，我回到楼上，拿上吉他，从后门溜走了。
So after breakfast, I went upstairs, got my guitar and slipped out the back way.

又是一个大热天，我爬上通往长椅的小路，汗不停地从脸上流下来。
It was really hot again and the sweat was running down my cheek as I climbed the path leading up to my bench.

虽说早饭的时候我一直在想着蒂洛和索尼娅，但这会儿早把他们抛在了脑后，所以当我爬上最后一段斜坡，看见索尼娅独自一人坐在梯田上时，不禁吓了一跳。
Even though I'd been thinking about Tilo and Sonja at breakfast, I'd forgotten them by this point, and so got a surprise when, coming up the final slope, I looked towards the bench and saw Sonja sitting there by herself.

索尼娅一眼就看见了我，朝我挥手。
She spotted me immediately and waved.

我对她仍旧有点提防，特别是蒂洛不在这里，我不是很想跟她坐在一起。
I was still a bit wary of her, and especially without Tilo around, I wasn't so keen to sit down with her.

可是她给了我一个灿烂的微笑，还往旁边挪了挪，像是给我让位，我别无选择。
But she gave me a big smile and did a shifting movement, like she was making room for me, so I didn't have much choice.

我们互相打了招呼，并排坐在一起，彼此都不说话。
We said our hellos, then for a time we just sat there side by side, not speaking.

一开始这样并不奇怪，一方面是因为我还气喘吁吁，一方面是因为眼前的景色。
This didn't seem so odd at first, partly because I was still getting my breath back, and partly because of the view.

今天的天气没有昨天晴朗，云也比较多，但是你注意看的话，还是可以看见威尔士境内的布莱克群山。
There was more haze and cloud than the previous day, but if you concentrated, you could still see beyond the Welsh borders to the Black Mountains.

风挺大的，但不会感觉不舒服。
The breeze was quite strong, but not uncomfortable.

“蒂洛呢？”
‘So where's Tilo?’

我终于开口问道。
I asked in the end.

“蒂洛？
‘Tilo?

哦……”她把手罩在眼睛上。然后她指着远处说：“在那。
Oh ...’ She put her hand up to shield her eyes. Then she pointed.

看见了吗？
‘There.

那里。
You see?

那个就是蒂洛。”
Over there. That is Tilo.’

远远的我看见一个人影，隐约穿着绿色T恤衫、戴着白色太阳帽，朝着伍斯特郡的比肯山往上爬。
Some way in the distance, I could see a figure, in what might have been a green T-shirt and a white sun cap, moving along the rising path towards Worcestershire Beacon.

“蒂洛说他想去散步，”索尼娅说。
‘Tilo wished to go for a walk,’ she said.

“你不和他一起？”
‘You didn't want to go with him?’

“不。我想留在这里。”
‘No. I decided to stay here.’

虽说她现在不是那个在店里发飙的顾客，但也不是昨天那个对我那么热情和鼓励的人。
While she wasn't by any means the irate customer from the cafe, neither was she quite the same person who'd been so warm and encouraging to me the day before.

肯定出了什么事，我心里准备着对哈格·弗雷泽旅馆的说辞。
There was definitely something up, and I started preparing my defence about Hag Fraser's.

“对了，”我说，“昨天那首歌我又写了一点。
‘By the way,’ I said, ‘I've been working a bit more on that song.

想不想听听看？”
You can hear it if you like.’

她想了想，说：“你要是不介意，恐怕现在不太合适。
She gave this consideration, then said:‘If you do not mind, perhaps not just at this minute.

蒂洛和我刚刚发生了口角，或者可以叫做争吵。”
You see, Tilo and I have just had a talk. You might call it a disagreement.’

“哦，好吧。
‘Oh okay.

很抱歉听你这么说。”
Sorry to hear that.’

“所以他散他的步去了。”
‘And now he has gone off for his walk.’

我们又不说话了。
Again, we sat there not talking.

过了一会儿，我叹了口气，说道：“我想都是因为我。”
Then I sighed and said:‘I think maybe this is all my fault.’

索尼娅转过来看着我。
She turned to look at me.

“因为你？
‘Your fault?

为什么？”
Why do you say that?’

“你们吵架，你们的假期搞砸了，都是因为我，因为那旅馆，不是吗？
‘The reason you've quarrelled, the reason your holiday's all messed up now. It's my fault. It's that hotel, isn't it?

那旅馆不是很好，对吧？”
It wasn't very good, right?’

“旅馆？”
‘The hotel?’

她一脸困惑。
She seemed puzzled.

“这个嘛，那旅馆是有些毛病。
‘That hotel. Well, it has some weak points.

可它就是个旅馆，跟其他的旅馆一样。”
But it is a hotel, like many others.’

“可你注意到了是吧？
‘But you noticed, right?

你注意到所有的毛病了。
You noticed all the weak points.

一定注意到了。”
You must have done.’

她像是想了想我的话，才点点头，说：“没错，我注意到了旅馆的毛病。
She seemed to think this over, then nodded. ‘It is true, I noticed the weak points. Tilo, however, did not.

可蒂洛没有。他当然是觉得旅馆很好。
Tilo, of course, thought the hotel was splendid.

他老说我们运气很好。
We are so lucky, he kept saying.

很幸运能找到一家那样的旅馆。
So lucky to find such a hotel.

然后，今天早上吃早饭的时候，蒂洛说早饭真不错，是他吃过的最好的早餐。
Then this morning we have our breakfast. For Tilo, this is a fine breakfast, the best breakfast ever.

我说蒂洛，别傻了，这早饭不怎么样，这旅馆也不怎么样。
I say, Tilo, don't be stupid. This is not a good breakfast. This is not a good hotel.

他说不，不，我们很幸运。
He says, no, no, we are so very lucky.

我生气了，向女主人投诉所有的问题。
So I become angry. I tell the proprietress everything that is wrong.

蒂洛把我拉开，说，我们去散步吧。
Tilo leads me away. Let's go for a walk, he says.

走一走你就会感觉好些了。
You will feel better then.

于是我们就到这儿来了。他说，索尼娅，看看这些山，不漂亮吗？
So we come out here. And he says, Sonja, look at these hills, aren't they so beautiful?

我们能到这种地方来度假不是很幸运吗？
Aren't we fortunate to come to such a place as this for our vacation?

他说，这些山比他听埃尔加的时候想象的还要美丽。
These hills, he says, are even more wonderful than he imagined them when we listen to Elgar.

他问我，不是吗？
He asks me, isn't this so?

我可能是又生气了，说，这些山不怎么样，不是我听埃尔加的时候想象的那个样子。
Perhaps I become angry again. I tell him, these hills are not so wonderful. It is not how I imagine them when I hear Elgar's music.

埃尔加的山雄伟、神秘，这儿只不过像个公园。
Elgar's hills are majestic and mysterious. Here, this is just like a park.

我这么跟他说的，这回轮到他生气了。
This is what I say to him, and then it is his turn to be cross.

他说既然这样，他要自个儿去散步。
He says in that case, he will walk by himself.

他说我们完了，如今我们什么都说不到一块儿去了。
He says we are finished, we never agree on anything now.

他说，没有错，索尼娅，你和我，我们完了。
Yes, he says, Sonja, you and me, we are finished.

说完他就走了！
And off he goes!

事情就是这样。
So there you are.

这就是为什么他在那里，我在这里。”
That is why he is up there and I am down here.’

说完她又把手罩在眼睛上，追随着蒂洛的身影。
She shielded her eyes again and watched Tilo's progress.

“真的很抱歉，”我说。
‘I'm really sorry,’ I said.

“当初我要是没有推荐你们到那里去……”
‘If only I hadn't sent you to that hotel in the first place ...’

“别这么说。旅馆不重要。”
‘Please. The hotel is not important.’

她往前探了探身子，好把蒂洛看得清楚些。
She leaned forward to get a better view of Tilo.

然后转过来对我微微一笑，我想她的眼睛里噙着些许泪水。
Then she turned to me and smiled, and I thought maybe there were little tears in her eyes.

她说：“说说你今天是不是打算再写几首歌？”
‘Tell me,’ she said. ‘Today, you mean to write more songs?’

“我是这么打算的。
‘That's the plan.

或者至少把还没写完的那首写完。
Or at least, I want to finish the one I've been working on.

昨天你们听的那首。”
The one you heard yesterday.’

“那首歌很美。
‘That was beautiful.

你在这里写完这些歌以后要做什么呢？
And what will you do then, once you have finished writing your songs here?

有什么计划吗？”
You have a plan?’

“我要回伦敦去组建一支乐队。
‘I'll go back to London and form a band.

这些歌需要一支合适的乐队，不然就没有用了。”
These songs need just the right band or they won't work.’

“多令人兴奋啊。
‘How exciting.

我衷心地祝你好运。”
I do wish you luck.’

过了一会儿，我轻声说：“也有可能我不会去费这个劲。
After a moment, I said, quite quietly:‘Then again, I may not bother.

你知道组建一支乐队不是那么容易的。”
It's not so easy, you know.’

她没有回答，我想她可能没听见，因为她又转过头去看蒂洛了。
She didn't reply, and it occurred to me she hadn't heard, because she'd turned away again, to look towards Tilo.

“知道吗？”过了好一会儿她说道，“以前没有什么事情会让我生气。
‘You know,’ she said eventually, ‘when I was younger, nothing could make me angry.

可现在我老是生气。
But now I get angry at many things.

我不知道我为什么会变成这个样子。
I don't know how I have become this way.

这样不好。
It is not good.

咳，我想蒂洛不会回这边来了。
Well, I do not think Tilo is coming back here.

我回旅馆等他吧。”
I will return to the hotel and wait for him.’

她站起来，视线没有离开远处的身影。
She got to her feet, her gaze still fixed on his distant figure.

我也站了起来，说道：“真遗憾你们在度假的时候吵架。
‘It's a shame,’ I said, also getting up, ‘you having a row on your holiday.

昨天我弹琴给你们听的时候，你们看上去是那么幸福的一对。”
And yesterday, when I was playing to you, you seemed so happy together.’

“是啊，多美好的时刻。
‘Yes, that was a good moment.

谢谢你的歌。”
Thank you for that.’

她突然伸过手来，亲切地笑着。
Suddenly, she held out her hand to me, smiling warmly.

“认识你真好。”
‘It has been so nice to meet you.’

我和她轻轻地握了握手。
We shook hands, in the slightly limp way you do with women.

她转身准备离开，突然又停下来，看着我。
She started to walk away, then stopped and looked at me.

“如果蒂洛在这，”她说，“他会对你说，永远别灰心。
‘If Tilo were here,’ she said, ‘he would say to you, never be discouraged.

他会说你一定要回到伦敦试着组建自己的乐队。
He would say, of course, you must go to London and try and form your band.

你一定会成功的。
Of course you will be successful.

蒂洛会这么说的。
That is what Tilo would say to you.

因为他就是这么一个人。”
Because that is his way.’

“那你会说什么呢？”
‘And what would you say?’

“我也会这么说。
‘I would like to say the same.

因为你既年轻又有才华。
Because you are young and talented.

可是我不那么肯定。
But I am not so certain.

生活总是有很多不尽如人意的地方。
As it is, life will bring enough disappointments.

但如果那是你的梦想……”她又笑了笑，耸耸肩。
If on top, you have such dreams as this . . .’ She smiled again and shrugged.

“可我不应该说这些。
‘But I should not say these things.

我不是你的好榜样。
I am not a good example to you.

而且，我看得出来你跟蒂洛比较像。
Besides, I can see you are much more like Tilo.

假设真的遇上困难，你也不会放弃。
If disappointments do come, you will carry on still.

你会跟他一样，说我太幸运了。”
You will say, just as he does, I am so lucky.’

她盯着我看了几秒钟，像是要记住我的模样。
For a few seconds, she went on gazing at me, like she was memorising the way I looked.

微风吹动了她的头发，使得她看上去比平时老。“我衷心地祝你好运，”她最后说道。
The breeze was blowing her hair about, making her seem older than she usually did. ‘I wish you much luck,’ she said finally.

“也祝你好运，”我说。
‘Good luck yourself,’ I said.

“希望你们能重归于好。”
‘And I hope you two make it up okay.’

她最后一次挥了挥手，走下坡去，不见了。
She waved a last time, then went off down the path out of my view.

我从盒子里拿出吉他，坐回到长椅上，并没有马上弹起来，而是看着远方，看着伍斯特郡的比肯山和斜坡上蒂洛细小的身影。
I took the guitar from its case and sat back on the bench. I didn't play anything for a while though, because I was looking into the distance, towards Worcestershire Beacon, and Tilo's tiny figure up on the incline.

也许是太阳照射在山上的角度的问题，现在蒂洛的身影比刚才清楚多了，虽然他离得更远了。
Maybe it was to do with the way the sun was hitting that part of the hill, but I could see him much more clearly now than before, even though he'd got further away.

他在小路上驻足了片刻，似乎在环顾四周的山峰，就好像是想重新评价它们。
He'd paused for a moment on the path, and seemed to be looking about him at the surrounding hills, almost like he was trying to reappraise them.

然后他的身影又开始移动。
Then his figure started to move again.

我继续写歌，可老是开小差，老是在想早上索尼娅去找哈格·弗雷泽理论时，哈格·弗雷泽会是什么表情。
I worked on my song for a few minutes, but kept losing concentration, mainly because I was thinking about the way Hag Fraser's face must have looked as Sonja laid into her that morning.

我看了看天上的白云，又看了看脚下广袤的大地，然后把思绪重新拉回到我的歌上，拉回到还没写好的桥段上。
Then I gazed at the clouds, and at the sweep of land below me, and I made myself think again about my song, and the bridge passage I still hadn't got right.

# 小夜曲 | NOCTURNE

两天前，琳迪·加德纳还住在我的隔壁。
UNTIL TWO DAYS AGO, Lindy Gardner was my nextdoor neighbor.

好吧，你会想，要是琳迪·加德纳住在我隔壁，那是不是说我住在贝弗利山；我是个电影制片人、演员或者音乐家。
Okay, you're thinking, if Lindy Gardner was my neighbor, that probably means I live in Beverly Hills; a movie producer, maybe, or an actor or a musician.

没错，我是个乐手。
Well, I'm a musician all right.

但虽说我在一两个你听说过的艺人身后表演过，我并不是什么大明星。
But though I've played behind one or two performers you'll have heard of, I'm not what you'd call big-league.

我的经纪人布拉德利·史蒂文森，同时也是我多年的好友，说我有成为大明星的潜质。
My manager, Bradley Stevenson, who in his way has been a good friend over the years, maintains I have it in me to be big-league.

不只是成为在录音室里替人灌制唱片的大牌录音乐手，而是成为抛头露面的大腕。谁说萨克斯手再也成不了腕儿了，他说，然后开出一串名单。
Not just big-league session player, but big-league headliner. It's not true saxophonists don't become headliners any more, he says, and repeats his list of names.

马库斯·莱特富特，西尔维奥·塔伦蒂尼，他们都是爵士乐手，我指出。
Marcus Lightfoot. Silvio Tarrentini. They're all jazz players, I point out.

“你不是爵士乐手，是什么？”他说。
‘What are you, if you're not a jazz player?’ he says.

然而只有在我梦想的最深处我才是一个爵士乐手。
But only in my innermost dreams am I still a jazz player.

在现实生活中——在我像现在这样把整张脸都缠上绷带之前——我只是一个打零工的萨克斯手，在录音室里讨生活，或者给乐队补缺。他们要流行歌曲，我就吹流行歌曲。
In the real world – when I don't have my face entirely wrapped in bandages the way I do now – I'm just a jobbing tenor man, in reasonable demand for studio work, or when a band's lost their regular guy. If it's pop they want, it's pop I play.

节奏布鲁斯？
R & B? Fine.

没问题。汽车广告，脱口秀的进场音乐，我都做。
Car commercials, the walk-on theme for a talk show, I'll do it.

只有在我自己的小卧室里我才是一个爵士乐手。
I'm a jazz player these days only when I'm inside my cubicle.

我更想在客厅里吹萨克斯，可是我们的公寓是造价低廉的那种，整条走廊上的邻居都会抱怨。
I'd prefer to play in my living room, but our apartment's so cheaply made the neighbors would start complaining all the way down the hall.

于是我就把最小的房间改造成一间练习室。
So what I've done is convert our smallest room into a rehearsal room.

说是房间，其实也不过就一个厕所那么大——在里面放把办公椅就满了——可是我用泡沫、鸡蛋托和布拉德利从办公室寄来的旧加垫信封把这里隔了音。
It's no more than a closet really – you can get an office chair in there and that's it – but I've sound-proofed it with foam and egg-trays and old padded envelopes my manager Bradley sent round from his office.

我妻子海伦，以前还和我住在一起的时候，看我拿着萨克斯要去那个房间时，就会笑着说，我像是要去厕所，而有时候感觉就是这样。也就是说，我坐在那间阴暗、不通风的房间里，做着自己的事，没人会想要来打扰。
Helen, my wife, when she used to live with me, she'd see me going in there with my sax and she'd laugh and say it was like I was going to the toilet, and sometimes that's how it felt. That's to say, it was like I was sitting in that dim, airless cubicle taking care of personal business no one else would ever care to come across.

你已经猜到琳迪·加德纳不可能住在我说的这么一个公寓隔壁。
You've guessed by now Lindy Gardner never lived next to this apartment I'm talking about.

她也不可能是我在隔音室外面吹萨克斯就来“乓乓”敲门的邻居。
Neither was she one of the neighbors who banged the door whenever I played outside the cubicle.

我说她住在我的隔壁是另有所指，我现在就来解释给你听。
When I said she was my neighbor, I meant something else, and I'm going to explain this right now.

两天前，琳迪还住在这家豪华酒店的隔壁，而且和我一样，整张脸都缠着绷带。
Until two days ago, Lindy was in the next room here at this swanky hotel, and like me, had her face encased in bandages.

琳迪当然在这附近有一所舒适的大房子，还有帮佣，所以鲍里斯医生就让她回家了。
Lindy, of course, has a big comfortable house nearby, and hired help, so Dr Boris let her go home.

事实上，从严格的医学角度来讲，她大概早就可以回去了，但很明显还有其他原因。
In fact, from a strictly medical viewpoint, she could probably have gone much sooner, but there were clearly other factors.

比如说，回到自己家里就不那么容易躲开照相机和八卦专栏作者了。
For one, it wouldn't be so easy for her to hide from cameras and gossip columnists back in her own house.

再者，我的直觉告诉我鲍里斯医生名声好是因为他的做法不是百分百合法，所以他把病人藏在酒店里极其隐秘的这一层，普通员工和客人是找不到这里的，他也嘱咐我们不到万不得已不要离开房间。
What's more, my hunch is Dr Boris's stellar reputation is based on procedures that aren't one hundred per cent legal, and that's why he hides his patients up here on this hush-hush floor of the hotel, cut off from all regular staff and guests, with instructions to leave our rooms only when absolutely necessary.

要是你能透视这些纱布，你在这里待上一个星期比你在夏特蒙特酒店住上一个月更能发现名人。
If you could see past all the crêpe, you'd spot more stars up here in a week than in a month at the Chateau Marmont.

那么像我这种人怎么会跟这些大明星和大富翁住在一起，让全城最顶尖的医生给我整容呢？
So how does someone like me get to be here among these stars and millionaires, having my face altered by the top man in town?

我想这事儿是我的经纪人布拉德利起的头。他自己也不是什么大腕，也不比我长得更像乔治·克鲁尼。
I guess it started with my manager, Bradley, who isn't so big-league himself, and doesn't look any more like George Clooney than I do.

他第一次提起这事儿是在几年前，半开玩笑地，后来再提起的时候，一次比一次认真。
He first mentioned it a few years ago, in a jokey sort of way, then seemed to get more serious each time he brought it up again.

他的大意就是我太丑了。正是这一点阻碍我成名。
What he was saying, in a nutshell, was that I was ugly.

“看看马库斯·莱特富特，”他说。
And that this was what was keeping me from the big league.

“看看克里斯·布戈斯基，或者塔伦蒂尼。
‘Look at Marcus Lightfoot,’ he said. ‘Look at Kris Bugoski.

他们哪一个能吹出你这么有特色的声音？没有。
Or Tarrentini. Do any of them have a signature sound the way you do?

哪一个有你的温柔、你的想象力？
No. Do they have your tenderness? Your vision?

哪一个有你一半的技巧？没有。
Do they have even half your technique?

可人家长得端正，所以大门一直为他们敞开。”
No. But they look right, so doors keep opening for them.’

“那比利·福格尔呢？”
‘What about Billy Fogel?’

我说。
I said.

“他丑得不行，可他混得不错。”
‘He's ugly as hell and he's doing fine.’

“比利是很丑。
‘Billy's ugly all right.

可他是性感的、坏坏的丑。
But he's sexy, bad guy ugly.

而你，史蒂夫，你是……咳，你是平庸的、失败者的丑。
You, Steve, you're . . .

不对路子的丑。
Well, you're dull, loser ugly.

听着，你有没有想过对你的容貌做点什么？
The wrong kind of ugly.

我是指外科手术方面的？”
Listen, have you ever considered having a little work done?

回家以后我把这些话原原本本地讲给海伦听，因为我想她会和我一样觉得太滑稽了。
Of a surgical nature, I mean?’

刚开始确实是这样，我们把布拉德利好好地嘲笑了一番。
I went home and repeated this all to Helen because I thought she'd find it as funny as I did.

接着海伦不笑了，伸手搂住我，说，至少对她来说，我是世界上最帅的。
And at first, sure enough, we had a lot of laughs at Bradley's expense.

然后她后退了一步，不说话了。
Then Helen came over, put her arms around me and told me that for her at least, I was the most handsome guy in the universe.

我问她怎么了，她说没什么。
Then she kind of took a step back and went quiet, and when I asked her what was wrong, she said nothing was wrong.

接着她说，也许，只是也许，布拉德利说得对。
Then she said that perhaps, just perhaps, Bradley had a point.

也许我是应该考虑一下改变我的容貌。
Maybe I should consider having a little work done.

“没必要这么看着我！”她喊道。
‘No need to look at me like that!’ she yelled back.

“大家都这么做。
‘Everyone's doing it.

而你，你这么做是出于职业需要。
And you, you have a professional reason.

想要当好司机的人就得去买一辆好车。
Guy wants to be a fancy chauffeur, he goes and buys a fancy car.

你也一样！”
It's no different with you!’

然而那个时候我没有细想这件事，虽说我开始接受这个说法：我是“失败者的丑”。
But at that stage I gave the idea no further thought, even if I was beginning to accept this notion that I was ‘loser ugly’.

一方面，我没有钱。
For one thing, I didn't have the money.

实话告诉你，海伦说什么好司机的那会儿，我们欠债九千五百美元。
In fact, the very moment Helen was talking about fancy chauffeurs, we were nine and a half thousand dollars in debt.

这就是海伦。
This was characteristic of Helen.

就很多方面而言她是个好人，可是这种全然忘记我们实际的经济状况、开始幻想大笔新的花销的能力，这就是海伦。
A fine person in many ways, but this ability to forget completely the true state of our finances and start dreaming up major new spending opportunities, this was very Helen.

除了钱以外，一想到要被人切来划去的，我就满心的不喜欢。我受不了这类事情。
Money aside, I didn't like the idea of someone cutting me up. I'm not so good with that kind of thing.

我刚开始和海伦拍拖时，有一次，她叫我跟她一起跑步。那是一个寒冷而干燥的冬天的早晨，我自己从来不怎么跑步，但是那时我被她迷住了，急于想表现自己。
One time, early in my relationship with Helen, she invited me to go running with her. It was a crisp winter's morning, and I've never been much of a jogger, but I was taken by her and anxious to impress.

于是我们就绕着公园慢跑，一开始我稳稳地跟在她后面，突然我的鞋踢到了地上凸出来的什么硬物，脚疼了一下，但不太厉害。
So there we were running around the park, and I was doing fine keeping up with her, when suddenly my shoe hit something very hard jutting out of the ground.

可是当我脱掉运动鞋和袜子一看，大拇指上的趾甲翘了起来，像在做一个希特勒式的敬礼。我感到一阵恶心，昏了过去。我就是这个样子。
I could feel a pain in my foot, which wasn't so bad, but when I took off my sneaker and sock, and saw the nail on my big toe rearing up from the flesh like it was doing a Hitler-style salute, I got nauseous and fainted.

所以你瞧，我对整容这事儿不感冒。
That's the way I am. So you can see, I wasn't wild about face surgery.

此外，当然了，还有原则问题。
Then, naturally, there was the principle of the thing.

好吧，像我刚才说的，我并不坚持只做什么类型的音乐。为了赚钱，我什么都演。
Okay, I've told you before, I'm no stickler for artistic integrity. I play every kind of bubble-gum for the pay.

但整容就是另外一码事了，我还是有点尊严的。
But this proposition was of another order, and I did have some pride left.

布拉德利说对了一件事：我的才华是这座城市里大多数人的两倍。然而如今这个不重要了。
Bradley was right about one thing: I was twice as talented as most other people in this town. But it seemed that didn't count for much these days.

重要的是形象好、有市场、上杂志、上电视、去派对，还有你和什么人吃饭。这些统统让我恶心。
Because it has to do with image, marketability, being in magazines and on TV shows, about parties and who you ate lunch with. It all made me sick.

我是个音乐家，我为什么要加入这个游戏呢？
I was a musician, why should I have to join in this game?

我为什么不能按照我心中最理想的方式演奏我的音乐，并且不断进步呢？即使只是在我的小卧室里，也许有一天，只是也许，真正喜欢音乐的人会听见并且欣赏我的演奏。
Why couldn't I just play my music the best way I knew, and keep getting better, if only in my cubicle, and maybe some day, just maybe, genuine music lovers would hear me and appreciate what I was doing.

我为什么要整容呢？
What did I want with a plastic surgeon?

刚开始海伦像是站在我这边的，有一段时间没有再提起这件事。
At first Helen seemed to see it my way, and the topic didn't come up again for some time.

就是说，直到她从西雅图打电话来，说她要离开我去跟克里斯·普伦德加斯特在一起。
That is, not until she phoned from Seattle to say she was leaving me and moving in with Chris Prendergast, a guy she'd known since high school and who now owned a string of successful diners across Washington.

这个普伦德加斯特她从高中起就认识，如今在华盛顿拥有成功的连锁餐厅。
I'd met this Prendergast a few times over the years – he'd even come to dinner once – but I'd never suspected a thing.

这些年我见过这个普伦德加斯特几次——他还来吃过一次晚饭——可是我从来没有怀疑过。
‘All that sound-proofing in that cupboard of yours,’ Bradley said at the time.

“你那个隔音的碗柜，”那时布拉德利说道，“作用是双向的。”
‘It works both ways.’

我想他说得对。
I suppose he had a point.

然而除了说明他们跟我现在在这里有什么关系以外，我不想多说海伦和普伦德加斯特的事。
But I don't want to dwell on Helen and Prendergast except to explain their part in getting me where I am now.

你大概在想我立马北上，找那快乐的一对算账，在与情敌进行了一番男子汉大丈夫的争吵过后，整容就是自然而然的了。
Maybe you're thinking I drove up the coast, confronted the happy couple, and plastic surgery became necessary following a manly altercation with my rival. Romantic, but no, that's not the way it happened.

很浪漫，可惜你错了，事实不是这样的。事实是：打电话来几个星期以后，海伦回来收拾她的东西。
What happened was that a few weeks after her phone call, Helen came back to the apartment to organise moving out her belongings.

她伤心地在公寓里走来走去——毕竟我们在这里有过美好的时光。
She looked sad walking around the place – where, after all, we'd had some happy times.

我以为她要哭出来了，可是她没有哭，只是继续整理东西，把所有的东西整整齐齐地打包好，说这一两天会有人过来取走行李。
I kept thinking she was about to cry, but she didn't, and just went on putting all her things into neat piles. Someone would be along to pick them up in a day or two, she said.

我手里拿着萨克斯往小卧室走时，她抬起头来，静静地说：
Then as I was on my way to my cubicle, tenor in hand, she looked up and said quietly:

“史蒂夫，求你了。
‘Steve, please.

别再去那里了。
Don't go into that place again.

我们得谈谈。”
We need to talk.’

“谈什么？”
‘Talk about what?’

“史蒂夫，看在上帝的分上。”
‘Steve, for God's sake.’

于是我把萨克斯放回盒子里，我们走进小厨房，在桌子旁面对面坐下。
So I put the sax back in its case and we went into our little kitchen and sat down at the table facing one another.

她开口了。
Then she put it to me.

做了这个决定她不会回头了。
There was no going back on her decision.

她和普伦德加斯特在一起很开心，她在学校的时候就暗恋他了。
She was happy with Prendergast, for whom she'd carried a torch since school.

可是离开我她感到难过，特别是在我事业不如意的时候。
But she felt bad about leaving me, especially at a time when my career wasn't going so good.

所以她考虑了以后，和她的新欢谈了谈，那人也替我难过。
So she'd thought things over and talked with her new guy, and he too had felt bad about me.

他的原话是：“史蒂夫得为我们的幸福买单真是太不幸了。”
Apparently, what he'd said was:‘It's just too bad Steve has to pay the price for all our happiness.’

于是就这么定了。
So here was the deal.

普伦德加斯特愿意为我出钱到全城最好的外科医生那里做整容手术。
Prendergast was willing to pay for me to have my face fixed by the best surgeon in town.

“是真的，”发现我茫然地看着她，她说道。
‘It's true,’ she said, when I looked back at her blankly.

“他说真的。
‘He means it.

费用他全包。
No expense spared.

医院的费用、康复的费用、所有费用。
All the hospital bills, recuperation, everything.

全城最好的外科医生。”
The best surgeon in town.’

一旦我整了容，就没有什么能阻止我前进了，她说。
Once my face was fixed, there'd be nothing holding me back, she said.

我会一飞冲天，我怎么可能会失败呢，以我的才华？
I'd go right to the top, how could I fail, with the kind of talent I had?

“史蒂夫，为什么这样看着我？
‘Steve, why are you looking at me like that?

机会难得。
This is a great offer.

天晓得半年以后他还愿不愿意。
And God knows if he'll still be willing in six months.

现在就答应下来，好好地对待自己一回。
Say yes right now and do yourself a big favor.

只需忍耐几个星期，然后，嗖！
It's just a few weeks of discomfort, then whoosh!

你就一炮而红了！”
Jupiter and beyond!’

十五分钟后，在门口，海伦用严厉得多的语气说道：“你说的是什么话？
Fifteen minutes later, on her way out, she said in much sterner tones:‘So what is it you're saying?

什么叫做你愿意一辈子都在那个小房间里吹萨克斯？
That you're happy playing in that little closet for the rest of your life?

什么叫做你喜欢做一个大失败者？”
That you just love being this big a loser?’

说完，她走了。
And with that, she left.

第二天，我走进布拉德利的办公室，看看他有没有活给我，碰巧提起了这件事，原以为他会和我一起笑一笑，没想到他根本没有笑。
The next day I went into Bradley's office to see if he had anything for me, and I happened to mention what had occurred, expecting us to laugh about it. But he didn't laugh at all.

“这家伙很有钱？
‘This guy's rich?

而且他愿意给你找最好的外科医生？
And he's willing to get you a top surgeon?

也许他会给你找克雷斯波，甚至是鲍里斯。”
Maybe he'll get you Crespo. Or even Boris.’

现在又多了个布拉德利，劝我要抓住这次机会，若我错过了这次机会，我这辈子就永远是个失败者。
So now I had Bradley too, telling me how I had to take this opportunity, how if I didn't I'd be a loser all my life.

我生气地离开他的办公室，但是那天下午，他打电话给我，不停地劝我。
I left his office pretty angry, but he phoned later that same afternoon and kept on about it.

他说，如果是因为我不想打这通电话；如果是因为拿起电话对海伦说，好，求你了，我愿意，求你让你的男朋友开那张大支票吧，会挫伤我的自尊心；如果是这个原因阻止了我，那么，他，布拉德利，愿意替我进行所有的交涉。
If it was the call itself holding me back, he said, if it was the blow to my pride involved in picking up a phone and saying to Helen, yes, please, I want to do it, please get your boyfriend to sign that big check, if that's what was holding me up, then he, Bradley, was happy to do all the negotiations on my behalf.

我叫他吃屎去吧，挂断了电话。
I told him to go sit on a tall spike, and hung up.

可一个小时后他又打过来，说他已经把事情都想通了，说我自己没想明白真是个傻瓜。
But then he called again an hour later. He told me he'd now figured it all out and I was a fool not to have done so myself.

“这可是海伦精心策划的。
‘Helen's got this carefully planned.

想想她的处境吧。
Consider her position.

她爱你。
She loves you.

可说到相貌，咳，你真的长得很抱歉。
But looks-wise, well, you're an embarrassment when you're seen in public.

你不是靓仔。
You're no turn-on.

她希望你采取一点行动，但是你拒绝了。
She wants you to do something about it, but you refuse.

所以她能怎么办呢？
So what's she to do?

啊，她这一步真是壮举。
Well, her next move's magnificent.

处心积虑。
Full of subtlety.

作为一名职业经纪人，我不得不佩服她。
As a professional manager I have to admire it.

她跟这个人走了。
She goes off with this guy.

好吧，也许她一直对这个人念念不忘，但其实她根本不爱他。
Okay, maybe she's always had the hots for him, but really, she doesn't love him at all.

海伦利用他来为你的脸出钱。
She gets the guy to pay for your face.

一旦你手术成功，她就会回来，看见帅气的你，她就会想要你这个人，迫不及待地想让人看见跟你出入宾馆……”
Once you're healed up, she comes back, you're good-looking, she's hungry for your body, she can't wait to be seen with you in restaurants . . .’

说到这里，我打断了他。我说，虽然这几年我习惯了他出于自身的职业利益编各种故事出来说服我做这个做那个，但是这次扯得太远了，扯到不见天日的深谷里去了，热气腾腾的马粪在那里也会瞬间冻结。
I stopped him here to point out that though over the years I'd become accustomed to the depths to which he could sink when persuading me to do something to his professional advantage, this latest ploy was somewhere so far down in the pits it was a place no light penetrated and where steaming horseshit would freeze in seconds.

说到马粪，我说我理解他出于本能忍不住每次都要胡扯一通，但是我还是不相信他的话，这只不过是他想出来的、希望能暂时把我忽悠成功的东西。说完，我再次挂断他的电话。
And on the subject of horseshit, I told him that while I understood how he, on account of his nature, couldn't help shovelling the stuff all the time, it would still be sound strategy on his part to come up with the sort that had at least a chance of taking me in for a minute or two. Then I hung up on him again.

接下来的几个星期，工作似乎比以前少了。每次我打电话给布拉德利，问他有没有活，他都会说：“你自己都不帮自己，别人怎么帮你。”
Over the next few weeks, work seemed scarcer than ever, and each time I called Bradley to see if he had anything, he'd say something like:‘It's hard to help a guy who won't help himself.’

最后，我开始更加务实地考虑整件事情。
In the end, I began considering the whole matter more pragmatically.

我不得不面对这个事实：我得吃饭。
I couldn't get away from the fact that I needed to eat.

还有，若这么做意味着最后会有更多的人听到我的音乐，这样的结果也不错啊？还有，我不是希望有朝一日能组建自己的乐队吗？
And if going through with this meant that eventually a lot more people got to hear my music, was that such a bad result? And what about my plans to lead my own band one day?

什么时候能够实现呢？
How was that ever going to happen?

最后，大概在海伦提议后六个星期，我随口跟布拉德利说到我重新考虑了这件事情。
Finally, maybe six weeks after Helen came up with the offer, I mentioned casually to Bradley that I was thinking it over again.

有我这句话就够了。
That was all he needed.

他立马行动，打电话、做安排、又喊又叫，兴奋得不得了。
He was off, making phone calls and arrangements, shouting a lot and getting excited.

说句公道话，他说到做到：所有的中间协商他全包了，我一次也不用跟海伦进行丢脸的谈话，更不用说跟普伦德加斯特了。
To give him his due, he was true to his word: he did all the go-between stuff so I didn't have to have a single humiliating conversation with Helen, let alone with Prendergast.

有时候布拉德利甚至能够制造出这种假象，感觉他在替我谈一桩生意，感觉有东西可卖的人是我。
At times Bradley even managed to create the illusion he was negotiating a deal for me, that it was me who had something to sell.

即便如此，我还是每天都要怀疑好几次。
Even so, I was having doubts several times each day.

当事情真的来临的时候，来得很突然。
When it happened, it happened suddenly.

布拉德利打电话来说鲍里斯医生突然临时取消了原定计划，我得自己一个人拿着行李在当天下午三点半之前到达指定地点。
Bradley called to say Dr Boris had a last-minute cancellation and I had to get myself to a particular address by three-thirty that same afternoon with all my bags packed.

大概那个时候我临阵退缩了，因为我记得布拉德利在电话里冲我大嚷，叫我振作起来，说他会亲自送我去。接下来，经过九拐十八弯，我被载到了好莱坞山上的一所大房子，打了麻药，就像雷蒙德·钱德勒小说里的人物。
Maybe I had some final jitters at that point, because I remember Bradley yelling down the phone at me to pull myself together, that he was coming to get me himself, and then I was being driven up winding roads to a big house in the Hollywood hills and put under anaesthetic, just like a character in a Raymond Chandler story.

两天以后，我被送到了这里，贝弗利山上的一家酒店，在夜色的掩护下从后门进来。我被推到了走廊的深处，这里十分隐蔽，与酒店的正常营业完全隔绝。
After a couple of days I was brought down here, to this Beverly Hills hotel, by the back entrance under cover of dark, and wheeled down this corridor, so exclusive we're sealed off entirely from all the regular life of the hotel.

第一个星期，我的脸疼得要命，体内的麻药让我觉得恶心。
The first week, my face was painful and the anaesthetic in my system made me nauseous.

我得把枕头立起来靠着才能睡，也就是说我根本睡不了觉。护士坚持二十四小时都把窗帘拉得严严实实的，所以我不知道到了什么钟点。
I had to sleep propped up on pillows, which meant I didn't sleep much at all, and because my nurse insisted on keeping the room dark all the time, I lost sense of what hour of the day it was.

然而，我一点儿也不觉得坏。
Even so, Ididn't feel at all bad.

事实上，我感觉好极了，兴奋、乐观。我对鲍里斯医生充满信心，多少电影明星把自己的前程交到他的手里。
In fact, I felt exhilarated and optimistic. I felt complete confidence in Dr Boris, who was after all a guy in whose hands movie stars placed their entire careers.

再者，我知道我将是他的杰作；看见我这张失败者的脸，激起了他内心最深处的雄心壮志，让他想起了当初为什么选择了这个职业。他会百分之两百地全力以赴。
What's more, I knew that with me he'd completed his masterpiece; that on seeing my loser's face, he'd felt his deepest ambitions stir, remembered why he'd chosen his vocation in the first place, and put everything into it and more.

解开绷带以后，我会看见一张精心雕琢过的脸，有点野性但又很有味道。
When the bandages came off, I could look forward to a cleanly chiselled face, slightly brutal, yet full of nuance.

毕竟像他这么有名望的人，会认真思考一个严肃的爵士乐手的各种需求，不会把爵士乐手跟其他人，比如说，电视上的新闻主播混为一谈。
A guy with his reputation, after all, would have thought through carefully the requirements of a serious jazz musician, and not confused them with, say, those of a TV anchorman.

他甚至有可能还给我加了点那种似有似无的忧郁气质，有点像年轻时的德尼罗，或者吸毒前的切特·贝克。
He may even have put in something to give me that vaguely haunted quality, kind of like the young De Niro, or like Chet Baker before the drugs ravaged him.

我畅想着我要做的专辑，要请哪些明星来助阵。
I thought about the albums I'd make, the line-ups I'd hire to back me.

我感觉得意洋洋，不敢相信自己曾经迟迟不愿整容。
I felt triumphant and couldn't believe I'd ever hesitated about the move.

到了第二个星期，药物的作用慢慢退去，我开始觉得消沉、孤独、可鄙。
Then came the second week, when the effect of the drugs wore off, and I felt depressed, lonely and cheap.

我的护士格雷西让一点阳光透进屋子里来——但她顶多是把百叶窗放了一半下来——还允许我穿着晨衣在房间里走动。
My nurse, Gracie, now let a little more light into the room – though she kept the blinds at least halfway down – and I was allowed to walk about the room in my dressing gown.

于是我把CD一张接一张不停地放进B&O，并在地毯上走来走去，时不时在梳妆台的镜子前停下，审视着镜子里那个只露出两只小眼睛的缠着绷带的怪物。
So I put one CD after another into the Bang & Olufsen and went round and round the carpet, now and then stopping in front of the dressing-table mirror to inspect the weird bandaged monster gazing back through peephole eyes.

就是在这期间，格雷西第一次告诉我琳迪·加德纳住在隔壁。
It was during this phase that Gracie first told me Lindy Gardner was next door.

她要是早点告诉我这件事，在亢奋期的时候，我听了会很开心，甚至把它当作我美好新生活的首个标志。
Had she brought this news in my earlier, euphoric phase, I'd have greeted it with delight.

可我偏巧在这个时候听说这件事，在我跌入低潮的时候，听了这个消息我讨厌得又是一阵恶心。
I might even have taken it as the first indicator of the glamorous life I was now headed for.

若你是琳迪众多的崇拜者之一，我说声抱歉。
Coming when it did though, just as I was falling into my trough, the news filled me with such disgust it set off another bout of nausea.

但事实就是，那时，如果有这么一个人能代表世上所有肤浅和恶心的东西，非琳迪·加德纳莫属：一个一无是处的人——实事求是吧，她已经证明她不会演戏，也不假装有什么音乐才能——可她还是照样能走红，电视和杂志争相报道她，怎么拍都拍不够她的笑脸。
If you're one of Lindy's many admirers, I apologise for what's coming up here.

之前，我路过一家书店，书店外大排长龙。
But the fact was, at that moment, if there was one figure who epitomised for me everything that was shallow and sickening about the world, it was Lindy Gardner: a person with negligible talent – okay, let's face it, she's demonstrated she can't act, and she doesn't even pretend to have musical ability – but who's managed all the same to become famous, fought over by TV networks and glossy magazines who can't get enough of her smiling features.

我以为是斯蒂芬·金什么的来了，结果是琳迪在签售她最新的口述自传。
I went past a bookstore earlier this year and saw a snaking line and wondered if someone like Stephen King was around, and here it turns out to be Lindy signing copies of her latest ghosted autobiography.

她是怎么做到的？
And how was this all achieved?

当然是靠老一套。
The usual way, of course.

适时的绯闻，适时的结婚，适时的离婚。
The right love affairs, the right marriages, the right divorces.

这样她自然而然就上了应景的封面、脱口秀，或者是像最近她在广播上做的那个节目，我不记得节目的名字了，她在节目里教大家离婚后的首个重要约会应该如何着装打扮，抑或是如果你怀疑你丈夫是同志，你该怎么做，等等。
All leading to the right magazine covers, the right talk shows, then stuff like that recent thing she had on the air, I don't remember its name, where she gave advice about how to dress for that first big date after your divorce, or what to do if you suspect your husband is gay, all of that.

你会听见人们谈论她有什么“明星气质”，但其中的秘诀再简单不过了。
You hear people talk about her ‘star quality’, but the spell's easy enough to analyse.

就是不断地在电视和杂志封面上抛头露脸，不停地出席各种首映礼和派对，把自己的手搭到名人的胳膊上。
It's the sheer accumulation of TV appearances and glossy covers, of all the photos you've seen of her at premieres and parties, her arm linked to legendary people.

如今她就在这里，在隔壁，和我一样接受了鲍里斯医生的面部手术，在休养中。
And now here she was, right next door, recovering just like me from a face job by Dr Boris.

没有什么比这件事更能反映出现在我堕落到了什么地步。
No other news could have symbolised more perfectly the scale of my moral descent.

一个星期前，我还是一个爵士乐手。
The week before, I'd been a jazz musician.

如今我成了又一个可怜的骗子，妄图通过整容跟在琳迪·加德纳们的后面，爬进空虚的名流堆。
Now I was just another pathetic hustler, getting my face fixed in a bid to crawl after the Lindy Gardners of this world into vacuous celebrity.

接下来的几天，我试着用看书来打发时间，却无法集中精神。
The next few days, I tried to pass the time reading, but couldn't concentrate.

绷带之下的脸有的地方生疼地抽动，有的地方痒得要命。还有一阵一阵的发热和被关久了的幽闭感。
Under the bandages, parts of my face throbbed awfully, others itched like hell and I had bouts of feeling hot and claustrophobic.

我渴望吹萨克斯，一想到还要过好几周我的面部肌肉才能承受萨克斯的压力，我就更加沮丧。
I longed to play my sax, and the thought that it would be weeks yet until I could put my facial muscles under that kind of pressure made me even more despondent.

最后，我发现最好的打发大白天的做法不是听CD，而是盯着活页乐谱——我把小卧室里装和弦谱和乐谱的文件夹带来了——哼些即兴的调子。
In the end, I worked out the best way to get through the day was to alternate listening to CDs with spells of staring at sheet music – I'd brought the folder of charts and lead sheets I worked with in my cubicle – and humming improvisations to myself.

第二个星期快过去的时候，我肉体上和精神上的情况都开始好转。就在这时，我的护士递给我一个信封，神秘地笑了笑，说：“这可不是天天都有的。”
It was towards the end of the second week, when I was starting to feel a little better both physically and mentally, my nurse handed me an envelope with a knowing smile, saying:‘Now that ain't something you'll get every day.’

信封里是一张酒店的便笺纸。这张纸现在就在我手边，我转抄如下：
Inside was a page of hotel notepaper, and since I've got it right here beside me, I'll quote it just the way it came.

格雷西告诉我说你厌倦了这种安逸的生活。
Gracie tells me you're getting weary of this high life.

我也是。
I'm that way too.

你过来看看我，如何？
How about you come and visit?

今晚五点喝鸡尾酒会不会太早了？
If five o'clock tonight isn't too early for cocktails?

鲍医生说我不能喝酒，我猜你也是。
Dr B. says no alcohol, I expect same for you.

所以看来只有苏打水和矿泉水了。
So looks like club sodas and Perrier.

去他的！
Curse him!

五点见，不然我会伤心的。
See you at five or I'll be heartbroken.

琳迪·加德纳。
Lindy Gardner.

也许是因为我那个时候实在是无聊至极；或者是我的心情又好起来了；或者是觉得有个一起被关的伙伴能聊聊天、说说话很不错。
Maybe it was because I'd become so bored by this point; or just that my mood was on the up again; or that the thought of having a fellow prisoner to swap stories with was extremely appealing.

又或者是我并不是对美女完全免疫。
Or maybe I wasn't so immune myself to the glamor thing.

总之，虽然我对琳迪·加德纳有种种成见，看了这封信以后，我还是感到兴奋，叫格雷西转告琳迪，我五点过去。
In any case, despite everything I felt about Lindy Gardner, when I read this, I felt a tingle of excitement, and I found myself telling Gracie to let Lindy know I'd be over at five.

琳迪·加德纳脸上的绷带比我还多。
Lindy Gardner had on even more bandages than I did.

我至少头顶上还留了一块，我的头发就像沙漠里的棕榈树那样露在外面。
I'd at least been left an opening at the top, from which my hair sprang up like palms in a desert oasis.

可鲍里斯把琳迪的整个脑袋都包得严严实实的，活像一个椰子的形状，只在眼睛、鼻子和嘴巴的地方开了条槽。
But Boris had encased the whole of Lindy's head so it was a contoured coconut shape, with slots only for eyes, nose and mouth.

她那头浓密的金发怎么了，我不得而知。
What had happened to all that luxuriant blonde hair, I didn't know.

她的声音倒是没有受到绷带的影响，我在电视上看见过她几次，听得出她的声音。
Her voice, though, wasn't as constricted as you'd expect, and I recognized it from the times I'd seen her on TV.

“你现在感觉怎么样？”她问道。
‘So how are you finding all this?’ she asked.

我回答说感觉还不错。她说：“史蒂夫。
When I replied I wasn't finding it too bad, she said:‘Steve.

我能叫你史蒂夫吗？
May I call you Steve?

我从格雷西那里听说了你所有的事情。”
I've heard all about you from Gracie.’

“哦？
‘Oh?

但愿她略过了不好的地方。”
I hope she left out the bad part.’

“嗯，她说你是个乐手。
‘Well, I know you're a musician.

很有前途的乐手。”
And a very promising one too.’

“她说的？”
‘She told you that?’

“史蒂夫，你在紧张。
‘Steve, you're tense.

我希望你和我在一起时不要紧张。
I want you to relax when you're with me.

我知道有些名人喜欢崇拜者见到他们时觉得紧张。
Some famous people, I know, they like the public to be tense around them.

这让他们更加觉得自己与众不同。
Makes them feel all the more special.

可我讨厌这样。
But I hate that.

我希望你把我当成普通朋友。
I want you to treat me just like I'm one of your regular friends.

你刚才说什么？
What were you telling me?

你说你不太在意这些。”
You were saying you don't mind this so much.’

她的房间比我的大很多，这里只是套房的客厅。
Her room was significantly bigger than mine, and this was just the lounge part of her suite.

我们面对面地坐在一对白色沙发上，中间隔着一张矮矮的烟色玻璃的咖啡桌，能看见玻璃底下垫着的大块浮木。
We were sitting facing each other on matching white sofas, and between us was a low coffee table made of smoked glass, through which I could see the hunk of driftwood it rested on.

桌上放满了光鲜的杂志和一只未拆掉玻璃纸的水果篮。
Its surface was covered with shiny magazines and a fruit basket still in cellophane.

和我一样，她的空调也开得很大——裹着绷带是很热的——百叶窗也放得低低的，挡住窗外的夕阳。
Like me, she had the air-conditioning up high – it gets warm in bandages – and the blinds low over the windows against the evening sun.

一个女佣给我端来了一杯水和咖啡，两杯里面都浮着吸管——我们喝什么都得用吸管——然后就离开了。
A maid had just brought me a glass of water and a coffee, both with straws bobbing in them – which is how everything has to be served here – then had left the room.

为了回答她的问题，我说我最痛苦的地方是不能吹萨克斯。
In answer to her question, I told her the toughest part for me was not being able to play my sax.

“可是你应该明白鲍里斯为什么不让你吹，”她说。
‘But you can see why Boris won't let you,’ she said.

“试想一下。
‘Just imagine.

你还没完全康复之前就去吹那管子，你脸上的肉会飞得屋里到处都是的！”
You blow on that horn a day before you're ready, bits of your face will fly out all over the room!’

她好像被逗乐了，朝我挥了挥手，好像说那俏皮话的人是我。她说：“好了，你笑得太厉害了！”
She seemed to find this pretty funny, waving her hand at me, as though it was me that had made the wisecrack and she was saying:‘Stop it, you're too much!’

我也笑了，然后用吸管吸了几口咖啡。
I laughed with her, and sipped some coffee through the straw.

接着她聊起了最近整了容的朋友，聊他们都说了些什么、他们身上发生了什么好笑的事。她提到的人要么是名人，要么是跟名人结婚的人。
Then she began talking about various friends who'd recently gone through cosmetic surgery, what they'd reported, funny things that had happened to them. Every person she mentioned was a celebrity or else married to one.

“这么说你是个萨克斯手咯，”她突然改变了话题。
‘So you're a sax player,’ she said, suddenly changing the subject.

“选得好。
‘You made a good choice.

萨克斯是种好乐器。
It's a wonderful instrument.

知道我对所有年轻的萨克斯手说什么吗？
You know what I say to all young saxophone players?

我叫他们多听听前辈的作品。
I tell them to listen to the old pros.

我认识一个萨克斯手，和你一样刚刚崭露头角，只听那些喜欢标新立异的人的。
I knew this sax player, up-and-coming like you, only ever listened to these far-out guys.

韦恩·肖特之类。
Wayne Shorter and people like that.

我对他说，从老一辈人那里你可以学到更多的东西。
I said to him, you'll learn more from the old pros.

他们也许不是特别创新，但是他们的技术是一流的。
Might not have been so ground-breaking, I said to him, but those old pros knew how to do it.

史蒂夫，介不介意我放点东西给你听？
Steve, do you mind if I play you something?

好让你明白我的意思？”
To show you exactly what I'm talking about?’

“不，我不介意。
‘No, I don't mind.

可是加德纳太太……”
But Mrs Gardner . . .’

“哦，叫我琳迪。
‘Please. Call me Lindy.

在这里没有辈分之分。”
We're equals here.’ ‘Okay.

“好吧。
Lindy.

琳迪。我想说，我不年轻了。
I just wanted to say, I'm not so young.

事实上，我快三十九了。”
In fact, I'll be thirty-nine next birthday.’

“哦，真的？
‘Oh really?

那也不老。
Well, that's still young.

不过你说得对，我没想到你年纪这么大了。
But you're right, I thought you were much younger.

鲍里斯给我们戴上这些一模一样的面具就看不出来了，是不是？
With these exclusive masks Boris has given us, it's hard to tell, right?

听格雷西说的，我以为你是个刚刚崭露头角的孩子，被父母送来这里准备飞黄腾达。
From what Gracie said, I thought you were this up-and-coming kid, and maybe your parents had paid for this surgery to get you off to a flying start.

对不起，我搞错了。”
Sorry, my mistake.’

“格雷西说我‘刚刚崭露头角’？”
‘Gracie said I was “up-and-coming”?’

“别难为她。
‘Don't be hard on her.

她说你是个音乐家，我就问她你的名字。
She said you were a musician so I asked her your name.

我说我没听过这个名字，她说：‘那是因为他刚刚崭露头角。’
And when I said I wasn't familiar with it, she said, “That's because he's up-and-coming.”

就是这样。
That's all it was.

好了，听着，你多大又有什么关系呢？
Hey, but listen, what does it matter how old you are?

你还是可以从老一辈乐手那里学到东西。
You can always learn from the old pros.

我想让你听听这个。
I want you to listen to this.

我想你会喜欢的。”
I think you'll find it interesting.’

她走到一个柜子前，不一会儿拿出了一张CD。
She went over to a cabinet and a moment later held up a CD.

“你会喜欢这个的。
‘You'll appreciate this.

这首歌里的萨克斯太棒了。”
The sax on this is so perfect.’

和我那边一样，她的房里也有一套B&O的音响。不一会儿，房里就响起了悦耳的弦乐声。
Her room had a Bang & Olufsen system just like mine, and soon the place filled with lush strings.

几小节过后，一个懒洋洋的、本·韦伯斯特式的次中音萨克斯响了起来，接着整个乐队也跟了进来。对这类东西不熟的人会以为是纳尔逊·里德尔在为西纳特拉吹奏歌曲的引子。
A few measures in, a sleepy, Ben Webster-ish tenor broke through and proceeded to lead the orchestra. If you didn't know too much about these things, you could even have mistaken it for one of those Nelson Riddle intros for Sinatra.

但最终传来的是托尼·加德纳的声音。
But the voice that eventually came on belonged to Tony Gardner.

这首歌的歌名——我刚刚想起来——是《当时在卡尔弗城时》，一首不是非常流行的民谣，如今也没什么人演了。
The song – I just about remembered it – was something called “Back at Culver City”, a ballad that never quite made it and which no one plays much any more.

托尼·加德纳唱着，萨克斯则一路跟着他，一行行地应和着。
All the time Tony Gardner sang, the sax kept up with him, replying to him line by line.

整首歌平淡无奇，而且太甜了。
The whole thing was utterly predictable, and way too sugary.

不久，我的注意力从音乐上面转移到了琳迪身上。她在我面前缓缓地随着歌曲起舞，自我陶醉了。
After a while, though, I'd stopped paying much attention to the music because there was Lindy in front of me, gone into a kind of dream, dancing slowly to the song.

她动作轻盈、优雅——显然手术没有影响到她的身体——而且她身材苗条、匀称。
Her movements were easy and graceful – clearly the surgery hadn't extended to her body – and she had a shapely, slim figure.

她穿着一件半是睡衣半是晚礼服的衣服，也就是说，看上去既像病人但又迷人。与此同时，我努力在搞清楚一件事。
She was wearing something that was part nightgown, part cocktail dress; that's to say, it was at the same time vaguely medical yet glamorous. Also, I was trying to work something out.

我印象中琳迪最近刚刚和托尼·加德纳离了婚，但说到演艺圈的八卦，我是全国最差的一个，所以我渐渐地怀疑是我搞错了。
I'd had the distinct impression Lindy had recently divorced Tony Gardner, but given I'm the nation's worst when it comes to showbiz gossip, I began to think maybe I'd got it wrong.

要不然她怎么会这样跳着舞，沉醉在音乐里，一副很陶醉的样子？
Otherwise why was she dancing this way, lost in the music, evidently enjoying herself?

托尼·加德纳的声音停了下来，弦乐器在桥段达到高潮，最后只剩下钢琴独奏。
Tony Gardner stopped singing a moment, the strings swelled into the bridge, and the piano player started a solo.

这时，琳迪好像回到了人间，停止摇摆，用遥控器关掉音响，然后走过来在我对面坐下。“是不是很棒？
At this point, Lindy seemed to come back to the planet. She stopped swaying around, turned the music off with the remote, then came and sat down in front of me.

明白我刚才说的话了吗？”
‘Isn't that marvellous? You see what I mean?’

“是，很美，”我说道，心想不知道现在是不是还只谈论萨克斯。
‘Yeah, that was beautiful,’ I said, not sure whether we were still only talking about the sax.

“对了，你的耳朵没有骗你。”
‘Your ears weren't deceiving you, by the way.’

“什么？”
‘I'm sorry?’

“那个歌手。
‘The singer.

正是你想的那个人。
That was who you thought it was.

并不因为他不再是我丈夫了我就不能放他的唱片，不是吗？”
Just because he's no longer my husband, that doesn't mean I can't play his records, right?’

“啊，当然不是。”
‘No, of course not.’

“而且歌里的萨克斯很美。
‘And that's a lovely saxophone.

现在明白我为什么要你听这个了吧。”
You see now why I wanted you to hear it.’ ‘Yeah, it was beautiful.’

“是，很美。”“史蒂夫，你有唱片吗？
‘Steve, are there recordings of you somewhere?

我指你自己演奏的？”
I mean, of your own playing?’

“当然有了。
‘Sure.

事实上隔壁就有几张CD。”
In fact I have a few CDs with me next door.’

“亲爱的，你下次过来时把它们拿过来。
‘The next time you come, sweety, I want you to bring them.

我想听听你的演奏。
I want to hear how you sound.

好吗？”
Will you do that?’

“好的，但愿你不嫌弃。”
‘Okay, if it's not going to bore you.’

“哦，不，不会的。
‘Oh no, it won't bore me.

可我希望你不要觉得我多管闲事。
But I hope you don't think I'm nosy.

托尼总说我爱多管闲事，我不应该干涉别人的事。可你知道，我觉得他那是势利。
Tony always used to say I was nosy, I should just let people be, but you know, I think he was just being snobby.

很多名人认为他们应该只对其他名人感兴趣。可我从不这么想。
A lot of famous people, they think they should be interested only in other famous people.

我把每个人都当作可能的朋友。比如说格雷西。
I've never been that way. I see everybody as a potential friend.

她就是我的朋友。
Take Gracie. She's my friend.

我家里所有的用人，他们也都是我的朋友。
All my staff at home, they're also my friends.

再比如在派对上。
You should see me at parties.

其他人都相互聊着他们最新的电影什么的，只有我和女服务员或者吧台的男招待聊天。我不觉得这是多管闲事，你觉得呢？”
Everyone else, they're talking to each other about their latest movie or whatever, I'm the one having a conversation with the catering girl or the bartender.

“不，我丝毫不觉得那是多管闲事。
I don't think that's being nosy, do you?’

不过，你瞧，加德纳太太……”
‘No, I don't think that's nosy at all. But look, Mrs Gardner . . .’

“请叫我琳迪。”
‘Lindy, please.’

“琳迪。
‘Lindy.

你瞧，跟你聊天真是太愉快了。
Look, it's been fabulous being with you.

可是这些药物真的把我搞得很累。
But these drugs, they really tire me out.

我想我得回去躺一会儿。”
I think I'm going to have to go lie down for a while.’

“哦，你不舒服？”
‘Oh, you're not feeling well?’

“没什么。
‘It's nothing.

只是这些药。”
It's just these drugs.’

“太糟了！
‘Too bad!

你感觉好一些的时候一定要再过来。
You definitely have to come back when you're feeling better.

把那些唱片带来，你演奏的唱片。
And bring those recordings, the ones with you playing.

说定了？”
Is that a deal?’

我不得不再次向她保证我今天聊得很愉快，我一定会再来。
I had to reassure her some more that I'd had a good time and that I'd come back.

我正要出门时，她突然说道：
Then as I was going out the door, she said:

“史蒂夫，你下象棋吗？
‘Steve, do you play chess?

我是全世界下象棋下得最糟的，可我有一副很可爱的象棋。
I'm the world's worst chess player, but I've got the cutest chess set.

上周梅格·瑞安带来给我的。”
Meg Ryan brought it in for me last week.’

回到房里，我从迷你冰箱里拿了瓶可乐，在写字桌前坐下，看着窗外。
Back in my own room, I took a Coke from the mini-bar, sat down at the writing desk and looked out my window.

窗外是一大片粉红色的夕阳。我们住得很高，我能看见远处高速公路上来来往往的汽车。
There was a big pink sunset now, we were a long way up, and I could see the cars moving along the freeway in the distance.

几分钟后，我打电话给布拉德利。他的秘书让我等了很长时间，但他最后终于来听电话了。
After a few minutes I phoned Bradley, and though his secretary kept me on hold a long time, he eventually came on the line.

“脸怎么样了？”他担心地问，好像在询问一只他放在我这里托管的心爱的宠物。
‘How's the face?’ he asked worriedly, like he was inquiring after a well-loved pet he'd left in my care.

“我怎么知道？
‘How should I know?

我仍旧是个隐形人。”
I'm still the Invisible Man.’

“你还好吧？
‘Are you all right?

你听上去……无精打采的。”
You sound ... dispirited.’

“我确实无精打采。这整件事都错了。
‘I am dispirited. This whole thing was a mistake.

我现在看明白了。
I can see that now.

事情不会成的。”
It's not going to work.’

一阵沉默。接着他问道：“手术失败了？”
There was a moment's silence, then he asked:‘The operation's a failure?’

“我肯定手术没问题。
‘I'm sure the operation's fine.

我是说其余的部分，这事的发展。
I mean all the rest of it, what it's going to lead to.

这个计划……事情的结果不会是像你说的那个样子。
This scheme . . . It's never going to play out the way you said.

我真不应该被你说动。”
I should never have let you talk me into it.’

“你是怎么了？
‘What's the matter with you?

你听上去情绪低落。
You sound depressed.

他们给你灌什么了？”
What have they been pumping into you?’

“我很好。
‘I'm fine.

事实上，现在我的头脑比以前清楚多了。
In fact, my head's straighter than it's been for a long while.

所以麻烦就来了。
That's the trouble.

现在我看明白了。
I can see it now.

你的计划……我真不应该听你的。”
Your scheme . . . I should never have listened to you.’

“你说什么呢？
‘What is this?

什么计划？
What scheme?

听着，史蒂夫，事情很简单。
Look, Steve, this isn't complicated.

你是个很有天赋的艺术家。
You're a very talented artist.

等这件事过了，你还和以前一样该做什么做什么。
When you're through with this, all you do is what you've always done.

你现在只是在清除一个障碍，没别的。
Just now you're simply removing an obstacle, that's all.

没有什么计划……”
There's no scheme . . .’

“听着，布拉德利，这里糟透了。不只是肉体上的难受。
‘Look, Bradley, it's bad here. It's not just the physical discomfort.

我现在意识到我在对自己做什么了。
I realise now what I'm doing to myself.

整件事都错了。我应该更看得起自己一些。”
It's been a mistake, I should have had more respect for myself.’

“史蒂夫，什么事让你突然想说这些？
‘Steve, what's triggered this?

出了什么事？”
Did something just happen over there?’

“是他妈的出事了。
‘Damn right something happened.

所以我才给你打电话。我要你把我从这里弄出去。
That's why I'm calling, I need you to get me out of this.

我要你给我换家酒店？”
I need you to get me to a different hotel.’

“换家酒店？
‘Different hotel?

你以为你是谁？
Who are you?

阿卜杜拉王储啊？
Crown Prince Abdullah?

那家酒店他妈的怎么了？”
What the fuck's wrong with the hotel?’

“怎么了？就是琳迪·加德纳住在我隔壁。
‘What's wrong is I've got Lindy Gardner right next door.

她刚刚请我过去，叫我以后还要去。
And she just invited me over, and she's going to keep on inviting me over.

就是这么了！”
That's what's wrong!’

“琳迪·加德纳住在隔壁？”
‘Lindy Gardner's next door?’

“听着，我受不了再去一次。
‘Look, I can't go through that again.

我刚刚去了，耐着性子待在那里。
I've just been in there, it was all I could do to stay as long as I did.

现在她说我们要玩她那副梅格·瑞安的象棋……”
And now she's saying we have to play with her Meg Ryan chess set . . .’

“史蒂夫，你是说琳迪·加德纳住在隔壁？
‘Steve, you're telling me Lindy Gardner's next door?

你还去看了她？”
You spent time with her?’

“她放她丈夫的唱片！
‘She put on her husband's record!

妈的，我想她现在又在放另一张。
Fuck it, I think she's playing another one right now.

我现在堕落到这种地步了。
This is what I've come to.

跟她那种人。”
This is my level now.’

“打住，史蒂夫，把事情从头说一遍。
‘Steve, hold it, let's go over this again.

史蒂夫，你他妈的闭嘴，把整件事解释给我听。
Steve, just shut the fuck up, then explain it to me.

解释一下你怎么会去看琳迪·加德纳。”
Explain to me how you get to be with Lindy Gardner.’

这时我确实暂时冷静下来了。我就简要地告诉他琳迪怎么请我过去，后来又发生了什么事。
I did calm down then for a while, and I gave a brief account of how Lindy had asked me over, and the way things had gone.

“那么你没有对她无礼？”我一说完他就这么问道。
‘So you weren't rude to her?’ he asked as soon as I was through.

“没有，我没有对她无礼。
‘No, I wasn't rude to her.

我一直忍着。
I kept it all held in.

可是我不会再去了。
But I'm not going back in there.

我要换酒店。”
I need to change hotels.’

“史蒂夫，你不能换酒店。
‘Steve, you're not going to change hotels.

琳迪·加德纳？
Lindy Gardner?

她缠着绷带，你也缠着绷带。
She's in bandages, you're in bandages.

她就住在你隔壁。
She's right next door.

史蒂夫，这是一个绝好的机会。”
Steve, this is a golden opportunity.’

“没有的事，布拉德利。
‘It's nothing of the sort, Bradley.

这里是名流地狱。
It's inner-circle hell.

她那副梅格·瑞安的象棋，我的老天！”
Her Meg Ryan chess set for God's sake!’

“梅格·瑞安的象棋？
‘Meg Ryan chess set?

什么意思？
How does that work?

棋子长得像梅格·瑞安？”
Every piece looks like Meg?’

“她还要听我演奏！
‘And she wants to hear my playing!

她要我下次一定带CD过去！”
She's insisting next time I take in CDs!’

“她要你……天啊，史蒂夫，你还没把绷带拆掉就已经撞大运了。
‘She wants to . . . Jesus, Steve, you haven't even got the bandages off and everything's going your way.

她想听你演奏？”
She wants to hear you play?’

“我要你摆平这件事，布拉德利。
‘I'm asking you to deal with this, Bradley.

我现在真是麻烦大了，我做了手术，你说动我做的，我居然傻到相信了你的话。
Okay, I'm in deep, I've had the surgery, you talked me into it, because I was fool enough to believe what you said.

可我用不着忍受这个。
But I don't have to put up with this.

我用不着接下来两个星期都得和琳迪·加德纳在一起。
I don't have to spend the next two weeks with Lindy Gardner.

我要你马上把我搬出去！”
I'm asking you to get me moved pronto!’

“我不会把你搬出去的。
‘I'm not getting you moved anywhere.

你知不知道琳迪·加德纳是多重要的人物？
Do you realise how important a person Lindy Gardner is?

你知不知道她都和哪些人往来，她打个电话就能替你做什么事？
You know the kind of people she's pals with? What she could do for you with one phone call?

没错，如今她是和托尼·加德纳离婚了。可这没有影响。
Okay, she's divorced from Tony Gardner now. That doesn't change a thing.

拉拢她，加上你的新面孔，大门就为你打开了。
Get her on your team, get your new face, doors will open.

你会成为大明星的，只要一眨眼的工夫。”“没有什么大明星，布拉德利，因为我不会再过去了，我也不要什么门为我打开，除非是因为我的音乐。
It'll be big league, five seconds flat.’ ‘It won't be big-league anything, Bradley, because I'm not going over there again, and I don't want any doors opening for me other than ones that open because of my music.

我不相信你以前说的那些话，我不相信什么计划不计划的……”
And I don't believe what you said before, I don't believe this crap about a scheme . . .’

“你别讲得这么激动。
‘I don't think you should be expressing yourself so emphatically.

我很担心你脸上的线。”
I'm very concerned about those stitches ...’

“布拉德利，很快你就不用再担心我脸上的线了，知道为什么吗？
‘Bradley, very soon you won't have to be concerned about my stitches at all, because you know what?

我要把这副木乃伊面具拆下来，我要把手指伸到嘴里去，使劲拉我的脸，能拉成什么样就拉成什么样。
I'm going to pull off this mummy mask and I'm going to put my fingers into the corners of my mouth and yank my face into every kind of stretchy combination possible!

你听到了吗，布拉德利？”
Do you hear me, Bradley?’

我听到他叹了口气，然后说：“好吧，冷静。
I heard him sigh. Then he said:‘Okay, calm down. Just calm down.

冷静。你最近压力太大。
You've been under a lot of stress lately.

我可以理解。
It's understandable.

如果你现在不想见到琳迪，如果你想让这么好的机会白白溜走，好吧，我理解你的立场。
If you don't want to see Lindy right now, if you want to let gold go floating by, okay, I understand your position.

但是要礼貌，好吗？
But be polite, okay?

找个好借口。
Make a good excuse.

别断了后路。”
Don't burn any bridges.’

跟布拉德利通完电话以后，我感觉好多了，过了一个相当惬意的晚上，看了半部电影，然后听比尔·埃文斯的CD。
I felt a lot better after this talk with Bradley, and had a reasonably contented evening, watching half a movie, then listening to Bill Evans.

第二天早餐过后，鲍里斯医生和两个护士过来，看似很满意就离开了。
The next morning after breakfast, Dr Boris came in with two nurses, seemed satisfied and left.

不久之后，十一点左右，有人来看望我——一个叫李的鼓手，几年前我在圣地亚哥的一支室内乐队里和他共事过。
A little later, around eleven, I had a visitor – a drummer called Lee who I'd played with in a house band in San Diego a few years ago.

布拉德利也是他的经纪人，让他过来看我。
Bradley, who's also Lee's manager, had suggested he come by.

李是个不错的家伙，我很高兴见到他。
Lee's okay and I was pleased to see him.

他待了一个小时左右，我们交换彼此都认识的朋友的新闻，谁在哪个乐队，谁收拾行李去了加拿大或者欧洲。
He stayed for an hour or so, and we swapped news of mutual friends, who was in which band, who'd packed their bags and gone to Canada or to Europe.

“好多老队友都走了，不在了，太可惜了，”他说。
‘It's too bad how so many of the old team aren't around any more,’ he said.

“大家本来相处得很愉快，可转眼你就不知道对方身在何处了。”
‘You have great times together, next thing you don't know where they are.’

他聊了聊他最近接的活，我们回忆了在圣地亚哥的一些时光，聊得很开心。
He told me about his recent gigs, and we laughed over some memories from our San Diego days.

就在他的来访接近尾声时，他说道：
Then towards the end of his visit, he said:

“那杰克·马弗尔呢？
‘And what about Jake Marvell?

你怎么解释？
What do you make of it?

世界真奇怪，不是吗？”
Strange world, ain't it?’

“是很奇怪，”我说。
‘It's strange all right,’ I said.

“可话说回来，杰克一直是个好乐手。
‘But then again, Jake was always a good musician.

他现在的成就是他应得的。”
He deserves what he's getting.’

“是，可还是奇怪啊。
‘Yeah, but it's strange.

记得那时候的杰克吗？
Remember how Jake was back then?

在圣地亚哥时？
In San Diego?

史蒂夫，你随便哪一天晚上都有可能把他赶下台去。
Steve, you could have blown him off the stage every night of the week.

现在看看他。
And now look at him.

纯粹是运气还是其他？”
Is that just luck or what?’

“杰克一直是个好人，”我说，“就我而言，看见任何一个萨克斯手得到认可都是好的。”
‘Jake was always a nice guy,’ I said. ‘And as far as I'm concerned, it's good to see any sax player getting recognition.’

“认可是没错，”李说。
‘Recognition's right,’ Lee said.

“而且还就在这家酒店。
‘And right here in this hotel too.

我找找，我带着呢。”
Let me see, I've got it here.’

他在包里找了一通，掏出一份皱巴巴的《洛杉矶周报》。
He rummaged in his bag and produced a tattered copy of LA Weekly.

“找到了，在这里。
‘Yeah, here it is.

西蒙——韦斯伯里音乐奖。
The Simon and Wesbury Music Awards.

年度最佳爵士乐手。
Jazz Musician of the Year.

杰克·马弗尔。
Jake Marvell.

看看，什么时候举行？
Let's see, when is this fucker?

明天在楼下舞厅。
Tomorrow down in the ballroom.

你可以溜达下去参加颁奖仪式。”
You could take a stroll down those stairs and attend the ceremony.’

他放下报纸，摇了摇头。
He put down the paper and shook his head.

“杰克·马弗尔。
‘Jake Marvell.

年度最佳爵士乐手。
Jazz Musician of the Year.

谁想得到呢，啊，史蒂夫？”
Who'd have thought it, eh, Steve?’

“我想我是不可能下楼的，”我说。
‘I guess I won't make it downstairs,’ I said.

“但我会记得举杯祝贺的。”
‘But I'll remember to raise a glass to him.’

“杰克·马弗尔。
‘Jake Marvell.

天啊，这世界是不是疯了？”
Boy, is this a screwed-up world or what?’

午饭后大约一个小时，电话铃响了，是琳迪。
About an hour after lunch, the phone rang and it was Lindy.

“棋盘摆好了，亲爱的，”她说。
‘The chess set's all laid out, sweety,’ she said.

“过来玩吧？
‘You ready to play?

别说不行，我无聊得快发疯了。
Don't say no, I'm going crazy here with boredom.

哦，别忘了带CD过来。
Oh, and don't forget now, bring those CDs.

我太想听你的演奏了。”
I'm just dying to hear your playing.’

我放下电话，坐在床边，想不通刚才为什么没有更加坚定自己的立场。
I put down the phone, then sat on the edge of the bed trying to figure out how it was I hadn't stood my ground better.

我甚至连暗示说“不”都没有。
In fact, I hadn't put up even a hint of a ‘no’.

也许我就是没有骨气。
Maybe it was plain spinelessness.

也有可能我虽然嘴上不承认，但其实认同了布拉德利的话。
Or maybe I'd taken on board much more of Bradley's argument on the phone than I'd admitted.

可是现在没时间想这些了，我得赶紧决定我的哪些CD最有可能感动她。
But now there wasn't time to think about it, because I had to decide which of my CDs were most likely to impress her.

前卫的是肯定不行的，比如去年我在旧金山跟一群电子乐手合录的那些。
The more avant-garde stuff was definitely out, as was the stuff I'd recorded with the electro-funk guys in San Francisco last year.

最后，我选了一张CD，换上干净的衬衫，再把晨衣披上，到隔壁去。
In the end, I chose just the one CD, changed into a fresh shirt, put my dressing gown back over the top and went next door.

琳迪也穿着晨衣，可她穿着这身衣服去参加个电影首映礼也没多大问题。
She too had on a dressing gown, but it was the kind she could have worn to a movie premiere without too much embarrassment.

棋盘确实已经在矮矮的玻璃桌上摆好了。我们像上次那样面对面坐下，开始下棋。
Sure enough, the chess set was there on the low glass table, and we sat down on opposite sides like before and began a game.

大概是因为有事可做，这次的气氛比上次轻松多了。
Maybe because we had something to do with our hands, things felt much more relaxed than the last time.

我们边下棋边东聊西聊：电视节目啦、她最喜欢的欧洲城市啦、中国菜啦。这次没有像上次那样提到很多人的名字，她似乎也比上次安静许多。
As we played, we found ourselves talking about this and that: TV shows, her favourite European cities, Chinese food. There was far less name-dropping this time round, and she seemed much calmer.

下着下着，她突然说道：
At one point she said:

“你知道我怎么没让自己在这个地方待到疯掉吗？
‘You know what I do to stop myself going crazy in this place?

我的秘诀？
My big secret?

我来告诉你，可你不能说出去，对格雷西也不能说，好吗？
I'll tell you, but not a word, not even to Gracie, promise?

我的秘诀就是半夜出去散步。
What I do is go out for midnight walks.

只在这栋楼里，但是楼很大，可以走个不停。
Just inside this building, but it's so vast you can walk around forever.

而且夜深人静的时候真是太不可思议了。
And in the dead of night, it's amazing.

昨天晚上我走了有一个小时？
Last night I was out there maybe a whole hour?

你也得当心，还是一直都有工作人员在走来走去，但是我从来没有被人撞见。
You have to be careful, there's still staff roving around all the time, but I've never been caught.

我一听到动静就跑开躲起来。
I hear anything at all, I run away and hide somewhere.

有一次清洁工瞥见了我，但是我马上躲到阴影里去了！
Once these cleaning guys saw me for a second, but like that I was away into the shadows!

太刺激了。
It's so exciting.

整个白天你是个囚犯，到了晚上，你就好像完全自由了，真的是太好玩了。
All day you're this prisoner, then it's like you're completely free, it's truly wonderful.

哪天晚上我带你一起去，亲爱的。
I'm gonna take you with me some night, sweety.

我带你看好东西。
I'll show you great things.

酒吧、餐厅、会议室，还有很棒的舞厅。
The bars, the restaurants, conference rooms.

一个人也没有，又空又黑。
Wonderful ballroom.

我还发现了一个最有意思的地方，一间顶层公寓，我想以后是总统套房？
And there's no one there, everything's just dark and empty.

建了一半，可被我找到了，我还进得去。
And I discovered the most fantastic place, a kind of penthouse, I think it's gonna be a presidential suite?

我待在那里，二十分钟，半个小时，在那里想事情。
They're halfway through building it, but I found it and I was able to walk right in, and I stayed there, twenty minutes, half an hour, just thinking things over.

嘿，史蒂夫，这样对吗？
Hey, Steve, is this right?

我可以这样走，吃掉你的皇后吗？”
I can do this and take your queen?’

“哦。
‘Oh.

对，我想是。
Yeah, I guess so.

我没看见。
I didn't see that.

嘿，琳迪，你说你不会下棋，可实际上你挺行的嘛。
Hey, Lindy, you're a lot smarter at this than you let on. Now what am I supposed to do?’

现在我要怎么走呢？”
‘All right, I tell you what.

“好吧，听我说。你是客人，而且听我说话确实让你分心了。我就假装没看见。
Since you're the guest, and you were obviously distracted by what I was saying, I'm gonna pretend I never saw it.

我是不是很好？
Isn't that nice of me?

对了，史蒂夫，我不记得问没问过你。
Say, Steve, I can't remember if I asked you this before.

你结婚了吧？”
You're married, right?’

“结了。”
‘That's right.’

“她对这件事怎么看？
‘So what does she think of all this?

我的意思是这不便宜。
I mean, this isn't cheap.

用这些钱她可以买好几双鞋。”
Quite a few pairs of shoes she could buy with this kind of money.’

“她同意这件事。
‘She's okay about it.

事实上，这事最初是她的想法。
In fact, this was her idea in the first place.

看看现在是谁不专心了？”
Look who's not paying attention now.’

“哦，该死。
‘Oh hell.

反正我下得很臭。
I'm such a lousy player anyway.

我不是要多管闲事，可她经常来看你吗？”
Say, I don't mean to be nosy, but does she come visit you much?’

“她一次也没来过。
‘Actually she hasn't been here at all.

可这是我们的共识，在我来这里之前。”“哦？”
But that was always the understanding we had, before I came in here.’

她好像没听懂，我就说：“是挺奇怪，我知道。
‘Yeah?’

可我们说好了要这样。”
She seemed puzzled so I said:‘It might sound odd, I know, but that's the way we wanted to do it.’

“好吧。”
‘Right.’

过了一会儿，她说道：“那是不是说没人来看你呢？”
Then after a while she said:‘So does that mean no one comes to visit you here?’

“有人来看我。
‘I get visitors.

其实今天早上就有。
Matter of fact, someone called this morning.

我以前共事的乐手。”
Musician I used to work with.’

“哦，是吗？
‘Oh yeah?

那太好了。
That's good.

亲爱的，我一直都搞不清楚马怎么走。
You know, sweety, I've never been sure how these knights move.

你要是发现我走错了就告诉我，好吗？
If you see me do something wrong, you just say, okay?

我不是有意要作弊的。”
It's not me trying to pull a fast one.’

“好的。”
‘Sure.’

然后我说道，“今天来看我的那家伙给我带来一条新闻。
Then I said:‘The guy who came to see me today, he told me some news.

有点奇怪。
It was kind of strange.

挺巧的。”
A coincidence.’

“嗯哼？”
‘Yeah?’

“几年前我们认识了一个萨克斯手，在圣地亚哥，一个叫杰克·马弗尔的人。
‘There's this saxophone player we both knew a few years back, in San Diego, guy called Jake Marvell.

你可能听说过他。
Maybe you've heard of him.

如今他是个明星了。
He's big-league now.

可那个时候，我们认识他的时候，他还默默无闻。
But back then, when we knew him, he was nothing. In fact, he was a phoney.

但他其实是个骗子、冒牌货。从来都找不着调。
What you'd call a bluffer. Never knew his way around the keys properly.

最近我也听过他的演出，好几次，没有比以前进步。
And I've heard him recently, plenty of times, and he hasn't gotten any better.

可他交了几次好运，如今成了红人了。
But he's had a few breaks and now he's considered hot.

我向你发誓他没有比以前好到哪儿去，一点也没有。
I swear to you he's not one bit better than he used to be, not one bit.

可你知道是什么新闻吗？
And you know what this news was?

就是这家伙，杰克·马弗尔，明天要参加一个盛大的音乐奖颁奖礼，就在这家酒店。
This same guy, Jake Marvell, he's getting a big music award tomorrow, right here in this hotel.

年度最佳爵士乐手。
Jazz Musician of the Year.

真是疯了，你知道吗？
It's just crazy, you know?

那么多的有才华的萨克斯手，他们却决定要把奖给杰克？”
So many talented sax players out there, and they decide to give it to Jake.’

我停了下来，抬头看着棋盘对面的琳迪，笑了笑，用平静了些的语气说道：“你能怎么办？”
I made myself stop, and looking up from the chess board, did a little laugh. ‘What can you do?’ I said, more gently.

琳迪坐了起来，把注意力全都放在我身上。
Lindy was sitting up, her attention fully on me.

“太糟了。
‘That's too bad.

你说这个人根本不优秀？”
And this guy, he's no good, you say?’

“对不起，我有点失态了。
‘I'm sorry, I was kind of out of line there.

他们想颁给杰克一个奖，有什么不可以呢？”
They want to give Jake an award, why shouldn't they?’

“可要是他根本不优秀……”
‘But if he's no good ...’

“他不比其他人差。
‘He's as good as the next guy.

我说说而已。
I was just talking.

对不起，你不用搭理我。”
I'm sorry, you have to ignore me.’

“嘿，对了，”琳迪说道。
‘Hey, that reminds me,’ Lindy said.

“你把你的唱片带来了吗？”
‘Did you remember to bring your music?’

我指了指身旁沙发上的CD。
I indicated the CD beside me on the sofa.

“不晓得你会不会有兴趣。
‘I don't know if it would interest you.

你用不着非得听……”
You don't have to listen ...’

“哦，可我要听，一定要。
‘Oh, but I do, I absolutely do.

来，给我看看。”
Here, let me see it.’

我把CD递给她。
I handed her the CD.

“这是我在帕萨迪纳市时共事的一支乐队。
‘It's a band I played with in Pasadena.

我们演奏经典曲目，老派的摇摆乐，有点巴萨诺瓦。
We played standards, old-fashioned swing, a little bossa nova.

没什么特别的地方，只是你要我带我就带了。”
Nothing special, I just brought it because you asked.’

她端详着CD封面，先拿近了看，又拿开，又拿近，说：“你在封面上吗？
She was examining the CD case, holding it close to her face, then away from her again. ‘So are you in this picture?’

我很好奇你长什么样。
She brought it up close again.

或者我应该说，你以前长什么样。”
‘I'm kind of curious what you look like. Or I should say, what you looked like.’

“右边第二个。
‘I'm second from the right.

穿着一件夏威夷衬衫，拿着烫衣板。”
In the Hawaiian shirt, holding the ironing board.’

“这个？”
‘This one?’

她看了看CD，然后又看着我，说，“嘿，你长得很可爱。”
She stared at the CD, then over at me. Then she said:‘Hey, you're cute.’

可是她的声音很轻，一点儿都不让人信服，我甚至能清楚地感觉到有丝丝的怜悯。
But she said it quietly, in a voice devoid of conviction. In fact, I noted a definite touch of pity there.

然而她马上回过神来。“好，我们来听听看！”
Almost immediately, though, she'd recovered. ‘Okay, so let's hear it!’

她朝音响走去，我说道：“第九首，《你在身旁》，是我的特别曲目。”
As she moved towards the Bang & Olufsen, I said:‘Track number nine. “The Nearness of You”. That's my special track.’

“《你在身旁》来了。”
‘“The Nearness of You” coming up.’

我是经过一番思考才选了这首歌的。
I'd settled on this track after some thought.

这支乐队里的成员水平很高。
The musicians in that band had been top-notch.

作为个人我们都有更加激进的理想，但是我们组了这么个乐队，专门演奏一些优秀的主流作品，晚餐食客们喜欢听的那种。
Individually we'd all had more radical ambitions, but we'd formed the band with the express purpose of playing quality mainstream material, the sort the supper crowd would want.

我们演奏的《你在身旁》——我的萨克斯贯穿整首歌——并非完全颠覆托尼·加德纳的版本，但是我总是引以为豪。
Our version of “The Nearness of You” – which featured my tenor all the way through – wasn't a hundred miles from Tony Gardner territory, but I'd always been genuinely proud of it.

你可能会想这首歌的各种版本你都听过了。
Maybe you think you've heard this song done every way possible.

好吧，听听我们的。
Well, listen to ours.

比如说，听听副歌第二段。
Listen, say, to that second chorus.

或是中间的八个小节，乐队从Ⅲ-5和弦升到Ⅵ x-9和弦时，我的萨克斯一直高上去，期间的跨度是你无法想象的，然后停留在那甜蜜的、非常温柔的降B大调。
Or to that moment as we come out of the middle eight, when the band go III-5 to VIx-9 while I rise up in intervals you'd never believe possible and then hold that sweet, very tender high B-flat.

我觉得我的演绎赋予了歌曲不一样的味道，渴望、悔恨，你以前一定没有听过。
I think there are colours there, longings and regrets, you won't have come across before.

因此可以说，我有信心这首歌能让琳迪满意。
So you could say I was confident this recording would meet with Lindy's approval.

头一两分钟，她似乎很享受。
And for the first minute or so, she looked to be enjoying herself.

把CD放进去以后她就站在原地，像上次放她丈夫的唱片时那样开始随着缓缓的节拍恍恍惚惚地摇摆起来。
She'd stayed on her feet after loading the CD, and just like the time she'd played me her husband's record, she began swaying dreamily to the slow beat.

可是渐渐地，她的动作越来越小，最后站在那里不动了，背对着我，低着头，像是在专心思考。
But then the rhythm faded from her movements, until she was standing there quite still, her back to me, head bent forward like she was concentrating.

一开始我并不觉得这是什么坏兆头。
I didn't at first see this as a bad sign.

可歌还没播完，她就走回来坐下，这时我才意识到有哪里不对了。
It was only when she came walking back and sat down with the music still in full flow, I realised something was wrong.

隔着绷带，我当然没办法看到她的表情，可是她跌倒在沙发里的样子可不好看，像个紧绷绷的模特衣架。
Because of the bandages, of course, I couldn't read her expression, but the way she let herself slump into the sofa, like a tense mannequin, didn't look good.

歌播完了，我拿起桌上的遥控器，把音响整个儿关掉了。
When the track ended, I picked up the remote and turned it all off.

琳迪还是那么坐着，姿势僵硬、难看。
For what felt a long time, she stayed the way she was, stiff and awkward.

似乎过了很久，她才稍微振作起来，伸手抚弄一颗棋子。
Then she hauled herself up a little and began fingering a chess piece.

“很好听，”她说。
‘That was very nice,’ she said.

“谢谢你给我听这个。”
‘Thank you for letting me hear it.’

很客套，而她似乎并不在意她的话说得这么没有诚意。
It sounded formulaic, and she didn't seem to mind that it did.

“这首歌大概不合你的胃口。”
‘Maybe it wasn't quite your kind of thing.’

“没有，没有。”
‘No, no.’

她的声音变得阴沉、冷淡。
Her voice had become sulky and quiet.

“很不错。
‘It was just fine.

谢谢你给我听这个。”
Thank you for letting me hear it.’

说着她走出手里的棋子，说道，“轮到你了。”
She put the chess piece down on a square, then said:‘Your move.’

我看着棋盘，努力回忆我们下到哪里。
I looked at the board, trying to remember where we were.

片刻后，我轻声问道：“也许那首歌，那首歌让你产生特别的联想？”
After a while, I asked gently:‘Maybe that particular song, it has special associations for you?’

她抬起头来，我能感觉到绷带后面的怒气。
She looked up and I sensed anger behind her bandages.

可她还是用冷冷的声音说道：“那首歌？
But she said in the same quiet voice:‘That song?

没有什么联想。
It has no associations.

没有。”
None at all.’

突然她笑了起来——短促的、冷酷的笑。
Suddenly she laughed – a short, unkind laugh.

“哦，你是说有关他的联想，有关托尼的？
‘Oh, you mean associations with him, with Tony?

没有，没有。
No, no.

他从没唱过那首歌。
It was never one of his numbers.

你吹得很好。
You play it very nicely.

很专业。”
Really professional.’

“很专业？
‘Really professional?

什么意思？”
What's that supposed to mean?’

“意思就是……就是很专业。
‘I mean ... that it's really professional.

我是在表扬你。”
I mean it as a compliment.’

“专业？”
‘Professional?’

我站了起来，走过去把碟从音响里拿出来。
I got to my feet, crossed the room and got the disc out of the machine.

“你生什么气？”
‘What are you so mad about?’

她的声音仍旧冷冰冰的。
Her voice was still distant and cold.

“我说错话了？
‘I say something wrong?

抱歉。
I'm sorry.

我没有恶意。”
I was trying to be nice.’

我走回桌子边，把碟放进盒子里，但没有坐下。
I came back to the table, put the disc back in its case, but didn't sit down.

“棋还下吗？”她问。
‘So we going to finish the game?’ she asked.

“你若不介意，我有一些事情得处理。
‘If you don't mind, I've got a few things I have to do.

电话啦，文件啦。”
Phone calls. Paperwork.’

“你生什么气？
‘What are you so mad about?

我不明白。”
I don't understand.’

“我没有生气。
‘I'm not mad at all.

时间晚了，就这样。”
Time's getting on, that's all.’

她终于站起来，送我到门口。我们冷冷地握手道别。
She at least got to her feet to walk me to the door, where we parted with a cold handshake.

我说过手术以后我的睡眠规律被打乱了。
I've said already how my sleep rhythm had been screwed up after the surgery.

那天晚上我突然觉得累，早早睡觉，酣睡了几个小时，半夜醒来，就睡不着了。
That evening I became suddenly tired, went to bed early, slept soundly for a few hours, then woke in the dead of night unable to go back to sleep.

我躺了一会儿就起来开电视。
After a while I got up and turned on the TV.

我发现一部小时候看的电影，就拖了把椅子过来，声音开得小小的，把剩下的看完。
I found a movie I'd seen as a kid, so pulled up a chair and watched what remained of it with the volume down low.

看完了以后，我又看两名传教士在一群叫嚣怂恿的看客面前吵来吵去。
When that was over I watched two preachers shouting at each other in front of a baying audience.

总的说来我很满意。
All in all, I was contented.

我感觉惬意，觉得自己远离了外面的世界。
I felt cosy and a million miles from the outside world.

所以当电话响起时，我的心脏都快跳出来了。
So my heart just about jumped out of my chest when the phone rang.

“史蒂夫？
‘Steve?

是你吗？”
That you?’

是琳迪。
It was Lindy.

她的声音怪怪的，像是喝了酒。
Her voice sounded odd and I wondered if she'd been drinking.

“是我。”
‘Yeah, it's me.’

“我知道很晚了。
‘I know it's late.

可是我刚才路过的时候看见门缝底下有光。
But just now, when I was passing, I saw your light on under your door.

我想你和我一样睡不着。”
I supposed you were having trouble sleeping, just like me.’

“我想是吧。
‘I guess so.

如今很难正常起居。”
It's difficult keeping regular hours.’

“是啊。
‘Yeah.

肯定。”
It sure is.’

“没事吧？”
‘Is everything okay?’

我问道。
I asked.

“没事。
‘Sure.

都好。
Everything's good.

好得很。”
Very good.’

此时我听出来她并没有喝醉，可我仍搞不清楚她是怎么了。
I realised now she wasn't drunk, but I couldn't put my finger on what was up with her.

她也不一定就是喝醉了——可能只是睡不着，有话想跟我说，所以兴奋。
She probably wasn't high on anything either – just peculiarly awake and maybe excited about something she had to tell me.

“真的没事？”
‘You sure everything's okay?’

我又问了一遍。
I asked again.

“没事，真的，可是……听着，亲爱的，我有个东西，我有个东西想给你。”
‘Yeah, really, but . . . Look, sweety, I have something here, something I want to give to you.’

“哦？
‘Oh?

是什么呢？”
And what might that be?’

“我不想说。
‘I don't want to say.

我要给你一个惊喜。”
I want it to be a surprise.’

“有意思。
‘Sounds interesting.

我什么时候过去拿吧，嗯，早饭以后？”
I'll come and get it, maybe after breakfast?’

“我希望你现在就过来拿。
‘I was kinda hoping you'd come and get it now.

我是说，东西在这里，而且你醒着，我也醒着。
I mean, it's here, and you're awake and I'm awake. I know it's late, but . . . Listen, Steve, about earlier, about what happened.

我知道很晚了，可是……听着，史蒂夫，今天白天，下午的事，我觉得我欠你一个解释。”
I feel I owe you an explanation.’ ‘Forget it. I didn't mind ...’

“忘了吧。我不介意……”
‘You were mad at me because you thought I didn't like your music.

“你以为我不喜欢你的音乐，所以生我的气。不是的。
Well, that wasn't true. That was the reverse of the truth, the exact reverse.

不是这样的，恰恰相反。你给我听的，那个版本的《你在身旁》，我怎么也不能把它赶出脑海。
What you played me, that version of “Nearness of You”? I haven't been able to get it out of my head.

不，我指的不是头脑，我指的是心。
No, I don't mean head, I mean heart.

我怎么也不能把它赶出心扉。”
I haven't been able to get it out of my heart.’

我不知道该说什么，不等我回答，她又说道：
I didn't know what to say, and before I could think of anything she was talking again.

“你过来吗？
‘Will you come over?

现在？
Right now?

我好好地解释给你听。
Then I'll explain it all properly.

而且最重要的是……不，不，我现在不能说。
And most important . . . No, no, I'm not saying.

我要给你一个惊喜。
It's gonna be a surprise.

你过来就知道了。
Come on over and you'll see.

把你的CD再带过来。
And bring your CD again.

好吗？”
Will you do that?’

琳迪一开门就把CD从我手里拿过去，好像我是送货的，可是接着她就抓住我的手腕，把我拉进去。她还穿着那件漂亮的晨衣，但是看起来没有之前那么完美了：衣服一边高一边低，后脑勺领口附近的绷带钩住了一团绒毛。
She took the CD from me as soon as she opened the door, like I was the delivery boy, but then grasped me by the wrist and led me in. Lindy was in the same glamorous dressing gown as before, but she looked a little less immaculate now: one side of the gown was hanging lower than the other, and a woolly dangle of fluff was caught on the back of her bandages near the neckline.

“我想你刚刚夜游回来。”我说。
‘I take it you've been on one of your nocturnal walks,’ I said.

“你醒着我太高兴了。
‘I'm so glad you're up.

我不知道我是不是能等到早上。
I don't know if I could have waited till morning.

好了，听着，就像我刚刚说的，我要给你一个惊喜。
Now listen, like I told you, I have a surprise.

我希望你会喜欢，我想你会喜欢的。
I hope you're gonna like it, I think you will.

可我要你先坐下来。
But first I want you to make yourself comfortable.

我们再听一遍你那首歌。
We're gonna listen to your song again.

我看看，是第几首？”
Let me see, which track was it?’

我在老地方坐下，看着她摆弄音响。
I sat down on my usual sofa and watched her fussing with the hi-fi.

屋里的灯光柔和，空气凉爽宜人。
The lighting in the room was soft, and the air felt pleasantly cool.

接着《你在身旁》的音乐高声响了起来。
Then “The Nearness of You” came on at high volume.

“不会吵到别人吗？”
‘Don't you think this might disturb people?’

我说。
I said.

“管他的。
‘To hell with them.

我们付了这里一大笔钱，其他人不关我们的事。
We pay enough for this place, it's not our problem.

好了，嘘！
Now shhh!

听，听！”
Listen, listen!’

她开始像之前那样随着音乐摇摆，只是这次她没有中途停下来，而且随着音乐的进行，她似乎越来越陶醉，张开手臂，像是在与一个假想的舞伴共舞。
She began to sway to the music like before, only this time she didn't stop after a verse. In fact, she seemed to get more lost in the music the longer it went on, holding out her arms like she had an imaginary dance partner.

音乐停止以后，她关掉CD，一动不动地背对着我站在房间的尽头。
When it finished, she turned it off and remained very still, standing at the end of the room with her back to me.

她那样子站了似乎很长一段时间才朝我走过来。“我不知道该说什么，”她说道。
She stayed like that for what felt like a long time, then finally came towards me. ‘I don't know what to say,’ she said.

“太出色了。
‘It's sublime.

你是个很棒、很棒的乐手。
You're a wonderful, wonderful musician.

你是个天才。”
You're a genius.’

“呃，谢谢。”
‘Well, thank you.’

“我第一次听就知道了。
‘I knew it the first time.

是真的。
That's the truth.

所以今天下午我才会有那样的反应。假装不喜欢，假装讨厌？”
That's why I reacted the way I did. Pretending not to like it, pretending to be snotty?’

她坐了下来，看着我，叹了口气。
She sat down facing me and sighed.

“以前托尼总叫我别这样。我老是这样，怎么也改不掉。
‘Tony used to pull me up about it. I've always done it, it's something I don't ever seem to get over.

我遇见一个，你知道，一个真正的天才，一个天资过人的人，我就忍不住，我的第一反应就是像我今天下午对你的那样。
I run into a person who's, you know, who's really talented, someone who's just been blessed that way by God, and I can't help it, my first instinct is to do what I did with you.

这就是，我不知道，我想是嫉妒吧。
It's just, I don't know, I guess it's jealousy.

就好像有时候一群女人，姿色平庸，一个漂亮的女人走了进来，就会遭到其他人的憎恨，想把她的眼睛挖出来。
It's like you see these women sometimes, they're kind of plain? A beautiful woman comes into the same room, they hate it, they want to claw her eyes out.

我遇见像你这样的人时就是这样。
That's the way I am when I meet someone like you.

特别是不期而遇时，像今天这样，我没有准备。
Especially if it's unexpected, the way it was today and I'm not ready.

我是说，一分钟前我以为你只是一个普通人，突然间你……你不再是普通人了，你变成另一个人了。
I mean, there you were, one minute I'm thinking you're just one of the public, then suddenly you're . . . well, something else.

你明白我在说什么吗？
You know what I'm saying?

总之我试着跟你解释为什么今天下午我会表现得那么坏。
Anyway, I'm trying to tell you why I behaved so badly earlier on.

你完全有理由生我的气。”
You had every right to be mad at me.’

一时间我们都没有说话，午夜的寂静笼罩下来。
The late-night silence hung between us for a while.

过了许久，我说道：“啊，谢谢，谢谢你跟我说这些。”
‘Well, I appreciate it,’ I said eventually. ‘I appreciate you telling me this.’

琳迪突然站了起来。
She stood up suddenly.

“现在，我要给你的惊喜！
‘Now, the surprise!

在那里等着，别动。”
Just wait there, don't move.’

她走进隔壁的房间，传来开、关抽屉的声音。
She went through into the adjoining room and I could hear her opening and shutting drawers.

她回来的时候，胸前双手握着一件东西，然而她用丝手帕把东西盖着，我不知道她拿的是什么。
When she came back, she was holding something in front of her with both hands, but I couldn't see what the something was, because she'd thrown a silk handkerchief over it.

她在房间的中央站住了。
She halted in the middle of the room.

“史蒂夫，我要你过来领。
‘Steve, I want you to come and receive this.

这是一个颁奖仪式。”
This is going to be a presentation.’

虽然不知道她要干什么，我还是站了起来，走过去。
I was puzzled, but got to my feet.

她揭开手帕，伸手递给我一个亮晶晶的铜像。
As I went to her, she pulled off the handkerchief and held towards me a shiny brass ornament.

“你完全配得上这个奖。
‘You thoroughly deserve this.

这个奖是你的了。
So it's yours.

年度最佳爵士乐手。
Jazz Musician of the Year.

也许是史上最佳。
Maybe of all time.

恭喜你。”
Congratulations.’

她把铜像放到我手中，透过纱布轻轻地亲了亲我的脸颊。
She placed it in my hands and kissed me lightly on the cheek through the crêpe.

“啊，谢谢。
‘Well, thanks.

确实是个惊喜。
This is a surprise.

嘿，真好看。
Hey, this looks pretty.

这是什么？
What is it?

鳄鱼吗？”
An alligator?’

“鳄鱼？
‘An alligator?

拜托！
Come on!

是一对可爱的小天使在接吻。”
It's a pair of cute little cherubs kissing each other.’

“哦，是，我看出来了。
‘Oh yeah, I can see it now.

啊，谢谢你，琳迪。
Well, thanks, Lindy.

我不知道该说什么。
I don't know what to say.

真的很漂亮。”
It's really beautiful.’

“鳄鱼！”
‘An alligator!’

“对不起。
‘I'm sorry.

只是这个小家伙把腿伸得这么老长。
It's just the way this guy has his leg stretched all the way out.

可现在我看出来了。
But I see now.

真的很漂亮。”
It's really beautiful.’

“啊，奖是你的了。
‘Well, it's yours.

你应该得到这个奖。”
You deserve it.’

“我很感动，琳迪。
‘I'm touched, Lindy.

真的。
I really am.

这下面写什么？
And what does this say down here?

我没戴眼镜。”
I don't have my glasses.’

“写着‘年度最佳爵士乐手’啊。
‘It says “Jazz Musician of the Year”. What else would it say?’

不然还能写什么？”
‘That's what it says?’

“真的？”
‘Sure, that's what it says.’

“是啊，当然是真的。”
I went back to the sofa, holding the statuette, sat down and thought a little.

我握着铜像走回沙发，坐下来想了一会儿，说：“告诉我，琳迪。
‘Say, Lindy,’ I said eventually.

你刚刚给我的东西。
‘This item you've just given me.

不可能是你在夜里散步的时候碰巧拿到的吧？”
It's not possible, is it, you came across it on one of your midnight walks?’

“是啊。
‘Sure.

当然可能了。”
Sure it's possible.’

“这样。
‘I see.

那不可能是，是真的奖杯吧？
And it's not possible, is it, this is the real award?

我指他们要颁给杰克的那个奖？”
I mean the actual gong they were going to hand to Jake?’

琳迪没有马上回答，而是静静地站了一会儿才答道：
Lindy didn't reply for a few seconds, but kept standing there very still. Then she said:

“当然是真的了。
‘Of course it's the real thing.

给你一个旧破烂有什么意义呢？
What would be the point, giving you any old junk?

本来会发生一件不公平的事，如今公正得到了伸张。
There was an injustice about to be committed, but now justice has prevailed.

这才是关键。
That's all that matters.

嘿，亲爱的，好了。
Hey, sweety, come on.

你知道你才应该得到这个奖。”
You know you're the one who deserves this award.’

“你这么说我很感激。
‘I appreciate your viewpoint.

只是……啊，这有点像偷窃。”
It's just that . . . well, this is kind of like stealing.’

“偷窃？
‘Stealing?

不是你自己说那家伙一点儿都不优秀吗？
Didn't you say yourself this guy's no good?

是个冒牌货？
A fake?

可你是个天才。
And you're a genius.

是谁偷了谁的？”
Who's trying to steal from who here?’

“琳迪，你到底是在哪里拿到这个东西的？”
‘Lindy, where exactly did you come across this thing?’

她耸耸肩。
She shrugged.

“一个地方。
‘Just some place.

我去的一个地方。
One of the places I go.

可能是个办公室。”
An office, you'd call it maybe.’

“今天晚上？
‘Tonight?

你今天晚上拿的？”
You picked it up tonight?’

“当然是今天晚上拿的。
‘Of course I picked it up tonight.

昨天晚上我又不知道这个奖。”
I didn't know about your award last night.’

“没错，没错。
‘Sure, sure.

那么是一个小时前，对吗？”
So that was an hour ago, would you say?’

“一小时。
‘An hour.

也有可能是两小时。
Maybe two hours.

谁知道？
Who knows?

我出来了一段时间，去了一会儿我的总统套房。”
I was out there some time. I went to my presidential suite for a while.’ ‘Jesus.’

“天啊。”
‘Look, who cares?

“听着，谁会在意？
What are you so worried about?

你担心什么呢？他们丢了一个奖杯可以再去拿一个。
They lose this one, they can just go get another one.

说不定他们有一整柜的奖杯。
They've probably got a closet full somewhere.

我给你一个你应得的东西。
I presented you with something you deserve.

你不会不要吧，史蒂夫？”
You're not going to turn it down, are you, Steve?’

“我不是不要，琳迪。
‘I'm not turning it down, Lindy.

这份好意，这份荣誉，等等，我都接受，我真的很高兴。
The sentiment, the honour, all of that, I accept it all, I'm really happy about it.

可是这个，这个真的奖杯，我们得还回去。
But this, the actual trophy. We're going to have to take it back.

我们得把它放回原处。”“见鬼！
We'll have to put it back exactly where you found it.’

谁会在意？”
‘Screw them! Who cares?’

“琳迪，好好想想。
‘Lindy, you haven't thought this through.

事情被发现了你会怎么样？
What will you do when this gets out?

你能想象得到媒体对这件事会怎么说吗？
Can you imagine what the press will do with this? The gossip, the scandal?

你的崇拜者们会怎么说？
What will your public say?

快点。
Now come on.

我们现在就还回去，在大家还没起来之前。
We're going out there right now before people start waking up.

告诉我你在哪里找到这个东西的。”
You're going to show me exactly where you found this thing.’

她突然像个做错事的小孩，叹了口气，说：“我想你是对的，亲爱的。”
She suddenly looked like a kid who'd been scolded. Then she sighed and said:‘I guess you're right, sweety.’

说好了还回去以后，琳迪变得对这个奖杯特别恋恋不舍，一直把铜像紧紧地捏在胸前。我们匆匆地走过寂静的走廊，偌大的旅馆都在沉睡中。
Once we'd agreed to take it back, Lindy became quite possessive about the award, holding it close to her bosom all the time we hurried through the passageways of the vast, sleeping hotel.

琳迪带着我走下隐蔽的楼梯和员工通道，走过桑拿浴室和自动贩卖机。我们一个人也没有看见或者听见。
She led the way down hidden stairways, along back corridors, past sauna rooms and vending machines. We didn't see or hear a soul.

走着走着，琳迪突然小声说道：“这边。”我们推开厚厚的门，走进一个黑咕隆咚的地方。
Then Lindy whispered:‘It was this way,’ and we pushed through heavy doors into a dark space.

我确定周围没有人后就打开从琳迪房里拿的手电筒，照了照四周。
Once I was sure we were alone, I switched on the flashlight I'd brought from Lindy's room and shone it around.

我们在一个舞厅里，可是如果你打算这时候跳舞的话，会发现有餐桌碍事。每张餐桌上都铺着白色亚麻桌布，摆着相应的椅子。
We were in the ballroom, though if you were looking to dance just then, you'd have had trouble with all the dining tables, each one with its white linen cover and matching chairs.

天花板上有一盏华丽的中央吊灯。
The ceiling had a fancy central chandelier.

房间的最里面有一个凸起的台子，幕布遮着，但挺大的，应该可以进行一场相当规模的演出。
At the far end there was a raised stage, probably large enough to put on a fair-sized show, though right now the curtains were drawn across it.

房间的中央搁着一架活动梯子，一台真空吸尘器竖直靠在墙边。
Someone had left a step-ladder in the middle of the room and an upright vacuum cleaner against the wall.

“看来要举行一个派对，”琳迪说。
‘It's going to be some party,’ she said.

“四五百人？”
‘Four hundred, five hundred people?’

我往里面走了走，又用手电筒照了照。
I wandered further into the room and threw the torch beam around some more.

“可能就是这里了。
‘Maybe this is where it's going to happen.

就在这里给杰克颁奖。”
Where they're going to give Jake his award.’

“当然是了。
‘Of course it is.

我发现这个地方”——她举起铜像——“还有其他铜像。
Where I found this’ – she held up the statuette – ‘there were other ones too.

最佳新人，最佳年度R&B专辑，等等这类东西。
Best Newcomer. R&B Album of the Year. That kind of stuff.

是个大活动呢。”
It's going to be a big event.’

虽然手电筒不是很亮，可我的眼睛适应了这里的光线，能把这个地方看得更清楚了。刹那间，我站在那里看着舞台，能想象这个地方明天会是什么样子。
Now my eyes had adjusted, I could see the place better, even though the flashlight wasn't so powerful. And for a moment, as I stood there looking up at the stage, I could imagine the way the place would look later on.

我想象着所有的人穿着盛装，唱片公司的人、知名的活动赞助商、演艺圈的各路明星，大家有说有笑，互相恭维。每当主持人提到某个赞助商的名字，大家奉承地鼓鼓掌；而当得奖人登台时，大家就认真鼓掌了，还夹杂着欢呼声和喝彩声。
I imagined all the people in their fancy clothes, the record-company men, the big-time promoters, the random showbiz celebrities, laughing and praising each other; the fawningly sincere applause every time the MC mentioned the name of a sponsor; more applause, this time with whoops and cheers, when the award winners went up.

我想象着杰克·马弗尔站在台上，手握奖杯，脸上挂着一副自鸣得意的微笑，就像在圣地亚哥他独奏完、接受观众鼓掌时的那种微笑。
I imagined Jake Marvell up on that stage, holding his trophy, the same smug smile he'd always have in San Diego when he'd finished a solo and the audience had clapped.

“也许我们错了。”我说道。
‘Maybe we've got this wrong,’ I said.

“也许没必要把这个还回来。
‘Maybe there's no need to return this.

也许我们应该把它扔到垃圾堆里去。
Maybe we should throw it in the garbage.

和你找到的其他奖杯一起。”
And all the other awards you found with it.’

“哦？”
‘Yeah?’

琳迪糊涂了。
Lindy sounded puzzled.

“你这样想的，亲爱的？”
‘Is that what you want to do, sweety?’

我叹了口气。
I let out a sigh.

“不，不是。
‘No, I guess not.

可是这样做……很痛快，不是吗？
But it would be . . . satisfying, wouldn't it?

把所有的奖杯都扔进垃圾堆里。
All those awards in the garbage.

我敢说所有的得奖人都是冒牌货。
I bet every one of those winners is a fake.

我敢说他们那群人连个热狗面包都做不来。”
I bet there isn't enough talent between the lot of them to fill a hot-dog bun.’

我等着琳迪接我的话，可是她什么也没说。
I waited for Lindy to say something to this, but nothing came.

而当她开口时，她的声音里有一丝与先前不同的语气，严厉的语气。
Then when she did speak, there was some new note, something tighter, in her voice.

“你怎么知道有些得奖人不行？
‘How do you know some of these guys aren't okay?

你怎么知道有些人不配得到他们的奖？”
How do you know some of them don't deserve their award?’

“我怎么知道？”我突然很生气。
‘How do I know?’ I felt a sudden tide of irritation.

“我怎么知道？
‘How do I know?

想想看吧。
Well, think about it.

一个认为杰克·马弗尔是年度最杰出的爵士乐手的评审团，他们会把奖给什么样的人呢？”
A panel that considers Jake Marvell the year's outstanding jazz musician. What other kind of people are they going to honour?’

“可是你怎么知道其他人怎么样？
‘But what do you know about these guys?

甚至是这个杰克。
Even this Jake fella.

你怎么知道他取得这个奖不是他努力来的？”
How do you know he didn't work really hard to get where he has?’

“这算什么话？
‘What is this?

难不成现在你成了杰克最大的粉丝了？”
You're Jake's greatest fan now?’ ‘I'm just expressing my opinion.’

“我只是说说我的想法。”
‘Your opinion? So this is your opinion?

“你的想法？这是你的想法？
I guess I shouldn't be so surprised.

我想我不应该这么惊讶。我差点忘了你是什么人了。”
For a moment there, I was forgetting who you were.’

“你这话是什么意思？
‘What the hell's that supposed to mean?

你怎么敢这么跟我说话？！”
How dare you speak to me that way?!’

我突然意识到我情绪失控了，赶紧说道：“好了，我失态了。
It occurred to me I was losing my grip.

对不起。
I said quickly:‘Okay, I'm out of line.

我们开始找那间办公室吧。”
I'm sorry.

琳迪没有做声。
Now let's go find this office.’

我转过去看着她，光线太暗，我猜不出她在想什么。
Lindy had gone silent, and when I turned to face her, I couldn't see well enough in the light to guess what she was thinking.

“琳迪，办公室在哪儿？
‘Lindy, where's this office?

我们得找到那里。”
We need to find it.’

最后，她终于用拿着雕像的手指向舞厅的后面，然后在我前面穿过那些桌子，仍旧没有说话。
Eventually, she indicated with the statuette towards the back of the hall, then led the way past the tables, still not speaking.

我们走到舞厅的后面，我把耳朵贴在门上听了几秒钟，没有声响，我小心地打开门。
When we were there, I put my ear against the door for a few seconds, and hearing nothing, opened it carefully.

我们到了一个似乎与舞厅平行的狭长的地方。
We were in a long narrow space that seemed to run parallel with the ballroom.

不知哪里有盏昏暗的灯开着，所以我们不用手电筒就能依稀看得见。
A dim light had been left on somewhere, so we could just about make things out without the flashlight.

这里显然不是我们要找的办公室，而像是个餐厅连着厨房的地方。
It was obviously not the office we were after, but some kind of catering-cum-kitchen area.

墙的两边摆着长长的工作台，中间留着一条仅供工作人员取食物的过道。
Long extended work counters ran along both walls, leaving a gangway down the middle wide enough for staff to put final touches to the food.

然而琳迪好像认识这个地方，大踏步朝走道里面走去。
But Lindy seemed to recognise the place and went striding purposefully down the gangway.

走到半中间突然停下来，研究起留在台子上的一个烤盘。
About halfway along, she stopped suddenly to examine one of the baking trays left on the counter.

“嘿，是饼干！”
‘Hey, cookies!’

她的情绪好像恢复了平静。
She seemed completely to have regained her equanimity.

“真可惜都包着玻璃纸。
‘Too bad it's all under cellophane.

我饿扁了。
I'm famished.

看！
Look!

我们看看这底下是什么。”
Let's see what's under this one.’

她又往前走了几步，打开一个穹顶状的大盖子。
She went on a few more steps, to a big dome-shaped lid, and raised it.

“看啊，亲爱的。
‘Look at this, sweety.

真是诱人！”
This looks really good.’

出现在琳迪面前的是一只又肥又大的烤火鸡。
She was leaning over a plump roast turkey.

她没有把盖子盖上，而是小心翼翼地放在火鸡的旁边。
Instead of replacing the lid, she laid it down carefully next to the bird.

“我扯条腿他们会不会介意？”
‘Do you think they'd mind if I pulled off a leg?’

“我想他们会很介意，琳迪。
‘I think they'd mind a lot, Lindy.

可管他呢。”
But what the hell.’

“这腿真大。
‘It's a big baby.

你要和我分吗？”
You want to share a leg with me?’

“不要白不要。”
‘Sure, why not?’

“好。
‘Okay.

来吧。”
Here goes.’

她把手伸向火鸡。
She reached towards the turkey.

可是突然间她直起身子，转向我。
Then suddenly she straightened and turned to face me.

“刚才到底是什么意思？”
‘So what was that supposed to mean back there?’

“什么什么意思？”
‘What was what supposed to mean?’

“你刚才说的话。
‘What you were saying.

说你不应该惊讶。
When you said you weren't surprised.

对我的想法。
About my opinion.

什么意思？”
What was that about?’

“对不起。
‘Look, I'm sorry.

我不是有意冒犯。
I wasn't trying to be offensive.

我只是自言自语。”
Just thinking aloud, that's all.’

“自言自语？
‘Thinking aloud?

干吗不再多自言自语一些？
Well, how about thinking aloud some more?

我说也许有些人配得到他们的奖。这有什么好笑的？”
So I suggest some of these guys may have deserved their awards, why is that a ridiculous statement?’

“我的意思只是这些奖颁错了人。
‘Look, all I'm saying is that the wrong people end up with the awards.

可是你好像不这么认为。
That's all. But you seem to know better.

你觉得不是这样……”
You think that's not what happens . . .’

“其中一些人可能很努力才取得今天的成就。
‘Some of those guys, maybe they worked damn hard to get where they have.

他们需要一点认可。
And maybe they deserve a little recognition.

像你这样的人问题就在于，就因为上天赋予了你们特殊的才华，你们就觉得你们应该应有尽有。
The trouble with people like you, just because God's given you this special gift, you think that entitles you to everything.

你们比我们其他人优秀，你们每次都应该排在前面。
That you're better than the rest of us, that you deserve to go to the front of the line every time.

你们没有看见还有很多其他人不如你们幸运，可是他们很努力赢得社会的认可……”
You don't see there's a whole lot of other people weren't as lucky as you who work really hard for their place in the world . . .’

“那你觉得我没有努力咯？
‘So you don't think I work hard?

你觉得我整天游手好闲？
You think I sit on my ass all day?

我费尽千辛万苦才做出有价值的、优美的音乐，可到头来谁受到认可？
I sweat and heave and break my balls to come up with something worthwhile, something beautiful, then who is it gets the recognition?

杰克·马弗尔！
Jake Marvell!

你这样的人！”
People like you!’

“你该死的敢这么说！
‘How fucking dare you!

我跟这件事有什么关系？
What do I have to do with this?

我今天得奖了吗？
Am I getting an award today?

谁给我颁过他妈的什么奖？
Has anyone ever given me a goddamn award?

我得到过什么？就是在学校，有没有什么唱歌、跳舞还是其他什么玩意的证书？
Have I ever had anything, even in school, one lousy certificate for singing or dancing or any damn thing else?

没有！
No!

什么都没有！
Not a fucking thing!

我总是看着别人，看着你们这些讨厌的家伙上台领奖，你们的父母在台下鼓掌……”
I had to watch all of you, all you creeps, going up there, getting the prizes, and all the parents clapping . . .’

“没得过奖？
‘No prizes?

没得过奖？
No prizes?

看看你！
Look at you!

谁是名人？
Who gets to be famous?

谁住漂亮房子……”
Who gets the fancy houses ...’

就在这时，啪的一声，开关开了，我们俩在刺眼的强光下对视。
At that moment someone flicked a switch and we were blinking at each other under harsh bright lights.

两名男子从我们刚才进来的地方进来，朝我们走过来。
Two men had come in the same way we had, and were now moving towards us.

过道刚好够他们两个人并排走。
The gangway was just wide enough to let them walk side by side.

其中一个黑人大个儿穿着酒店的保安制服，一开始我以为他手里拿着枪，后来看清那是一部对讲机。
One was a huge black guy in a hotel security guard's uniform, and what I first thought was a gun in his hand was a two-way radio.

另一个是个小个子白人，穿着浅蓝色西服，一头黑亮的头发。
Beside him was a small white man in a light-blue suit with slick black hair.

两个人看起来都不怎么友善。
Neither of them looked particularly deferential.

他们在我们面前一两码的地方停下，小个子从上衣里掏出证件。
They stopped a yard or two away, then the small guy took an ID out of his jacket.

“洛杉矶警局的摩根，”他说。
‘LAPD,’ he said. ‘Name's Morgan.’

“晚上好，”我说。
‘Good evening,’ I said.

那个警察和保安一言不发地看着我们。
For a moment the cop and the security guard went on looking at us in silence.

过了一会儿，那个警察问道：
Then the cop asked:

“酒店的客人？”
‘Guests of the hotel?’

“是的，”我说。
‘Yes, we are,’ I said.

“我们是酒店的客人。”
‘We're guests.’

我感觉到琳迪柔软的睡袍擦过我的后背。
I felt the soft material of Lindy's night-gown brush against my back.

接着她拉住我的胳膊，我们肩并肩站着。
Then she'd taken my arm and we were standing side by side.

“晚上好，警官。”她用和平时不一样的、懒洋洋、甜滋滋的声音说道。
‘Good evening, officer,’ she said in a sleepy, honeydew voice quite unlike her usual one.

“晚上好，夫人，”警察说道。
‘Good evening, ma'am,’ the cop said.

“你们这会儿不睡觉是不是有什么特殊原因？”
‘And are you folks up at this time for any special reason?’

我们俩马上抢着回答。
We both started to answer at once, then laughed.

我们笑了，但另外两个人可一点笑容也没有。
But neither of the men laughed or smiled.

“我们睡不着，”琳迪说。
‘We were having trouble sleeping,’ Lindy said.

“所以出来散步。”
‘So we were just walking.’

“出来散步。”
‘Just walking.’

警察借着刺眼的白光环顾了一下四周。
The cop looked around in the stark white light.

“还是找吃的。”
‘Maybe looking for something to eat.’

“是，警官！”
‘That's right, officer!’

琳迪还是尖着嗓门说。
Lindy's voice was still way over the top.

“我们饿了，我相信您晚上有时候也会肚子饿。”
‘We got a little hungry, the way I'm sure you do too sometimes in the night.’

“我想客房服务不够好，”警察说道。
‘I guess room service isn't up to much,’ the cop said.

“是不怎么好，”我说。
‘No, it's not so good,’ I said.

“尽是些稀疏平常的东西，”警察说。“牛排、比萨、汉堡、三明治。
‘Just the usual stuff,’ the cop said. ‘Steaks, pizzas, hamburgers, triple-decker clubs.

我刚刚自己从通宵营业的客房服务那里点了一份，所以知道。不过我想你们不喜欢这些东西。”
I know because I just ordered from all-night room service myself. But I guess you folks don't like that kind of food.’

“嗯，您知道的，警官，”琳迪说道。
‘Well, you know how it is, officer,’ Lindy said. ‘It's the fun.

“只是好玩。偷偷下来吃点东西，明知不允许。您小时候也干过吧？”
The fun of creeping down and taking a bite, you know, a little bit forbidden, the way you did when you were a kid?’

那两个人都没有软化的迹象。
Neither men showed any sign of melting.

可是那个警察说道：
But the cop said:

“抱歉打扰二位，可是要知道这里不对客人开放。
‘Sorry to trouble you folks.

而且刚刚丢了一两件东西。”
But you understand this area isn't open to guests.

“真的？”
And one or two items have gone missing just lately.’

“是的。
‘Really?’

二位今晚看见什么奇怪、可疑的东西了吗？”
‘Yeah. You folks see anything odd or suspicious tonight?’

琳迪和我对视了一下，然后她朝我使劲地摇摇头。
Lindy and I looked at each other, then she shook her head at me dramatically.

“没有，”我说。
‘No,’ I said.

“我们没有看见什么奇怪的东西。”
‘We haven't seen anything odd.’

“什么都没有？”
‘Nothing at all?’

说话间保安慢慢走上前来，他的大块头挤过我们身边的餐台，走到我们身后。
The security guard had been coming closer, and now he came past us, squeezing his bulk along the counter.

我明白了他们的策略是保安上前来检查我们，看看我们有没有把什么东西藏在身上，而他的同伴不停地跟我们说话。
I realised the plan was for him to check us over more closely, to see if maybe we were concealing anything on our persons, while his partner kept us talking.

“没有，什么都没有。”
‘No, nothing,’ I said.

我说。“你们觉得有什么呢？”
‘What kind of thing did you have in mind?’

“可疑的人。
‘Suspicious people.

不寻常的举动。”
Unusual activity.’

“警官，您的意思是，”琳迪惊恐地说，“房间遭盗窃了？”
‘Do you mean, officer,’ Lindy said with shocked horror, ‘that rooms have been broken into?’

“不算是，夫人，可是确有一些重要的东西不见了。”
‘Not exactly, ma'am. But certain items of value have gone missing.’

我能感觉到保安在我们身后晃动。
I could sense the security guard shift behind us.

“所以您才会在这里，”琳迪说道。
‘So that's why you're here with us,’ Lindy said.

“来保护我们的人身和财产安全。”
‘To protect us and our belongings.’

“是的，夫人。”
‘That's right, ma'am.’

那个警察的视线微微动了一下，我感到他和我们身后的那个人交换了一下眼神。
The cop's gaze moved fractionally, and I got the impression he'd exchanged a look with the man behind us.

“好了，要是你们看见什么奇怪的东西，请马上联系保安。”
‘So if you see anything odd, please call security right away.’

看来盘问结束了，警察让开道让我们出去。
The interview seemed to be over and the cop moved aside to let us out.

我松了一口气，准备离开，可是琳迪说道：
Relieved, I made a move to go, but Lindy said:

“我想我们太调皮了，跑到这里来吃东西。
‘I suppose it was kind of naughty of us, coming down here to eat.

我们本想吃些那里的奶油蛋糕，可是我们想那蛋糕可能是有特殊用途的，糟蹋了可惜。”
We thought about helping ourselves to some of that gateau over there, but then we thought it might be for a special occasion and it would be such a shame to spoil it.’

“酒店里有很好的客房服务，”警察说。
‘This hotel has good room service,’ the cop said.

“全天候的服务。”
‘Twenty-four hours.’

我想把琳迪拽走，可她好像突然中了邪，变成人们常说的那种莽撞、不知死活的罪犯。
I tugged at Lindy, but she seemed now to be seized by the oft-cited mania of criminals to flirt with being caught.

“您刚刚自己点了东西，警官？”
‘And you just ordered something up yourself, officer?’

“是的。”
‘Sure.’

“东西好吗？”
‘And was it good?’

“挺不错的。
‘It was pretty good.

我建议二位也这么做。”
I recommend you folks do the same.’

“让先生们继续他们的调查吧，”我拽着琳迪的胳膊说，可她仍不走。
‘Let's leave these gentlemen to get on with their investigations,’ I said, tugging at her arm.

“警官，您介不介意我问您一个问题？”
But still she didn't budge. ‘Officer, may I ask you something?’ she asked.

她问道。
‘Do you mind?’

“请问。”
‘Try me.’

“您刚才说看见什么奇怪的东西。
‘You were talking just now about seeing something odd.

您自己不就看见什么奇怪的东西了吗？
You see anything odd yourself?

我是指，我们两个？”
I mean, about us?’

“我不明白你的意思，夫人？”
‘I don't know what you mean, ma'am.’

“比如说我们两个脸上都缠满绷带？
‘Like we both of us have our faces entirely wrapped in bandages?

您没注意到吗？”
Did you notice that?’

警察仔细地看了看我们，像在验证琳迪说的最后一句话，然后说道：“事实上，我注意到了，夫人。
The cop looked at us carefully, as though to verify this last statement. Then he said:‘As a matter of fact, I did notice, ma'am, yes.

可是我不想过问私事。”
But I didn't wish to make personal remarks.’

“哦，这样啊。”
‘Oh, I see,’ Lindy said.

琳迪说道，然后转向我，“他是不是很体贴？”
Then turning to me:‘Wasn't that considerate of him?’

“走吧，”我说道，这次用力地把她拽走了。
‘Come on,’ I said, pulling her along now quite forcefully.

我能感觉到那两个人一直盯着我们的后背，直到门口。我们故作镇定地穿过舞厅。
I could feel both men staring at our backs all the way to the exit. We crossed the ballroom with an outward show of calm.

可一走出那扇双开式弹簧大门，我们就害怕得几乎跑起来了。我们一直搭着胳膊，所以一路上跌跌撞撞。
But once we were past the big swing doors, we gave in to panic and broke into a near-run. Our arms stayed linked, so we did a lot of stumbling and colliding as Lindy led me through the building.

琳迪领着我往前走，最后把我拉进了一架货运电梯。当电梯的门关上、我们开始往上升时，琳迪才放开我的手，背靠在金属墙上，发出一阵奇怪的声音，是透过绷带传来的歇斯底里的笑声。
Then she pulled me into a service elevator, and only when the doors closed and we were climbing did she let go, lean back against the metal wall and start up a weird noise, which I realised was how hysterical laughter sounds coming through bandages.

走出电梯以后，她再次把手搭在我的胳膊上，说：“好了，我们安全了。
When we stepped out of the elevator, she put her arm through mine again. ‘Okay, we're safe,’ she said.

现在我带你去一个地方。
‘Now I want to take you somewhere.

很特别的地方。
This is really something.

看这个？”
See this?’

她拿出一张钥匙卡。
She was holding up a key card.

“看看它能干什么用。”
‘Let's see what this can do for us.’

她拿着卡片打开一扇写着“私人禁地”的门，然后又打开一扇写着“危险，禁止入内”的门。
She used the card to get us through a door marked ‘Private’, then a door marked ‘Danger. Keep Out.’

最后我们来到一个充满油漆和石灰味的地方。
Then we were standing in a space smelling of paint and plaster.

墙上、天花板上都垂着电线，冷冰冰的地板上满是水渍和污渍。
There were cables dangling from the walls and ceiling, and the cold floor was splashed and mottled.

我们能看清楚是因为房间有一面整个儿是玻璃——还没有挂上窗帘或者百叶窗——外面所有的亮光在这里投下淡黄色的斑点。
We could see fine because one side of the room was entirely glass – unadorned by curtains or blinds – and all the outdoor lighting was filling the place with yellowish patches.

这里比我们的房间还要高：看窗外的高速公路和周围的区域，我们像是从直升飞机上往下看。
We were up even higher than on our floor: there was in front of us a helicopter-style view over the freeway and the surrounding territory.

“这里要建新的总统套房，”琳迪说道。
‘It's going to be a new presidential suite,’ Lindy said.

“我喜欢来这里。
‘I love coming here.

还没有电灯，没有地毯。
No light switches yet, no carpet.

可正渐渐成形。我第一次来的时候比现在粗糙得多呢。
But it's slowly coming together. When I first found it, it was much rougher.

如今你可以看出形状来了，甚至还多了这张睡椅。”
Now you can see how it'll look. There's even this couch now.’

屋子的中央有一大团黑影，被床单完全盖住了。
In the centre of the room was a bulky shape with a sheet draped completely over it.

琳迪像看见老朋友一样走过去，疲惫地一屁股坐了下去。
Lindy went to it like it was an old friend and flopped down tiredly.

“虽然这是我的想象，”她说，“可是我相信他们建这房间是为了我。
‘It's my fantasy,’ she said, ‘but I kind of believe in it. They're building this room just for me.

所以我能到这里来。
That's why I get to be in here.

这一切。
All of this.

因为他们在帮我。
It's because they're helping me.

帮我塑造我的未来。
Helping me build my future.

这里以前乱七八糟的。
This place used to be a real mess.

可是看看现在。
But look at it now.

它在渐渐成形。
It's taking shape.

这里以后会很漂亮。”
It's gonna be grand.’

她拍了拍身旁的垫子。
She patted the space next to her.

“来吧，亲爱的，休息一下。
‘Come on, sweety, have a rest.

我累坏了。
I'm feeling drained.

你一定也是。”
You must be too.’

想不到这睡椅——抑或床单底下是其他什么东西——这么舒服。我一坐下去就感觉一阵阵的疲惫朝我袭来。
The couch – or whatever it was under the sheet – was surprisingly comfortable, and as soon as I'd sunk into it, I felt waves of tiredness coming over me.

“天啊，我困了，”琳迪说道，把全部的重量压在我的肩膀上。
‘Boy, am I sleepy,’ Lindy said, and her weight fell onto my shoulder.

“这里是不是很棒？
‘Isn't this a great place?

我在狭缝里发现了钥匙，第一次来的时候。”
I found the key in the slot, first time I came here.’

有一会儿我们都不说话，我自己也困了。
We were quiet for a while, and I felt myself falling asleep.

可是我突然想到什么事情。
But then I remembered something.

“嘿，琳迪。”
‘Hey, Lindy.’

“哼？”
‘Mmm?’

“琳迪。
‘Lindy.

奖杯哪儿去了？”
What happened to that award?’

“奖杯？
‘The award?

哦，对了。
Oh yeah.

奖杯。
The award.

我藏起来了。
I hid it.

不然还能怎么样？
What else could I do?

要知道，亲爱的，你真的配得那个奖。
You know, sweety, you really deserved that award.

我希望这事儿对你有意义，我把奖颁给你，像今晚这样。
I hope it means something to you, my presenting it to you tonight, the way I did.

不是我一时心血来潮。
It wasn't just a whim. I thought about it.

我考虑过，很认真地考虑过。
I thought about it really carefully.

我不知道这样做对你意义大不大，也不知道十年、二十年后你还会不会记得。”
I don't know if it means much to you. I don't know if you'll even remember it ten years, twenty years down the line.’

“我当然会记得。
‘I will for sure.

而且这件事对我意义重大。
And it does mean a lot to me.

可是琳迪，你说你藏起来了，藏在哪里？
But Lindy, you say you hid it, but where?

你把铜像藏到哪里去了？”
Where did you hide it?’

“哼？”
‘Mmm?’

她又昏昏欲睡了。
She was falling asleep again.

“藏在我唯一能藏的地方。
‘I hid it the only place I could.

我把它放到火鸡里去了。”
I put it in that turkey.’ ‘You put it in the turkey.’

“你把它放到火鸡里。”“跟我九岁的时候一模一样。
‘I did exactly the same thing once when I was nine years old.

我把妹妹的荧光球藏在火鸡里。就想到了。
I hid my sister's glowball inside a turkey. That's what gave me the idea.

反应够快吧？”
Quick thinking, right?’

“是，确实。”
‘Yeah, it sure was.’

我累得不行，可我强迫自己集中精神。
I felt so tired, but I forced myself to focus.

“但是琳迪，你藏得很好吗？
‘But Lindy, how well did you hide it?

我是说那些警察现在会不会已经发现了？”
I mean, would those cops have found it by now?’

“我想不会。
‘I don't see how.

没有角露出来，如果你是指这个。
There wasn't anything sticking out, if that's what you mean.

他们怎么会想到找那里呢？
Why would they think to look up there?

我在背后塞的，像这样。
I was pushing it behind my back, like this.

一直塞。
And kept pushing.

我没有转头去看，不然那两个人就会怀疑了。
I didn't turn around to look at it, because then those boys would have wondered what I was doing.

不是心血来潮。
It wasn't just a whim, you know.

决定给你那个奖。
Deciding to give you that award.

我想过，很认真地想过。
I thought about it, real hard.

我真的希望这事儿对你有意义。
I sure hope it means something to you.

天啊，我得睡了。”
God, I need to sleep.’

她倒在我身上，不一会儿就打起呼噜来了。
She slumped against me and the next moment she was making snoring noises.

考虑到她动的手术，我小心翼翼地移动她的脑袋，以免她的脸颊压在我的肩膀上。
Concerned about her surgery, I adjusted her head carefully so her cheek wasn't pressing on my shoulder.

接着，我也渐渐入睡。
Then I too began to drift off.

我猛地醒过来，看见面前的大窗户外天快亮了。
I woke with a jerk and saw signs of dawn in the big window in front of us.

琳迪还在熟睡，所以我小心翼翼地离开她，站起来，伸了伸胳膊。
Lindy was still fast asleep, so I carefully extricated myself from her, stood up and stretched my arms.

我走到窗户前，看着灰白的天空和底下远远的高速公路。
I went to the window and looked at the pale sky and the freeway far below.

我拼命回忆我睡着之前想到了一件什么事，可是我的脑子累得不行、迷迷糊糊的。
Something had been on my mind as I was falling asleep and I tried to remember what it was, but my brain was foggy and exhausted.

突然间我想起来了，我走回睡椅，摇醒琳迪。
Then I remembered, and I went to the couch and shook Lindy awake.

“什么事？
‘What is it?

什么事？
What is it?

你要干吗？”她闭着眼睛说。
Whaddaya want?’ she said without opening her eyes.

“琳迪，”我说。
‘Lindy,’ I said.

“奖杯。
‘The award.

我们把奖杯忘了。”
We've forgotten about the award.’

“我告诉过你了。
‘I told you already.

奖杯在火鸡里。”
It's in that turkey.’

“是，所以你听着。
‘Okay, so listen.

那些警察可能不会想到去看火鸡里面。
Those cops may not have thought to look inside the turkey.

可是迟早会有人发现的。
But sooner or later, someone's going to find it.

说不定现在就有人在切火鸡了。”
Maybe someone's carving it right now.’

“那又怎么样？
‘So what?

他们发现奖杯在里面。
So they find the thing in there.

那又怎么样？”
So what?’

“他们发现奖杯在里面，他们会报告这一重大发现。
‘They find the thing in there, they report the big find.

那个警察就会想起我们。
Then that cop remembers us.

他会想起我们曾经在那里，站在火鸡旁。”
He remembers we were there, standing next to that turkey.’

琳迪好像清醒多了，说道：“是，我明白你的意思了。”
Lindy seemed to get more awake. ‘Yeah,’ she said. ‘I see what you're saying.’

“只要奖杯在火鸡里，他们就会怀疑我们跟这一罪行有关。”
‘While that trophy stays in the turkey, they can link us to the crime.’

“罪行？
‘Crime?

嘿，什么罪行？”
Hey, what do you mean crime?’

“随便你怎么说。
‘Doesn't matter what you call it.

我们得回去把东西从鸡里拿出来。
We need to go back there and get that thing out of the turkey.

然后随便放哪里都可以，就是不能放在那里。”
It doesn't matter where we leave it after that. But we can't leave it where it is now.’

“亲爱的，我们真的非这样做不可吗？
‘Sweety, are you sure we have to do this?

我现在累死了。”
I'm so tired now.’

“我们非这样做不可，琳迪。奖杯放在那里，我们会有麻烦的。
‘We have to do it, Lindy. We leave it the way it is, you'll get in trouble.

而且记住，对于记者来说，这可是一条大新闻啊。”
And remember that means a big story for the press.’

琳迪想了想，然后稍微直了直身子，看着我说：“好吧，我们回那里去吧。”
Lindy thought about this, then she straightened up her posture a few notches and looked up at me. ‘Okay,’ she said. ‘Let's go back there.’

这一次走廊里有做清洁和人说话的声音，但我们还是安全地回到了那个舞厅，没遇见一个人。
This time round there were cleaning noises and voices down corridors, but we still made it back to the ballroom without encountering anyone.

光线也好多了，琳迪指了指双开门旁边的告示。
There was also more light to see by, and Lindy pointed out the notice beside the double doors.

上面用塑料的字母拼块写着：J. A.普尔清洁剂公司早餐会。
It said in plastic mix-and-spell letters: J. A. POOL CLEANSERS ASSOCIATION LUNCH.’

“难怪昨晚找不到放奖杯的办公室，”她说，“不是这个舞厅。”
‘No wonder we couldn't find that office with all the awards,’ she said. ‘This is the wrong ballroom.’

“这没关系。
‘It makes no difference.

现在我们要的东西在这里面。”
What we want is in there now.’

我们穿过舞厅，小心翼翼地走进餐厅。
We crossed the ballroom, then cautiously entered the catering room.

和昨天晚上一样有盏昏暗的灯开着，现在又多了些气窗照进来的自然光。
Like before, a dim light had been left on, and now there was also some natural light from the ventilation windows.

没有看见人，可我沿着长长的工作台扫了一眼，发现我们有麻烦了。
There was nobody in sight, but when I glanced along the long work counters, I saw we were in trouble.

“看来有人来过，”我说道。
‘Looks like someone's been here,’ I said.

“是啊。”
‘Yeah.’

琳迪往过道里走了几步，看看两边。
Lindy took a few steps down the gangway, glancing about her.

“是啊。
‘Yeah.

看那里。”
Looks that way.’

之前我们看见的罐子、盘子、蛋糕盒、有银色穹顶盖子的大盘子统统不见了。
All the canisters, trays, cake-boxes, silver-domed platters we'd seen earlier had vanished.

取而代之的是一堆堆间隔整齐地摆放着的盘子和餐巾。
In their place were neat piles of plates and napkins positioned at regular intervals.

“得，他们把食物都搬走了，”我说。
‘Okay, so they've moved all the food,’ I said.

“问题是，搬到哪儿去了？”
‘Question is, where to?’

琳迪又往过道里走了几步，然后突然转过来。
Lindy wandered further down the gangway, then turned to me.

“记得吗，史蒂夫，上次在这里，在那两个人进来之前，我们在讨论一个问题。”
‘Remember, Steve, the last time we were here, before those men came in? We were having quite a discussion.’

“是的，我记得。
‘Yeah, I remember.

可又提起它干吗？
But why go over that again?

我知道我失态了。”
I know I was out of line.’

“是啊，不提了。
‘Yeah right, let's forget it.

那只火鸡到底哪儿去了？”
So where's that turkey gone?’

她又左右看了看。
She glanced around some more.

“知道吗，史蒂夫？
‘You know what, Steve?

小时候我十分渴望成为舞蹈家或歌唱家。
When I was a kid, I so wanted to be a dancer and a singer.

我努力啊努力，老天知道我努力了，可人们只知道笑话我，我觉得这个世界太不公平了。
And I tried and tried, God knows I tried, but people just laughed, and I thought, this world is so unfair.

但是后来我长大一些，我发现这个世界也不是那么不公平。
But then I grew up a little and I realised the world wasn't so unfair after all.

即使是像我这样的人，没有什么天赋的人，也仍然是有机会的。你仍旧可以在天底下找到自己的位置，不一定只能是个默默无闻的人。
That even if you were like me, one of the unblessed, there was still a chance for you, you could still find a place in the sun, you didn't have to settle for being just public.

要做到不容易。
It wasn't going to be easy.

你得十分努力，不理会别人怎么说。
You'd have to work at it, not mind what people said.

可机会一定有。”
But there was definitely still a chance.’

“啊，你似乎干得不错。”
‘Well, it looks like you did okay.’

“世界上的事真奇怪。
‘It's funny the way this world works.

知道吗，我觉得这是非常明智的。
You know, I think it was very insightful.

我指你妻子，叫你来做这个手术。”
On the part of your wife, I mean. Telling you to get this surgery.’

“我们别提她。
‘Let's leave her out of it.

嘿，琳迪，你知道那扇门通向哪里吗？
Hey, Lindy, do you know where that leads?

那边那扇？”
Over there?’

房间的尽头，餐台的末端，有三个台阶通向一扇绿色的门。
At the far end of the room, where the counters came to an end, there were three steps leading up to a green door.

“干吗不去看看？”
‘Why don't we try it?’

琳迪说。
Lindy said.

我们像刚刚一样小心翼翼地打开门，一时间我完全找不着北了。
We opened the door as cautiously as the last one, then for a while I became utterly disoriented.

这里很暗，我每次想转身都会碰上帘子或防水布之类的东西。
Everything was very dark and each time I tried to turn I found I was beating back curtain material or else tarpaulin.

琳迪拿着手电筒在我前面，似乎没有我这么狼狈。
Lindy, who'd taken the flashlight, seemed to be doing better somewhere in front of me.

接着我终于踉跄地走到了一个黑咕隆咚的场子，琳迪正等着我，手电筒照着我的脚。
Then I stumbled out into a dark space, where she was waiting for me, shining the torch at my feet.

她低声说道：“我发现你不喜欢谈到她。
‘I've noticed,’ she said, in a whisper. ‘You don't like talking about her.

我指你妻子。”
Your wife, I mean.’

我也低声回答她：“没有的事。
‘It's not that exactly,’ I whispered back.

我们这是在哪儿？”
‘Where are we?’

“她没来看过你。”
‘And she never comes to visit.’

“那是因为我们现在不在一起。
‘That's because we're not exactly together just now.

既然你非得知道。”
Since you must know.’

“哦，对不起。
‘Oh, I'm sorry.

我不是要多管闲事。”
I didn't mean to be nosy.’

“你不是要多管闲事？！”
‘You didn't mean to be nosy?!’

“嘿，亲爱的，看！
‘Hey, sweety, look!

就是这个！
This is it!

我们找到了！”
We've found it!’

她用手电筒照着不远处的一张桌子。
She was pointing the beam at a table a short distance away.

桌子上铺着白色桌布，并排放着两个银色穹顶盖子。
It had a white tablecloth on it, and two silver domes side by side.

我走到第一个穹顶前，小心地打开。
I went up to the first dome and carefully raised it.

一只肥肥的烤火鸡端坐在里面。
Sure enough, there was a fat roast turkey sitting there.

我摸索着它的腹腔，伸了根指头进去找。
I searched out its cavity and inserted a finger.

“什么都没有，”我说。
‘Nothing here,’ I said.

“你得伸到里面去。
‘You have to get right in there.

我塞得很里面。
I pushed it right up.

这些鸡比你想的要大。”
These birds are bigger than you think.’

“我说了里面什么都没有。
‘I'm telling you there's nothing in there.

手电筒照那里。
Hold the flashlight over here.

我们试试另一只。”
We'll try this other one.’

我小心地掀开第二只的盖子。
I carefully took the lid off the second turkey.

“你知道，史蒂夫，我觉得这样不对。
‘You know, Steve, I think it's a mistake.

你不应该觉得说这件事是丢脸的。”
You shouldn't be embarrassed to talk about it.’

“说什么事？”
‘Talk about what?’

“说你和妻子分开了。”
‘About you and your wife being separated.’

“我说我们分开了？
‘Did I say we were separated?

我那样说了吗？”
Did I say that?’ ‘I thought ...’

“我以为……”“我说我们不在一起。
‘I said we weren't exactly together.

两码事。”
That's not the same thing.’

“像一回事……”
‘It sounds the same thing ...’

“啊，不是。
‘Well, it isn't.

只是暂时的，试验性的。
It's just a temporary thing, something we're trying out.

嘿，我摸到什么东西了。
Hey, I've got something.

这里面有东西。
There's something in here.

找到了。”
This is it.’

“把它拽出来，亲爱的。”
‘Then why don't you pull it out, sweety?’

“不然你以为我在干吗？
‘What do you think I'm trying to do?!

天啊！
Jesus!

你非得塞这么里面吗？”
Did you have to push it in so far?’

“嘘！
‘Sssh!

外面有人！”
There's someone out there!’

一开始很难判断外面有几个人。
At first it was hard to say how many of them there were.

接着声音近了，我听出来只有一个人，在不停地打电话。
Then the voice came closer and I realised it was just the one guy, talking continuously into a cellphone.

我也明白我们在哪里了。
I also realised exactly where we were.

我本以为我们到了一个什么后台，但其实我们就站在舞台上，我面前的帘子是把我们和舞厅隔开的唯一东西。
I'd been thinking we'd wandered into some vague backstage area, but in fact we were up on the stage itself, and the curtain facing me was the only thing now dividing us from the ballroom.

打电话的男子正穿过舞池，朝舞台走过来。我轻声示意琳迪关掉手电筒，灯熄了，一片漆黑。
The man on the cellphone, then, was walking across the floor of the ballroom towards the stage. I whispered to Lindy to turn off the flashlight and it went dark.

她在我耳边说道：“我们离开这里。”说完我听见她悄悄地离开。
She said into my ear:‘Let's get out of here,’ and I could hear her creeping away.

我再次试图把铜像从火鸡里拿出来，可现在我不敢弄出声音，而且我的手指头没法抓牢铜像。
I tried again to pull the statuette out of the turkey, but now I was afraid of making noise, and besides, my fingers just couldn't get any purchase.

声音越来越近，最后那家伙像是就在我面前。
The voice kept coming closer until it felt like the guy was right there in front of me.

“……那不是我的问题，拉里。
‘. . . It's not my problem, Larry.

菜单上得印上公司标志。
We need the logos to be on these menu cards.

我不管你们怎么印。
I don't care how you do it.

好吧，那你就自己印吧。对，你自己印，自己送过来，我不管你怎么做。
Okay, then you do it yourself. That's right, you do it yourself, bring them over yourself, I don't care how you do it.

只要在今天早上送过来，最迟七点半。
Just get them here this morning, nine-thirty latest.

我们这里要那些东西。
We need those things here.

桌子很好。
The tables look fine.

桌子很多，相信我。
There are plenty of tables, trust me.

好好。
Okay.

我会确认的。
I'll check that out.

好，好。
Okay, okay.

对。
Yeah.

我马上就确认。”
I'm gonna check that out right now.’

那男的边说最后一句话，边走到了房间的另一头。
For the last part of this, his voice had been moving over to one side of the room.

他一定是按了墙上的什么开关，一道强烈的光线从我头顶上直射下来，同时传来类似空调的嗡嗡的声音。
He must now have flicked a switch on some wall panel, because a strong beam came on directly above me, and also a whirring noise like the air-conditioning had come on.

只是我意识到发出声音的不是空调，而是我面前的帘子在慢慢打开。
Only I realised the noise wasn't the air-conditioning, but the curtains opening in front of me.

在我职业生涯中我总共上台过两次进行独奏表演，突然间我不知道从何开始，不知道要用哪个调，不知道怎么换弦。那两次我都僵住了，像电影里的定格，直到乐队里有个人上来救我。
Twice in my career I've had it happen when I've been on stage, I've had a solo to play, and suddenly it hits me I don't know how to start, which key I'm in, how the chords change. On both occasions this happened, I just froze up, like I was in a still from a movie, until one of the other boys stepped in to the rescue.

我入行二十年这种事情只发生过两次。
It's only happened twice in over twenty years of playing professionally.

总之，这就是头顶的聚光灯打开、幕帘慢慢掀开时我的反应。
Anyway, this is how I reacted to the spotlight coming on above me and the curtains starting to move.

我僵住了。
I just froze.

而且我突然感觉自己置身事外，有点好奇帘子拉开以后会看见什么。
And I felt oddly detached. I felt a kind of mild curiosity concerning what I'd see once the curtain was gone.

我看见了舞厅，而且从舞台上更能看出桌子从头到尾被排列成整齐的两排。
What I saw was the ballroom, and from the vantage point of the stage, I could appreciate better the way the tables were laid out in two parallel lines all the way to the back.

头顶的灯光在舞厅里投下了些许阴影，可我还是能看见大吊灯和华丽的天花板。
The spot above me was putting the room in shade a little, but I could make out the chandelier and the fancy ceiling.

打电话的男子是个秃头的胖子，穿着灰色西服、开领衬衫。
The cellphone man was an overweight bald guy in a pale suit and open-neck shirt.

他一定是按了开关以后就走开了，如今他几乎和我平齐。
He must have walked away from the wall as soon as he'd flicked the switch, because now he was more or less level with me.

他的电话贴在耳朵上，看他的表情你以为他在专心听对方讲话。
He had his phone pressed to his ear, and from his expression you'd guess he was listening with extra attention to what was being said at the other end.

可是我想他没有，他的眼睛死死地盯着我。
But I supposed he wasn't, because his eyes were fixed on me.

他瞪着我，我也瞪着他，我们会这样子永远瞪下去，要不是他又接着打电话，可能是对方问他为什么突然不说话了。
He kept looking at me and I kept looking at him, and the situation might have gone on indefinitely if he hadn't said into the phone, maybe in response to a query about why he'd gone silent:

“没事。
‘It's all right.

没事。
It's all right.

是个人。”
It's a man.’

他停顿了一下，接着说，“我刚刚以为是什么东西。
There was a pause, then he said:‘I thought for a moment it was something else.

没想到是个人。
But it's a man.

头上包着绷带，穿着睡衣。
With a bandaged head, wearing a night-gown.

就是这样，现在我看清楚了。
That's all it is, I see it now.

他手里抓着一只鸡什么的。”
It's just that he's got a chicken or something on the end of his arm.’

我突然清醒过来，下意识地开始甩动手臂。
Straightening up, I instinctively started to stretch out my arms in a shrugging motion.

我右手手腕以下还在火鸡里，我用力的甩动弄得整张桌子哐当作响。
My right hand still being inside the turkey beyond the wrist, the sheer weight brought the whole arrangement back down with a crash.

可至少现在我不用担心被发现了，因此我不管三七二十一，拼了命努力把手和铜像拿出来。
But at least I'd no more worries about concealment, so I went right at it, no holds barred, in an effort to extricate both my hand and the statuette.

而那个男的继续打他的电话。
Meanwhile the man went on talking into his phone.

“不，我没有骗你。
‘No, it's exactly what I say.

现在他把鸡拿掉了。
And now he's taking his chicken off.

哦，他从里面拿出了什么东西。
Oh, and he's producing something out of it.

嘿，老天，那是什么？
Hey, fella, what is that?

鳄鱼？”
An alligator?’

他平静地说出最后那几个字，真是令人佩服。
These last words he'd addressed to me with admirable nonchalance.

铜像拿出来了，火鸡嘭的一声掉到地板上。
But now I had the statuette in my hands and the turkey fell to the floor with a thud.

我急忙走进身后漆黑的地方，听见那个男的对他的朋友说：
As I hurried towards the darkness behind me, I heard the man say to his friend:

“我怎么知道？
‘How the hell do I know?

可能是什么魔术吧。”
Some kind of magic show maybe.’

我不记得我们是怎么回到我们住的地方了。
I don't remember how we got back to our floor.

离开舞台后我又被一堆帘子搞得晕头转向，好在琳迪抓住我的手。
I was lost again in a mess of curtains coming off the stage, then she was there pulling me by the hand.

然后，我们急匆匆地奔回房间，再也不管我们弄出了多少声响，或者撞见了谁。
Next thing, we were hurrying through the hotel, no longer caring how much noise we made or who saw us.

路上，我把铜像放在某个房间外客房服务的盘子上，不知谁吃剩的晚餐旁。
Somewhere along the way I left the statuette on a room-service tray outside a bedroom, beside the remains of someone's supper.

回到琳迪的房间，我们一屁股坐到沙发上，大笑起来，一直笑到我们两个倒成一团。
Back in her room, we flopped down into a sofa and laughed.

琳迪站起来，走到窗户旁，打开百叶窗。
We laughed till we were collapsing into each other, then she got up, went to the window and raised the blinds.

天已经亮了，虽说是阴天。
It was now light outside, though the morning was overcast.

她走到橱子前调起饮料——“世界上最棒的无酒精鸡尾酒”——然后递给我一杯。
She went to her cabinet to mix drinks – ‘the world's sexiest alcohol-free cocktail’ – and brought me over a glass.

我以为她会在我旁边坐下，可她又走回窗前，小口喝着自己的饮料。
I thought she'd sit down beside me, but she drifted back towards the window, sipping from her own glass.

过一会儿她问道：“你期待吗，史蒂夫？
‘You looking forward to it, Steve?’ she asked after a while.

期待绷带拆下来？”
‘To the bandages coming off?’

“我想是吧。”
‘Yeah. I suppose so.’

“上周我都还没怎么想这件事。
‘Even last week, I didn't think about it so much.

觉得事情还远着呢。
It seemed such a long way off.

可现在不远了。”
But now it's not so long.’

“是啊，离我也不远了。”
‘That's right,’ I said. ‘It's not long for me either.’

说完我轻声叫道，“天啊。”
Then I said quietly:‘Jesus.’

琳迪抿了一口酒，看着窗外。
She sipped her drink and looked out of the window.

然后我听见她说：“嘿，亲爱的，你怎么了？”
Then I heard her say:‘Hey, sweety, what's the matter with you?’

“我很好，只是得睡一觉。”
‘I'm fine. I just need to get some sleep, that's all.’

她看了我好一会儿，说道：“听我说，史蒂夫，会好起来的。
She kept looking at me for a while. ‘I tell you, Steve,’ she said eventually.

鲍里斯是最棒的医生。
‘It's gonna be fine. Boris is the best.

你瞧着吧。”
You'll see.’

“是。”
‘Yeah.’

“嘿，你是怎么了？
‘Hey, what's wrong with you?

听着，这是我第三次整容。
Listen, this is my third time.

第二次找鲍里斯。
Second time with Boris.

会好起来的。
It's gonna be just fine.

你会变帅，很帅。
You're gonna look great, just great.

而你的事业，从此以后蒸蒸日上。”
And your career. From here it's gonna rocket.’

“可能吧。”
‘Maybe.’

“不是可能！
‘No maybe about it!

会焕然一新的，相信我。
It'll make such a difference, believe me.

你会上杂志，上电视。”
You'll be in magazines, you'll be on TV.’

我没有回答。
I said nothing to this.

“嘿，好了！”
‘Hey, come on!’

她朝我走了几步。
She took a few steps towards me.

“打起精神来。
‘Cheer up there.

你不是还生我的气吧？
You're not still mad at me, are you?

在下面我们不是搭档得很好吗？
We were a great team down there, weren't we?

我还要告诉你，从今以后我就是你的搭档。
And I'll tell you something else. From now on I'm gonna stay part of your team.

你是个天才，我来助你一臂之力。”“行不通的，琳迪。”
You're a goddamn genius, and I'm gonna make sure things go well for you.’ ‘It won't work, Lindy.’

我摇摇头。
I shook my head.

“行不通的。”
‘It won't work.’

“谁说行不通。
‘Like hell it won't work.

我去找人，能帮你大忙的人。”
I'll talk to people. People who can do you a lot of good.’

我仍旧摇头。
I kept shaking my head.

“我很感激。
‘I appreciate it.

可是没有用。
But it's no use.

行不通的。
It won't work.

从来就行不通。
It was never going to work.

我不应该听布拉德利的。”
I should never have listened to Bradley.’

“嘿，好了。
‘Hey, come on.

没错，我不再是托尼的妻子了，可我在城里还有很多好朋友。”
I may not be married to Tony any more, but I still have a lot of good friends in this town.’

“这我知道，琳迪。
‘Sure, Lindy, I know that.

可是没有用。
But it's no use.

是这样的，是布拉德利，我的经纪人，说动我来做手术的。
You see, Bradley, that's my manager, he talked me into this whole thing.

我真是个白痴，听了他的话，可我没办法。
I was an idiot to listen to him, but I couldn't help it.

我无计可施了，而他想出了这么套理论。
I was at my wit's end, and then he came out with this theory.

他说是我妻子海伦想出了这个计划。
He said my wife, Helen, she had this scheme.

她不是真的离开我。
She hadn't really left me.

不是，这只是她计划的一部分。
No, it was all part of this scheme she had.

她那么做都是为了我，为了让我能做这个手术。
She was doing it all for me, to make it possible for me to get this surgery.

绷带拆掉以后，我有了张新面孔，她就会回来，一切就又会好起来。
And when the bandages came off, and I had a new face, she'd come back and it'd be all right again.

布拉德利这么说的。
That's what Bradley said.

他说的时候我就不相信，可我能怎么样呢？至少还有希望。
Even when he was saying it, I knew it was bullshit, but what could I do?

布拉德利利用了这个，他利用了这个，他就是这样，你知道。
It was some kind of hope at least. Bradley used it, he used it, he's like that, you know?

他是个卑鄙小人，整天只想着生意，还有什么大腕。
He's lowlife. All he thinks about is business. And about the big league.

他怎么会关心她会不会回来？”
What does he care if she comes back or not?’

我不说了，琳迪也没有出声。
I stopped and she didn't say anything for a long time.

过了好一会儿，她说道：
Then she said:

“听着，亲爱的，听着。
‘Look, sweety, listen.

我希望你妻子回来。
I hope your wife comes back.

真的。
I really do.

可如果她不回来，你也应该向前看。
But if she doesn't, well, you've just got to start getting some perspective.

她也许是个好人，可是生活不单单只是爱一个人。
She might be a great person, but life's so much bigger than just loving someone.

你得振作起来，史蒂夫。
You got to get out there, Steve.

像你这样的人，你们不属于普通人一类的。
Someone like you, you don't belong with the public. Look at me.

看看我。绷带拆掉以后，我会回到二十年前吗？我不知道。
When these bandages come off, am I really going to look the way I did twenty years ago?

而且我已经很久没有在男人们之间周旋了。
I don't know. And it's a long time since I was last between husbands.

可我还是要去，去试一试。”
But I'm going to go out there anyway and give it a go.’

她走过来，推了推我的肩膀。
She came over to me and shoved me on the shoulder.

“嘿，你只是累了。
‘Hey. You're just tired.

睡一觉就会感觉好多了。
You'll feel a lot better after some sleep.

听着，鲍里斯是最棒的。
Listen. Boris is the best.

他会搞定的，我们俩都是。
He'll have fixed it, for the both of us.

你瞧着吧。”
You just see.’

我把杯子放到桌子上，站起来。
I put my glass down on the table and stood up.

“我想你说得对。
‘I guess you're right.

就像你说的，鲍里斯是最棒的。
Like you say, Boris is the best.

而且在下面我们搭档得很好。”
And we were a good team down there.’

“在下面我们搭档得很好。”
‘We were a great team down there.’

我往前把手搭在她的肩上，亲了亲她两个缠着绷带的脸颊，说：“你自己也好好睡一觉。
I reached forward, put my hands on her shoulders, then kissed each of her bandaged cheeks. ‘You have yourself a good sleep,’ I said.

我很快会再过来，我们再来下棋。”
‘I'll come over soon and we'll play more chess.’

可是那天早上以后，我们很少再见面。事后想想，那天晚上我说了什么话本应该道歉，或至少是给个解释的。
But after that morning, we didn't see much more of each other. When I thought about it later, it occurred to me there'd been some things said during the course of that night, things I should maybe have apologised about, or at least tried to explain.

可是那时，回到她房间的时候，我们在沙发上大笑的时候，似乎没有必要，甚至是不应该旧事重提。那天早上道别的时候，我以为我们俩都已经不再想那件事了。
At the time, though, once we'd made it back to her room, and we'd been laughing together on the sofa, it hadn't seemed necessary, or even right, to bring all of that up again. When we parted that morning, I thought the two of us were well beyond that stage.

即便如此，我已经见识了琳迪的反复无常。没准后来她回想起来，又生我的气了。
Even so, I'd seen how Lindy could switch. Maybe later on, she thought back and got mad at me all over again.

谁知道？
Who knows?

总之，我以为那天她会打电话给我，可是没有，第二天也没有。相反，透过墙壁，我听见托尼·加德纳的唱片高声播放着，一张接一张。
Anyway, though I'd expected a call from her later that day, it never came, and neither did one come the day after. Instead, I heard Tony Gardner records through the wall, playing at top volume, one after the next.

当我终于又过去的时候，大概是四天以后，她欢迎我，但有点冷淡。
When I did eventually go round there, maybe four days later, she was welcoming, but distant.

和第一次一样，她侃侃而谈她的名人朋友——虽然没有一个跟帮助我的事业有关，可是我不介意。
Like that first time, she talked a lot about her famous friends – though none of it about getting them to help with my career. Still, I didn't mind that.

我们下了棋，可是她的电话响个不停，她老得去卧室接电话。
We gave chess a try, but her phone kept ringing and she'd go into the bedroom to talk.

后来，大前天晚上，她过来敲门说她要离开酒店了。
Then two evenings ago she knocked on my door and said she was about to check out.

鲍里斯对她的情况很满意，同意她回家拆绷带。
Boris was pleased with her and had agreed to take the bandages off in her own house.

我们友好地道别，可是似乎我们真正的道别已经说过了，就在那次大冒险过后的早上，当我上前亲吻她的两个脸颊的时候。
We said our goodbyes in a friendly way, but it was like our real goodbyes had been said already, that morning right after our escapade, when I'd reached forward and kissed her on both cheeks.

这就是琳迪·加德纳住在我隔壁的故事。
So that's the story of my time as Lindy Gardner's neighbor.

我祝她顺利。
I wish her well.

至于我，我还要六天才能拆绷带，还要很久才能吹萨克斯。可现在我已经习惯这种生活了，我安心地过着每一天。
As for me, it's six more days till my own unveiling, and a lot longer still before I'm allowed to blow a horn. But I'm used to this life now, and I pass the hours quite contentedly.

昨天我接到海伦的电话，问我怎么样了。当我告诉她我认识了琳迪·加德纳时，她十分震惊。
Yesterday I got a call from Helen asking how I was doing, and when I told her I'd gotten to know Lindy Gardner, she was mightily impressed.

“她还没再婚吗？”她问。
‘Hasn't she married again?’ she asked.

当我把事情说给她听，她说：“哦，好吧。
And when I put her straight on that, she said:‘Oh, right.

我一定是把她跟什么人混起来了，她叫什么名字来着。”
I must have been thinking about that other one. You know. What's-her-name.’

我们尽谈些无关紧要的事——她看了什么电视，她的朋友带着孩子顺道去看望她。
We talked a lot of unimportant stuff – what she'd watched on TV, how her friend had stopped by with her baby.

接着她说普伦德加斯特向我问好，她说这句话的时候语气明显变紧张了。
Then she said Prendergast was asking for me, and when she said that, there was a noticeable tightening in her voice.

我差点要说：“喂？
And I almost said:‘Hello?

我是不是听见你说情人的名字时没好气？”
Do I detect a note of irritation associated with lover boy's name?’

可是没有。
But I didn't.

我只说向他问声好，她没有再提起他。
I just said to say hi to him, and she didn't bring him up again.

也有可能是我自己想象出来的。
I'd probably imagined it anyway.

说不定她是希望我感激一下他。
For all I know, she was just angling for me to say how grateful I was to him.

她准备挂机的时候，我用夫妻间打完电话时那种快速、例行公事的语气说：“我爱你。”
When she was about to go, I said:‘I love you,’ in that fast, routine way you say it at the end of a call with a spouse.

几秒钟的沉默，然后她也用同样例行公事的语气说“我也爱你”，就挂了。
There was a silence of a few seconds, then she said it back, in the same routine way. Then she was gone.

天知道她什么意思。
God knows what that meant.

我想如今我没什么可做的了，只能等着拆绷带。
There's nothing to do now, I guess, but wait for these bandages to come off.

然后呢？
And then what?

也许琳迪说得对。
Maybe Lindy's right.

也许像她说的，我应该向前看，生活确实不单单只是爱一个人。
Maybe, like she says, I need some perspective, and life really is much bigger than loving a person.

也许这次真的是我的转折点，我的明星梦不远了。
Maybe this really is a turning point for me, and the big league's waiting.

也许她说得对。
Maybe she's right.

# 大提琴手 | CELLISTS

这是午饭后我们第三次演奏《教父》了，我扫视了一下坐在广场上的游客，想看看大概有多少是听过之前一次的。
IT WAS OUR THIRD TIME playing the Godfather theme since lunch, so I was looking around at the tourists seated across the piazza to see how many of them might have been there the last time we'd played it.

经典的歌曲人们不介意多听一遍，但不能太频繁，不然他们就会怀疑你是不是没有其他节目了。
People don't mind hearing a favourite more than once, but you can't have it happen too often or they start suspecting you don't have a decent repertoire.

每年到了这个时候，重复一些曲目通常没什么问题。
At this time of year, it's usually okay to repeat numbers.

渐起的秋风和贵得离谱的咖啡总是让客人换了一批又一批。
The first hint of an autumn wind and the ridiculous price of a coffee ensure a pretty steady turnover of customers.

总之，这就是为什么我会去注意广场上的面孔，意外地发现了蒂博尔。
Anyway, that's why I was studying the faces in the piazza and that's how I spotted Tibor.

他正挥舞着手臂，一开始我以为他是在跟我们挥手，后来发现他是在招呼服务生。
He was waving his arm and I thought at first he was waving to us, but then I realised he was trying to attract a waiter.

他看上去比以前老，还胖了些，但不难认出来。
He looked older, and he'd put on some weight, but he wasn't hard to recognise.

我用胳膊肘轻轻地推了推身边拉手风琴的费边，摆头示意他注意那个年轻人，因为当时我没法从萨克斯上腾出手来指给他看。
I gave Fabian, on accordion right next to me, a little nudge and nodded towards the young man, though I couldn't take either hand off my saxophone just then to point him out properly.

就在这时，当我环顾乐队时，突然间发现：我们认识蒂博尔的那年夏天，当时在乐队里的那群人就只剩下我和费边了。
That was when it came home to me, looking around the band, that apart from me and Fabian, there was no one left in our line-up from that summer we'd met Tibor.

没错，那是七年前的事了，可我还是感到不小的震撼。
Okay, that was all of seven years ago, but it was still a shock.

像这样天天在一起演出，渐渐地你会把乐队当作家，把乐队里的其他成员当作你的兄弟。
Playing together every day like this, you come to think of the band as a kind of family, the other members as your brothers.

当时不时有人离开的时候，你就会想他们会一直保持联系，从威尼斯、伦敦或其他地方寄明信片回来，抑或是寄一张目前所在乐队的照片——就像给老家写信一样。
And if every now and then someone moves on, you want to think he'll always stay in touch, sending back postcards from Venice or London or wherever he's got to, maybe a polaroid of the band he's in now – just like he's writing home to his old village.

因此想到以前的乐队就剩我们两个人，不禁令人感慨世事无常。
So a moment like that comes as an unwelcome reminder of how quickly things change.

今日的知己明日就变成失去联络的陌路人，分散在欧洲各地，在你永远不会去的广场和咖啡馆里演奏着《教父》或者《秋叶》。
How the bosom pals of today become lost strangers tomorrow, scattered across Europe, playing the Godfather theme or ‘Autumn Leaves’ in squares and cafes you'll never visit.

这支曲子奏完了，费边狠狠地瞪了我一眼，怪我在他的“特别小节”推了他——算不上独奏，却是一段小提琴和单簧管难得停下来的时候，我的萨克斯以柔和的音符给他伴奏，由他的手风琴把持调子。
When we finished our number, Fabian gave me a dirty look, annoyed I'd nudged him during his ‘special passage’ – not a solo exactly, but one of those rare moments when the violin and clarinet have stopped, I'm blowing just quiet notes in the background, and he's holding the tune together on his accordion.

我跟他解释，把蒂博尔指给他看，这会儿蒂博尔正在阳伞下搅动着咖啡。
When I tried to explain, pointing out Tibor, now stirring his coffee beneath a parasol, Fabian seemed to have trouble remembering him.

费边想了好一会儿才认出他来，说：
In the end, he said:

“啊，对了，那个拉大提琴的小子。
‘Ah yes, the boy with the cello.

不知道他是不是还跟那个美国女人在一起。”
I wonder if he's still with that American woman.’

“当然不在了，”我说。
‘Of course not,’ I said.

“你不记得了？
‘Don't you remember?

事情那个时候就结束了。”
That all came to an end at the time.’

费边耸耸肩，把注意力放到他的乐谱上，不一会儿我们开始演奏下一首歌。
Fabian shrugged, his attention now on his sheet music, and then we were starting our next number.

我很失望费边对蒂博尔的出现不怎么感兴趣，不过我想他跟其他人不一样，从来就不曾对这个年轻的大提琴手有特别的兴趣。
I was disappointed Fabian hadn't shown more interest, but I suppose he'd never been one of those particularly concerned about the young cellist.

是这样的，费边只是个在酒吧和咖啡厅里演出的乐手，不像詹卡洛，我们当时的小提琴手，或者欧内斯托，当时的贝司手，他们是受过专业训练的，所以对蒂博尔这样的人总是很感兴趣。
Fabian, you see, he's only ever played in bars and cafes. Not like Giancarlo, our violin player at that time, or Ernesto, who was our bass player. They'd had formal training, so to them someone like Tibor was always fascinating.

也许是有一点点的嫉妒在里面——嫉妒蒂博尔受过顶级的音乐教育，嫉妒他还有大好的前途。
Maybe there was a tiny bit of jealousy there – of Tibor's top-drawer musical education, of the fact that his future was still in front of him.

但平心而论，我觉得他们只是想保护像蒂博尔这样的人，给他们一些帮助，甚至让他们对未来做好准备，这样，当事情不尽人意的时候，他们就不会太接受不了。
But to be fair, I think it was just that they liked to take the Tibors of this world under their wing, look after them a little, maybe prepare them for what lay ahead, so when the disappointments came they wouldn't be quite so hard to take.

七年前的那个夏天异常炎热，即便在这个城市有时也感觉像是在亚得里亚海。我们要在室外演出四个多月——在咖啡店的遮阳篷底下，面对着广场和所有的桌子——告诉你吧，干这活儿热得不得了，就算有两三台电扇在你旁边呼呼地吹。
That summer seven years ago had been an unusually warm one, and even in this city of ours, there were times you could believe we were down on the Adriatic. We played outdoors for over four months – under the cafe awning, facing out to the piazza and all the tables – and I can tell you that's hot work, even with two or three electric fans whirring around you.

可是这倒带来了好生意，游客熙熙攘攘，很多是从德国和奥地利来的。本地的居民也跑到沙滩上来乘凉。
But it made for a good season, plenty of tourists passing through, a lot from Germany and Austria, as well as natives fleeing the heat down on the beaches.

那年夏天我们还开始留意到俄国人。
And that was the summer we first started noticing Russians.

如今看见俄国游客不稀奇，他们和其他游客没什么两样。
Today you don't think twice about Russian tourists, they look like everyone else.

可当时俄国人还很罕见，让人不禁停下来看几眼。
But back then, they were still rare enough to make you stop and stare.

他们穿着古怪，像学校里新来的小孩子一般不自在。
Their clothes were odd and they moved around like new kids at school.

我们第一次见到蒂博尔是在幕间休息的时候，我们在一旁咖啡馆为我们准备的一张大桌子旁休息喝饮料。他就坐在旁边，不停地起来摆弄琴箱，不让太阳照到。
The first time we saw Tibor, we were between sets, refreshing ourselves at the big table the cafe always kept aside for us. He was sitting nearby, continually getting up and re-positioning his cello case to keep it in the shade.

“瞧他，”詹卡洛说。
‘Look at him,’ Giancarlo said.

“俄国来的穷音乐学生。
‘A Russian music student with nothing to live on.

他在这儿做什么呢？
So what does he do?

打算把所有的钱都扔在中央广场的咖啡上吗？”
Decides to waste his money on coffees in the main square.’

“准是个傻瓜，”欧内斯托说。
‘No doubt a fool,’ Ernesto said.

“但是个浪漫的傻瓜。
‘But a romantic fool.

为了在广场上坐一下午宁可饿肚子。”
Happy to starve, so long as he can sit in our square all afternoon.’

他瘦瘦的，浅褐色头发，戴着一副老土的厚框眼镜，活像只熊猫。
He was thin, sandy-haired and wore unfashionable spectacles – huge frames that made him look like a panda.

他每天都来，我不记得究竟是怎么起的头，只记得过了一段时间我们开始在幕间休息时和他坐在一起聊天。
He turned up day after day, and I don't remember how exactly it happened, but after a while we began to sit and talk with him in between sets.

有时他在我们晚上演出的时候过来，演出结束以后我们会把他叫来，请他喝杯酒，或者吃烤面包片什么的。
And sometimes if he came to the cafe during our evening session, we'd call him over afterwards, maybe treat him to some wine and crostini.

不久我们就知道了蒂博尔不是俄国人，是匈牙利人；他的实际年龄要比长相大一些，他在伦敦的皇家音乐学院学习过，然后在维也纳待了两年，师从奥列格·彼得罗维奇。
We soon discovered Tibor was Hungarian, not Russian; that he was probably older than he looked, because he'd already studied at the Royal Academy of Music in London, then spent two years in Vienna under Oleg Petrovic.

经过一开始痛苦的适应期后，他学会了应付大师出了名的坏脾气，信心满满地离开维也纳——应邀到欧洲一些不大、但是很有名的地方演出。
After a rocky start with the old maestro, he'd learnt to handle those legendary temper tantrums and had left Vienna full of confidence – and with a series of engagements in prestigious, if small venues around Europe.

可是后来由于演出市场不景气，音乐会逐渐被取消；他开始被迫演奏一些他讨厌的音乐；住的地方不是贵就是脏。
But then concerts began to get cancelled due to low demand; he'd been forced to perform music he hated; accommodation had proved expensive or sordid.

于是乎我们这里精心组织的文化艺术节——那年夏天他正是为此而来——就成了他最需要的助推器。当皇家学院的一个老朋友愿意夏天把运河旁的一间公寓借给他时，他毫不犹豫就答应了。
So our city's well-organised Arts and Culture Festival – which was what brought him here that summer – had been a much-needed boost, and when an old friend from the Royal Academy had offered him a free apartment for the summer down near the canal, he'd taken it up without hesitation.

他说他很喜欢我们的城市，可是钱永远是个问题，虽然他偶尔有些演出，但现在他不得不好好考虑下一步怎么走了。
He was enjoying our city, he told us, but cash was always a problem, and though he'd had the occasional recital, he was now having to think hard about his next move.

听说了蒂博尔的烦恼以后不久，詹卡洛和欧内斯托决定：我们应该为他做些事情。
It was after a while of listening to these worries that Giancarlo and Ernesto decided we should try and do something for him.

就这样蒂博尔见到了阿姆斯特丹来的考夫曼先生，詹卡洛的一个远房亲戚，在酒店界有点关系。
And that was how Tibor got to meet Mr Kaufmann, from Amsterdam, a distant relative of Giancarlo's with connections in the hotel world.

我仍然清楚地记得那个晚上。
I remember that evening very well.

那时还是初夏，考夫曼先生、詹卡洛、欧内斯托，还有乐队里其他所有的人，我们坐在咖啡馆的里屋，听蒂博尔拉琴。
It was still early in the summer, and Mr Kaufmann, Giancarlo, Ernesto, all the rest of us, we sat indoors, in the back room of the cafe, listening to Tibor play his cello.

年轻人一定是知道这是考夫曼先生的试听，所以那天晚上表演得特别卖力，现在回想起来真是有意思。
The young man must have realised he was auditioning for Mr Kaufmann, so it's interesting now to remember how keen he was to perform that night.

他显然很感激我们，当考夫曼先生答应回阿姆斯特丹以后会尽力帮助他的时候，他的喜悦之情溢于言表。
He was obviously grateful to us, and you could see he was pleased when Mr Kaufmann promised to do what he could for him on his return to Amsterdam.

大家说那年夏天蒂博尔开始走下坡路，说他头脑发热、不知好歹，说都是因为那个美国女人，咳，也许不无道理。
When people say Tibor changed for the worse that summer, that his head got too big for his own good, that this was all down to the American woman, well, maybe there's something in that.

一天，蒂博尔喝着第一杯咖啡，注意到了那个女人。
Tibor had become aware of the woman while sipping his first coffee of the day.

那时广场上还挺凉快——早上大部分时候咖啡馆的尽头都照不到太阳——洒过水的石块路面还湿湿的。
At that moment, the piazza was pleasantly cool – the cafe end remains shaded for much of the morning – and the paving stones were still wet from the city workers’ hoses.

蒂博尔没有吃早饭，所以眼红地看着隔壁的女人点了好几种混合果汁，后来又要了一盘蒸贻贝——肯定是一时兴起点的，因为那时还不到十点。
Having gone without breakfast, he'd watched enviously while at the next table she'd ordered a series of fruit-juice concoctions, then – apparently on a whim, for it wasn't yet ten o'clock – a bowl of steamed mussels.

他隐约觉得那女的也在偷偷看他，可他没有放在心上。
He had the vague impression the woman was, for her part, stealing glances back at him, but hadn't thought too much about it.

“她长得不错，甚至算得上漂亮，”那时蒂博尔这么对我们说。
‘She looked very pleasant, beautiful even,’ he told us at the time.

“可你们瞧，她比我大十、十五岁。
‘But as you see, she's ten, fifteen years older than me.

所以我干吗要胡思乱想呢？”
So why would I think anything was going on?’

不久蒂博尔就把她给忘了，准备回去，在邻居回家吃午饭、开起收音机前练两个小时琴。突然那女的站到他面前。
He'd forgotten about her and was preparing to get back to his room for a couple of hours’ practice before his neighbour came in for lunch and turned on that radio, when suddenly there was the woman standing in front of him.

女人笑嘻嘻地看着他，那样子好像他们认识似的。
She was beaming broadly, everything in her manner suggesting they already knew each other.

只不过蒂博尔天性害羞，才没有跟她打招呼。
In fact it was only his natural shyness that stopped him greeting her.

女人把一只手搭到他的肩上，像是在原谅一个考试不及格的学生，说：
Then she placed a hand on his shoulder, as though he'd failed some test but was being forgiven anyway, and said:

“几天前我看了你的独奏会。
‘I was at your recital the other day.

在圣洛伦佐。”
At San Lorenzo.’

“谢谢，”他答道，但心里知道自己的回答傻乎乎的。
‘Thank you,’ he replied, even as he realised how foolish this might sound.

看见那女的还是低头朝着他笑，他又说道：“哦，是的，圣洛伦佐教堂。
Then when the woman just went on beaming down at him, he said:‘Oh yes, the San Lorenzo church.

没错。
That's correct.

我确实在那里演出过。”
I did indeed give a recital there.’

那女的笑了一声，突然在他面前坐了下来。
The woman laughed, then suddenly seated herself in the chair in front of him.

“说得好像你最近演出很多似的，”女人略带讥讽地说道。
‘You say that like you've had a whole string of engagements lately,’ she said, a hint of mockery in her voice.

“如果您这么觉得，恐怕我给了您错误的印象。
‘If that is so, I've given you a misleading impression.

您看的那场独奏会是我最近两个月唯一的一次演出。”
The recital you attended was my only one in two months.’

“可是你才刚开始，”女的说。
‘But you're just starting out,’ she said.

“有演出就是好事。
‘You're doing fine to get any engagements at all.

而且那天观众不少。”
And that was a good crowd the other day.’

“观众不少？
‘A good crowd?

那天才二十四个人。”
There were only twenty-four people.’

“那是下午。
‘It was the afternoon.

下午的独奏会能有那些人算不错了。”
It was good for an afternoon recital.’

“我不应该抱怨。
‘I should not complain.

可是观众实在不多。
Still, it wasn't a good crowd.

都是些没有其他事可做的游客。”
Tourists with nothing better to do.’

“哦！
‘Oh!

别这么瞧不起人。
You shouldn't be so dismissive.

毕竟我在那里。
After all, I was there.

我也是游客之一。”
I was one of those tourists.’

蒂博尔脸红了——因为他无意冒犯——这时那女的拍了拍他的手臂，微笑着说道：“你才刚开始。
Then as he began to redden – for he hadn't meant to give offence – she touched his arm and said with a smile:‘You're just starting out.

别在意有多少观众。
Don't worry about audience size.

你不是为了这个演出的。”
That's not why you're performing.’

“哦？
‘Oh?

若不是为了观众，那我为了什么演出呢？”
Then why am I performing if not for an audience?’

“我不是这个意思。
‘That's not what I said.

我想说的是在你事业的这个阶段，二十个观众还是两百个观众，没有关系。
What I'm saying to you is that at this stage in your career, twenty in the audience or two hundred, it doesn't matter.

为什么？
Should I tell you why not?

因为你行！”
Because you've got it!’

“我行？”
‘I have it?’

“没错。
‘You have it.

你行。
Most definitely.

你有……这个潜力。”
You have ... potential.’

蒂博尔差点儿很没礼貌地笑出声来。
He stifled a brusque laugh that came to his lips.

他不怪那女的，更多的是怪他自己。他本以为对方会说“天赋”，或至少是“才能”，可马上转念想到：他希望对方这么评价自己是多么的愚蠢。
He felt more reproach towards himself than for her, for he had expected her to say ‘genius’ or at least ‘talent’ and it immediately struck him how deluded he'd been to expect such a comment.

然而那女的继续说道：
But the woman was continuing:

“现阶段，你要做的是等有人来听见你的音乐。
‘At this stage, what you're doing is waiting for that one person to come and hear you.

这个人很可能就在周二那天的那间屋子里，在那二十个人里面……”
And that one person might just as easily be in a room like that one on Tuesday, in a crowd of just twenty people . . .’

“是二十四个人，不包括组织者……”
‘There were twenty-four, not including the organisers. . .’

“二十四，随便。
‘Twenty-four, whatever.

我的意思是目前观众的人数不重要。
What I'm saying is that numbers don't matter right now.

重要的是那一个人。”
What matters is that one person.’

“您是指唱片公司的？”
‘You refer to the man from the recording company?’

“唱片公司？
‘Recording?

哦，不，不是。
Oh no, no.

用不着操心那个。
That'll take care of itself.

不，我指能挖掘你潜力的人。
No, I mean the person who'll make you blossom.

听了你的音乐，知道你不是又一个训练有素的平庸之才的人。
The person who'll hear you and realise you're not just another well-trained mediocrity.

知道虽然你现在还只是一枚茧，但只要些许帮助，就可以破茧成蝶。”
That even though you're still in your chrysalis, with just a little help, you'll emerge as a butterfly.’

“我懂您的意思了。
‘I see.

您是不是碰巧就是那个人？”
By any chance, might you be this person?’

“哦，拜托！
‘Oh, come on!

我看得出来你是个自尊心很强的年轻人，可我不觉得会经常有导师主动来找你。
I can see you're a proud young man. But it doesn't look to me like you have so many mentors falling over themselves to get to you.

至少不是我这个级别的。”
At least not ones of my rank.’

这时，蒂博尔突然意识到自己可能在犯一个大错。他仔细端详着那个女人的脸。
It occurred to him then that he was in the midst of making a colossal blunder, and he considered the woman's features carefully.

那女的已把墨镜摘下，她的脸温柔友善，但带着失望，甚至是些许愤怒。蒂博尔直盯着她看，脑子里拼命在想她是谁，但最后他只能说道：
She'd now removed her sunglasses, and he could see a face that was essentially gentle and kind, yet with upset and perhaps anger not far away. He went on looking at her, hoping he'd soon recognise her, but in the end he was forced to say:

“很抱歉。
‘I'm very sorry.

您大概是位著名的音乐家？”
You are perhaps a distinguished musician?’

“我叫埃洛伊丝·麦科马克，”她微笑着说道，伸出一只手来。
‘I'm Eloise McCormack,’ she announced with a smile, and held out her hand.

可惜这个名字对蒂博尔来说毫无意义，他不知该如何是好。
Unfortunately, the name meant nothing to Tibor and he found himself in a quandary.

他的第一反应是假装惊讶，他说：“真的。
His first instinct was to feign astonishment, and he actually said:‘Really.

太惊讶了。”
This is quite amazing.’

可他马上就振作起来，知道这种谎话不仅不诚实，而且几秒钟内就会被揭穿的，那样更加尴尬。
Then he pulled himself together, realising such bluffing was not only dishonest, but likely to lead to embarrassing exposure within seconds.

于是他坐直了身子，说道：
So he sat up straight and said:

“麦科马克小姐，很荣幸见到您。
‘Miss McCormack, it's an honour to meet you.

我知道您一定会觉得不可思议，然而是这样，我还年轻，而且是在冷战时期的东欧、在铁幕下长大的，很多西欧人家喻户晓的电影明星和政治人物，我至今还一无所知。
I realise this will seem unbelievable to you, but I beg you to make allowances both for my youth and for the fact that I grew up in the former Eastern bloc, behind the Iron Curtain. There are many film stars and political personalities who are household names in the West, of whom, even today, I remain ignorant.

所以请您原谅，我并不知道您是谁。”
So you must forgive me that I do not know precisely who you are.’

“呃……真是诚实可嘉。”
‘Well . . . that's commendably frank.’

虽然她嘴上这么说，但显然觉得受到了冒犯，没有了之前的热情。
Despite her words, she was clearly affronted, and her ebullience seemed to drain away.

两人尴尬地沉默了片刻，蒂博尔接着说道：
After an awkward moment, he said again:

“您是著名音乐家，没错吧？”
‘You are a distinguished musician, yes?’

她点点头，目光游移到广场上。
She nodded, her gaze drifting across the square.

“我再次向您道歉，”蒂博尔说。
‘Once again I must apologise,’ he said.

“像您这样的人会来看我的演出真是我的荣幸。
‘It was indeed an honour that someone like you should come to my recital.

请问您演奏什么乐器？”
And may I ask your instrument?’

“和你一样，”那女的很快地说道。
‘Like you,’ she said quickly.

“大提琴。
‘Cello.

所以我才会进去听。
That's why I came in.

即便是那天那种不起眼的小音乐会，我也忍不住要去听，不能走开。
Even if it's a humble little recital like yours, I can't help myself. I can't walk by.

我想我有一种使命感。”
I have a sense of mission, I guess.’

“使命感？”
‘A mission?’

“我不知道还有别的什么叫法。
‘I don't know what else to call it.

我希望每个大提琴手都能拉好琴。
I want all cellists to play well.

拉出优美的琴。
To play beautifully.

他们的演奏方法常常被误导了。”
So often, they play in a misguided way.’

“抱歉，是只有我们大提琴手犯有这个毛病，还是指所有的音乐家？”
‘Excuse me, but is it just we cellists who are guilty of this misguided performance? Or do you refer to all musicians?’

“其他乐器可能也有。
‘Maybe the other instruments too.

但我是一个大提琴手，所以我也听其他大提琴手的。
But I'm a cellist, so I listen to other cellists, and when I hear something going wrong . . .

当我听出毛病的时候……你瞧，有一次，我看见一群年轻人在科雷尔博物馆的大厅演奏，大家都从他们身边匆匆走过去，我却停下来听他们演奏。
You know, the other day, I saw some young musicians playing in the lobby of the Museo Civico and people were just rushing past them, but I had to stop and listen.

我极力控制住自己没有走到他们面前去跟他们说。”
And you know, it was all I could do to stop myself going right up to them and telling them.’

“他们拉错了？”
‘They were making errors?’

“不算是。
‘Not errors exactly.

但……咳，就是没有。
But . . . well, it just wasn't there.

就是少了。
It wasn't nearly there.

不过你瞧，我要求太高了。
But there you go, I ask too much.

我知道我不应该要求每个人都达到我给自己定的水平。
I know I shouldn't expect everyone to come up to the mark I set for myself.

我想他们还只是音乐学院的学生。”
They were just music students, I guess.’

那女的第一次靠到椅背上，看着在中央喷泉泼水嬉闹的孩子们。
She leaned back in her seat for the first time and gazed at some children, over by the central fountain, noisily soaking one another.

最后蒂博尔打破沉默，说道：
Eventually, Tibor said:

“星期二那天您大概也有这种冲动吧。
‘You felt this urge also on Tuesday perhaps.

想过来找我把您的意见说出来。”
The urge to come up to me and make your suggestions.’

她微笑了一下，但马上变得非常严肃。
She smiled, but then the next moment her face became very serious.

“没错，”她说道。
‘I did,’ she said. ‘I really did.

“我确实想。因为当我听你演奏的时候，我听见了以前的我。
Because when I heard you, I could hear the way I once was. Forgive me, this is going to sound so rude.

恕我直言，你现在的路子不对。当我听你演奏的时候，我很想帮你走上正轨。
But the truth is, you're not quite on the correct path just now. And when I heard you, I so wanted to help you find it.

宜早不宜迟。”
Sooner rather than later.’

“我必须声明，我接受过奥列格·彼得罗维奇的指导。”
‘I must point out, I have been tutored by Oleg Petrovic.’

蒂博尔平静地说道，等着对方的反应。
Tibor stated this flatly and waited for her response.

他惊奇地看见那女的强忍着没笑出来。
To his surprise, he saw her trying to suppress a smile.

“彼得罗维奇，是，”对方说道。
‘Petrovic, yes,’ she said.

“彼得罗维奇在他的鼎盛时期是一位非常令人尊敬的音乐家。
‘Petrovic, in his day, was a very respectable musician.

我也知道在他的学生心里，他一定仍然是一位重要的人物。
And I know that to his students he must still appear a considerable figure.

可是对我们很多人来说，如今他的想法，他那整套方法……”她摇摇头，两手一摊。
But to many of us now, his ideas, his whole approach . . .’ She shook her head and spread out her hands.

一时间蒂博尔气得说不出话来，只是瞪着她。那女的又一次把一只手搭在他的胳膊上，说：“我说得够多了。
Then as Tibor, suddenly speechless with fury, continued to stare at her, she once again placed a hand on his arm. ‘I've said enough.

我没有权利。
I've no right.

我不再打扰你了。”
I'll leave you in peace.’

她站了起来，这个动作平息了蒂博尔的怒火；蒂博尔天生一副好脾气，从不会对别人耿耿于怀。
She rose to her feet and this action soothed his anger; Tibor had a generous temperament and it wasn't in his nature to remain cross with people for long.

再者，那女人刚才说的关于他旧日老师的那番话触到了他内心深处一根隐隐作痛的心弦——一些他一直不敢面对的想法。
Besides, what the woman had just said about his old teacher had struck an uncomfortable chord deep within him – thoughts he'd not quite dared to express to himself.

因此，当蒂博尔抬头看着那女人时，他脸上更多的是迷惑。
So when he looked up at her, his face showed confusion more than anything else.

“瞧，”那女的说道，“我这么说你一定很生气。
‘Look,’ she said, ‘you're probably too angry with me just now to think about this.

可我想帮你。
But I'd like to help you.

要是你决定想谈一谈，我就住在那里。
If you do decide you want to talk this over, I'm staying over there.

怡东酒店。”
At the Excelsior.’

这家全城最好的酒店坐落在广场的另一头，与咖啡店相对。那女的微笑着指给蒂博尔看，然后迈步朝酒店走去。
This hotel, the grandest in our city, stands at the opposite end of the square from the cafe, and she now pointed it out to Tibor, smiled, and began to walk off towards it.

蒂博尔一直看着她，快到中央喷泉时，那女的突然转过身来，惊起一群鸽子。她朝蒂博尔挥挥手才继续往前走。
He was still watching her when she turned suddenly near the central fountain, startling some pigeons, gave him a wave, then continued on her way.

接下来的两天，这次会面在蒂博尔的脑海里挥之不去。
Over the next two days he found himself thinking about the encounter many times.

他又想起当他那么自豪地说出彼得罗维奇的名字时她嘴角的冷笑，心里的怒火又烧了起来。
He saw again the smirk around her mouth as he'd so proudly announced Petrovic's name and felt the anger rising afresh.

回想那时的情景，蒂博尔知道他并不是为他旧日的老师感到生气，而是他已经习惯认为彼得罗维奇这个名字一定会产生效果，他可以依靠彼得罗维奇这个名字得到关注和尊敬：换句话说，他把这个名字当作向世人炫耀的证书。
But on reflection, he could see he had not really been angry on his old teacher's behalf. It was rather that he had become accustomed to the idea that Petrovic's name would always produce a certain impact, that it could be relied upon to induce attention and respect: in other words, he'd come to depend on it as a sort of certificate he could brandish around the world.

让他感到如此不安的是这个证书也许并不像他原来想的那么有分量。
What had so disturbed him was the possibility that this certificate didn't carry nearly the weight he'd supposed.

他还念念不忘那女的临别时的邀请。当他坐在广场上时，他的视线不时游移到广场的另一端，怡东酒店的大门口，出租车和豪华轿车在门口不停地迎来送往。
He kept remembering too her parting invitation, and during those hours he sat in the square, he found his gaze returning to the far end, and the grand entrance of the Excelsior Hotel, where a steady stream of taxis and limousines drew up in front of the doorman.

终于，那次会面后的第三天，蒂博尔穿过广场，走进酒店的大理石大堂，请前台拨打那女人的分机号。
Finally, on the third day after his conversation with Eloise McCormack, he crossed the piazza, entered the marbled lobby and asked the front desk to call her extension.

前台拨通电话，问蒂博尔名字，说了几句以后就把话筒递给他。
The receptionist spoke into the phone, asked his name, then after a short exchange, passed the receiver to him.

“对不起，”蒂博尔听见那女人的声音说。
‘I'm so sorry,’ he heard her voice say.

“那天我忘了问你的名字，一下子没想起来你是谁。
‘I forgot to ask you your name the other day and it took me a while to figure out who you were.

可我当然没有忘记你。
But of course I haven't forgotten you.

其实我一直在想你。
As a matter of fact, I've been thinking about you an awful lot.

我有好多话想对你说。
There's so much I'd like to talk through with you.

但是要知道，我们得把这事给做对了。
But you know, we have to do this right.

你带着琴吗？
Do you have your cello?

没有，当然没有了。
No, of course you don't.

你一个小时以后再过来吧，一个小时整，到时把琴带上。
Why don't you come back in an hour, exactly one hour, and this time bring your cello.

我在这里等你。”
I'll be waiting here for you.’

当蒂博尔带着乐器回到怡东酒店时，前台马上把电梯指给他看，告诉他麦科马克小姐在等他。
When he returned to the Excelsior with his instrument, the receptionist immediately indicated the elevators and told him Miss McCormack was expecting him.

想到在大下午进她的房间，蒂博尔觉得很不好意思，好在麦科马克小姐的房间是一间大套房，卧室锁着，看不见。
The idea of entering her room, even in the middle of the afternoon, had struck him as awkwardly intimate, and he was relieved to find a large suite, the bedroom closed off entirely from view.

高大的落地窗外装有两扇木质遮阳板，此时打开着，所以蕾丝窗帘随风摇摆。蒂博尔发现走到阳台上就可以俯视广场。
The tall French windows had boarded shutters, for the moment folded back, so the lace curtains moved in the breeze, and he could see that by stepping through onto the balcony, he'd find himself looking over the square.

房间里粗糙的石墙和深色的木地板，感觉非常朴素，只有花、垫子和古典式家具作为装饰。
The room itself, with its rough stone walls and dark wood floor, had almost a monastic air about it, softened only partially by the flowers, cushions and antique furniture.

相反，女主人穿着T恤衫、田径裤和运动鞋，像刚跑步回来。
She, in contrast, was dressed in T-shirt, tracksuit trousers and trainers, as though she'd just come in from running.

她什么招待也没有——没有茶也没有咖啡——就说：
She welcomed him with little ceremony – no offer of tea or coffee – and said to him:

“拉琴给我听。
‘Play for me.

拉些你在独奏会上拉的曲子。”
Play me something you played at your recital.’

她指了指端正地摆放在屋子中央的一把光亮的直椅，蒂博尔坐下来，拿出琴。
She had indicated a polished upright chair carefully placed in the centre of the room, so he sat down on it and unpacked his cello.

那女的则在一扇大窗户前坐下，整个人侧对着蒂博尔，让人感觉不太自在。蒂博尔调音的时候，那女的一直都看着窗外。
Rather disconcertingly, she sat herself in front of one of the big windows so that he could see her almost exactly in profile, and she continued to stare into the space before her all the time he tuned up.

他开始拉了，那女的姿势也没有改变。第一支曲子拉完了，女人不发一言，于是他紧接着演奏下一首，然后又是一首。
Her posture didn't alter as he began to play, and when he came to the end of his first piece, she didn't say a word. So he moved quickly to another piece, and then another.

半个小时过去了，然后一个小时过去了。昏暗的房间、简陋的音效、飘动的蕾丝窗帘掩映下的午后阳光、远远传来的广场上的嘈杂声，但最主要的是那个女人的存在，使他的音符有了新的深度和含义。
A half-hour went by, then a whole hour. And something to do with the shaded room and its austere acoustics, the afternoon sunlight diffused by the drifting lace curtains, the background hubbub rising from the piazza, and above all, her presence, drew from him notes that held new depths, new suggestions.

快一小时的时候，蒂博尔深信他的表现超出了对方的预期。然而当他演奏完最后一曲时，两个人默默地坐了好一会儿，那女的才终于转向他，说道：
Towards the end of the hour, he was convinced he'd more than fulfilled her expectations, but when he had finished his last piece, and they had sat in silence for several moments, she at last turned in her chair towards him and said:

“是，我知道你现在是什么样一个情况了。
‘Yes, I understand exactly where you are.

这事儿不容易，可是你做得到。
It won't be easy, but you can do it.

你一定做得到。
Definitely, you can do it.

我们从布里顿开始吧。
Let's start with the Britten.

那一曲再拉一遍，第一乐章就好，然后我们聊聊。
Play it again, just the first movement, and then we'll talk.

我们一起努力，每次进步一点。”
We can work through this together, a little at a time.’

听了她的话，蒂博尔真想马上收拾东西走人。可是另一种本能——也许仅仅是好奇，也许是其他更深层次的东西——压过了他的自尊心，迫使他开始重新演奏那女的叫他拉的曲子。
When he heard this, he felt an impulse just to pack away his instrument and leave. But then some other instinct – perhaps it was simply curiosity, perhaps something deeper – overcame his pride and compelled him to start playing again the piece she had requested.

他刚拉了几小节，那女的就叫他停下来，开始讲。蒂博尔再次想起身走人。
When after several bars she stopped him and began to talk, he again felt the urge to leave.

出于礼貌，他决定对这不请自来的指导最多再忍五分钟。可是他发现自己没有离开，多待了一会儿，然后又多待了一会儿。
He resolved, just out of politeness, to endure this uninvited tutorial for at most another five minutes. But he found himself staying a little longer, then longer again.

他又拉了几小节，那女的又接着说。她的话一开始总是让人觉得狂妄又很抽象，但当他试着把她的意思表现在音乐里的时候，他发现效果惊人。
He played some more, she talked again. Her words would always strike him initially as pretentious and far too abstract, but when he tried to accommodate their thrust into his playing, he was surprised by the effect.

就这样，不知不觉又一个小时过去了。
Before he realised, another hour had gone by.

“我突然间看见了什么东西，”蒂博尔这么跟我们说。
‘I could suddenly see something,’ he explained to us.

“一座我没进去过的花园。
‘A garden I'd not yet entered.

就在那里，在远处。
There it was, in the distance.

有东西挡着我的去路。
There were things in the way.

可第一次有这么一个花园。
But for the first time, there it was.

一个我从来没见过的花园。”
A garden I'd never seen before.’

当他终于离开酒店，穿过广场来到咖啡馆的时候，太阳已经快落山了。他犒赏了自己一份掼奶油杏仁蛋糕，喜悦之情一览无余。
The sun had almost set when he finally left the hotel, crossed the piazza to the cafe tables, and allowed himself the luxury of an almond cake with whipped cream, his sense of elation barely contained.

接下来的几天，蒂博尔每天下午都到酒店去，回来的时候，虽不像第一次那样有茅塞顿开之感，但至少是精神焕发、信心满满。麦科马克小姐的评论越来越大胆，旁观者（若有这么个旁观者的话）也许会觉得她的话太过分了，可是现在当她打断他的演奏时，蒂博尔再也不会这样想了。
For the next several days, he returned to her hotel each afternoon and always came away, if not with the same sense of revelation he'd experienced on that first visit, then at least filled with fresh energy and hope. Her comments grew bolder, and to an outsider, had there been one, might have seemed presumptuous, but Tibor was no longer capable of regarding her interventions in such terms.

如今他害怕的是麦科马克小姐什么时候会离开这个城市。这个问题开始在他心里萦绕，让他睡不好觉，在每一次愉快的交流过后，当他走出酒店、走进广场时，在他心头投下一层阴影。
His fear now was that her visit to the city would come to an end, and this thought began to haunt him, disturbing his sleep, and casting a shadow as he walked out into the square after another exhilarating session.

可是每次蒂博尔试探地问她的时候，她的回答总是含含糊糊，不能让蒂博尔安心。
But whenever he tentatively raised this question with her, the replies were always vague and far from reassuring.

“哦，等天凉到我受不了的时候，”一次她这么说道。
‘Oh, just until it gets too chilly for me,’ she had said once.

还有一次：“我想我会一直待到我觉得烦为止。”
Or another time:‘I guess I'll stay as long as I'm not bored here.’

“可她自己呢？”
‘But what's she like herself?’ we kept asking him.

我们一直问他。
‘On the cello.

“她的琴拉得怎么样？”
What's she like?’

我们第一次问他这个问题的时候，蒂博尔并没有好好地回答我们，只是说“她一开始就跟我说她是一个大师”之类的话，然后就把话题转到别的地方去了。
The first time we raised this question, Tibor didn't answer us properly, just saying something like:‘She told me she was a virtuoso, right from the start,’ then changing the subject.

可我们揪着问题不放，他只好叹了口气，跟我们解释。
But when he realised we wouldn't let it go, he sighed and began to explain it to us.

事实是，从第一次指导开始，蒂博尔就想听麦科马克小姐演奏，可是不好意思开口。
The fact was, even at that first session, Tibor had been curious to hear her play, but had been too intimidated to ask her to do so.

他看了看麦科马克小姐的房间，没有大提琴的影子，心里有些生疑。
He'd felt only a tiny nudge of suspicion when, looking around her room, he'd seen no sign of her own cello.

可毕竟度假时没把琴带着是很正常的。
After all, it was perfectly natural she wouldn't bring a cello on holiday with her.

而且，也有可能确有一把琴——可能是租来的——在关着的卧室的门后。
And then again, it was possible there was an instrument – perhaps a rented one – in the bedroom behind the closed door.

然而随着他一次次来到这里练琴，这种疑问越来越强烈。
But as he'd continued to return to the suite for further sessions, the suspicions had grown.

蒂博尔努力不去想这些，因为他原本对他们的会面还有所保留，现在统统没有了。
He'd done his best to push them out of his mind, for by this time, he'd lost any lingering reservations about their meetings.

麦科马克小姐只听不拉，似乎给了蒂博尔想象的空间。在不去麦科马克小姐那里的时间里，蒂博尔发觉自己常常在脑子里准备着曲子，想象着她会怎么评论，想象着她摇头、皱眉，或者肯定地点点头。可最让人开心的还数看到她陶醉在自己的音乐里，闭着眼睛，手跟着他假装拉起来。
The mere fact that she was listening to him seemed to draw fresh layers from his imagination, and in the hours between these afternoon sessions, he'd often find himself preparing a piece in his mind, anticipating her comments, her shakes of the head, her frown, the affirming nod, and most gratifying of all, those instances she became transported by a passage he was playing, when her eyes would close and her hands, almost against her will, began shadowing the movements he was making.

然而，他心里的疑问一直挥之不去。一天，他走进麦科马克小姐的套房，卧室的门半掩着。
All the same, the suspicions wouldn't go away, and then one day he came to the room and the bedroom door had been left ajar.

他看见房间里的石墙、一张中世纪风格的四柱床，可没有大提琴的影子。
He could see more stone walls, what looked to be a medieval four-poster bed, but no trace of a cello.

一个大师就算是在度假，也这么久不碰她的乐器吗？
Would a virtuoso, even on holiday, go so long without touching her instrument?

可蒂博尔同样把这个问题赶出了脑海。
But this question, too, he pushed out of his mind.

夏日一天天过去，渐渐地，他们练习完了以后还要到咖啡厅里来继续交谈。麦科马克小姐给他买咖啡，买蛋糕，或者三明治。
As the summer went on, they began to prolong their conversations by coming over to the cafe together after their sessions, and she'd buy him coffees, cakes, sometimes a sandwich.

如今他们不仅仅谈论音乐——虽然每每都会回到音乐上来。比如，麦科马克小姐会问蒂博尔与他在维也纳相好的德国女孩的事。
Now their talk was no longer just about music – though everything always seemed to come back to it. For instance, she might question him about the German girl he'd been close to in Vienna.

“可您要知道，她不是我的女朋友，”蒂博尔说。
‘But you must understand, she was never my girlfriend,’ he would tell her.

“我们从没正式交往。”
‘We were never like that.’

“你的意思是你们从来没有亲密的肢体接触？
‘You mean you never became physically intimate?

这并不代表你不爱她。”
That doesn't mean you weren't in love with her.’

“不，麦科马克小姐，不是的。
‘No, Miss Eloise, that is incorrect.

我当然喜欢她。
I was fond of her, certainly.

可是我们没有相恋。”
But we were not in love.’

“可是昨天你拉拉赫玛尼诺夫的时候，你想起了一段感情。
‘But when you played me the Rachmaninov yesterday, you were remembering an emotion.

是爱，罗曼蒂克的爱。”
It was love, romantic love.’

“不，太荒谬了。
‘No, that is absurd.

我们是好朋友，但不是恋人。”
She was a good friend, but we did not love.’

“但是你拉那一段的时候就像在回忆一段恋情。
‘But you play that passage like it's the memory of love.

你还这么年轻就已经知道抛弃、离别。
You're so young, and yet you know desertion, abandonment.

所以你会那样演奏第三乐章。
That's why you play that third movement the way you do.

大多数大提琴手演奏那一段时都是喜悦的。
Most cellists, they play it with joy.

但是在你看来，那不是喜悦，而是追忆一去不复返的快乐时光。”
But for you, it's not about joy, it's about the memory of a joyful time that's gone for ever.’

他们的交谈就像这样子。蒂博尔也很想回问她的事。
They had conversations like this, and he was often tempted to question her in return.

可是就像他跟着彼得罗维奇学习的时候，他不敢问老师一个私人问题一样，如今他也没有勇气问她的私事。
But just as he'd never dared ask Petrovic a personal question in the whole time he'd studied under him, he now felt unable to ask anything of substance about her.

蒂博尔只是问些她无意中提到的小事——她现在怎么会住在俄勒冈州的波特兰，三年前她怎么从波士顿搬到那里，为什么她“因为有不好的回忆”而讨厌巴黎——但从不深究。
Instead, he dwelt on the little things she let fall – how she now lived in Portland, Oregon, how she'd moved there from Boston three years ago, how she disliked Paris ‘because of its sad associations’ – but drew back from asking her to expand.

如今麦科马克小姐的笑容比他们刚认识的时候自然得多。她还养成了走出酒店时挽着蒂博尔的手走过广场的习惯。
She would laugh much more easily now than in the first days of their friendship, and she developed the habit, when they stepped out of the Excelsior and crossed the piazza, of linking her arm through his.

我们就是这样开始注意他们的，奇怪的一对，男的长相比实际年龄年轻许多，女的有时像个母亲，有时又像个“风骚的女演员”（欧内斯托语）。
This was the point at which we first started noticing them, a curious couple, he looking so much younger than he actually was, she looking in some ways motherly, in other ways ‘like a flirty actress’, as Ernesto put it.

认识蒂博尔之前，我们总爱拿他们俩来嚼舌根。看见他们手挽着手从我们面前信步走过，我们交换一下眼神，说道：“你们觉得呢？
In the days before we got to talking with Tibor, we used to waste a lot of idle chat on them, the way men in a band do. If they strolled past us, arm in arm, we'd look at each other and say:‘What do you think?

他们好上了吧？”
They've been at it, yes?’

可是乐完了以后，我们还是耸耸肩，承认不像：他们没有恋人的感觉。
But having enjoyed the speculation, we'd then shrug and admit it was unlikely: they just didn't have the atmosphere of lovers.

认识蒂博尔以后，听了他给我们讲他每天下午在她套房里的事，我们就不再消遣他，或者拿他开玩笑了。
And once we came to know Tibor, and he began telling us about those afternoons in her suite, none of us thought to tease him or make any funny suggestions.

一天下午，他们坐在广场上喝着咖啡、吃着蛋糕，她讲起了一个想跟她结婚的男子。
Then one afternoon when they were sitting in the square with coffee and cakes, she began to talk about a man who wanted to marry her.

那人名叫彼得·亨德森，在俄勒冈州做高尔夫器材生意，做得很成功。
His name was Peter Henderson and he ran a successful business in Oregon selling golfing equipment.

他聪明、亲切，受到邻里的爱戴。
He was smart, kind, well respected in the community.

他比埃洛伊丝大六岁，但这点年龄差不算大。
He was six years older than Eloise, but that was hardly old.

他跟前妻生有两个孩子，但事情已经妥善解决了。
There were two young children from his first marriage, but things had been settled amicably.

“现在你知道我在这里干什么了吧，”她说道，不安地笑了笑，蒂博尔还没见过她这样子笑。
‘So now you know what I'm doing here,’ she said with a nervous laugh he'd never heard from her before.

“我在躲他。
‘I'm hiding out.

彼得不知道我在哪里。
Peter has no idea where I am.

我想我很残忍。
I guess it's cruel of me.

上周二我给他打了电话，告诉他我在意大利，但没说在哪个城市。
I called him last Tuesday, told him I was in Italy, but I didn't say which city.

他很生我的气，我想他有权生气。”
He was mad at me and I guess he's entitled to be.’

“这么说，”蒂博尔说道。
‘So,’ said Tibor.

“这个夏天你在考虑你的未来。”
‘You are spending the summer contemplating your future.’

“不算是。
‘Not really.

我只是在躲着他。”
I'm just hiding.’

“您不喜欢他？”
‘You do not love this Peter?’

她耸耸肩。
She shrugged.

“他是个好人。
‘He's a nice man.

再说，我也没其他什么人可选。”
And I don't have a lot of other offers on the table.’

“这个彼得。
‘This Peter.

他喜欢音乐吗？”
He is a music lover?’

“哦……在我现在住的地方，他当然算是喜欢音乐的。
‘Oh . . . Where I live now, he would certainly count as one.

至少他去听音乐会。
After all, he goes to concerts.

然后到餐厅吃饭的时候，他会就刚刚听的东西大加赞美。所以我想他是喜欢音乐的。”
And afterwards, in the restaurant, he says a lot of nice things about what we just heard. So I guess he's a music lover.’

“可是他……欣赏您吗？”
‘But he ... appreciates you?’

“他知道跟一个音乐大师一起生活不容易。”
‘He knows it won't always be easy, living with a virtuoso.’

她叹了口气。
She gave a sigh.

“我一辈子都有这个问题。
‘That's been the problem for me all my life.

你也一样。
It won't be easy for you either.

可是你和我，我们别无选择。
But you and me, we don't really have a choice.

我们有我们的路要走。”
We have our paths to follow.’

她没有再提起彼得。可是从那以后，他们的关系又加深了一些。
She didn't bring Peter up again, but now, after that exchange, a new dimension had opened in their relationship.

当他演奏完、她陷入沉思的时候，当他们一起坐在广场上，她看着旁边的阳伞默不做声的时候，蒂博尔一点儿也不会觉得不自在。他知道麦科马克小姐不是不理睬他，反而是感谢有他在。
When she had those quiet moments of thought after he'd finished playing, or when, sitting together in the piazza, she became distant, staring off past the neighbouring parasols, there was nothing uncomfortable about it, and far from feeling ignored, he knew his presence there beside her was appreciated.

一天下午，蒂博尔拉完一曲后，麦科马克小姐叫他把接近尾声的一个八小节再拉一遍。
One afternoon when he'd finished playing a piece, she asked him to play again one short passage – just eight bars – from near the close.

他照做了，然后看见麦科马克小姐仍旧微微地皱着眉。
He did as asked and saw the little furrow remain on her forehead.

“拉的不是我们，”她摇摇头，说。
‘That doesn't sound like us,’ she said, shaking her head.

麦科马克小姐和平常一样坐在落地窗前侧对着蒂博尔。
As usual, she was sitting in profile to him in front of the big windows.

“其他部分都很好。
‘The rest of what you played was good.

剩下的全部都是我们。
All the rest of it, that was us.

可是这一小段……”她轻轻地哆嗦了一下。
But that passage there . . .’ She did a little shudder.

他用不同的方法又演奏了一遍，但其实并不清楚他到底应该怎么拉，所以看见麦科马克小姐再次摇头他不奇怪。
He played it again, differently, though not at all sure what he was aiming for, and wasn't surprised to see her shake her head again.

“请原谅，”蒂博尔说道。
‘I'm sorry,’ he said.

“请您说得明白一点。
‘You must express yourself more clearly.

我不明白您说的‘不是我们’是什么意思。”
I do not understand this “not us”.’

“你是要我示范给你看吗？
‘You mean you want me to play it myself?

你是这意思吗？”
Is that what you're saying?’

她的语气平静，转过脸来看着蒂博尔，蒂博尔感到气氛紧张。
She'd spoken calmly, but as she now turned to face him, he was aware of a tension descending on them.

她目不转睛地看着他，近乎挑战，等着他回答。
She was looking at him steadily, almost challengingly, waiting for his answer.

最后，蒂博尔说道：“不是，我再试一次。”
Eventually he said:‘No, I'll try again.’

“可你在想我为什么不示范给你看，对不对？
‘But you're wondering why I don't just play it myself, aren't you?

为什么不借你的琴来说明我的意思。”
Borrow your instrument and demonstrate what I mean.’

“没有……”蒂博尔摇摇头，努力装作若无其事的样子。
‘No . . .’

“没有。
He shook his head with what he hoped looked like nonchalance.

我觉得现在这样很好。
‘No. I think it works well, what we've always done.

您口述，我拉琴。
You suggest verbally, then I play.

这样我才不是在模仿、模仿、模仿。
That way, it's not like I copy, copy, copy.

您的话给我打开了一扇扇窗子。
Your words open windows for me.

要是您来拉，窗子就不会打开。
If you played yourself, the windows would not open.

我就只是在模仿。”
I'd only copy.’

麦科马克小姐想了想，说：“也许你说得对。
She considered this, then said:‘You're probably right.

好吧，我尽量解释得明白一点。”
Okay, I'll try and express myself a little better.’

接下来的几分钟，麦科马克小姐跟他解释乐曲的尾声与桥段的差别。
And for the next few minutes she talked – about the distinction between epilogues and bridging passages.

然后蒂博尔把那一小段又拉了一遍，麦科马克小姐笑了笑，赞许地点点头。
Then when he played those bars once more, she smiled and nodded approvingly.

然而这个小插曲以后，他们的下午时光就蒙上了一层阴影。
But from that little exchange on, something shadowy had entered their afternoons.

也许阴影一直都在，只不过现在不小心从瓶子里跑出来，萦绕着他们。
Perhaps it had been there all along, but now it was out of the bottle and hovered between them.

又有一次，他们坐在广场上，蒂博尔说起他的大提琴的前一任主人怎么在苏联时代用几条美国牛仔裤换得这把琴。
Another time, when they were sitting in the piazza, he'd been telling her the story of how the previous owner of his cello had come by it in the Soviet Union days by bartering several pairs of American jeans.

故事讲完以后，麦科马克小姐似笑非笑地看着他，说：
When he'd finished the story, she looked at him with a curious half-smile and said:

“这是把好琴。
‘It's a good instrument.

声音不错。
It has a fine voice.

可我碰都没碰过，说不准。”
But since I've never so much as touched it, I can't really judge it.’

蒂博尔知道她又在试图闯入那个领域，马上把目光转向别处，说道：
He knew then she was again moving towards that territory, and he quickly looked away, saying:

“它不适合像您这种地位的人。
‘For someone of your stature, it would not be an adequate instrument.

就算是我，现在也感觉不太够用了。”
Even for me, now, it is barely adequate.’

蒂博尔发现他再也不能无忧无虑地与麦科马克小姐交谈了。他害怕麦科马克小姐重新提起这件事，又回到那里。
He found he could no longer relax during a conversation with her for fear she would hijack it and bring it back onto this territory.

即便是在他们交谈甚欢的时候，蒂博尔大脑的一部分也在提防着，她一想从别的突破口转到那里去，蒂博尔马上把门关上。
Even during their most enjoyable exchanges, a part of his mind would have to remain on guard, ready to shut her off if she found yet another opening.

即便如此，蒂博尔也不是每一次都能把话题转开，于是当她说：“哦，要是我能示范给你看就容易多了！”之类的话时，他只能装作没听见。
Even so, he couldn't divert her every time, and he'd simply pretend not to hear when she said things like:‘Oh, it would be so much easier if I could just play it for you!’

九月下旬——风渐渐转凉——詹卡洛接到考夫曼先生从阿姆斯特丹打来的电话：在市中心的一家五星级饭店里一支小型室内乐队需要一个大提琴手。
Towards the end of September – there was now a chill in the breeze – Giancarlo received a phone call from Mr Kaufmann in Amsterdam; there was a vacancy for a cellist in a small chamber group at a five-star hotel in the centre of the city.

乐队在一个俯瞰餐厅的音乐席上演奏，一周演出四次。
The group played in a minstrels' gallery overlooking the dining room four evenings a week, and the musicians also had other ‘light, non-musical duties’ elsewhere in the hotel.

除了演出，乐手们在酒店里还有其他“与音乐无关的、轻松的工作”，包食宿。
Board and accommodation terms were available.

考夫曼先生马上想到蒂博尔，把空缺给他留着。
Mr Kaufmann had immediately remembered Tibor and the post was being held open for him.

我们立即把这个消息告诉蒂博尔——就在考夫曼先生打来电话的当晚，在咖啡馆里——我想大家都被蒂博尔的冷淡反应吓了一跳。
We gave Tibor the news straight away – in the cafe the very evening of Mr Kaufmann's call – and I think we were all taken aback by the coolness of Tibor's response.

与之前我们安排考夫曼先生对他进行“试听”时判若两人。
It was certainly a contrast to his attitude earlier in the summer, when we'd fixed up his ‘audition’ with Mr Kaufmann.

尤其是詹卡洛非常生气。
Giancarlo, in particular, became very angry.

“你还有什么好考虑的？”他质问蒂博尔。
‘So what is it you have to think over so carefully?’ he demanded of the boy.

“你想要什么样儿的？
‘What were you expecting?

卡内基音乐厅？”
Carnegie Hall?’

“我不是不领情。可我总得考虑一下。
‘I'm not ungrateful. Nevertheless, I must give this matter some thought.

给在吃饭聊天的人演奏，还有酒店的其他工作，是不是真的适合我？”
To play for people while they chat and eat. And these other hotel duties. Is this really suitable for someone like me?’

詹卡洛是个容易冲动的人，我们大家赶紧拦住他，不让他抓住蒂博尔的衣服，冲他大嚷。
Giancarlo always lost his temper too quickly, and now the rest of us had to stop him from grabbing Tibor by his jacket and shouting into his face.

我们当中的一些人帮蒂博尔说话，说毕竟这是他自己的事，他没有义务接受他觉得不合适的工作。事情终于平静下来，这时蒂博尔也说这份工作若作为一份临时工作，也是有诸多优点的。
Some of us even felt obliged to take the boy's side, pointing out it was his life, after all, and that he was under no obligation to take any job he was uncomfortable with. Things eventually calmed down, and Tibor then began to agree the job had some good points if viewed as a temporary measure.

他冷冷地指出，这座城市过了旅游旺季就是一潭死水，阿姆斯特丹好歹是个文化中心。
And our city, he pointed out rather insensitively, would become a backwater once the tourist season was over. Amsterdam at least was a cultural centre.

“我会好好考虑的，”最后他说道。
‘I'll give this matter careful thought,’ he said in the end.

“麻烦你转告考夫曼先生，我会在三天之内给他答复。”
‘Perhaps you will kindly tell Mr Kaufmann I will give him my decision within three days.’

詹卡洛对这个结果一点儿都不满意——他原本期望蒂博尔会对他感恩戴德——可他还是去给考夫曼先生打了电话。
Giancarlo was hardly satisfied by this – he'd expected fawning gratitude, after all – but he went off all the same to call back Mr Kaufmann.

整个晚上，没有人提起埃洛伊丝·麦科马克，然而大家都清楚蒂博尔会说那些话都是因为她。
During the whole of this discussion that evening, Eloise McCormack had not been mentioned, but it was clear to us all her influence was behind everything Tibor had been saying.

“那个女人把他变成了一个不知天高地厚的小笨蛋，”蒂博尔离开以后欧内斯托说。
‘That woman's turned him into an arrogant little shit,’ Ernesto said after Tibor had left.

“让他就这副德性去阿姆斯特丹吧。
‘Let him take that attitude with him to Amsterdam.

很快他就会尝到苦头了。”
He'll soon get a few corners knocked off him.’

蒂博尔从未跟埃洛伊丝提起考夫曼先生的试听。
Tibor had never told Eloise about his audition with Mr Kaufmann.

他好几次想把事情说出来，却总是开不了口。他们的友谊越深，蒂博尔就越觉得若他接受了这份工作就像是背叛了埃洛伊丝。
He'd been on the verge of doing so many times, but had always drawn back, and the deeper their friendship had grown, the more it seemed a betrayal that he'd ever agreed to such a thing.

因此蒂博尔自然不会把事情的最新进展与埃洛伊丝商量，甚至都没有让她知道。可是蒂博尔从来就不善于隐藏秘密，他决定不让埃洛伊丝知道这件事，却发生了意想不到的事。
So naturally Tibor felt no inclination to consult Eloise about these latest developments, or even allow her any inkling of them. But he'd never been good at concealment, and this decision to keep a secret from her had unexpected results.

那天下午异常暖和。
It was unusually warm that afternoon.

蒂博尔像往常一样来到酒店，开始把他准备的新曲子演奏给埃洛伊丝听。
He'd come to the hotel as usual, and begun to play for her some new pieces he'd been preparing.

但是刚拉了三分钟，埃洛伊丝就叫他停下，说道：
But after barely three minutes, she made him stop, saying:

“你有心事，你一进来我就看出来了。
‘There's something wrong. I thought it when you first came in.

我现在很了解你了，蒂博尔，我几乎从你敲门的声音就能听出来。
I know you so well now, Tibor, I could tell, almost from the way you knocked on the door.

听你拉琴以后，我更肯定了。
Now I've heard you play, I know for certain.

没用的，你瞒不过我。”
It's useless, you can't hide it from me.’

蒂博尔沮丧地放下琴弓，正准备和盘托出时，埃洛伊丝举起一只手，说道：
He was in some dismay, and lowering his bow, was about to make a clean breast of everything, when she put up her hand and said:

“这件事我们逃避不了。
‘This is something we can't keep running away from.

你一直在回避这个问题，没用的。
You always try to avoid it, but it's no use.

我想谈一谈。
I want to discuss it.

这一个星期以来，我一直想谈一谈。”
The whole of this past week, I've been wanting to discuss it.’

“真的？”
‘Really?’

蒂博尔惊讶地看着她。
He looked at her in astonishment.

“对，”她说道，并且把椅子转过来，第一次正对着蒂博尔。
‘Yes,’ she said, and moved her chair so that for the first time she was directly facing him.

“我从没有要骗你，蒂博尔。
‘I never intended to deceive you, Tibor.

过去这几周，我很不好受，你是这么好的一个朋友。
These last few weeks, they haven't been the easiest for me, and you've been such a dear friend.

若你觉得我是个无耻的骗子，我会非常非常难过的。
I'd so hate it if you thought I ever meant to play some cheap trick on you.

不，求你，别再拦着我了。
No, please, don't try and stop me this time.

我要说出来。
I want to say this.

如果现在你把琴给我，叫我拉，我只能说不行，我拉不了。
If you gave me that cello right now and asked me to play, I'd have to say no, I can't do it.

不是因为那把琴不好，不是的。
Not because the instrument isn't good enough, nothing like that.

要是你现在觉得我是一个骗子、我是一个冒牌货，那我要告诉你，你错了。看看我们一起取得的成绩。
But if you're now thinking I'm a fake, that I've somehow pretended to be something I'm not, then I want to tell you you're mistaken.

难道还不足以证明我是货真价实的？
Look at everything we've achieved together.

没错，我跟你说我是一个大师。
Isn't that proof enough I'm no fake anything?

好吧，我来解释一下我这么说的意思。
Yes, I told you I was a virtuoso. Well, let me explain what I meant by that.

我天生拥有非常特殊的天赋，像你一样。你和我，我们拥有其他大多数大提琴手没有的东西，这种东西不管他们怎么努力练习，都没法得到。
What I meant was that I was born with a very special gift, just as you were. You and me, we have something most other cellists will never have, no matter how hard they practise.

我在教堂里第一次听你演出时，就在你身上看见了这种东西。
I was able to recognise it in you, the moment I first heard you in that church.

而你一定也从哪里看出我身上的这种东西，所以你当初才会决定到酒店来找我。
And in some way, you must have recognised it in me too. That's why you decided to come to this hotel that first time.

“像我们这种人不多，蒂博尔，而我们认识了彼此。
‘There aren't many like us, Tibor, and we recognise each other.

就算我还没学会拉琴，又有什么关系。
The fact that I've not yet learned to play the cello doesn't really change anything.

你得明白，我确实是一个大师。
You have to understand, I am a virtuoso.

只是我的才能还没得到挖掘。
But I'm one who's yet to be unwrapped.

你也一样，你的才能还没有被完全挖掘出来。
You too, you're still not entirely unwrapped, and that's what I've been doing these past few weeks.

这就是我这几周以来一直在做的事情，帮你剥去外面的表层。
I've been trying to help you shed those layers.

但是我从没有要骗你。
But I never tried to deceive you.

百分之九十九的大提琴手表层下面没东西了，没有才能可挖。
Ninety-nine per cent of cellists, there's nothing there under those layers, there's nothing to unwrap.

所以我们这类人应该互相帮助。
So people like us, we have to help each other.

当我们在一个拥挤的广场，还是别的什么地方发现对方时，应该主动伸出援手，因为像我们这样的人太少了。”
When we see each other in a crowded square, wherever, we have to reach out for one another, because there are so few of us.’

蒂博尔发现她的眼睛里噙着泪水，但声音却始终平稳。
He noticed that tears had appeared in her eyes, but her voice had remained steady.

如今她不说话了，再次把脸转开。
She now fell silent and turned away from him again.

“这么说您相信自己将来会成为一名特别的大提琴演奏家，”片刻的沉默之后蒂博尔说道。
‘So you believe yourself to be a special cellist,’ he said after a moment.

“一位大师。
‘A virtuoso.

我们其他人，埃洛伊丝小姐，按您的话说，我们得鼓起勇气挖掘自己，却始终不确定能挖到什么。
The rest of us, Miss Eloise, we have to take our courage in our hands and we unwrap ourselves, as you put it, all the time unsure what we will find underneath.

而您，您不在乎什么挖掘。
Yet you, you do not care for this unwrapping.

您什么都不做。
You do nothing.

但您很肯定自己是个大师……”
But you are so sure you are this virtuoso . . .’

“请别生气。
‘Please don't be angry.

我知道我说的像疯话。
I know it sounds a little crazy.

可我说的是真的，事实就是如此。
But that's how it is, it's the truth.

我母亲在我很小的时候就发现了我的天赋。
My mother, she recognised my gift straight away, when I was tiny.

我至少很感激她这一点。
I'm grateful to her for that at least.

可是她给我找的那些老师，我四岁的那个，七岁的，十一岁的，统统不好。
But the teachers she found for me, when I was four, when I was seven, when I was eleven, they were no good.

妈妈不知道，可我知道。
Mom didn't know that, but I did.

虽然我还只是个孩子，可是我有这种直觉。
Even as a small girl, I had this instinct.

我知道我得保护我的天赋，不让别人给毁了，不管这些人多么好心。
I knew I had to protect my gift against people who, however well-intentioned they were, could completely destroy it.

于是我把这些人统统赶走了。
So I shut them out.

你也一样，蒂博尔。
You've got to do the same, Tibor.

你的天赋很宝贵。”
Your gift is precious.’

“请原谅，”蒂博尔打断埃洛伊丝，但语气没有刚才那么冲了。
‘Forgive me,’ Tibor interrupted, now more gently.

“你是说你小时候拉过琴。
‘You say you played the cello as a child.

可现在……”
But today . . .’

“我从十一岁以后就再也没碰过琴了，从我向我母亲解释我不能再跟罗斯先生学琴的那天起。
‘I haven't touched the instrument since I was eleven. Not since the day I explained to Mom I couldn't continue with Mr Roth.

她理解。
And she understood.

她同意最好等等，先什么都别做。
She agreed it was much better to do nothing and wait.

最重要的是不要破坏我的天赋。
The crucial thing was not to damage my gift.

总有一天我的时机会到。
My day may still come though.

好吧，有时候我也觉得拖得太久了。
Okay, sometimes I think I've left it too late.

我今年四十一了。
I'm forty-one years old now.

可至少我没有破坏我与生俱来的那些东西。
But at least I haven't damaged what I was born with.

这些年来我遇到了多少自称能帮助我的老师，可是我把他们看透了。
I've met so many teachers over the years who've said they'd help me, but I saw through them.

就算是我们，有时候也很难辨别出来，蒂博尔。
Sometimes it's difficult to tell, Tibor, even for us.

这些人，他们太……太专业了，他们讲得头头是道，你听着，然后就被骗了，以为，啊，终于有人能帮我了，他跟我们是一类。
These teachers, they're so . . . professional, they talk so well, you listen and at first you're fooled. You think, yes, at last, someone to help me, he's one of us.

可后来你就知道他根本不是。
Then you realise he's nothing of the kind.

这个时候你就得坚决地把自己关起来。
And that's when you have to be tough and shut yourself off.

记住，蒂博尔，宁可再等一等。
Remember that, Tibor, it's always better to wait.

有时候我也感到痛苦，我的才华还没被挖掘出来。
Sometimes I feel bad about it, that I still haven't unveiled my gift.

可我也还没把它给毁了，这才是最重要的。”
But I haven't damaged it, and that's what counts.’

蒂博尔终于把他准备的曲子拉了两首给麦科马克小姐听，但是两个人心情都不好，就早早结束了练习。
He eventually played for her a couple of the pieces he'd prepared, but they couldn't retrieve their usual mood and they ended the session early.

他们来到广场上喝咖啡，很少说话，直到蒂博尔告诉麦科马克小姐他打算离开这里几天。
Down in the piazza, they drank their coffee, speaking little, until he told her of his plans to leave the city for a few days.

他说他一直想到附近的乡村去走一走，所以给自己安排了一个短假。
He'd always wanted to explore the surrounding countryside, he said, so now he'd arranged a short holiday for himself.

“放个假好，”麦科马克小姐平静地说。
‘It'll do you good,’ she said quietly.

“可别去太久。
‘But don't stay away too long.

我们还有很多事要做。”
We still have a lot to do.’

蒂博尔保证说他顶多一个星期就回来。
He reassured her he'd be back within a week at the most.

可当他们分手的时候，麦科马克小姐的样子还是有些不安。
Nevertheless, there was still something uneasy in her manner as they parted.

蒂博尔说他要离开不全是实话：他还什么都没准备。
He'd not been entirely truthful about his going away: he hadn't yet made any arrangements.

但是那天下午与埃洛伊丝道别以后，他回到家里，打了几通电话，最后在翁布里亚附近山区的一家青年旅馆订了一张床位。
But after leaving Eloise that afternoon, he went home and made several phone calls, eventually reserving a bed at a youth hostel in the mountains near the Umbrian border.

那天晚上他来咖啡馆看我们，同时告诉我们他准备去旅行——我们七嘴八舌地告诉他应该去哪里、应该看些什么——他还怯怯地请詹卡洛告诉考夫曼先生说他愿意接受那份工作。
He came to see us at the cafe that night, and as well as telling us about his trip – we gave him all kinds of conflicting advice about where to go and what to see – he rather sheepishly asked Giancarlo to let Mr Kaufmann know he'd like to take up the job offer.

“不然我能怎么办？”
‘What else can I do?’ he said to us.

他说。“等我回来就分文不剩了。”
‘By the time I get back, I'll have no money left at all.’

蒂博尔在附近的乡村度过了一个不错的假期。
Tibor had a pleasant enough break in our countryside.

他没有告诉我们多少旅行见闻，只说和几个徒步旅行的德国游客交了朋友，在山坡上的小饭馆多花了些钱。
He didn't tell us much about it, other than that he'd made friends with some German hikers, and that he'd spent more than he could afford in the hillside trattorias.

他去了一个星期，回来以后明显精神了许多，但也急于想知道埃洛伊丝·麦科马克是不是还在这里。
He came back after a week, looking visibly refreshed, but anxious to establish that Eloise McCormack had not left the city during his absence.

那时游客已经逐渐变少，店里的服务生也把室外暖气搬了出来、放在餐桌旁。
The tourist crowds were beginning to thin by then, and the cafe waiters were bringing out terrace heaters to place among the outdoor tables.

蒂博尔回来的那天下午就拿着琴，在跟平时一样的时间，来到怡东酒店。他高兴地发现埃洛伊丝不仅在等他，而且看得出来还在想念他。
On the afternoon of his return, at their usual time, Tibor took his cello to the Excelsior again, and was pleased to discover not only that Eloise was there waiting for him, but that she'd obviously missed him.

埃洛伊丝热情地欢迎他，就好像一般人激动的时候会拿一大堆吃的或者喝的招待客人一样，埃洛伊丝一把把蒂博尔推到他平时坐的那把椅子上，迫不及待地打开琴盒，说：“拉琴给我听！
She welcomed him with emotion, and just as someone else, in a surfeit of affection, might have plied him with food or drink, she pushed him into his usual chair and began impatiently unpacking the cello, saying:‘Play for me!

快点！
Come on!

快拉吧！”
Just play!’

他们在一起度过了一个愉快的下午。
They had a wonderful afternoon together.

来之前蒂博尔还在担心在她“坦白”了以后，在他们上次那样分手了以后，事情会变成什么样。但是所有的紧张好像都消失了，他们之间的气氛比以前更融洽了。
He'd worried beforehand how things would be, after her ‘confession’ and the way they'd last parted, but all the tension seemed simply to have evaporated, and the atmosphere between them felt better than ever.

即便是在他拉完一曲，埃洛伊丝闭着眼睛，开始长篇大论、尖刻地批评他的演奏的时候，他也不觉得生气，只希望自己尽可能地理解她的意思。
Even when, after he'd finished a piece, she closed her eyes and embarked on a long, stringent critique of his performance, he felt no resentment, only a hunger to understand her as fully as possible.

第二天、第三天都一样：气氛轻松，有时还开开玩笑。蒂博尔觉得自己的琴从来没拉得这么好过。
The next day and the day after, it was the same: relaxed, at times even jokey, and he felt sure he'd never played better in his life.

他们没有再提起他离开之前的那次谈话，埃洛伊丝也没有问起他在乡下的旅行。
They didn't allude at all to that conversation before he'd gone away, nor did she ask about his break in the countryside.

他们只谈论音乐。
They only talked about the music.

到了他回来以后的第四天，接二连三的小意外——包括他房里马桶的蓄水池漏水了——害他没法准时到怡东酒店去。
Then on the fourth day after his return, a series of small mishaps – including a leaking toilet cistern in his room – prevented him going to the Excelsior at the usual hour.

等他从咖啡馆走过去的时候，天已经开始暗了，服务生已经把小玻璃碗里的蜡烛点亮了，我们也已经演奏了两个晚餐的节目。
By the time he came past the cafe, the light was fading, the waiters had lit the candles inside the little glass bowls, and we were a couple of numbers into our dinner set.

他朝我们挥挥手，穿过广场朝酒店走去，因为背着琴，走起路来看上去一瘸一拐的。
He waved to us, then went on across the square towards the hotel, his cello making him look like he was limping.

蒂博尔注意到前台在打电话给埃洛伊丝之前稍稍犹豫了一下。
He noticed the receptionist hesitate slightly before phoning up to her.

埃洛伊丝打开门，热情地欢迎他，但感觉跟平时不太一样。不等蒂博尔开口，埃洛伊丝就很快地说道：
Then when she opened the door, she greeted him warmly, but somehow differently, and before he had a chance to speak, she said quickly:

“蒂博尔，真高兴你来了。
‘Tibor, I'm so glad you've come.

我正把你的事说给彼得听呢。
I was just telling Peter everything about you.

没错，彼得终于找到我了！”
That's right, Peter's found me at last!’

说完，她朝屋里喊道，“彼得，他来了！
Then she called into the room:‘Peter, he's here!

蒂博尔来了。
Tibor's here.

还带着琴！”
And with his cello too!’

蒂博尔走进房间，看见一个穿着浅色开领短袖衬衫、身材高大、步履蹒跚、头发灰白的男人微笑着站了起来。
As Tibor stepped into the room, a large, shambling, greying man in a pale polo shirt rose to his feet with a smile.

彼得紧紧地握住蒂博尔的手说：“哦，我听说了你所有的事。
He gripped Tibor's hand very firmly and said:‘Oh, I've heard all about you.

埃洛伊丝肯定你将来会是个大明星。”
Eloise is convinced you're gonna be a big star.’

“彼得不肯放弃，”埃洛伊丝说。
‘Peter's persistent,’ she was saying.

“我就知道他迟早会找到我的。”
‘I knew he'd find me in the end.’

“别想躲着我，”说着，彼得拉来一把椅子请蒂博尔坐下，从壁橱上的冰桶里给他倒了一杯香槟。
‘No hiding from me,’ said Peter. Then he was pulling up a chair for Tibor, pouring him a glass of champagne from an ice-bucket on the cabinet.

“来吧，蒂博尔，为我们庆祝重逢。”
‘Come on, Tibor, help us celebrate our reunion.’

蒂博尔抿了一口酒，注意到彼得给他的椅子刚好是他平时坐的那把“琴椅”。
Tibor sipped the champagne, aware that Peter had pulled up for him, by chance, his usual ‘cello chair’.

埃洛伊丝不知哪里去了，只剩蒂博尔和彼得一面喝酒一面聊天。
Eloise had vanished somewhere, and for a while, Tibor and Peter made conversation, their glasses in their hands.

彼得很友善的样子，问了很多问题。
Peter seemed kindly and asked a lot of questions.

他问蒂博尔是怎么在匈牙利那样的地方长大的。
How had it been for Tibor growing up in a place like Hungary?

他刚到西欧来的时候有没有感到震撼？
Had it been a shock when he'd first come to the West?

“会乐器真好，”彼得说。
‘I'd love to play an instrument,’ Peter said.

“你真幸运。
‘You're so lucky.

我也想学。
I'd like to learn.

可我想有点迟了。”
A little late now though, I guess.’

“哦，永远不会太迟，亨德森先生，”蒂博尔说。
‘Oh, you can never say too late,’ Tibor said.

“说得对。
‘You're right.

永不言迟。
Never say too late.

说太迟了永远只是借口。
Too late is always just an excuse.

不，事实是，我是个大忙人，我对自己说我太忙了，没时间学法语，没时间学乐器，没时间读《战争与和平》等等我一直想做的事。
No, the truth is, I'm a busy man, and I tell myself I'm too busy to learn French, to learn an instrument, to read War and Peace. All the things I've always wanted to do.

埃洛伊丝小时候拉过琴，我想她跟你说了。”
Eloise used to play when she was a kid. I guess she told you about that.’

“是，她说过。
‘Yes, she did.

我知道她很有天赋。”
I understand she has a lot of natural gifts.’

“哦，没错。
‘Oh, she sure does.

认识她的人都看得出来。
Anyone who knows her will be able to see that.

她有对音乐的敏感。
She has such sensitivity.

她就应该学音乐。
She's the one who should be having those lessons.

至于我，我只是个香蕉手。”
Me, I'm just Mr Banana Fingers.’

他举起手，笑了。
He held up his hands and laughed.

“我想弹钢琴，可这手怎么弹？
‘I'd like to play piano, but what can you do with hands like these?

倒是很适合挖土，我家祖祖辈辈就是干这个的。
Great for digging the earth, that's what my people did for generations.

可那位女士”——他用拿着酒杯的手指了指房门——“她有对音乐的敏感。”
But that lady’ – he indicated towards the door with his glass – ‘now she's got sensitivity.’

埃洛伊丝终于从房里出来了，穿着一件深色晚礼服，戴着满身珠宝。
Eventually, Eloise emerged from the bedroom in a dark evening dress and a lot of jewellery.

“彼得，别烦蒂博尔了，”她说。
‘Peter, don't bore Tibor,’ she said.

“他对高尔夫不感兴趣。”
‘He's not interested in golf.’

彼得伸出手，恳求地看着蒂博尔。
Peter held out his hands and looked pleadingly at Tibor.

“告诉我，蒂博尔。
‘Now tell me, Tibor.

我跟你提起过高尔夫一个字吗？”
Did I say a single word to you about golf?’

蒂博尔说他得走了；他看得出来他耽搁他们去吃晚饭了。
Tibor said he should be going; that he could see he was keeping the couple from their dinner.

他的话遭到了两人的反对，彼得说：
This was met by protests from both of them, and Peter said:

“看看我。
‘Now look at me.

我这打扮像要去吃饭吗？”
Do I look like I'm dressed for dinner?’

虽然蒂博尔觉得彼得这样穿就很得体，但他还是会意地笑了。
And though Tibor thought he looked perfectly decent, he gave the laugh that seemed expected of him.

彼得又说道：
Then Peter said:

“你得给我们拉点什么才能走。
‘You can't leave without playing something.

我听说了很多你的琴技。”
I've been hearing so much about your playing.’

蒂博尔不知如何是好，打开琴盒正准备把琴拿出来，突然听见埃洛伊丝坚定地说道，语气跟刚刚不太一样：
Confused, Tibor had actually started to unfasten his cello case, when Eloise said firmly, some new quality in her voice:

“蒂博尔说得对。
‘Tibor's right.

时间不早了。
Time's getting on.

这里的饭店你不准时去的话，他们不会给你留着位置的。
The restaurants in this town, they don't keep your table if you don't come on time.

彼得，去换衣服吧。
Peter, you get yourself dressed.

也许把脸也刮一下？
Maybe a shave too?

我送蒂博尔出去。
I'll see Tibor out.

我想和他单独谈谈。”
I want to speak with him in private.’

电梯里，他们脉脉地相视而笑，但没有说话。
In the lift, they smiled affectionately at each other, but didn't speak.

他们走出酒店，发现广场上已经华灯初上。
When they came outside, they found the piazza lit up for the night.

放暑假回来的当地孩子们有的在踢球，有的在喷泉边追逐嬉戏。
Local kids, back from their holidays, were kicking balls, or chasing each other around the fountain.

夜晚的行人熙来攘往，我想我们的音乐应该传到了他们的耳朵里。
The evening passeggiata was in full flow, and I suppose our music would have come drifting through the air to where they were standing.

“咳，就是这样了，”她终于开口说道。
‘Well, that's it,’ she said, eventually.

“他找到了我，所以我想他应该得到我。”
‘He's found me, so I guess he deserves me.’

“他很有魅力，”蒂博尔说。
‘He is a most charming person,’ Tibor said.

“那您要回美国去了？”
‘You intend to return to America now?’

“我想过几天就会回去了吧。”
‘In a few days. I suppose I will.’

“您要结婚？”
‘You intend to marry?’

“我想是吧。”
‘I guess so.’

一时间埃洛伊丝严肃地看着蒂博尔，但马上把脸转开了。
For an instant, she looked at him earnestly, then looked away.

“我想是吧，”她重复道。
‘I guess so,’ she said again.

“我衷心地祝您幸福。
‘I wish you much happiness.

他是个好人。
He is a kind man.

而且喜欢音乐。
Also a music lover.

这点对您来说很重要。”
That's important for you.’

“是的，很重要。”
‘Yes. That's important.’

“刚才您换衣服的时候，我们不是在聊高尔夫，我们在聊学音乐。”
‘When you were getting ready just now. We were talking not of golf, but of music lessons.’

“哦，真的？
‘Oh really?

他学还是我学？”
You mean for him or for me?’

“都有。
‘For both.

不过我想在俄勒冈波特兰没有多少人能教您。”
However, I don't suppose there will be many teachers in Portland, Oregon, who could teach you.’

她笑了一声。
She gave a laugh.

“就像我说的，我们这类人不好过。”
‘Like I said, it's difficult for people like us.’

“是，我明白。
‘Yes, I appreciate that.

经过这几周我更加明白这个道理。”蒂博尔停顿了一下，接着说道，“埃洛伊丝小姐，我们道别之前我有件事情要告诉您。
After these last few weeks, I appreciate that more than ever.’ Then he added:‘Miss Eloise, there is something I must tell you before we part.

我很快就要去阿姆斯特丹了。我在那里的一家大酒店里找到了一份工作。”
I will soon leave for Amsterdam, where I have been given a position in a large hotel.’

“你要去当门卫？”
‘You're going to be a porter?’

“不是。我要在酒店餐厅的小乐队里演出。
‘No. I will play in a small chamber group in the hotel dining room.

在客人吃饭的时候提供娱乐。”
We will entertain the hotel guests while they eat.’

蒂博尔凝视着埃洛伊丝，看见她的眼睛里闪过一道火花，然后慢慢褪去。
He was watching her carefully and saw something ignite behind her eyes, then fade away.

她一手搭在蒂博尔的手臂上，笑了。
She laid a hand on his arm and smiled.

“那祝你好运。”
‘Well then, good luck.’

她停顿了一下，又补充道，“那些酒店里的客人有耳福了。”
Then she added:‘Those hotel guests. They've got some treat coming up.’

“希望如此。”
‘I hope so.’

一时间他们俩默默地站在那里，站在酒店前门的灯光照不到的地方，硕大的提琴立在他们中间。
For another moment, they remained standing there together, just beyond the pool of light cast by the front of the hotel, the bulky cello between them.

“我也祝愿您与彼得先生过得幸福。”蒂博尔说。
‘And I hope also’, he said, ‘you'll be very happy with Mr Peter.’

“我也希望如此。”
‘I hope so too,’ she said and laughed again.

埃洛伊丝说道，又笑了笑。
Then she kissed him on the cheek and gave him a quick hug.

接着她亲了亲蒂博尔的脸颊，给了他一个匆匆的拥抱，说道：“保重。”
‘You take care of yourself,’ she said.

蒂博尔道了声谢，不等他反应过来，就只看见埃洛伊丝走进怡东酒店的背影。
Tibor thanked her, then before he quite realised it, he was watching her walking back towards the Excelsior.

不久之后蒂博尔就离开了这里。
Tibor left our city soon after that.

他最后一次跟我们喝酒时好好地感谢了詹卡洛和欧内斯托帮他找到这份工作，也感谢我们大家的友谊，但我不由得感觉他的态度有点冷淡。
The last time we had drinks with him, he was clearly very grateful to Giancarlo and Ernesto for his job, and to us all for our friendship, but I couldn't help getting the impression he was being a little aloof with us.

不只我，其他人也这么想，可是直性子的詹卡洛现在又站在蒂博尔一边，说他只是对人生的这下一步感到兴奋、紧张。
A few of us thought this, not just me, though Giancarlo, typically, now took Tibor's side, saying the boy had just been feeling excited and nervous about this next step in his life.

“兴奋？
‘Excited?

他怎么可能兴奋？”
How can he be excited?’

欧内斯托说。
Ernesto said.

“整个夏天他都被别人叫做天才。
‘He's spent the summer being told he's a genius.

到酒店工作是委屈了他。
A hotel job, it's a comedown.

坐在这里跟我们聊天也是委屈了他。
Sitting talking to us, that's a comedown too.

夏天刚到那会儿他还是个好孩子。
He was a nice kid at the start of the summer.

可那女人对他做了那些事以后，我很高兴能看见他回来。”
But after what that woman's done to him, I'm glad we're seeing the back of him.’

我说过了，这是七年前的事了。
Like I said, this all happened seven years ago.

詹卡洛、欧内斯托，当时乐队里的其他人，除了我和费边都走了。
Giancarlo, Ernesto, all the boys from that time except me and Fabian, they've all moved on.

我很久没再想起我们这位年轻的匈牙利天才，直到那天偶然在广场上发现他。
Until I spotted him in the piazza the other day, I hadn't thought about our young Hungarian maestro for a long time. He wasn't so hard to recognise.

他没怎么变，只是胖了些，脖子粗了好一圈。
He'd put on weight, certainly, and was looking a lot thicker around the neck.

他用手指头招呼服务生的动作——也许是我的想象——有些不耐烦，有些粗鲁，自然而然就有些愤恨。我这么说可能不公平，毕竟我只瞥了他几眼。
And the way he gestured with his finger, calling for a waiter, there was something – maybe I imagined this – something of the impatience, the off- handedness that comes with a certain kind of bitterness. But maybe that's unfair.

但我还是觉得他似乎失去了年轻时的快活劲儿和以前认认真真的态度。
After all, I only glimpsed him. Even so, it seemed to me he'd lost that youthful anxiety to please, and those careful manners he had back then.

你可能会说在这世上这不是什么坏事。
No bad thing in this world, you might say.

我本想过去跟他聊聊，可是等表演结束，他已经走了。
I would have gone over and talked with him, but by the end of our set he'd already gone.

据我所知，他只在广场上待了一个下午。
For all I know, he was here only for the afternoon.

他穿着西装——不是什么特别好的，普通西装而已——所以我猜他现在白天在哪里坐办公室。
He was wearing a suit – nothing very grand, just a regular one – so perhaps he has a day job now behind a desk somewhere.

他可能是到附近办事，想起以前的时光，顺路到这里来一下，谁知道？
Maybe he had some business to do nearby and came through our city just for old times'sake, who knows?

要是他再到广场上来时我不在演出的话，我一定过去跟他聊聊。
If he comes back to the square, and I'm not playing, I'll go over and have a word with him.
