# 第一部 · 第一章 | PART ONE · Chapter One

我们最终给小女儿取名叫妮基。这不是缩写，这是我和她父亲达成的妥协。
Niki, the name we finally gave my younger daughter, is not an abbreviation; it was a compromise I reached with her father.

真奇怪，是他想取一个日本名字，而我——或许是出于不愿想起过去的私心——反而坚持要英文名。他最终同意妮基这个名字，觉得还是有点东方的味道在里头。
For paradoxically it was he who wanted to give her a Japanese name, and I — perhaps out of some selfish desire not to be reminded of the past — insisted on an English one. He finally agreed to Niki, thinking it had some vague echo of the East about it.

妮基今年早些时候来看过我，四月的时候，那时天还很冷，细雨绵绵。
She came to see me earlier this year, in April, when the days were still cold and drizzly.

也许她本打算多待几天，我不知道。
Perhaps she had intended to stay longer, I do not know.

但我住的乡下房子和房子里的安静让她不安，没多久，我就看出来她急着想回伦敦自己的生活中去。
But my country house and the quiet that surrounds it made her restless, and before long I could see she was anxious to return to her life in London.

她不耐烦地听着我的古典唱片，随意地翻着一本本杂志。
She listened impatiently to my classical records, flicked through numerous magazines.

经常有她的电话，她大踏步走过地毯，瘦瘦的身材挤在紧紧的衣服里，小心地关上身后的门，不让我听到她的谈话。
The telephone rang for her regularly, and she would stride across the carpet, her thin figure squeezed into her tight clothes, taking care to close the door behind her so I would not overhear her conversation.

五天后她离开。
She left after five days.

直到来的第二天她才提起景子。
She did not mention Keiko until the second day.

那是一个灰暗的、刮着风的早晨，我们把沙发挪近窗户，看雨水落在花园里。
It was a grey windy morning, and we had moved the armchairs nearer the windows to watch the rain falling on my garden.

“你指望过我去吗？”她问。
“Did you expect me to be there?” she asked.

“我是说葬礼。”
“At the funeral, I mean.”

“不，没有。
“No, I suppose not.

我知道你不会来。”
I didn't really think you'd come.”

“我真的很难过，听到她的死讯。
“It did upset me, hearing about her.

我差点就来了。”
I almost came.”

“我从不指望你会来。”
“I never expected you to come.”

“别人不知道我到底是怎么了，”她说，“我没有告诉任何人。
“People didn't know what was wrong with me,” she said. “I didn't tell anybody.

我想我那时觉得很丢脸。
I suppose I was embarrassed.

别人不会真的理解的，他们不可能理解我的感受。
They wouldn't understand really, they wouldn't understand how I felt about it.

姐妹之间应该是很亲近的，不是吗？你可能不太喜欢她们，可你还是和她们很亲近。
Sisters are supposed to be people you're close to, aren't they. You may not like them much, but you're still close to them.

但是我和她根本不是这样。
That's just not how it was though.

我甚至都不记得她长什么样了。”
I don't even remember what she looked like now.”

“是啊，你很久没见到她了。”
“Yes, it's quite a time since you saw her.”

“我只记得她是一个让我难受的人。
“I just remember her as someone who used to make me miserable.

这就是我对她的印象。
That's what I remember about her.

可是我真的很难过，听到她的消息。”
But I was sad though, when I heard.”

也许不单单是这里的安静驱使我女儿回伦敦去。
Perhaps it was not just the quiet that drove my daughter back to London.

虽然我们从来不长谈景子的死，但它从来挥之不去，在我们交谈时，时刻萦绕在我们的心头。
For although we never dwelt long on the subject of Keiko's death, it was never far away, hovering over us whenever we talked.

和妮基不同，景子是纯血统的日本人，不止一家报纸马上就发现了这个事实。
Keiko, unlike Niki, was pure Japanese, and more than one newspaper was quick to pick up on this fact.

英国人有一个奇特的想法，觉得我们这个民族天生爱自杀，好像无需多解释；因为这就是他们报导的全部内容：她是个日本人，她在自己的房间里上吊自杀。
The English are fond of their idea that our race has an instinct for suicide, as if further explanations are unnecessary; for that was all they reported, that she was Japanese and that she had hung herself in her room.

那天晚上，我站在窗前，看着外面漆黑一片，突然听到妮基在我身后问：“你在看什么呢，妈妈？”
That same evening I was standing at the windows, looking out into the darkness, when I heard Niki say behind me; “What are you thinking about now, Mother?”

她坐在房间那头的长靠背椅上，膝盖上放着一本软皮书。
She was sitting across the settee, a paperback book on her knee.

“我在想以前认识的一个人。
“I was thinking about someone I knew once.

以前认识的一个女人。”
A woman I knew once.”

“在你……来英国之前认识的？”
“Someone you knew when you … before you came to England?”

“我在长崎时认识的，要是你指的是这个。”
“I knew her when I was living in Nagasaki, if that's what you mean.”

她还看着我，我就补充道，“很久以前了。
She continued to watch me, so I added: “A long time ago.

在我认识你父亲之前很久。”
Long before I met your father.”

这下她好像满意了，嘟囔了句什么，继续看她的书。
She seemed satisfied and with some vague comment returned to her book.

从很多方面来说，妮基是个孝顺的孩子。她不仅仅是来看看景子死后我的情况；她是出于一种使命感来的。
In many ways Niki is an affectionate child. She had not come simply to see how I had taken the news of Keiko's death; she had come to me out of a sense of mission.

这几年，她开始欣赏起我过去的某些方面。她来是准备告诉我：事实仍旧如此，我不应后悔从前做的那些决定。
For in recent years she has taken it upon herself to admire certain aspects of my past, and she had come prepared to tell me things were no different now, that I should have no regrets for those choices I once made.

简而言之，是来安慰我说我不应为景子的死负责。
In short, to reassure me I was not responsible for Keiko's death.

如今我并不想多谈景子，多说无益。
I have no great wish to dwell on Keiko now, it brings me little comfort.

我在这里提起她只是因为这是今年四月妮基来我这里时的情形，正是在那段时间里，我在这么多年后又想起了佐知子。
I only mention her here because those were the circumstances around Niki's visit this April, and because it was during that visit I remembered Sachiko again after all this time.

我和佐知子并不很熟。
I never knew Sachiko well.

事实上我们的友谊就只有几个星期，那是在许多年前的一个夏天。
In fact our friendship was no more than a matter of some several weeks one summer many years ago.

那时最坏的日子已经过去了。
The worst days were over by then.

美国大兵还是和以前一样多——因为朝鲜半岛还在打仗——但是在长崎，在经历了那一切之后，日子显得平静安详。
American soldiers were as numerous as ever—for there was fighting in Korea—but in Nagasaki, after what had gone before, those were days of calm and relief.

空气中处处感觉到变化。
The world had a feeling of change about it.

我和丈夫住在东边的城郊，离市中心有一小段电车的距离。
My husband and I lived in an area to the east of the city, a short tram journey from the centre of town.

旁边有一条河，我听说战前河边有一个小村庄。
A river ran near us, and I was once told that before the war a small village had grown up on the riverbank.

然而炸弹扔下来以后就只剩下烧焦的废墟。
But then the bomb had fallen and afterwards all that remained were charred ruins.

人们开始重建家园，不久，四栋混凝土大楼拔地而起，每栋有四十间左右的独立公寓。
Rebuilding had got under way and in time four concrete buildings had been erected, each containing forty or so separate apartments.

这四栋楼里，我们这一栋是最后建的，也宣告重建计划暂告一段落；公寓楼和小河之间是一片好几英亩废弃不用的空地，尽是污泥和臭水沟。
Of the four, our block had been built last and it marked the point where the rebuilding programme had come to a halt; between us and the river lay an expanse of wasteground, several acres of dried mud and ditches.

很多人抱怨这会危害健康，确实，那里的污水很吓人。
Many complained it was a health hazard, and indeed the drainage was appalling.

一年到头死水积满土坑，到了夏天还有让人受不了的蚊子。
All year round there were craters filled with stagnant water, and in the summer months the mosquitoes became intolerable.

时不时看见有公务人员来丈量土地、在本子上写写画画，但是好几个月过去，没有任何动静。
From time to time officials were to be seen pacing out measurements or scribbling down notes, but the months went by and nothing was done.

这些公寓楼的住户都和我们相似——都是刚结婚的年轻夫妇，男人们在规模渐大的公司里找到了不错的工作。
The occupants of the apartment blocks were much like ourselves — young married couples, the husbands having found good employment with expanding firms.

很多公寓都是公司所有，然后以优惠的价格租给员工们。
Many of the apartments were owned by the firms, who rented them to employees at a generous rate.

每间公寓都是一样的：榻榻米的地板，西式的浴室和厨房。
Each apartment was identical; the floors were tatami, the bathrooms and kitchens of a Western design.

房子不大，天气暖和一点时又不凉快，不过大家普遍感到心满意足。
They were small and rather difficult to keep cool during the warmer months, but on the whole the feeling amongst the occupants seemed one of satisfaction.

可是我记得公寓楼里又确实有一种临时过渡的感觉，好像我们都在等着有一天我们会搬到更好的房子里去。
And yet I remember an unmistakable air of transience there, as if we were all of us waiting for the day we could move to something better.

一座小木屋在战争的炮火和政府的推土机中幸存下来。
One wooden cottage had survived both the devastation of the war and the government bulldozers.

我从窗户就能看见木屋独自伫立在那片空地的尽头，就在河岸边上。
I could see it from our window, standing alone at the end of that expanse of wasteground, practically on the edge of the river.

是乡下常见的那种木屋子，斜斜的瓦屋顶都快碰到地面了。
It was the kind of cottage often seen in the countryside, with a tiled roof sloping almost to the ground.

我不干活时经常站在窗前盯着它看。
Often, during my empty moments, I would stand at my window gazing at it.

从佐知子搬到那里受到的关注看来，我不是唯一一个盯着木屋看的人。
To judge from the attention attracted by Sachiko's arrival, I was not alone in gazing at that cottage.

有一天大家看到两个男的在那里忙活，大家议论着他们是不是政府的人。
There was much talk about two men seen working there one day — as to whether or not they were government workers.

后来就听说有个女的带着她的小女儿住进了那里，我自己也看见过她们几次，看见她们小心翼翼地走过臭水坑。
Later there was talk that a woman and her little girl were living there, and I saw them myself on several occasions, making their way across the ditchy ground.

我是在快夏天时——那时我已经怀孕三四个月了——第一次看见那辆破旧的白色美国大车的，车子正跌跌撞撞地穿过空地朝河边开去。
It was towards the beginning of summer — I was in my third or fourth month of pregnancy by then — when I first watched that large American car, white and battered, bumping its way over the wasteground towards the river.

那时天已经快黑了，小屋后的最后几缕阳光滑过金属的车身。
It was well into the evening, and the sun setting behind the cottage gleamed a moment against the metal.

后来一天下午，我在电车站听到两个女人在谈论刚搬进河边那间破房子的那个女人。
Then one afternoon I heard two women talking at the tram stop, about the woman who had moved into the derelict house by the river.

其中一个对另一个说，那天早上她跟那个女人说话，却受到了明显的冷落。
One was explaining to her companion how she had spoken to the woman that morning and had received a clear snub.

听话的人也觉得新来的人似乎不是很友善——大概是傲慢。
Her companion agreed the newcomer seemed unfriendly — proud probably.

她们觉得那个女人至少有三十岁了，因为那个孩子至少十岁了。
She must be thirty at the youngest, they thought, for the child was at least ten.

第一个女人说陌生人是东京腔，肯定不是长崎人。
The first woman said the stranger had spoken with a Tokyo dialect and certainly was not from Nagasaki.

她们说了一会儿她的那个“美国朋友”，然后第一个女人又回头说这个陌生人早上是如何冷落她的。
They discussed for a while her “American friend”, then the woman spoke again of how unfriendly the stranger had been to her that morning.

如今我并不怀疑那时和我住在同一区的女人里有的也受了很多苦，也充满了痛苦、可怕的回忆。
Now I do not doubt that amongst those women I lived with then, there were those who had suffered, those with sad and terrible memories.

但是看着她们每天围着自己的丈夫和孩子忙得团团转，那时的我很难相信——她们的生活也曾经历了战争的不幸和噩梦。
But to watch them each day, busily involved with their husbands and their children, I found this hard to believe — that their lives had ever held the tragedies and nightmares of wartime.

我从来不想显得不友好，可是大概我也从来没有刻意努力显得友好。
It was never my intention to appear unfriendly, but it was probably true that I made no special effort to seem otherwise.

因为那时我还是想独自一人、不被打扰。
For at that point in my life, I was still wishing to be left alone.

那天我饶有兴趣地听着那两个女人谈论佐知子。
It was with interest then that I listened to those women talking of Sachiko.

我至今还清楚地记得那天下午电车站的情景。
I can recall quite vividly that afternoon at the tram stop.

六月的雨季终于过去，天开始放晴，湿透了的砖头和水泥都开始变干。
It was one of the first days of bright sunlight after the rainy season in June, and the soaked surfaces of brick and concrete were drying all around us.

我们站在一座铁路桥上，山脚下铁路的一侧是鳞次栉比的屋顶，好像一座座房子从山坡上滚下来。
We were standing on a railway bridge and on one side of the tracks at the foot of the hill could be seen a cluster of roofs, as if houses had come tumbling down the slope.

越过这些房子，再过去一些，就是我们的公寓楼，像四根水泥柱子立在那里。
Beyond the houses, a little way off, were our apartment blocks standing like four concrete pillars.

当时我隐隐地同情佐知子，有时我远远地看着她，感觉她不太合群，而我觉得自己可以理解她的那种心情。
I felt a kind of sympathy for Sachiko then, and felt I understood something of that aloofness I had noticed about her when I had watched her from afar.

那年夏天我们成了朋友，至少有一小段时间她允许我介入她的私事。
We were to become friends that summer and for a short time at least I was to be admitted into her confidence.

如今我已经记不得我们是怎么认识的。
I am not sure now how it was we first met.

我只记得一天下午，我在出公寓区的小路上看见她在我前头。
I remember one afternoon spotting her figure ahead of me on the path leading out of the housing precinct.

我急忙走上前去，而佐知子不缓不慢地迈着步子。
I was hurrying, but Sachiko walked on with a steady stride.

那时我们应该已经知道对方的名字，因为我记得我边往前走边叫她。
By that point we must have already known each other by name, for I remember calling to her as I got nearer.

佐知子转过身站住、等我追上她。
Sachiko turned and waited for me to catch up.

“什么事？”她问。
“Is something wrong?” she asked.

“找到你太好了，”我有点上气不接下气地说，“你女儿，我出来时看见她在打架。
“I'm glad I found you,” I said, a little out of breath. “Your daughter, she was fighting just as I came out.

就在水沟旁。”
Back there near the ditches.”

“她在打架？”
“She was fighting?”

“和另外两个孩子。
“With two other children.

其中一个是男的。
One of them was a boy.

看起来打得挺凶。”
It looked a nasty little fight.”

“我知道了。”
“I see.”

说完她继续往前走去。
Sachiko began to walk again.

我跟在她的旁边。
I fell in step beside her.

“我不是想吓你，”我说，“可真的看起来打得挺凶。
“I don't want to alarm you,” I said, “but it did look quite a nasty fight.

事实上我想我看到你女儿脸划伤了。”
In fact, I think I saw a cut on your daughter's cheek.”

“我知道了。”
“I see.”

“就在那里，空地边上。”
“It was back there, on the edge of the wasteground.”

“你想他们还在打吗？”
“And are they still fighting, do you think?”

她继续往山上走。
She continued to walk up the hill.

“呃，我想不打了。
“Well, no.

我看见你女儿跑了。”
I saw your daughter running off.”

佐知子看着我，笑了笑。
Sachiko looked at me and smiled.

“你不习惯看小孩子打架？”
“Are you not used to seeing children fight?”

“呃，我想小孩子是会打架。
“Well, children do fight, I suppose.

但我想我应该告诉你一声。
But I thought I ought to tell you.

还有你看，我想你女儿不是要去上学。
And you see, I don't think she's on her way to school.

另外两个孩子继续往学校的方向走，而她却回河那边去了。”
The other children carried on towards the school, but your daughter went back towards the river.”

佐知子没有回答，继续往山上走。
Sachiko made no reply and continued to walk up the hill.

“其实，”我接着说，“我以前就想跟你说了。
“As a matter of fact,” I continued, “I'd meant to mention this to you before.

是这样的，最近我时常看见你的女儿。
You see, I've seen your daughter on a number of occasions recently.

我在想，她是不是偶尔会逃学。”
I wonder, perhaps, if she hasn't been playing truant a little.”

小路在山顶上分岔了。
The path forked at the top of the hill.

佐知子停住脚步，转向我。
Sachiko stopped and we turned to each other.

“谢谢你的关心，悦子，”她说，“你真好心。
“It's very kind of you to be so concerned, Etsuko,” she said. “So very kind.

我肯定你会是一位好母亲。”
I'm sure you'll make a splendid mother.”

之前我和电车站的女人一样认为佐知子三十岁上下。
I had supposed previously — like the women at the tram stop — that Sachiko was a woman of thirty or so.

然而也许是她略显年轻的身材骗了大家，她的脸远不止三十岁。
But possibly her youthful figure had been deceiving, for she had the face of an older person.

她用一副觉得有点好笑的神情看着我，而她神情里的某些东西让我尴尬地笑了笑。
She was gazing at me with a slightly amused expression, and something in the way she did so caused me to laugh self-consciously.

“很感激你这样来找我，”她又说道，“可是你瞧，我现在忙得很。
“I do appreciate your coming to find me like this,” she went on. “But as you see, I'm rather busy just now.

我得到城里去。”
I have to go into Nagasaki.”

“知道了。
“I see.

我只是想最好来跟你说一声，没别的。”
I just thought it best to come and tell you, that's all.”

她又用那副觉得好笑的神情看了我一会儿，然后说：“太谢谢你了。
For a moment, she continued to look at me with her amused expression. Then she said: “How kind you are.

现在请原谅，我得到城里去了。”
Now please excuse me. I must get into town.”

她欠了欠身，走向通往电车站的小路。
She bowed, then turned towards the path that led up towards the tram stop.

“只是她的脸划伤了，”我稍稍提高了声音，说。
“It's just that she had a cut on her face,” I said, raising my voice a little.

“而且河那边有些地方很危险。
“And the river's quite dangerous in places.

我想最好来跟你说一声。”
I thought it best to come and tell you.”

她再次转过身来，看着我。
She turned and looked at me once more.

“你要是有空，悦子，”她说，“今天能帮我看一下女儿吗？
“If you have nothing else to concern yourself with, Etsuko,” she said, “then perhaps you'd care to look after my daughter for the day.

我下午会回来。
I'll be back sometime in the afternoon.

我肯定你们能处得来。”
I'm sure you'll get on very well with her.”

“要是你希望如此，我不介意。
“I wouldn't object, if that's what you wish.

我得说，你女儿看上去还很小，不能让她一整天自己一个人待着。”
I must say, your daughter seems quite young to be left on her own all day.”

“太谢谢你了，”佐知子再次说道，然后又笑了笑。
“How kind you are,” Sachiko said again. Then she smiled once more.

“没错，我肯定你会是一位好母亲。”
“Yes, I'm sure you'll make a splendid mother.”

和佐知子分开后，我走下山，穿过公寓区，很快回到了我们的公寓楼外，面对着那片空地。
After parting with Sachiko, I made my way down the hill and back through the housing precinct. I soon found myself back outside our apartment block, facing that expanse of wasteground.

我没有看见小女孩，正打算进去，突然看见河边有动静。万里子刚才肯定是蹲下去了，因为现在我可以清楚地看见她小小的身影穿过泥地。
Seeing no sign of the little girl, I was about to go inside, but then caught sight of some movement along the riverbank. Mariko must previously have been crouching down, for now I could see her small figure quite clearly across the muddy ground.

刚开始，我想忘了这整件事，回去干活。
At first, I felt the urge to forget the whole matter and return to my housework.

但是最后，我迈开步子向她走去，小心地避开水沟。
Eventually, however, I began making my way towards her, taking care to avoid the ditches.

我印象那是我第一次跟万里子说话。
As far as I remember, that was the first occasion I spoke to Mariko.

所以很可能她那天早上的反应并没有什么奇怪的地方，毕竟我对她来说是陌生人，她很有理由不相信我。
Quite probably there was nothing so unusual about her behaviour that morning, for, after all, I was a stranger to the child and she had every right to regard me with suspicion.

要是我那时确实感到一种奇怪的不安，那也只不过是对万里子的态度的自然反应。
And if in fact I did experience a curious feeling of unease at the time, it was probably nothing more than a simple response to Mariko's manner.

那时雨季刚过去几个星期，河水还很高、很急。
The river that morning was still quite high and flowing swiftly after the rainy season a few weeks earlier.

空地和河岸之间有一道陡坡，小女孩就站在坡底的泥地里，那里的土显然湿得多。
The ground sloped down steeply before it reached the water's edge, and the mud at the foot of the slope, where the little girl was standing, looked distinctly wetter.

万里子穿着一件普通的到膝盖的棉布连衣裙，剪得短短的头发让她的脸像个男孩子。
Mariko was dressed in a simple cotton dress which ended at her knees, and her short trimmed hair made her face look boyish.

她抬头看着站在泥土坡上头的我，没有笑容。
She looked up, not smiling, to where I stood at the top of the muddy slope.

“你好，”我说，“我刚刚和你母亲说话。
“Hello,” I said, “I was just speaking with your mother.

你肯定就是万里子吧。”
You must be Mariko-San.”

小女孩还是盯着我，没有吭声。
The little girl continued to stare up at me, saying nothing.

之前我以为她的脸受伤了，现在看清楚那只是被土弄脏了。
What I had thought earlier to be a wound on her cheek, I now saw to be a smudge of mud.

“你怎么没去上学？”
“Shouldn't you be at school?”

我问。
I asked.

她还是不说话。
She remained silent for a moment.

过了一会儿才说：“我不上学。”
Then she said: “I don't go to school.”

“可小孩子应该上学。
“But all children must go to school.

你不想去吗？”
Don't you like to go?”

“我不上学。”
“I don't go to school.”

“可你妈妈没有送你到这里的学校去吗？”
“But hasn't your mother sent you to a school here?”

万里子没有回答。
Mariko did not reply.

相反，她往后退了一步。
Instead, she took a step away from me.

“小心，”我说。
“Careful,” I said.

“你会掉到河里的。
“You'll fall into the water.

很滑。”
It's very slippery.”

她还是站在坡底抬起头来瞪着我。
She continued to stare up at me from the bottom of the slope.

我看见她的小鞋子躺在旁边的泥土里。
I could see her small shoes lying in the mud beside her.

她的脚丫子和鞋子一样陷在泥土里。
Her bare feet, like her shoes, were covered in mud.

“我刚刚和你母亲说过话，”我说，亲切地笑了笑，“她说你可以到我家来等她。
“I was just speaking with your mother,” I said, smiling at her reassuringly. “She said it would be perfectly all right if you came and waited for her at my house.

就在那里，那栋楼里。
It's just over there, that building there.

你可以来尝尝我昨天做的蛋糕。
You could come and try some cakes I made yesterday.

好不好，万里子？
Would you like that, Mariko-San?

你还可以跟我说说你自己。”
And you could tell me all about yourself.”

万里子还是小心地看着我。
Mariko continued to watch me carefully.

然后，她一边目不转睛地看着我，一边弯下腰捡起鞋子。
Then, without taking her eyes off me, she crouched down and picked up her shoes.

一开始我以为她这是要跟我走。
At first, I took this as a sign that she was about to follow me.

可是她还是一直盯着我，我才明白她是抓住鞋子随时准备跑掉。
But then as she continued to stare up at me, I realized she was holding her shoes in readiness to run away.

“我不会伤害你的，”我紧张地笑了笑，说，“我是你妈妈的朋友。”
“I'm not going to hurt you,” I said, with a nervous laugh. “I'm a friend of your mother's.”

我记得这就是那天上午我和万里子间发生的一切。
As far as I remember, that was all that took place between us that morning.

我不想吓着她，不久就转身回去。
I had no wish to alarm the child further, and before long I turned and made my way back across the wasteground.

这孩子的反应着实让我失望；那时，这类小事都会让我对做母亲产生怀疑。
The child's response had, it is true, upset me somewhat; for in those days, such small things were capable of arousing in me every kind of misgiving about motherhood.

我对自己说，这不是什么大不了的事，将来我一定有机会和这个小女孩做朋友。
I told myself the episode was insignificant, and that in any case, further opportunities to make friends with the little girl were bound to present themselves over the coming days.

而后来，我是在大约两周后的一个下午才又和万里子说话的。
As it was, I did not speak to Mariko again until one afternoon a fortnight or so later.

那天下午之前，我从没进去过那间房子，佐知子请我去时我很意外。
I had never been inside the cottage prior to that afternoon, and I had been rather surprised when Sachiko had asked me in.

我马上想到她是有事才请我去的，而事实确实如此。
In fact, I had sensed immediately that she had done so with something in mind, and as it turned out, I was not mistaken.

屋里很整洁，但是很破旧。屋顶的木梁看上去很旧、不牢固，到处都有一股霉味。
The cottage was tidy, but I remember a kind of stark shabbiness about the place; the wooden beams that crossed the ceiling looked old and insecure, and a faint odour of dampness lingered everywhere.

房前的大部分拉门都打开了，好让阳光从走廊照进来。尽管如此，房子里的大部分地方还是照不到太阳。
At the front of the cottage, the main partitions had been left wide open to allow the sunlight in across the veranda. For all that, much of the place remained in shadow.

万里子躺在离阳光最远的角落里。
Mariko was lying in the corner furthest from the sunlight.

我看见她身旁的影子里有什么东西在动，走近一看，一只大猫蜷缩在榻榻米上。
I could see something moving beside her in the shade, and when I came closer, saw a large cat curled up on the tatami.

“你好，万里子，”我说，“你还记得我吗？”
“Hello, Mariko-San,” I said. “Don't you remember me?”

她停下抚摸猫的手，抬起头来。
She stopped stroking the cat and looked up.

“我们以前见过，”我又说，“记得吗？
“We met the other day,” I went on. “Don't you remember?

在河边。”
You were by the river.”

小女孩好像没有认出我来。
The little girl showed no signs of recognition.

她看了我一会儿，又继续抚摸她的猫。
She looked at me for a while, then began to stroke her cat again.

我听见在我身后，佐知子正在屋子中间地面的炉子上准备泡茶。
Behind me, I could hear Sachiko preparing the tea on the open stove at the centre of the room.

我正想走过去，突然听见万里子说：“它快生小猫了。”
I was about to go over to her, when Mariko said suddenly: “She's going to have kittens.”

“哦，真的？
“Oh really?

太好了。”
How nice.”

“你要一只小猫吗？”
“Do you want a kitten?”

“谢谢你，万里子。
“That's very kind of you, Mariko-San.

我得看看。
We'll see.

可是我肯定它们全都会找到好地方的。”
But I'm sure they'll all find nice homes.”

“你为什么不要一只？”
“Why don't you take a kitten?” the child said.

孩子说，“另外一个女人说她要一只。”
“The other woman said she'd take one.”

“我得看看，万里子。
“We'll see, Mariko-San.

另外一位女士是谁？”
Which other lady was this?”

“另外一个女人。
“The other woman.

在河对岸。
The woman from across the river.

她说她要一只。”
She said she'd take one.”

“可是我想河对岸没有人住，万里子。
“But I don't think anyone lives over there, Mariko-San.

那里只有树和林子。”
It's just trees and forest over there.”

“她说她要带我去她家。
“She said she'd take me to her house.

她住在河对岸。
She lives across the river.

我没有跟她去。”
I didn't go with her.”

我看了她一会儿。
I looked at the child for a second.

突然我想到了什么，笑了出来。
Then a thought struck me and I laughed.

“那是我，万里子。
“But that was me, Mariko-San.

你不记得了吗？
Don't you remember?

那天你妈妈进城去时我叫你去我家。”
I asked you to come to my house while your mother was away in the town.”

万里子再次抬起头来看我。
Mariko looked up at me again.

“不是你，”她说，“是另外一个女人。
“Not you,” she said. “The other woman.

她住在河对岸。
The woman from across the river.

她昨晚来这儿了。
She was here last night.

那时妈妈不在。”
While Mother was away.”

“昨晚？
“Last night?

你妈妈不在？”
While your mother was away?”

“她说她要带我去她家，可是我没有跟她去。
“She said she'd take me to her house, but I didn't go with her.

因为天黑了。
Because it was dark.

她说我们可以拿那个灯笼”——她指了指挂在墙上的灯笼——“可是我没有跟她去。
She said we could take the lantern with us” — she gestured towards a lantern hung on the wall — “but I didn't go with her.

因为天黑了。”
Because it was dark.”

在我身后，佐知子站起身来，看着她女儿。
Behind me, Sachiko had got to her feet and was looking at her daughter.

万里子不说话了，转过身去，继续抚摸她的猫。
Mariko became silent, then turned away and began once more to stroke her cat.

“我们到走廊去吧，”佐知子对我说，手里端着盛着茶具的托盘。
“Let's go out on the veranda,’ Sachiko said to me. She was holding the tea things on a tray.

“那里比较凉快。”
“It's cooler out there.”

我们去了走廊，把万里子留在角落里。
We did as she suggested, leaving Mariko in her corner.

在走廊上看不到河水，但是可以看到斜坡和河边潮湿的泥土。
From the veranda, the river itself was hidden from view, but I could see where the ground sloped down and the mud became wetter as it approached the water.

佐知子在垫子上坐下，开始倒茶。
Sachiko seated herself on a cushion and began to pour the tea.

“这里到处都是流浪猫，”她说，“对要出生的这些小东西我可没那么乐观。”
“The place is alive with stray cats,” she said. “I'm not so optimistic about these kittens.”

“是啊，很多野猫野狗，”我说，“真不像话。
“Yes, there are so many strays,” I said. “It's such a shame.

万里子的猫是在这里捡的吗？”
Did Mariko find her cat around here somewhere?”

“不，我们带来的。
“No, we brought that creature with us.

我是不想带它来，可是万里子不听。”
I'd have preferred to leave it behind myself, but Mariko wouldn't hear of it.”

“你们从东京一路带来？”
“You brought it all the way from Tokyo?”

“哦，不。
“Oh no.

我们在长崎住了快一年了。
We've been living in Nagasaki for almost a year now.

在城市的另一头。”
On the other side of the city.”

“哦，真的？
“Oh really?

我才知道。
I didn't realize that.

你和……和朋友一起住？”
You lived there with … with friends?”

佐知子停下正在倒茶的手，看着我，双手握着茶壶。
Sachiko stopped pouring and looked at me, the teapot held in both hands.

我在她眼里又看见了上次她看着我的那种觉得好笑的神情。
I saw in her gaze something of that amused expression with which she had observed me on that earlier occasion.

“我想你搞错了，悦子，”她终于说道，又接着倒茶。
“I'm afraid you're quite wrong, Etsuko,” she said, eventually. Then she began to pour the tea again.

“我们住在我伯父家。”
“We were staying at my uncle's house.”

“我向你保证，我只是……”
“I assure you, I was merely …”

“是啊，当然。
“Yes, of course.

所以没什么不好意思的。”
So there's no need to get embarrassed, is there?”

她笑了笑，把茶递给我。
She laughed and passed me my teacup.

“抱歉，悦子，我并没有要取笑你。
“I'm sorry, Etsuko, I don't mean to tease you.

其实，我有事要找你。
As a matter of fact, I did have something to ask you.

一点小忙。”
A little favour.”

佐知子开始给自己倒茶，这时，她的态度变得严肃许多。
Sachiko began to pour tea into her own cup, and as she did so, a more serious air seemed to enter her manner.

倒完茶，她放下茶壶，看着我。
Then she put down the teapot and looked at me.

“是这样的，悦子，一些事情没有照我计划的那样。
“You see, Etsuko, certain arrangements I made have not gone as planned.

结果，我发现自己钱不够了。
As a result, I find myself in need of money.

不是什么大数目，你知道。
Not a great deal, you understand.

就一点点。”
Just a small amount.”

“我明白的，”我压低声音，说。
“I quite understand,” I said, lowering my voice.

“你一定很艰难，带着万里子。”
“It must be very difficult for you, with Mariko-San to think of.”

“悦子，能帮帮我吗？”
“Etsuko, may I ask a favour of you?”

我鞠了鞠躬。
I bowed.

“我自己有些积蓄，”我说，几乎是耳语。
“I have some savings of my own,” I said, almost in a whisper.

“我很乐意帮忙。”
“I'd be pleased to be of some assistance.”

可是让我想不到的是，佐知子大笑起来。
To my surprise, Sachiko laughed loudly. “You're very kind,” she said.

“太谢谢你了，”她说，“可是我并不是要叫你借钱给我。
“But I didn't in fact want you to lend me money. I had something else in mind.

我有别的打算。前几天你提到一个开面店的朋友。”
You mentioned something the other day. A friend of yours who ran a noodle shop.”

“你是指藤原太太？”
“Mrs Fujiwara, you mean?”

“你说她需要一个帮手。
“You were saying she may want an assistant.

像这样的小工作就可以帮我大忙。”
A small job like that would be very useful to me.”

“这个嘛，”我拿不准地说，“你要的话我问问。”
“Well,” I said, uncertainly, “I could enquire if you wish.”

“那真是太好了。”
“That would be very kind.”

佐知子看了我一会儿。
Sachiko looked at me for a moment.

“可是你好像很没有把握，悦子。”
“But you look rather unsure about it, Etsuko.”

“没有的事。
“Not at all.

我下次看到她就帮你问。
I'll enquire when I next see her.

可是我在想”——我再次压低声音——“白天谁照顾你女儿呢？”
But I was just wondering” — I lowered my voice again — “who would look after your daughter during the day?”

“万里子？
“Mariko?

她可以在店里帮忙。
She could help at the noodle shop.

她很能干。”
She's quite capable of being useful.”

“我相信她行。
“I'm sure she is.

可是您看，我不知道藤原太太会怎么想。
But you see, I'm not certain how Mrs Fujiwara would feel.

毕竟其实万里子白天应该上学才对。”
After all, Mariko should in reality be at school during the day.”

“我向你保证，悦子。万里子决不会造成什么麻烦。
“I assure you, Etsuko, Mariko won't be the slightest problem.

况且下星期学校就都放假了。
Besides, the schools are closing next week.

我会保证不让她碍事的。
And I'll make sure she won't get in the way.

这点你可以放心。”
You can rest assured on that.”

我再次鞠了鞠躬。
I bowed again.

“我下次看到她就帮你问。”
“I'll enquire when I next see her.”

“太感谢你了。”
“I'm very grateful to you.”

佐知子呷了一口茶。
Sachiko took a sip from her teacup.

“其实我想让你这几天就去找你的朋友。”
“In fact, perhaps I could ask you to see your friend within the next few days.”

“我试试看。”
“I'll try.”

“你真是太好了。”
“You're so kind.”

我们沉默片刻。
We fell silent for a moment.

之前我就注意到了佐知子的茶壶；是用浅色瓷器做的，做工很精细。
My attention had been caught earlier by Sachiko's teapot; it appeared a fine piece of craftsmanship made from a pale china.

我手里的茶杯也是同一种精美的材料做的。
The teacup I now held in my hand was of the same delicate material.

精美的茶具与破旧的屋子和走廊下方泥泞的土地形成了强烈的对比。我之前就注意到这点，喝茶时这种感觉更加明显。
As we sat drinking our tea, I was struck, not for the first time, by the odd contrast of the tea-set alongside the shabbiness of the cottage and the muddy ground beneath the veranda.

当我抬起头来时才发现佐知子在看着我。
When I looked up, I realized Sachiko had been watching me.

“我用惯了好陶瓷，悦子，”她说，“你瞧，我不是一直都住在这种”——她朝屋子挥了挥手——“这种地方。
“I'm used to good crockery, Etsuko,” she said. “You see, I don't always live like” — she waved a hand towards the cottage — “like this.

当然了，我不介意吃一点苦。
Of course, I don't mind a little discomfort.

可是对有些东西，我还是很讲究的。”
But about some things, I'm still rather discerning.”

我欠了欠身，没说什么。
I bowed, saying nothing.

佐知子也研究起她手里的杯子来。
Sachiko, also, began to study her teacup.

她小心地转动着杯子，细细观察，然后突然说道：“我想可以说我偷了这套茶具。
She continued to examine it, turning it carefully in her hands. Then suddenly she said: “I suppose it's true to say I stole this tea-set.

可是我想伯父他不会太想它们的。”
Still, I don't suppose my uncle will miss it much.”

我有些吃惊地看着她。
I looked at her, somewhat surprised.

佐知子把杯子放下，挥手赶走几只苍蝇。
Sachiko put the teacup down in front of her and waved away some flies.

“你说你住在你伯父家？”
“You were living at your uncle's house, you say?”

我问。
I asked.

她慢慢地点了点头。
She nodded slowly.

“一栋很漂亮的房子。
“A most beautiful house.

花园里还有池塘。
With a pond in the garden.

和眼前的这一切很不一样。”
Very different from these present surroundings.”

一时间我们两个人都往屋子里看。
For a moment, we both glanced towards the inside of the cottage.

万里子还像我们出来时那样躺在她的角落里，背对着我们，好像在跟她的猫说话。
Mariko was lying in her corner, just as we had left her, her back turned towards us. She appeared to be talking quietly to her cat.

我们俩沉默了片刻后，我说：“我还不知道河对面住着人。”
“I didn't realize”, I said, when neither of us had spoken for some time, “that anyone lived across the river.”

佐知子转头看着远处的树木。
Sachiko turned and glanced towards the trees on the far bank.

“不，我没见过那里有人。”
“No, I haven't seen anyone there.”

“可是帮你看孩子的那个人。
“But your babysitter.

万里子说她是从那里来的。”
Mariko was saying she came from over there.”

“我没有人帮我看孩子，悦子。
“I have no babysitter, Etsuko.

我在这谁也不认识。”
I know nobody here.”

“刚才万里子跟我说有个女的……”
“Mariko was telling me about some lady …”

“请别当真。”
“Please don't pay any attention.”

“你是说那是万里子编出来的？”
“You mean she was just making it up?”

有那么一小会儿，佐知子像是在想些什么。
For a brief moment, Sachiko seemed to be considering something.

然后她才说：“对。
Then she said: “Yes.

是她编出来的。”
She was just making it up.”

“我想小孩子经常干这种事。”
“Well, I suppose children often do things like that.”

佐知子点点头。
Sachiko nodded.

“你当妈妈后，悦子，”她笑着说，“你就得要习惯这种事了。”
“When you become a mother, Etsuko,” she said, smiling, “you'll need to get used to such things.”

接着我们聊到别的事上去了。
We drifted on to other subjects then.

那时我们的友谊刚刚开始，我们只谈论一些无关紧要的小事。
Those were early days in our friendship and we talked mainly of little things.

直到几个星期后的一天早上，我才再次听到万里子提起那个来找她的女人。
It was not until one morning some weeks later that I heard Mariko mention again a woman who had approached her.

# 第一部 · 第二章 | PART ONE · Chapter Two

那时，回到中川一带仍然会令我悲喜交加。
In those days, returning to the Nakagawa district still provoked in me mixed emotions of sadness and pleasure.

这里山峦起伏，再次走在一座座房子间那些狭窄、陡峭的街道上总是给我一种深深的失落感。
It is a hilly area, and climbing again those steep narrow streets between the clusters of houses never failed to fill me with a deep sense of loss.

虽然我不会想来就来，但总也无法长久地远离这里。
Though not a place I visited on casual impulse, I was unable to stay away for long.

拜访藤原太太同样会给我这种感觉；因为她是我母亲最好的朋友之一，一位和蔼的女士，头发已经花白。
Calling on Mrs Fujiwara aroused in me much the same mixture of feelings; for she had been amongst my mother's closest friends, a kindly woman with hair that was by then turning grey.

她的面店开在一条热闹的小巷子里；店门口有一块水泥地，屋顶伸了出去，客人就在那里，坐在木桌和长凳上吃面。
Her noodle shop was situated in a busy sidestreet; it had a concrete forecourt under the cover of an extended roof and it was there her customers ate, at the wooden tables and benches.

她的客人主要是午休和下班时来光顾的上班族，其他钟点则没有什么客人。
She did a lot of trade with office workers during their lunch breaks and again on their way home, but at other times of the day the clientele became sparse.

那天下午我有点紧张，因为那是佐知子到那边工作后我第一次去。
I was a little anxious that afternoon, for it was the first time I had called at the shop since Sachiko had started to work there.

我在担心——替她们两个都担心——尤其是因为我不知道藤原太太是不是真的需要帮手。
I felt concerned — on both their behalves — especially since I was not sure how genuinely Mrs Fujiwara had wanted an assistant.

那天很热，小巷里都是人。
It was a hot day, and the little sidestreet was alive with people.

进到阴凉处我真高兴。
I was glad to come into the shade.

藤原太太见到我很高兴。
Mrs Fujiwara was pleased to see me.

她让我在一张桌子旁坐下，然后去取茶。
She sat me down at a table, then went to fetch some tea.

那天下午没有什么客人——可能一个都没有，我不记得了——也没有看见佐知子。
Customers were few that afternoon — perhaps there were none, I do not remember — and Sachiko was not to be seen.

藤原太太取来茶时，我问她：“我的朋友在这里做得怎么样？
When Mrs Fujiwara came back, I asked her: “How is my friend getting along?

她还行吧？”
Is she managing all right?”

“你的朋友？”藤原太太转头朝厨房的门看去。
“Your friend?” Mrs Fujiwara looked over her shoulder towards the doorway of the kitchen.

“她在削土豆。
“She was peeling prawns.

我想很快就会出来了。”
I expect she'll be out soon.”

然后，好像转念一想，她站起来，朝厨房门口走了几步。
Then, as if on second thoughts, she got to her feet and walked a little way towards the doorway.

“佐知子太太，”她喊道，“悦子来了。”
“Sachiko-San,” she called. “Etsuko is here.”

我听见里面传来一声应答。
I heard a voice reply from within.

藤原太太回来坐下，伸过手来摸我的肚子。
As she sat down again, Mrs Fujiwara reached over and touched my stomach.

“开始变明显了，”她说，“你现在开始可得当心啊。”
“It's beginning to show now,” she said. “You must take good care from now on.”

“反正我也没干多少活，”我说。
“I don't do a great deal anyway,” I said.

“我日子很清闲。”
“I lead a very easy life.”

“那就好。
“That's good.

我记得我怀第一胎时，遇上了地震，挺大的地震。
I remember my first time, there was an earthquake, quite a large one.

我那时怀的是和夫。
I was carrying Kazuo then.

可他后来也健康得很。
He came perfectly healthy though.

别太担心，悦子。”
Try not to worry too much, Etsuko.”

“我会的。”
“I try not to.”

我朝厨房门口看了一眼，“我的朋友在这里做得还好吧？”
I glanced towards the kitchen door. “Is my friend getting on well here?”

藤原太太顺着我的目光朝厨房看去。
Mrs Fujiwara followed my gaze towards the kitchen.

然后又转向我，说：“我想还好。
Then she turned to me again and said: “I expect so.

你们是好朋友，对吗？”
You're good friends, are you?”

“是的。
“Yes.

我在现在住的地方没有多少朋友。
I haven't found many friends where we live.

我很高兴认识了佐知子。”
I'm very glad to have met Sachiko.”

“是啊。
“Yes.

那太好了。”
That was fortunate.”

她坐在那里，看了我几秒钟。
She sat there looking at me for several seconds.

“悦子，你今天很累的样子。”
“Etsuko, you're looking rather tired today.”

“我想是很累。”
“I suppose I am.”

我笑了笑。
I laughed a little.

“我想是怀孕的缘故。”
“It's only to be expected, I suppose.”

“是啊，自然。”
“Yes, of course.”

藤原太太还是看着我的脸。
Mrs Fujiwara kept looking into my face.

“但我是说你好像——不太开心。”
“But I meant you looked a little — miserable.”

“不开心？
“Miserable?

才没有呢。
I certainly don't feel it.

我只是有点累，我没有比现在更开心了。”
I'm just a little tired, but otherwise I've never been happier.”

“那就好。
“That's good.

你现在得多想想开心的事。
You must keep your mind on happy things now.

孩子啊。
Your child.

未来啊。”
And the future.”

“是的，我会的。
“Yes, I will.

想到孩子我就很开心。”
Thinking about the child cheers me up.”

“很好。”
“Good.”

她点点头，但还是盯着我。
She nodded, still keeping her gaze on me.

“心态决定一切。
“Your attitude makes all the difference.

一位母亲应该得到她想要的所有的照顾，她需要以一种积极的心态来抚养孩子。”
A mother can take all the physical care she likes, she needs a positive attitude to bring up a child.”

“我确实很期待。”我笑了笑，说。
“Well, I'm certainly looking forward to it,” I said, with a laugh.

厨房里传出声响，我又一次看过去，但还是没有看见佐知子。
A noise made me look towards the kitchen again, but Sachiko was still not in sight.

“我每周都看见一个年轻的女子，”藤原太太接着说道。
“There's a young woman I see every week,” Mrs Fujiwara went on.

“怀孕六七个月了。
“She must be six or seven months pregnant now.

我每次去墓地都看见她。
I see her every time I go to visit the cemetery.

我没有跟她说过话，但是她看上去很悲伤，和她的丈夫站在那里。
I've never spoken to her, but she looks so sad, standing there with her husband.

真是羞愧啊，一个孕妇和她的丈夫每周日不做别的，就想着死人。
It's a shame, a pregnant girl and her husband spending their Sundays thinking about the dead.

我知道他们是敬爱死者，但仍旧不应该这样。
I know they're being respectful, but all the same, I think it's a shame.

他们应该想着未来才是。”
They should be thinking about the future.”

“我想她很难忘记过去。”
“I suppose she finds it hard to forget.”

“我想是吧。
“I suppose so.

我很同情她。
I feel sorry for her.

但是现在他们应该向前看。
But they should be thinking ahead now.

每周都来墓地，这样怎么能把孩子带到这个世上来呢？”
That's no way to bring a child into the world, visiting the cemetery every week.”

“大概不能。”
“Perhaps not.”

“墓地不是年轻人去的地方。
“Cemeteries are no places for young people.

和夫有时会陪我去，但我从来没有要他一定要去。
Kazuo comes with me sometimes, but I never insist.

他现在也应该向前看了。”
It's time he started looking ahead too.”

“和夫还好吗？”
“How is Kazuo?”

我问。
I asked.

“他的工作顺利吗？”
“Is his work coming on well?”

“工作很顺利。
“His work's fine.

下个月他就会得到晋升。
He's expecting to be promoted next month.

但他也该想想别的事了。
But he needs to give other things a little thought.

他不可能永远年轻。”
He won't be young for ever.”

突然我看见外面太阳下来来往往的人群中站着一个小小的身影。
Just then my eye was caught by a small figure standing out in the sunlight amidst the rush of passers-by.

“哎呀，那不是万里子吗？”
“Why, isn't that Mariko?”

我问。
I said.

藤原太太坐在椅子上转过头去。
Mrs Fujiwara turned in her seat.

“万里子，”她喊道。
“Mariko-San,” she called.

“你到哪里去了？”
“Where have you been?”

万里子站在马路上不动。
For a moment, Mariko remained standing out in the street.

但不一会儿，她走进阴凉的水泥地，走过我们，在旁边的一张空桌子坐下。
Then she stepped into the shade of the forecourt, came walking past us and sat down at an empty table nearby.

藤原太太先是看着万里子，然后不安地看了我一眼，好像要说什么，但是她站了起来，朝小女孩走去。
Mrs Fujiwara watched the little girl, then gave me an uneasy look. She seemed about to say something, but then got to her feet and went over to the little girl.

“万里子，你到哪里去了？”
“Mariko-San, where have you been?”

藤原太太压低了声音，但我还是听得见。
Mrs Fujiwara had lowered her voice, but I was still able to hear.

“你不可以老是这样子乱跑。
“You're not to keep running off like that.

你妈妈很生气。”
Your mother's very angry with you.”

万里子看着自己的手指，没有抬头看藤原太太。
Mariko was studying her fingers. She did not look up at Mrs Fujiwara.

“还有万里子，请你不要那样子跟客人说话。
“And Mariko-San, please, you're never to talk to customers like that.

你不知道那样子很没礼貌吗？
Don't you know it's very rude?

你妈妈很生气。”
Your mother's very angry with you.”

万里子还是看着自己的手指。
Mariko went on studying her hands.

在她身后，佐知子出现在厨房门口。
Behind her, Sachiko appeared in the doorway of the kitchen.

我记得那天早上看见佐知子时，我再次惊讶于她比我原先以为的要老得多；她的长发都塞进了头巾里，这样一来，眼角和嘴角的皱纹变得更加明显。
Seeing Sachiko that morning, I recall I was struck afresh by the impression that she was indeed older than I had first supposed; with her long hair hidden away inside a handkerchief, the tired areas of skin around her eyes and mouth seemed somehow more pronounced.

“你妈妈来了，”藤原太太说，“我想她一定很生气。”
“Here's your mother now,” said Mrs Fujiwara. “I expect she's very angry with you.”

小女孩还是坐在那里，背对着她妈妈。
The little girl had remained seated with her back to her mother.

佐知子很快地瞥了她一眼，笑着转向我。
Sachiko threw a quick glance towards her, then turned to me with a smile.

“你好啊，悦子，”她说，优雅地鞠了一躬。
“How do you do, Etsuko,” she said, with an elegant bow.

“在这里见到你真是惊喜。”
“What a pleasant surprise to see you here.”

在水泥地的另一头，两个上班模样的女人走进来坐下。
At the other end of the forecourt, two women in office clothes were seating themselves at a table.

藤原太太朝她们鞠了个躬，又转向万里子。
Mrs Fujiwara gestured towards them, then turned to Mariko once more.

“你为什么不到厨房去一会儿呢？”她小声说。
“Why don't you go into the kitchen for a little while,” she said, in a low voice.

“你妈妈会告诉你要做些什么的。
“Your mother will show you what to do.

很简单的。
It's very easy.

我相信像你这么聪明的女孩子一定会做的。”
I'm sure a clever girl like you could manage.”

万里子没有反应。
Mariko gave no sign of having heard.

藤原太太抬头看看佐知子，一刹那，我觉得她们冷冷地交换了眼神。
Mrs Fujiwara glanced up at Sachiko, and for a brief instant I thought they exchanged cold glances.

然后藤原太太转身向她的客人走去。
Then Mrs Fujiwara turned and went off towards her customers.

看来她认识她们，边走过水泥地，边熟识地跟她们打招呼。
She appeared to know them, for as she walked across the forecourt, she gave them a familiar greeting.

佐知子走过来在桌子边坐下。
Sachiko came and sat at the edge of my table.

“厨房里真热啊，”她说。
“It's so hot inside that kitchen,” she said.

“你在这里做得怎么样？”
“How are you getting on here?”

我问她。
I asked her.

“做得怎么样？
“How am I getting on?

哦，悦子，这真是很有趣的经历，在面店里工作。
Well, Etsuko, it's certainly an amusing sort of experience, working in a noodle shop.

我得说，我从没想过有一天我会在这种地方擦桌子。
I must say, I never imagined I'd one day find myself scrubbing tables in a place like this.

但是”——她很快地笑了笑——“很有趣。”
Still” — she laughed quickly — “it's quite amusing.”

“我知道了。
“I see.

那万里子呢，她习惯吗？”
And Mariko, is she settling in?”

我们都往万里子的桌子看去；那孩子还是看着她的手。
We both glanced over to Mariko's table; the child was still looking down at her hands.

“哦，她很好，”佐知子说。
“Oh, Mariko's fine,” said Sachiko.

“当然了，她有时候很好动。
“Of course, she's rather restless at times.

但是你怎么可能要她安静地待在这里呢？
But then you'd hardly expect otherwise under the circumstances.

真遗憾，悦子，但是你看，我的女儿并没有我的幽默感。
It's regrettable, Etsuko, but you see, my daughter doesn't seem to share my sense of humour.

她不觉得这里很有趣。”
She doesn't find it quite so amusing here.”

佐知子笑了笑，又看看万里子。
Sachiko smiled and glanced towards Mariko again.

然后她站起来，朝她走去。
Then she got to her feet and went over to her.

她静静地问：“藤原太太跟我说的是真的吗？”
She asked quietly: “Is it true what Mrs Fujiwara told me?”

小女孩没有回答。
The little girl remained silent.

“她说你又对客人不礼貌了。
“She says you were being rude to customers again.

是真的吗？”
Is that true?”

万里子还是不做声。
Mariko still gave no response.

“她跟我说的是真的吗？
“Is it true what she told me?

万里子，人家问你话时你要回答。”
Mariko, please answer when you're spoken to.”

“那个女人又来了，”万里子说。
“The woman came round again,” said Mariko.

“昨晚。
“Last night.

你不在的时候。”
While you were gone.”

佐知子看了她女儿一两秒钟，然后说：“我想你现在最好进去。
Sachiko looked at her daughter for a second or two. Then she said: “I think you should go inside now.

进去，我来告诉你要干些什么。”
Go on, I'll show you what you have to do.”

“她昨天晚上又来了。
“She came again last night.

她说她要带我去她家。”
She said she'd take me to her house.”

“进去，万里子，到厨房里去等我。”
“Go on, Mariko, go on into the kitchen and wait for me there.”

“她要带我去她住的地方。”
“She's going to show me where she lives.”

“万里子，进去。”
“Mariko, go inside.”

水泥地的那边，藤原太太和那两个女人为了什么事大笑起来。
Across the forecourt, Mrs Fujiwara and the two women were laughing loudly about something.

万里子还是看着她的手掌。
Mariko continued to stare at her palms.

佐知子走开了，回到我这张桌子。
Sachiko turned away and came back to my table.

“请原谅，悦子，”她说。
‘Excuse me a moment, Etsuko,” she said.

“我有东西在煮。
“But I left something boiling.

我一会儿就回来。”
I'll be back in just a moment.”

然后她降低声音加了句：“你不能指望她会对这种地方感兴趣，不是吗？”
Then lowering her voice, she added: “You can hardly expect her to get enthusiastic about a place like this, can you?”

她笑了笑，走向厨房。
She smiled and went towards the kitchen.

到了门口，她再次转向她的女儿。
At the doorway, she turned once more to her daughter.

“快点，万里子，进来。”
“Come on, Mariko, come inside.”

万里子没有动。
Mariko did not move.

佐知子耸耸肩，进去了。
Sachiko shrugged, then disappeared inside the kitchen.

同样在那段时间，初夏时，绪方先生到我们这里来了，那是他那年早些时候搬出长崎后第一次到这里来。
Around that same time, in early summer, Ogata-San came to visit us, his first visit since moving away from Nagasaki earlier that year.

他是我的公公，可是我却老是把他当作“绪方先生”，即使在我自己也姓绪方的时候。
He was my husband's father, and it seems rather odd I always thought of him as “Ogata-San”, even in those days when that was my own name.

那时，我已经认识他很久了——比我认识二郎还要久——一直叫他“绪方先生”，我从来不习惯叫他“爸爸”。
But then I had known him as “Ogata-San” for such a long time — since long before I had ever met Jiro — I had never got used to calling him “Father”.

他们父子俩长得不像。
There was little family resemblance between Ogata-San and my husband.

如今回想起二郎，我的眼前出现一个矮矮、结实的、表情严肃的男人；我丈夫对外表一丝不苟，即使在家里，也经常穿衬衫、打领带。
When I recall Jiro today, I picture a small stocky man wearing a stern expression; my husband was always fastidious about his appearance, and even at home would frequently dress in shirt and tie.

现在我还能想见他坐在客厅的榻榻米上，弓着背吃早、晚餐，就像我以前常见的那样。
I see him now as I saw him so often, seated on the tatami in our living room, hunched forward over his breakfast or supper.

我记得他老是弓着背——像拳击手那样——不管站着还是走路。
I remember he had this same tendency to hunch forward — in a manner not unlike that of a boxer — whether standing or walking.

相反，他的父亲总是坐得直直的，神情轻松、和蔼。
By contrast, his father would always sit with his shoulders flung well back, and had a relaxed, generous manner about him.

那年夏天他来的时候，他的健康状况还很好，身体硬朗、精神矍铄，不像有那么大岁数。
When he came to visit us that summer, Ogata-San was still in the best of health, displaying a well-built physique and the robust energy of a much younger man.

我记得一天早上，他第一次提到松田重夫。
I remember the morning he first mentioned Shigeo Matsuda.

那时他已经住了几天了，显然觉得这间小四方屋子很舒适，想多住几天。
He had been with us for a few days by then, apparently finding the small square room comfortable enough for an extended stay.

那是一个明媚的早晨，我们仨在吃早餐，二郎还没去上班。
It was a bright morning and the three of us were finishing breakfast before Jiro left for the office.

“你们的同学会，”他对二郎说。
“This school reunion of yours,” he said to Jiro.

“在今晚，是吧？”
“That's tonight, is it?”

“不，是明天晚上。”
“No, tomorrow evening.”

“你会见到松田重夫吗？”
“Will you be seeing Shigeo Matsuda?”

“重夫？
“Shigeo?

我想不会见到。
No, I doubt it.

他不常参加这些活动。
He doesn't usually attend these occasions.

我很抱歉得出去，不能陪你，爸爸。
I'm sorry to be going off and leaving you, Father.

我想不去的，但是那样会让他们不高兴。”
I'd rather give the thing a miss, but that may cause offence.”

“别担心。
“Don't worry.

悦子会把我照顾得很好的。
Etsuko-San will look after me well enough.

而且这些活动也很重要。”
And these occasions are important.”

“我想请几天假，”二郎说，“可是眼下我们很忙。
“I'd take some days off work,” Jiro said, “but we're so busy just now.

我说过了，订单刚好在您来的那天来了。
As I say, this order came into the office the day you arrived.

真是讨厌。”
A real nuisance.”

“哪儿的话，”他父亲说。
“Not at all,” said his father.

“我完全理解。
“I understand perfectly.

我自己前不久也还在为工作忙碌呢。
It wasn't so long ago I was rushed off my feet with work myself.

我没有那么老，你知道。”
I'm not so old, you know.”

“没有，当然没有。”
“No, of course.”

我们安静地吃着早餐。
We ate on in silence for several moments.

突然绪方先生说：
Then Ogata-San said:

“那么你觉得明天不会遇到松田重夫。
“So you don't think you'll be running into Shigeo Matsuda.

但是你们偶尔还是会碰面吧？”
But you still see him from time to time?”

“最近不常见了。
“Not so often these days.

长大以后大家就各走各的了。”
We've gone such separate ways since we got older.”

“是啊，都是这样。
“Yes, this is what happens.

学生们都各走各的，然后发现很难保持联系。
Pupils all go separate ways, and then they find it so difficult to keep in touch.

所以这些同学会就很重要。
That's why these reunions are so important.

人不应该那么快就忘记以前的感情。
One shouldn't be so quick to forget old allegiances.

应该时不时地看看过去，才能更好地认识事情。
And it's good to take a glance back now and then, it helps keep things in perspective.

没错，我觉得明天你当然要去。”
Yes, I think you should certainly go along tomorrow.”

“也许爸爸星期天的时候还在这里，”我丈夫说。
“Perhaps Father will still be with us on Sunday,” my husband said.

“那样我们也许能去哪里走走。”
“Then perhaps we could go out somewhere for the day.”

“嗯，好啊。
“Yes, we can do that.

好主意。
A splendid idea.

但是如果你得上班，那一点儿也不要紧。”
But if you have work to do, it doesn't matter in the least.”

“不，我想我星期天没事。
“No, I think I can leave Sunday free.

很抱歉眼下我太忙了。”
I'm sorry to be so busy at the moment.”

“明天你们请了以前的老师没？”
“Have you asked any of your old teachers along tomorrow?”

绪方先生问。
Ogata-San asked.

“据我所知没有。”
“Not that I know of.”

“真是遗憾啊，这种场合老师不太常被邀请。
“It's a shame teachers aren't asked more often to these occasions.

我以前有时也被邀请。
I was asked along from time to time.

在我年轻的时候，我们总是不忘要邀请老师。
And when I was younger, we always made a point of inviting our teachers.

我认为这样才恰当。
I think it's only proper.

这是一个机会让老师看看他的劳动成果，让学生们向他表示感激。
It's an opportunity for a teacher to see the fruits of his work, and for the pupils to express their gratitude to him.

我认为老师应该出席才对。”
I think it's only proper that teachers are present.”

“是，也许您说得对。”
“Yes, perhaps you have a point.”

“现在的人很容易就忘记他们的教育归功于谁。”
“Men these days forget so easily to whom they owe their education.”

“是，您说得很对。”
“Yes, you're very right.”

我丈夫吃完早餐，放下筷子。
My husband finished eating and laid down his chopsticks.

我给他倒了些茶。
I poured him some tea.

“有一天我碰到了一件奇怪的小事情，”绪方先生说。
“An odd little thing happened the other day,” Ogata-San said.

“现在想想我觉得挺有趣。
“In retrospect, I suppose it's rather amusing.

一天我在长崎的图书馆看见了一本期刊——一本教师期刊。
I was at the library in Nagasaki, and I came across this periodical — a teachers’ periodical.

我没听说过那个期刊，我教书的时候没有那个期刊。
I'd never heard of it, it wasn't in existence in my days.

读那本期刊，你会以为现在日本的教师都变成共产主义者了。”
To read it, you'd think all the teachers in Japan were communists now.”

“显然共产主义现在在日本越来越流行，”我丈夫说。
“Apparently communism is growing in the country,” my husband said.

“你的朋友松田重夫在上面发表了文章。
“Your friend Shigeo Matsuda had written in it.

想想我看见文章里提到我的名字时是多么惊讶。
Now imagine my surprise when I saw my name mentioned in his article.

我没想到现在还有人记得我。”
I didn't think I was so noteworthy these days.”

“我肯定在长崎还有很多人记得爸爸，”我插了一句。
“I'm sure Father is still remembered very well in Nagasaki,” I put in.

“太奇怪了。
“It was quite extraordinary.

他提到远藤老师和我，说到我们的退休。
He was talking about Dr Endo and myself, about our retirements.

要是我没理解错的话，他暗示说这一行没了我们真是庆幸。
If I understood him correctly, he was implying that the profession was well rid of us.

事实上，他甚至觉得我们在战争结束后就该被解职了。
In fact, he went so far as to suggest we should have been dismissed at the end of the war.

太奇怪了。”
Quite extraordinary.”

“您确定是同一个松田重夫吗？”二郎问。
“Are you sure it's the same Shigeo Matsuda?” asked Jiro.

“同一个。
“The same one.

栗山高中的。
From Kuriyama Highschool.

太奇怪了。
Extraordinary.

我记得他以前常来我们家和你玩。
I remember when he used to come to our house, to play with you.

你妈妈特别喜欢他。
Your mother used to spoil him.

我问图书馆的管理员可不可以买一本，她说她会帮我订一本。
I asked the librarian if I could buy a copy, and she said she would order one for me.

到时我拿给你看。”
I'll show it to you.”

“这不是忘恩负义吗？”我说。
“It seems very disloyal,” I said.

“当时我可惊讶了，”绪方先生转向我说。
“I was so surprised,” Ogata-San said, turning to me.

“是我把他介绍给栗山高中的校长的。”
“And I was the one who introduced him to the headmaster at Kuriyama.”

二郎喝完茶，用毛巾擦了擦嘴。
Jiro drank up his tea and wiped his mouth with his napkin.

“太遗憾了。
“It's very regrettable.

我说过了，我有一段时间没见到重夫了。
As I say, I haven't seen Shigeo for some time.

请原谅，爸爸，但是我得走了，不然要迟到了。”
I'm sorry, Father, but you must excuse me now or I'll be late.”

“哦，当然。
“Why certainly.

工作顺利。”
Have a good day at work.”

二郎走下玄关，开始穿鞋。
Jiro stepped down to the entryway, where he started to put on his shoes.

我对绪方先生说：“像爸爸这种地位的人一定会听到一些批评。
I said to Ogata-San: “Someone who reached your position, Father, must expect a little criticism.

这是很自然的。”
That's only natural.”

“是啊，”他说，笑了起来。
“Of course,” he said, breaking out into a laugh.

“别在意这件事，悦子。
“No, don't concern yourself about it, Etsuko.

我一点都不介意。
I hadn't given it a second thought.

只是二郎要去参加同学会，让我又想起了这件事。
I just happened to think of it because Jiro was going to his reunion.

不知道远藤读到这篇文章没有。”
I wonder if Endo read the article.”

“祝您今天愉快，爸爸，”二郎在玄关那里说道。
“I hope you have a good day, Father,” Jiro called from the entryway.

“可以的话我会争取早点回来。”
“I'll try to be back a little early if I can.”

“胡说什么。别为我操心。
“Nonsense, don't make such a fuss.

工作重要。”
Your work is important.”

那天上午晚些时候，绪方先生从房里出来，穿着外套、打着领带。
A little later that morning, Ogata-San emerged from his room dressed in his jacket and tie.

“您要出去吗，爸爸？”
“Are you going out, Father?”

我问。
I asked.

“我想去见见远藤老师。”
“I thought I'd just pay a visit to Dr Endo.”

“远藤老师？”
“Dr Endo?”

“对，我想去看看他最近过得怎么样。”
“Yes, I thought I'd go and see how he was keeping these days.”

“可是您不是要在吃午饭前去吧？”
“But you're not going before lunch, are you?”

“我想我最好马上就去，”他看了看表，说。
“I thought I'd better go quite soon,” he said, looking at his watch.

“远藤现在住的地方离长崎市区有点远。
“Endo lives a little way outside Nagasaki now.

我得搭电车。”
I'll need to get a train.”

“那让我给您准备一份便当吧，不用多长时间。”
“Well, let me pack you a lunch-box, it won't take a minute.”

“哎呀，谢谢了，悦子。
“Why, thank you, Etsuko.

那我就等几分钟。
In that case I'll wait a few minutes.

其实我是想让你帮我准备便当的。”
In fact, I was hoping you'd offer to pack me lunch.”

“那您就说出来，”我站起身来，说。
“Then you should have asked,” I said, getting to my feet.

“您不能老用这种暗示来得到您想要的东西，爸爸。”
“You won't always get what you want just by hinting like that, Father.”

“可是我知道你会领会我的意思的，悦子。
“But I knew you'd pick me up correctly, Etsuko.

我对你有信心。”
I have faith in you.”

我走向厨房，穿上拖鞋，走进铺着瓷砖的地面。
I went through to the kitchen, put on some sandals and stepped down to the tiled floor.

几分钟后，拉门开了，绪方先生出现在门口。
A few minutes later, the partition slid open and Ogata-San appeared at the doorway.

他就坐在门口看我准备便当。
He seated himself at the threshold to watch me working.

“你在给我做什么呢？”
“What is that you're cooking me there?”

“没什么。
“Nothing much.

只是昨晚的剩菜。
Just left-overs from last night.

这么短的时间里，不可能要求更好的了。”
At such short notice, you don't deserve any better.”

“但是我肯定你还是会把剩菜变得很可口。
“And yet you'll manage to turn it into something quite appetizing, I'm sure.

你拿蛋要做什么？
What's that you're doing with the egg?

那个不是剩菜吧？”
That's not a left-over too, is it?”

“我要加一个煎蛋。
“I'm adding an omelette.

您运气好，爸爸，我那么慷慨。”
You're very fortunate, Father, I'm in such a generous mood.”

“煎蛋。
“An omelette.

你一定要教我怎么做煎蛋。
You must teach me how to do that.

难不难？”
Is it difficult?”

“很难。
“Extremely difficult.

您这个年纪是学不来的。”
It would be hopeless you trying to learn at this stage.”

“可是我很想学。
“But I'm very keen to learn.

还有，你说‘您这个年纪’是什么意思？
And what do you mean ‘at this stage’?

我还年轻，还可以学很多新东西。”
I'm still young enough to learn many new things.”

“您真的打算成为一名厨师吗，爸爸？”
“Are you really planning on becoming a cook, Father?”

“没什么可笑的。
“It's nothing to laugh at.

这些年来，我渐渐懂得欣赏做菜了。
I've come to appreciate cooking over the years.

它是一门艺术，我确信这点，就像绘画或诗歌一样高雅。
It's an art, I'm convinced of it, just as noble as painting or poetry.

不能因为它的产品很快就消失了而不懂得欣赏。”
It's not appreciated simply because the product disappears so quickly.”

“您要坚持画画，爸爸。
“Persevere with painting, Father.

您画得越来越好了。”
You do it much better.”

“画画啊。”
“Painting.”

他叹了一口气。
He gave a sigh.

“画画已经不能像以前那样给我满足感了。
“It doesn't give me the satisfaction it once did.

不，我想我应该学做煎蛋做得跟你一样好，悦子。
No, I think I should learn to cook omelettes as well as you do, Etsuko.

我回福冈前你一定要教我。”
You must show me before I go back to Fukuoka.”

“一旦您学会了，您就不会再觉得它是什么艺术了。
“You wouldn't think it such an art once you'd learnt how it was done.

也许女人应该把这些事情保密。”
Perhaps women should keep these things secret.”

他笑了起来，像是在对自己笑，然后又安安静静地看我做事情。
He laughed, as if to himself, then continued to watch me quietly.

“你想是男孩还是女孩呢，悦子？”
“Which are you hoping for, Etsuko?” he asked, eventually.

过了好一会儿他问道。
“A boy or a girl?”

“我一点儿都不在乎。
“I really don't mind.

要是男孩就取您的名字。”
If it's a boy we could name him after you.”

“真的？
“Really?

一言为定？”
Is that a promise?”

“现在再想想，我又拿不准了。
“On second thoughts I don't know.

我不记得爸爸的名字了。
I was forgetting what Father's first name was.

征尔——这个名字不好听。”
Seiji — that's an ugly sort of name.”

“那只是因为我长得丑，悦子。
“But that's only because you find me ugly, Etsuko.

我记得有一个班的学生说我长得像河马。
I remember one class of pupils decided I resembled a hippopotamus.

可是你不应该光看外表就觉得不行。”
But you shouldn't be put off by such outer trappings.”

“没错。
“That's true.

我们还得看看二郎是怎么想的。”
Well, we'll have to see what Jiro thinks.”

“是。”
“Yes.”

“可是我希望我的儿子能取您的名字，爸爸。”
“But I'd like my son to be named after you, Father.”

“那可真让我高兴。”
“That would make me very happy.”

他笑着朝我微微鞠了一躬。
He smiled and gave me a small bow.

“可我是知道家人坚持要用自己的名字给孩子取名是多么讨人厌的。
“But then I know how irritating it is when relatives insist on having children named after them.

我记得我和老伴给二郎起名字的时候，我想用我一个叔叔的名字，可是孩子他妈不喜欢这种用亲戚的名字给孩子取名的做法。
I remember the time my wife and I argued over what to call Jiro. I wanted to name him after an uncle of mine, but my wife disliked this practice of naming children after relatives.

当然，后来她让步了。
Of course, she had her way in the end.

景子是个很固执的人。”
Keiko was a hard woman to budge.”

“景子是个好名字。
“Keiko is a nice name.

要是女孩，也许可以叫景子。”
Perhaps if it's a girl we could call her Keiko.”

“你可不能这么匆忙地做决定。
“You shouldn't make such promises so rashly.

你要是没有说到做到，会让老人家很失望的。”
You'll make an old man very disappointed if you don't keep to them.”

“对不起，我想到了就说出来了。”
“I'm sorry, I was just thinking aloud.”

“而且，悦子，我相信还有其他人的名字你想用。
“And besides, Etsuko, I'm sure there are others you'd prefer to name your child after.

其他跟你亲近的人。”
Others you were closer to.”

“也许吧。
“Perhaps.

不过要是男孩，我想用您的名字。
But if it's a boy I'd like him to be named after you.

您以前就像我的父亲。”
You were like a father to me once.”

“我现在不像你的父亲了？”
“Am I no longer like a father to you?”

“像，当然像。
“Yes, of course.

可是不一样。”
But it's different.”

“我希望二郎是个好丈夫。”
“Jiro is a good husband to you, I hope.”

“当然是了。
“Of course.

我再幸福不过了。”
I couldn't be happier.”

“孩子也会让你幸福。”
“And the child will make you happy.”

“是。
“Yes.

怀孕的时机再好不过了。
It couldn't have happened at a better time.

现在我们在这里安定下来了，二郎的工作也很顺利。
We're quite settled here now, and Jiro's work is going well.

这个时候要孩子最好。”
This is the ideal time for this to have happened.”

“那么你觉得幸福？”
“So you're happy?”

“是的，我很幸福。”
“Yes, I'm very happy.”

“很好。
“Good.

我真替你们两个高兴。”
I'm happy for you both.”

“给，做好了。”
“There, it's all ready for you.”

我把涂漆的便当盒递给他。
I handed him the lacquer lunch-box.

“啊对了，剩菜，”他说，接过去，深深地鞠了一躬。
“Ah yes, the left-overs,” he said, receiving it with a dramatic bow.

他微微打开盖子。
He lifted the lid a little.

“但看上去很可口。”
“It looks delightful though.”

我终于回到客厅。绪方先生在玄关那里穿鞋。
When I eventually went back into the living room, Ogata-San was putting on his shoes in the entryway.

“告诉我，悦子，”他头也不抬地说。
“Tell me, Etsuko,” he said, not looking up from his laces.

“你见过这个松田重夫吗？”
“Have you met this Shigeo Matsuda?”

“一两次。
“Once or twice.

我们结婚后他来过。”
He used to visit us after we were married.”

“但是现在他和二郎不是什么特别要好的朋友吧？”
“But he and Jiro aren't such close friends these days?”

“不是。
“Hardly.

我们寄寄贺年卡，仅此而已。”
We exchange greeting cards, but that's all.”

“我要叫二郎写信给他。
“I'm going to suggest to Jiro he writes to his friend.

重夫应该道歉。
Shigeo should apologize.

要不然我就要叫二郎跟这个年轻人断交。”
Or else I'll have to insist Jiro disassociates himself from that young man.”

“我知道了。”
“I see.”

“我本想早点跟他说，就在刚才吃早饭的时候。
“I thought of suggesting it to him earlier, when we were talking at breakfast.

但是这种事最好留到晚上再说。”
But then that kind of talk is best left till the evening.”

“也许您说得对。”
“You're probably right.”

绪方先生再次感谢我做的便当，然后出门了。
Ogata-San thanked me once more for the lunch-box before leaving.

结果，那天晚上他并没有提起这件事。
As it turned out, he did not bring the matter up that night.

他们两个回家时都很累了，一整晚大都在看报纸，很少说话。只有一次绪方先生提到了远藤老师。
They both seemed tired when they came in and spent most of the evening reading newspapers, speaking little.

那是在吃晚饭的时候，他轻描淡写地说了句：“远藤看来不错，只是想念他的工作。
And only once did Ogata-San mention Dr Endo. That was at supper, and he said simply: “Endo seemed well. He misses his work though.

毕竟教书是他的生命。”
After all, the man lived for it.”

那天晚上躺在床上准备睡觉时，我对二郎说：“我希望爸爸对我们的接待还满意。”
In bed that night, before we fell asleep, I said to Jiro: “I hope Father's quite content with the way we're receiving him.”

“不然他还想要怎么样？”我丈夫说。
“What else can he expect?” my husband said.

“你要是这么不放心，干吗不带他出去走走？”
“Why don't you take him out somewhere if you're so worried.”

“你周六下午要上班吗？”
“Will you be working on Saturday afternoon?”

“怎么可能不上班？
“How can I afford not to?

我进度已经落后了。
I'm behind schedule as it is.

他刚好挑在最不方便的时候来。
He happened to choose the most difficult of times to visit me.

实在太糟了。”
It's just too bad.”

“但是我们周日还是可以出去，对吧？”
“But we could still go out on Sunday, couldn't we?”

印象中我好像没有得到回答，虽然我久久地仰望着漆黑的房间、等着。
I have a feeling I did not receive a reply then, though I lay gazing up into the darkness waiting.

辛苦地工作了一天之后，二郎总是很累，不想说话。
Jiro was often tired after a day's work and not in the mood for conversation.

不管怎样，看来我是瞎操心绪方先生了，因为那次是他待得最久的一次。
In any case, it seems I was worrying unduly about Ogata-San, for his visit that summer turned out to be one of his lengthiest.

我记得佐知子来敲门的那天晚上他还在。
I remember he was still with us that night Sachiko knocked on our apartment door.

佐知子穿着一件我之前从没见过的裙子，肩膀上披着一条围巾。
She was wearing a dress I had never seen before, and there was a shawl wrapped around her shoulders.

脸上仔仔细细地化了妆，但是有一小撮头发松了，垂到了脸上。
Her face had been carefully made up, but a thin strand of hair had come loose and was hanging over her cheek.

“很抱歉打扰你，悦子，”她笑着说。
“I'm sorry to disturb you, Etsuko,” she said, smiling.

“我在想万里子是不是在这里。”
“I was wondering if by any chance Mariko was here.”

“万里子？
“Mariko?

怎么了，没有啊。”
Why, no.”

“哦，没关系。
“Well, never mind.

你没有见到过她？”
You haven't seen her at all?”

“抱歉，没有。
“I'm afraid not.

她丢了？”
You've lost her?”

“不是的，”她笑了笑，说，“只是我回去时她不在屋子里，没别的。
“There's no need to look like that,” she said, with a laugh. “It's just that she wasn't in the cottage when I got back, that's all.

我肯定我很快就能找到她。”
I'm sure I'll find her very soon.”

我们在玄关那里说话，我突然发觉二郎和绪方先生在看这边，就介绍了佐知子。
We were talking at the entryway, and I became aware of Jiro and Ogata-San looking towards us.

他们相互鞠了躬。
I introduced Sachiko, and they all bowed to each other.

“真让人担心，”绪方先生说。
“This is worrying,” Ogata-San said.

“也许我们最好马上打电话给警察。”
“Perhaps we'd better phone the police straight away.”

“没这个必要，”佐知子说。
“There's no need for that,” said Sachiko.

“我肯定我会找到她的。”
“I'm sure I'll find her.”

“可是也许安全起见，还是打一下好。”
“But perhaps it's best to be safe and phone anyway.”

“真的不用”——佐知子的声音里有一丝生气——“没有必要。
“No really” — a slight hint of irritation had entered Sachiko's voice — “there's no need.

我肯定我会找到她的。”
I'm sure I'll find her.”

“我帮你找，”我边说边穿上外套。
“I'll help you look for her,” I said, starting to put on my jacket.

我丈夫不满地看着我，好像要说什么，但又没说。
My husband looked at me disapprovingly. He seemed about to speak, but then stopped himself.

最后，他说：“天快黑了。”
In the end, he said: “It's almost dark now.”

“真的，悦子，不必这么大惊小怪的，”佐知子说。
“Really, Etsuko, there's no need to make such a fuss,” Sachiko was saying.

“不过要是你不介意出来一下的话，我感激不尽。”
“But if you don't mind coming out for a minute, I'll be most grateful.”

“要小心，悦子，”绪方先生说。
“Take care, Etsuko,” Ogata-San said.

“要是没有很快找到孩子，就给警察打电话。”
“And phone the police if you don't find the child soon.”

我们下了楼。
We descended the flight of stairs.

外面热气还未散尽，空地那头，太阳落得低低的，照亮了泥泞的水沟。
Outside it was still warm, and across the wasteground the sun had sunk very low, highlighting the muddy furrows.

“公寓这一带你找了吗？”
“Have you looked around the housing precinct?”

我问。
I asked.

“没有，还没有。”
“No, not yet.”

“那我们找找看吧。”
“Let's look then.”

我开始加快步子。
I began to walk rapidly.

“万里子可能待在什么朋友家吗？”
“Does Mariko have friends she may be with?”

“我想不可能。
“I don't think so.

真的，悦子”——佐知子笑了笑，拉住我的胳膊——“没必要这么慌张。
Really, Etsuko” — Sachiko laughed and put a hand on my arm — “there's no need to be so alarmed.

她不会有事的。
Nothing will have happened to her.

其实，悦子，我来找你是想告诉你一些事情。
In fact, Etsuko, I really came round because I wanted to tell you some news.

你瞧，事情终于定下来了。
You see, it's all been settled at last.

我们过几天就要去美国了。”
We're leaving for America within the next few days.”

“美国？”
“America?”

也许是因为佐知子抓住我的胳膊，也许是因为吃惊，我停住了脚步。
Perhaps because of Sachiko's hand on my arm, perhaps out of sheer surprise, I stopped walking.

“对，美国。
“Yes, America.

你肯定没听说过这么个地方。”
You've no doubt heard of such a place.”

看到我吃惊她好像很开心。
She seemed pleased at my astonishment.

我又走了起来。
I began to walk again.

公寓楼这一带都是水泥路，偶尔会遇见几棵细细的小树，是楼盖好了以后种的。
Our precinct was an expanse of paved concrete, interrupted occasionally by thin young trees planted when the buildings had gone up.

头顶上，大部分窗户的灯都亮了。
Above us, lights had come on in most of the windows.

“你不再问我别的了吗？”
“Aren't you going to ask me anything more?”

佐知子追上我，说。
Sachiko said, catching up with me.

“你不问我为什么要去？
“Aren't you going to ask me why I'm going?

要和谁去？”
And who I'm going with?”

“若这是你想要的，那我真替你高兴，”我说。
“I'm very glad if this is what you wanted,” I said.

“可是也许我们应该先找到您的女儿。”
“But perhaps we should find your daughter first.”

“悦子，你得明白，我没有什么丢脸的。
“Etsuko, you must understand, there's nothing I'm ashamed of.

我没有什么好隐瞒的。
There's nothing I want to hide from anyone.

请你问些你想知道的事吧，我不觉得丢脸。”
Please ask me anything you want, I'm not ashamed.”

“我想也许我们应该先找到您的女儿。
“I thought perhaps we should find your daughter first.

我们可以以后再说。”
We can talk later.”

“好吧，悦子，”她笑了笑，说。
“Very well, Etsuko,” she said, with a laugh.

“我们先找万里子吧。”
“Let's find Mariko first.”

我们找了孩子们玩耍的地方，看了每一栋公寓楼，很快发现我们回到了原来的地方。
We searched the playing areas and walked around each of the apartment blocks. Soon we found ourselves back where we had started.

突然，我看见其中一栋公寓的主入口有两个女人在说话。
Then I spotted two women talking by the main entrance to one of the apartment blocks.

“那里的两位太太也许能帮我们，”我说。
“Perhaps those ladies over there could help us,” I said.

佐知子没有动。
Sachiko did not move.

她朝她们看了看，说道：“我不觉得。”
She looked over towards the two women, then said: “I doubt it.”

“但是她们可能见过她。
“But they may have seen her.

她们可能见过您的女儿。”
They may have seen your daughter.”

佐知子还是看着她们。
Sachiko continued to look at the women.

然后她冷笑一声，耸耸肩，说：“好吧，我们去给她们一些嚼舌根的东西吧。
Then she gave a short laugh and shrugged. “Very well,” she said. “Let's give them something to gossip about.

我不在乎。”
It's no concern of mine.”

我们走过去，佐知子礼貌又镇静地问了她们。
We walked over to them and Sachiko politely and calmly made her enquiries.

两位太太交换了关切的眼神，但是她们都没有看见小女孩。
The women exchanged concerned looks, but neither had seen the little girl.

佐知子请她们放心，没什么可担心的，我们就离开了。
Sachiko assured them there was no cause for alarm, and we took our leave.

“我肯定这下她们高兴了，”她对我说。
“I'm sure that made their day,” she said to me.

“现在她们有东西可聊了。”
“Now they'll have something to talk about.”

“我相信她们肯定没有恶意。
“I'm sure they had no malicious thoughts whatsoever.

她们看上去都是真的很关心。”
They both seemed genuinely concerned.”

“你真好，悦子，不过不必跟我说这些。
“You're so kind, Etsuko, but there's really no need to convince me of such things.

我从来不在乎她们那样的人想什么，现在我更不在乎了。”
You see, it's never been any concern to me what people like that thought, and I care even less now.”

我们停住脚步。
We stopped walking.

我看了看四周，又望望公寓的窗户。
I threw a glance around me, and up at the apartment windows.

“她会在哪儿呢？”
“Where else could she be?”

我说。
I said.

“你瞧，悦子，我没有什么丢脸的。
“You see, Etsuko, there's nothing I'm ashamed of.

我没有什么好瞒着你的。
There's nothing I want to hide from you.

或者是瞒着那些女人。”
Or from those women, for that matter.”

“你想我们要不要到河边找一找？”
“Do you think we should search by the river?”

“河边？
“The river?

哦，我已经找过了。”
Oh, I've looked along there.”

“那另一边呢？
“What about the other side?

她可能到对面去了。”
Perhaps she's over on the other side.”

“我想不会，悦子。
“I doubt it, Etsuko.

其实，要是我没猜错的话，她现在已经回去了。
In fact, if I know my daughter, she'll be back at the cottage at this very moment.

大概还很高兴自己惹了这些麻烦。”
Probably rather pleased with herself to have caused this fuss.”

“那我们去看看。”
“Well, let's go and see.”

我们回到空地边，太阳已经落到河的下面去了，只能看见河边柳树的轮廓。
When we came back to the edge of the wasteground, the sun was disappearing behind the river, silhouetting the willow trees along the bank.

“你不用跟着我，”佐知子说。
“There's no need for you to come with me,” Sachiko said.

“我很快就会找到她了。”
“I'll find her in good time.”

“没关系。
“It's all right.

我和你一起去。”
I'll come with you.”

“那好吧。
“Very well then.

一起走吧。”
Come with me.”

我们朝小屋走去。
We began walking towards the cottage.

地上凹凸不平，我只穿着木屐，很难走。
I was wearing sandals and found it hard going on the uneven earth.

“你出去了多久？”
“How long were you out?”

我问。
I asked.

佐知子在我前面一两步；她没有回答，我想她可能没有听到，又问了一遍：“你出去了多久？”
Sachiko was a pace or two ahead of me; she did not reply at first, and I thought possibly she had not heard me. “How long were you out?” I repeated.

“哦，不太久。”
“Oh, not long.”

“是多久？
“How long?

半小时？
Half an hour?

不止？”
Longer?”

“我想大概三四个钟头。”
“About three or four hours, I suppose.”

“我知道了。”
“I see.”

我们一路穿过泥地，尽量当心不踩到臭水坑。
We continued our way across the muddy ground, doing our best to avoid any puddles.

快到小屋时，我说：“也许我们应该到对面看一看，以防万一。”
As we approached the cottage, I said: “Perhaps we should look over on the other side, just in case.”

“树林里？
“The woods?

我女儿不会在那里的。
My daughter wouldn't be over there.

我们进屋去看看吧。
Let's go and look in the cottage.

没必要这么担心，悦子。”
There's no need to look so worried, Etsuko.”

她又笑了笑，但是我觉得她的笑声里有丝丝的颤抖。
She laughed again, but I thought her voice wobbled a little as she did so.

屋里没有电灯，一片漆黑。
The cottage, having no electricity, was in darkness.

我在玄关等着，佐知子进屋去。
I waited in the entryway while Sachiko stepped up to the tatami.

她叫她女儿的名字，打开连着主室的两个小房间的拉门。
She called her daughter's name and slid back the partitions to the two smaller rooms that adjoined the main one.

我站在玄关，听着她在黑暗里来回走动，然后她回到玄关。
I stood listening to her moving around in the darkness, then she came back to the entryway.

“也许你是对的，”她说。
“Perhaps you're right,” she said.

“我们最好到对面看看。”
“We'd better look on the other bank.”

河边的半空中有很多小虫子。
Along the river the air was full of insects.

我们静静地朝下游的小木桥走去。
We walked in silence, towards the small wooden bridge further downstream.

走过木桥，对岸就是之前佐知子提到的树林。
Beyond it, on the opposite bank, were the woods Sachiko had mentioned earlier.

我们正走在桥上，佐知子突然转向我，飞快地说道：“我们最后去了酒吧。
We were crossing the bridge, when Sachiko turned to me and said rapidly: “We went to a bar in the end.

我们本来是要去看电影的，加里·库珀演的，可是排队的人太多了。
We were going to go to the cinema, to a film with Gary Cooper, but there was a long queue.

城里很挤，又有很多喝醉酒的。
The town was very crowded and a lot of people were drunk.

最后我们去了酒吧，他们给了我们单独的一间小房间。”
We went to a bar in the end and they gave us a little room to ourselves.”

“我知道了。”
“I see.”

“我想你没有去过酒吧吧，悦子？”
“I suppose you don't go to bars, do you, Etsuko?”

“没有，没去过。”
“No, I don't.”

那是我第一次到河对岸去。脚下的泥土很软，甚至感觉要陷下去。
That was the first time I had crossed to the far side of the river. The ground felt soft, almost marshy under my feet.

这也许只是我的想象，但是那时我在河边觉得凉飕飕的，很不自在，像是感觉到有事要发生。我重新加快脚步，朝前面漆黑的树林走去。
Perhaps it is just my fancy that I felt a cold touch of unease there on that bank, a feeling not unlike premonition, which caused me to walk with renewed urgency towards the darkness of the trees before us.

佐知子拉住我的胳膊不让我往前走。
Sachiko stopped me, grasping my arm.

我顺着她的目光看见河边草地上离河很近的地方躺着一捆什么东西。
Following her gaze, I could see a short way along the bank something like a bundle lying on the grass, close to the river's edge.

模模糊糊地看不清楚，只看见地上有一团比周围草地颜色深的黑影。
It was just discernible in the gloom, a few shades darker than the ground around it.

我的第一反应是要冲过去，却发现佐知子还呆呆地站着，盯着那团东西看。
My first impulse was to run towards it, but then I realized Sachiko was standing quite still, gazing towards the object.

“那是什么？”
“What is it?”

我傻乎乎地问。
I said, rather stupidly.

“是万里子，”她静静地说。
“It's Mariko,” she said, quietly.

当她转过头来看着我时，眼睛里有一种异样的神情。
And when she turned to me there was a strange look in her eyes.

# 第一部 · 第三章 | PART ONE · Chapter Three

也许随着时间的推移，我对这些事情的记忆已经模糊，事情可能不是我记得的这个样子。
It is possible that my memory of these events will have grown hazy with time, that things did not happen in quite the way they come back to me today.

但是我清楚地记得有一个神秘的咒语把我们两个定住了。天越来越暗，我们呆呆地站在原地，盯着远处河边的那个影子。
But I remember with some distinctness that eerie spell which seemed to bind the two of us as we stood there in the coming darkness looking towards that shape further down the bank.

突然间，咒语解除了，我们两个都跑了起来。跑近时，我看见万里子缩成一团侧躺着，背对着我们。
Then the spell broke and we both began to run. As we came nearer, I saw Mariko lying curled on her side, knees hunched, her back towards us.

佐知子比我早一点到那里，我怀着孕，行动不方便，等我到时，佐知子已经站在孩子身边了。
Sachiko reached the spot a little ahead of me, I being slowed by my pregnancy, and she was standing over the child when I joined her.

万里子的眼睛睁着，一开始我还以为她死了。
Mariko's eyes were open and at first I thought she was dead.

但是后来我看见她的眼睛动了，用奇怪的、空洞的眼神盯着我们。
But then I saw them move and they stared up at us with a peculiar blankness.

佐知子单腿跪下，扶起孩子的头。
Sachiko dropped on to one knee and lifted the child's head.

万里子还是那么盯着。
Mariko continued to stare.

“你没事吧，万里子？”
“Mariko-San, are you all right?”

我有点上气不接下气地说到。
I said, a little out of breath.

她没有回答。
She did not reply.

佐知子也不做声，检查着她的女儿，把她在怀里翻来翻去，好像她是一个易碎的、没有感觉的洋娃娃。
Sachiko too was silent, examining her daughter, turning her in her arms as if she were a fragile, but senseless doll.

我发现佐知子的袖子上有血，再一看，是万里子身上来的。
I noticed the blood on Sachiko's sleeve, then saw it was coming from Mariko.

“我们最好叫人，”我说。
“We'd better call someone,” I said.

“不严重，”佐知子说。
“It's not serious,” Sachiko said.

“只是擦伤。
“It's just a graze.

看，伤口不大。”
See, it's just a small cut.”

万里子躺在水沟里，短裙有一面浸在黑色的水里。
Mariko had been lying in a puddle and one side of her short dress was soaked in dark water.

血从她大腿内侧的伤口流出来。
The blood was coming from a wound on the inside of her thigh.

“怎么了？”
“What happened?”

佐知子问她女儿。
Sachiko said to her daughter.

“出什么事了？”
“What happened to you?”

万里子还是盯着她妈妈看。
Mariko went on looking at her mother.

“她可能吓着了，”我说。
“She's probably shocked,” I said.

“现在最好别问她问题。”
“Perhaps it's best not to question her immediately.”

佐知子扶万里子站了起来。
Sachiko brought Mariko to her feet.

“我们很担心你，万里子，”我说。
“We were very worried about you, Mariko-San,” I said.

小女孩狐疑地看了我一眼，转过去，走了起来。
The little girl gave me a suspicious look, then turned away and started to walk.

她走得很稳；腿上的伤看来并无大碍。
She walked quite steadily; the wound on her leg did not seem to trouble her unduly.

我们往回走，过了木桥，沿着河边走。
We walked back over the bridge and along the river.

她们两个走在我前面，没有说话。
The two of them walked in front of me, not talking.

我们回到小屋时，天已经全黑了。
It was completely dark by the time we reached the cottage.

佐知子把万里子带进浴室。
Sachiko took Mariko into the bathroom.

我点燃主室中间的炉子泡茶。
I lit the stove in the centre of the main room to make some tea.

除了炉子，刚才佐知子点亮的一盏吊着的旧灯笼是屋子里唯一的亮光，屋里大部分地方都还是漆黑一片。
Aside from the stove, an old hanging lantern Sachiko had lit provided the only source of light, and large areas of the room remained in shadow.

角落里，几只黑色的小猫仔被我们吵醒，开始骚动不安。
In one corner several tiny black kittens aroused by our arrival started to move restlessly.

它们的爪子在榻榻米上发出沙沙的声音。
Their claws, catching in the tatami, made a scuttling noise.

再次出现时，母女两人都换上了和服。
When they appeared again, both mother and daughter had changed into kimonos.

她们进了隔壁的一间小房间，我又等了一会儿。
They went through to one of the small adjoining rooms and I continued to wait for some time.

佐知子的声音透过隔板传了出来。
The sound of Sachiko's voice came through the screen.

最后，佐知子一个人出来了。
Finally, Sachiko came out alone. “It's still very hot,” she remarked.

“还是很热，”她说，走过房间，把通向走廊的拉门打开。
She crossed the room and slid apart the partitions which opened out on to the veranda.

“她怎么样了？”
“How is she?”

我问。
I asked.

“她没事。
“She's all right.

伤口没什么。”
The cut's nothing.”

佐知子在拉门旁坐下来吹风。
Sachiko sat down in the breeze, next to the partitions.

“我们要不要把这件事报告警察？”
“Shall we report the matter to the police?”

“警察？
“The police?

要报告什么呢？
But what is there to report?

万里子说她爬树，结果摔倒了，弄了那个伤。”
Mariko says she was climbing a tree and fell. That's how she got her cut.”

“这么说她今天晚上没有和什么人在一起？”
“So she wasn't with anyone tonight?”

“没有。她能和谁在一起呢？”
“No. Who could she have been with?”

“那个女人？”
“And what about this woman?”

我说。
I said.

“哪个女人？”
“What woman?”

“万里子说的那个女人。
“This woman Mariko talks about.

你现在还认为是她编出来的吗？”
Are you still certain she's imaginary?”

佐知子叹了口气。
Sachiko sighed.

“我想不完全是编的，”她说。
“She's not entirely imaginary, I suppose,” she said.

“是万里子以前见过的一个人。
“She's just someone Mariko saw once.

以前，她还很小的时候。”
Once, when she was much younger.”

“可是这个女人今晚会不会在这里呢？”
“But do you think she could have been here tonight, this woman?”

佐知子笑了笑。
Sachiko gave a laugh.

“不会的，悦子，不可能。
“No, Etsuko, that's quite impossible.

不管怎么说，那个女人已经死了。
In any case, that woman's dead.

相信我，悦子，说什么有个女人，都是万里子发难时的小把戏。
Believe me, Etsuko, all this about a woman, it's just a little game Mariko likes to play when she means to be difficult.

我已经很习惯她这些小把戏了。”
I've grown quite used to these little games of hers.”

“可是她为什么要编这些故事呢？”
“But why should she tell stories like that?”

“为什么？”
“Why?”

佐知子耸了耸肩。
Sachiko shrugged.

“小孩子就喜欢做这些。
“It's just what children like to do.

悦子，你自己当了妈妈以后也要习惯这些事情。”
Once you become a mother, Etsuko, you'll need to get used to such things.”

“你肯定她今天晚上没有和什么人在一起？”
“You're sure she was with no one tonight?”

“很肯定。
“Quite sure.

我很了解自己的女儿。”
I know my own daughter well enough.”

我们都不说话了。
We fell silent for a moment.

蚊子在我们周围嗡嗡叫。
Mosquitoes were humming in the air around us.

佐知子用手掩住嘴打了个哈欠。
Sachiko gave a yawn, covering her mouth with a hand.

“你瞧，悦子，”她说，“我很快就要离开日本了。
“So you see, Etsuko,” she said, “I'll be leaving Japan very shortly.

你好像不是很在意。”
You don't seem very impressed.”

“我当然在意了。
“Of course I am.

而且我很高兴，要是这是你所向往的。
And I'm very pleased, if this is what you wished.

不过不会遇到……很多困难吗？”
But won't there be … various difficulties?”

“困难？”
“Difficulties?”

“我是指，搬到另一个国家，语言、习惯都不同。”
“I mean, moving to a different country, with a different language and foreign ways.”

“我明白你的意思，悦子。
“I understand your concern, Etsuko.

但是说真的，我不觉得有什么可担心的。
But really, I don't think there's much for me to worry about.

你瞧，我听说过很多有关美国的事，对美国并不完全陌生。
You see, I've heard so much about America, it won't be like an entirely foreign country.

至于语言嘛，我已经会说很多了。
And as for the language, I already speak it to a certain extent.

我和弗兰克都说英语。
Frank-San and I, we always talk in English.

我在美国住一阵子后，就能像美国女人一样说话了。
Once I've been in America for a little while, I should speak it like an American woman.

我真的不觉得有什么可担心的。
I really don't see there's any cause for me to be worrying.

我知道我能行。”
I know I'll manage.”

我微微鞠了一躬，但没说什么。
I gave a small bow, but said nothing.

两只小猫朝佐知子坐的地方走来。
Two of the kittens began making their way towards where Sachiko was sitting.

她看了它们一会儿，然后笑了笑。
She watched them for a moment, then gave a laugh.

“当然了，”她说，“有时我也在想事情会怎么样呢。
“Of course,” she said, “I sometimes have moments when I wonder how everything will turn out.

但是真的”——她对我笑了笑——“我知道我能行。”
But really” — she smiled at me — “I know I'll manage.”

“其实，”我说，“我担心的是万里子。
“Actually,” I said, “it was Mariko I had in mind.

她会怎么样呢？”
What will become of her?”

“万里子？
“Mariko?

哦，她没问题的。
Oh, she'll be fine.

你了解小孩子。
You know how children are.

他们比大人更能适应新环境，不是吗？”
They find it so much easier to settle into new surroundings, don't they?”

“不过对她来说仍是个很大的变化。
“But it would still be an enormous change for her.

她准备好了吗？”
Is she ready for such a thing?”

佐知子不耐烦地叹了口气。
Sachiko sighed impatiently.

“说真的，悦子，你觉得我难道没有考虑过这些吗？
“Really, Etsuko, did you think I hadn't considered all this?

你以为我决定要离开这个国家前没有首先考虑女儿的利益吗？”
Did you suppose I would decide to leave the country without having first given the most careful consideration to my daughter's welfare?”

“当然，”我说，“你一定会仔仔细细地考虑。”
“Naturally,” I said, “you'd give it the most careful consideration.”

“对我来说，女儿的利益是最重要的，悦子。
“My daughter's welfare is of the utmost importance to me, Etsuko.

我不会做出有损她的未来的决定。
I wouldn't make any decision that jeopardized her future.

我已经仔细地考虑过了整件事情，我也和弗兰克商量过了。
I've given the whole matter much consideration, and I've discussed it with Frank.

我向你保证，万里子没事的。
I assure you, Mariko will be fine.

不会有问题的。”
There'll be no problems.”

“可是她的学习呢，会怎么样呢？”
“But her education, what will become of that?”

佐知子又笑了。
Sachiko laughed again.

“悦子，我又不是要到深山老林去。
“Etsuko, I'm not about to leave for the jungle.

美国有学校。
There are such things as schools in America.

而且你要明白，我的女儿非常聪明。
And you must understand, my daughter is a very bright child.

她爸爸出身名门，我这边也是，我的亲戚都是很有地位的人。
Her father was an accomplished man, and on my side too, there were relatives of the highest rank.

悦子，你不能因为……因为眼前的事物就认为她是什么贫农的孩子。”
You mustn't suppose, Etsuko, simply because you've seen her in these … in these present surroundings, that she's some peasant's child.”

“没有。
“Of course not.

我从来没有……”
I didn't for one moment …”

“她很聪明。
“She's a very bright child.

你没有见过她真正的样子，悦子。
You haven't seen her as she really is, Etsuko.

在眼前这种环境里，小孩子自然有时有点笨拙。
In surroundings like this, you can only expect a child to prove a little awkward at times.

但你要是在我伯父的家里头看见她，你就会发现她真正的品质。
But if you'd seen her while we were at my uncle's house, you'd have seen her true qualities then.

大人跟她说话时，她回答得清楚、流利，不会像很多小孩子那样傻笑或者扭扭捏捏。
If an adult addressed her, she'd answer back very clearly and intelligently, there'd be none of this giggling and shying away like most other children.

而且绝没有这些小把戏。
And there were certainly none of these little games of hers.

她去上学，跟最优秀的孩子交朋友。
She went to school, and made friends with the best kinds of children.

我们还给她请了一位家庭教师，老师对她的评价很高。
And we had a private tutor for her, and he praised her very highly.

她这么快就能赶上真是叫人吃惊。”
It was astonishing how quickly she began to catch up.”

“赶上？”
“To catch up?”

“这个”——佐知子耸耸肩——“很不幸，万里子的学习总是时不时地被打断。
“Well” — Sachiko gave a shrug — “it's unfortunate that Mariko's education's had to be interrupted from time to time.

这个事，那个事，我们又经常搬家。
What with one thing and another, and our moving around so much.

但是我们现在比较困难，悦子。
But these are difficult times we've come through, Etsuko.

要不是战争，要是我丈夫还活着，万里子就能过上我们这种地位的家庭应有的生活。”
If it wasn't for the war, if my husband was still alive, then Mariko would have had the kind of up-bringing appropriate to a family of our position.”

“是的，”我说。
“Yes,” I said.

“没错。”
“Indeed.”

佐知子可能是听出我的语气不大对，抬起头来看着我。当她往下说时，语气变紧了。
Perhaps Sachiko had caught something in my tone; she looked up and stared at me, and when she spoke again, her voice had become more tense.

“我不用离开东京的。悦子，”她说。
“I didn't need to leave Tokyo, Etsuko,” she said.

“但是我离开了，为了万里子。我大老远地来我伯父家住，是因为我认为这样对我女儿最好。
“But I did, for Mariko's sake. I came all this way to stay at my uncle's house, because I thought it would be best for my daughter.

我本来不用这么做的，我根本用不着离开东京。”
I didn't have to do that, I didn't need to leave Tokyo at all.”

我鞠了一躬。
I gave a bow.

佐知子看了我一会儿，然后转头凝视着屋外漆黑的一片。
Sachiko looked at me for a moment, then turned and gazed out through the open partitions, out into the darkness.

“可是如今你离开了你伯父家，”我说。
“But you've left your uncle now,” I said.

“现在又即将要离开日本。”
“And now you're about to leave Japan.”

佐知子生气地看着我。
Sachiko glared at me angrily.

“你为什么这么说话呢，悦子？
“Why do you speak to me like this, Etsuko?

你为什么不能祝福我呢？
Why is it you can't wish me well?

就因为你妒忌？”
Is it simply that you're envious?”

“我是祝福你的。
“But I do wish you well.

而且我向你保证我……”
And I assure you I …”

“万里子在美国会过得很好的，你为什么不肯相信？
“Mariko will be fine in America, why won't you believe that?

那里更适合孩子的成长。
It's a better place for a child to grow up.

在那里她的机会更多，在美国女人的生活要好得多。”
And she'll have far more opportunities there, life's much better for a woman in America.”

“我向你保证我替你高兴。
“I assure you I'm happy for you.

至于我自己，我再心满意足不过了。
As for myself, I couldn't be happier with things as they are.

二郎的工作很顺利，现在又在我们想要的时候有了孩子……”
Jiro's work is going so well, and now the child arriving just when we wanted it …”

“她可以成为女商人，甚至是女演员。
“She could become a business girl, a film actress even.

这就是美国，悦子，什么事情都有可能。
America's like that, Etsuko, so many things are possible.

弗兰克说我也有可能成为女商人。
Frank says I could become a business woman too.

在那里这些事情都有可能发生。”
Such things are possible out there.”

“我相信。
“I'm sure they are.

只是就我而言，我对我现在的生活非常满意。”
It's just that personally, I'm very happy with my life where I am.”

佐知子看着那两只小猫在她身旁的榻榻米上乱抓。
Sachiko gazed at the two small kittens, clawing at the tatami beside her.

有几分钟我们两个都没有说话。
For several moments we were silent.

“我得回去了，”我打破沉默。
“I must be getting back,” I said, eventually.

“他们要担心我了。”
“They'll be getting worried about me.”

我站起来，可是佐知子仍然看着那两只小猫。
I rose to my feet, but Sachiko did not take her eyes off the kittens.

“你们什么时候离开？”
“When is it you leave?”

我问。
I asked.

“这几天。
“Within the next few days.

弗兰克会开车来接我们。
Frank will come and get us in his car.

周末我们就会坐上船了。”
We should be on a ship by the end of the week.”

“那么我想你不会再去给藤原太太帮忙了吧。”
“I take it then you won't be helping Mrs Fujiwara much longer.”

佐知子抬起头来看我，冷笑道：“悦子，我要去美国了。
Sachiko looked up at me with a short incredulous laugh. “Etsuko, I'm about to go to America.

我不再需要到面店工作了。”
There's no need for me to work any more in a noodle shop.”

“我知道了。”
“I see.”

“其实，悦子，要请你转告藤原太太。
“In fact, Etsuko, perhaps you'd care to tell Mrs Fujiwara what's happened to me.

我不会再见到她了。”
I don't expect to be seeing her again.”

“你不自己跟她说吗？”
“Won't you tell her yourself?”

她不耐烦地叹了口气。
She sighed impatiently.

“悦子，难道你不能体会对我这样的人来说每天在面店里工作有多讨厌吗？
“Etsuko, can't you appreciate how loathsome it's been for someone such as myself to work each day in a noodle shop?

不过我不抱怨，要我做什么，我就做什么。
But I didn't complain and I did what was required of me.

但是现在都结束了，我不想再见到那个地方了。”
But now it's over, I've no great wish to see that place again.”

一只小猫在抓佐知子和服的袖子。
A kitten had been clawing at the sleeve of Sachiko's kimono.

佐知子用手背重重地拍了它一下，小家伙急忙往回跑过榻榻米。
She gave it a sharp slap with the back of her hand and the little creature went scurrying back across the tatami.

“所以请向藤原太太转达我对她的问候，”她说。
“So please give my regards to Mrs Fujiwara,” she said.

“也祝她生意兴隆。”
“And my best wishes for her trade.”

“我会的。
“I'll do that.

现在请原谅，我得走了。”
Now please excuse me, I must go.”

这次，佐知子站起来，送我到玄关。
This time, Sachiko got to her feet and accompanied me to the entryway.

“我们离开前我会去道别的，”我穿鞋时她说。
“I'll come and say goodbye before we leave,” she said, as I was putting on my sandals.

一开始这好像只是一个很普通的梦；我梦见了前一天看见的事——我们看见一个小女孩在公园里玩。
At first it had seemed a perfectly innocent dream; I had merely dreamt of something I had seen the previous day — the little girl we had watched playing in the park.

第二天晚上，我又做了同样的梦。
And then the dream came back the following night.

其实，这几个月里，我做了几次这样的梦。
Indeed, over the past few months, it has returned to me several times.

那天下午，我和妮基到村子里去时，看见小女孩在玩秋千。
Niki and I had watched the girl playing on the swings the afternoon we had walked into the village.

那是妮基来的第三天，雨小了，变成毛毛细雨。
It was the third day of Niki's visit and the rain had eased to a drizzle.

我有几天没有出门了，走在蜿蜒的小路上，户外的空气令我神清气爽。
I had not been out of the house for several days and enjoyed the feel of the air as we stepped into the winding lane outside.

妮基走得很快，每走一步，窄窄的皮靴子都咯咯响。
Niki tended to walk rather fast, her narrow leather boots creaking with each stride.

虽然我也可以走得很快，但是我更喜欢慢慢走。
Although I found it no trouble keeping up with her, I would have preferred a more leisurely pace.

妮基，我认为，应该懂得走路本身的快乐。
Niki, one supposes, has yet to learn the pleasures of walking for its own sake.

再者，虽然她在这里长大，却体会不到乡下给人的感觉。
Neither does she seem sensitive to the feel of the countryside despite having grown up here.

我们边走，我边把我的想法原原本本地说给她听。她反驳说这里不是真正的乡下，只是迎合住在这里的有钱人的一种居住模式。
I said as much to her as we walked, and she retorted that this was not the real countryside, just a residential version to cater for the wealthy people who lived here.

我想她说得对；我一直没敢到英国北部的农业区去，妮基说，那里才是真正的乡下。
I dare say she is right; I have never ventured north to the agricultural areas of England where, Niki insists, I will find the real countryside.

尽管如此，这些年来，我越来越喜欢这些小路带来的平静和安详。
Nevertheless, there is a calm and quietness about these lanes I have come to appreciate over the years.

到村子后，我带妮基去我有时光顾的茶馆。
When we arrived at the village I took Niki to the tea shop where I sometimes go.

村子不大，只有几间旅馆和商店；茶馆开在街角，在一家面包店楼上。
The village is small, just a few hotels and shops; the tea shop is on a street corner, upstairs above a bakery.

那天下午，妮基和我坐在靠窗的桌子，我们就是从那里看见小女孩在底下的公园玩。
That afternoon, Niki and I sat at a table next to the windows, and it was from there we watched the little girl playing in the park below.

我们看见她爬上一个秋千，朝坐在旁边长椅上的两个女人喊。
As we watched, she climbed on to a swing and called out towards two women sitting together on a bench nearby.

她是个活泼可爱的小女孩，穿着绿色橡胶雨衣和小橡胶雨靴。
She was a cheerful little girl, dressed in a green mackintosh and small Wellington boots.

“也许你很快就会结婚生孩子，”我说。
“Perhaps you'll get married and have children soon,” I said.

“我怀念小孩子。”
“I miss little children.”

“这是我最不想做的事了，”妮基说。
“I can't think of anything I'd like less,” said Niki.

“好吧，我想你还太年轻。”
“Well, I suppose you're still rather young.”

“这和年不年轻没关系。
“It's nothing to do with how young or old I am.

我就是不喜欢一群小孩子在你旁边大喊大叫。”
I just don't feel like having a lot of kids screaming around me.”

“别担心，妮基，”我笑了，说。
“Don't worry, Niki,” I said, with a laugh.

“我不是在强迫你生孩子。
“I wasn't insisting you became a mother just yet.

我刚刚突然心血来潮想当外婆，没别的。
I had this passing fancy just now to be a grandmother, that's all.

我想也许你能让我当上外婆，不过这事不急。”
I thought perhaps you'd oblige, but it can wait.”

小女孩站在秋千上，拼命拉链子，可是不知怎么，就是没办法让秋千荡得更高。
The little girl, standing on the seat of the swing, was pulling hard on the chains, but somehow she could not make the swing go higher.

但是她仍旧笑着，又朝那两个女人喊。
She smiled anyway and called out again to the women.

“我的一个朋友刚生了孩子，”妮基说。
“A friend of mine's just had a baby,” Niki said.

“她高兴得不得了。
“She's really pleased.

我真不明白。
I can't think why.

那小东西乱喊乱叫的。”
Horrible screaming thing she's produced.”

“至少她很开心。
“Well, at least she's happy.

你的朋友几岁？”
How old is your friend?”

“十九岁。”
“Nineteen.”

“十九岁？
“Nineteen?

比你还小。
She's even younger than you are.

她结婚了吗？”
Is she married?”

“没有。这有什么差别？”
“No. What difference does that make?”

“可是这样子她肯定不高兴。”
“But surely she can't be happy about it.”

“为什么不高兴？
“Why not?

就因为她没结婚？”
Just because she isn't married?”

“是的。
“There's that.

还有她才十九岁。
And the fact that she's only nineteen.

我不敢相信这样她会高兴。”
I can't believe she was happy about it.”

“她结没结婚有什么差别？
“What difference does it make whether she's married?

她想要孩子，所有的事情都是她计划好的。”
She wanted it, she planned it and everything.”

“她告诉你的？”
“Is that what she told you?”

“可是，妈妈，我了解她，她是我的朋友。
“But, Mother, I know her, she's a friend of mine.

我知道她想要孩子。”
I know she wanted it.”

长椅上的女人站了起来。
The women on the bench got to their feet.

其中一个喊那个女孩子。
One of them called to the little girl.

小女孩从秋千上下来，跑向她们。
She came off the swing and went running towards the women.

“那孩子的父亲呢？”
“And what about the father?”

我问。
I asked.

“他也很高兴。
“He was happy about it too.

我记得当他们发现他们有孩子了，我们全都出去庆祝。”
I remember when they first found out. We all went out to celebrate.”

“可是人们总是假装高兴的样子。
“But people always pretend to be delighted.

就像昨天晚上我们在电视上看的那部电影。”
It's like that film we saw on the television last night.”

“什么电影？”
“What film?”

“我想你没有在看。
“I expect you weren't watching it.

你在看你的杂志。”
You were reading your magazine.”

“哦那个。
“Oh that.

那电影很烂。”
It looked awful.”

“是很烂。
“It certainly was.

但我就是这个意思。
But that's what I mean.

我肯定没有人在知道有孩子时会像电影里的人那样。”
I'm sure nobody ever receives the news of a baby like these people do in these films.”

“说真的，妈妈，我真不知道你怎么能坐得住看那种垃圾。
“Honestly, Mother, I don't know how you can sit and watch rubbish like that.

你以前都不习惯看电视。
You hardly used to watch television at all.

我记得以前我电视看太多，你总是叫我把电视关掉。”
I remember you used to keep telling me off because I watched it so much.”

我笑了。
I laughed.

“你瞧，我们的角色变了，妮基。
“You see how our roles are reversing, Niki.

我相信你是为我好。
I'm sure you're very good for me.

你一定不能让我像那样浪费时间。”
You must stop me wasting my time away like that.”

我们离开茶馆往回走时，空中乌云密布，雨也变大了。
As we made our way back from the tea shop, the sky had clouded over ominously and the drizzle had become heavier.

我们刚走过一个小小的火车站不多远，就听见后面有人喊：“谢林汉姆太太！
We had walked a little way past the small railway station when a voice called from behind us: “Mrs Sheringham!

谢林汉姆太太！”
Mrs Sheringham!”

我回头看见一个穿着大衣的小个子女人正急急地走过来。
I turned and saw a small woman in an overcoat hurrying up the road.

“我猜是你，”她追上我们，说。
“I thought it was you,” she said, catching up with us.

“你最近好吗？”
“And how have you been keeping?”

她给了我一个灿烂的微笑。
She gave me a cheerful smile.

“你好，沃特斯太太，”我说。
“Hello, Mrs Waters,” I said.

“很高兴又见到你。”
“How nice to see you again.”

“看来又是坏天气。
“Seems to have turned all miserable again, hasn't it?

哦，你好，景子”——她碰了碰妮基的袖子——“我没注意是你。”
Why, hello, Keiko” — she touched Niki's sleeve — “I didn't realize it was you.”

“不是，”我急忙说，“这是妮基。”
“No,” I said hurriedly, “this is Niki.”

“妮基，没错。
“Niki, of course.

天啊，你长这么大了，亲爱的。
Good gracious, you've completely grown up, dear.

难怪我弄混了。
That's why I got you muddled.

你长这么大了。”
You've completely grown up.”

“你好，沃特斯太太，”妮基舒了口气，说。
“Hello, Mrs Waters,” Niki said, recovering.

沃特斯太太住在附近。现在我偶尔才见到她，几年前她教我的两个女儿钢琴。
Mrs Waters lives not far from me. These days I see her only very occasionally, but several years ago she had given piano lessons to both my daughters.

她教了景子好几年，而妮基只在小时候教了一年左右。
She had taught Keiko for a number of years, and then Niki for a year or so when she was still a child.

我很快就发现沃特斯太太的钢琴技术有限，而且她对音乐的总的看法也常常让我生气。比如说，她把肖邦和柴可夫斯基的作品都称为“动听的旋律”。
It had not taken me long to see Mrs Waters was a very limited pianist and her attitude to music in general had often irritated me; for instance, she would refer to works by Chopin and Tchaikovsky alike as “charming melodies”.

可是她为人和蔼可亲，我不忍心把她换掉。
But she was such an affectionate woman I never had the heart to replace her.

“你最近怎么样，亲爱的？”她问妮基。
“And what are you doing with yourself these days, dear?” she asked Niki.

“我？
“Me?

哦，我住在伦敦。”
Oh, I live in London.”

“哦，是吗？
“Oh yes?

你在那里干什么呢？
And what are you doing there?

读书？”
Studying?”

“我其实也没干什么。
“I'm not doing anything really.

只是住在那里。”
I just live there.”

“哦，我知道了。
“Oh, I see.

不过你在那里很开心，是吧？
But you're happy there, are you?

这是最主要的，不是吗？”
That's the main thing, isn't it.”

“是的，我很开心。”
“Yes, I'm happy enough.”

“那就好，这是最主要的，不是吗？
“Well, that's the main thing, isn't it.

那景子呢？”
And what about Keiko?”

沃特斯太太转向我。
Mrs Waters turned to me.

“她最近怎么样？”
“How is Keiko getting on now?”

“景子？
“Keiko?

哦，她搬到曼彻斯特去了。”
Oh, she went to live in Manchester.”

“哦，是吗？
“Oh yes?

听说那个城市总的来说还不错。
That's a nice city on the whole. That's what I've heard anyway.

她喜欢那里吗？”
And does she like it up there?”

“我最近没有她的消息。”
“I haven't heard from her recently.”

“哦，好吧。
“Oh well.

我想没有消息就是好消息。
No news is good news, I expect.

景子还弹琴吗？”
And does Keiko still play the piano?”

“我想还弹。
“I expect she does.

我最近都没有她的消息。”
I haven't heard from her recently.”

沃特斯太太终于看出我不想谈论景子，尴尬地笑了笑，放开这个话题。
My lack of enthusiasm seemed finally to penetrate, and she dropped the subject with an awkward laugh.

景子离开家的这几年来，每次遇见我，沃特斯太太总是要问起景子。
Such persistence on her part has characterized our encounters over the years since Keiko's leaving home.

我很明显不想谈论景子，而且到那天下午都还讲不出我女儿在什么地方。但是沃特斯太太从不把这些放在心上。
Neither my evident reluctance to discuss Keiko nor the fact that until that afternoon I had been unable to tell her so much as my daughter's whereabouts had succeeded in making any lasting impression upon her.

很可能以后我们每次见面，沃特斯太太还会笑着向我打听景子的事。
In all probability, Mrs Waters will continue to ask cheerfully after my daughter whenever we happen to meet.

我们到家时，雨一直淅淅沥沥地下着。
By the time we got home, the rain was falling steadily.

“我想我让你丢脸了，对吗？”
“I suppose I embarrassed you, didn't I?”

妮基对我说。
Niki said to me.

我们又坐在沙发上，看着外面的花园。
We were sitting once again in our armchairs, looking out into the garden.

“你怎么会这么想？”
“Why do you suppose that?”

我说。
I said.

“我应该跟她说我正在考虑上大学什么的。”
“I should have told her I was thinking of going to university or something like that.”

“我一点都不介意你说自己什么。
“I don't mind in the least what you say about yourself.

我不觉得丢脸。”
I'm not ashamed of you.”

“我想你不会。”
“No, I suppose not.”

“不过我想你对她很不耐烦。
“But I did think you were rather off-hand with her.

你从来都不太喜欢她，不是吗？”
You never did like that woman much, did you?”

“沃特斯太太？
“Mrs Waters?

哦，我以前很讨厌上她的课。
Well, I used to hate those lessons she gave me.

无聊死了。
They were sheer boredom.

我常常睡着，然后耳边不时有小小的声音，叫你把手指放在这里、这里或这里。
I used to just go off in a dream, then now and again there'd be this little voice telling me to put my finger here or here or here.

是你的主意吗，让我上钢琴课？”
Was that your idea, getting me to have lessons?”

“主要是我的意思。
“It was mainly mine.

你瞧，以前我对你期望很高。”
You see, I had great plans for you once.”

妮基笑了。
Niki laughed.

“对不起我没学成。
“I'm sorry to be such a failure.

可这得怪你自己。
But it's your own fault.

我根本没有学音乐的天赋。
I haven't got any musical sense at all.

我们屋里有个女孩是弹吉他的，她想教我几个和弦，可是我根本就不想学。
There's this girl in our house who plays the guitar, and she was trying to show me some chords, but I couldn't be bothered to even learn those.

我想沃特斯太太让我这辈子都讨厌音乐了。”
I think Mrs Waters put me off music for life.”

“将来有一天你可能会重新爱上音乐，那时你就会感激上过那些课了。”
“You may come back to it some time and you'll appreciate having had lessons.”

“可是我把学的全忘了。”
“But I've forgotten everything I ever learnt.”

“不可能全忘的。
“I doubt if you would have forgotten everything.

那个年纪学的东西是不会全丢掉的。”
Nothing you learn at that age is totally lost.”

“反正是浪费时间，”妮基嘟囔道。
“A waste of time, anyway,” Niki muttered.

她坐在那里看着窗外，过了一会儿，转向我说：“我想很难跟别人说吧。
She sat looking out of the windows for some time. Then she turned to me and said: “I suppose it must be quite difficult to tell people.

我是指景子的事。”
About Keiko, I mean.”

“我那样说最省事，”我答道。
“It seemed easiest to say what I did,” I replied.

“她着实吓了我一跳。”
“She rather took me by surprise.”

“我想是这样。”妮基又面无表情地看着窗外。
“Yes, I suppose so.” Niki went on looking out of the window with an empty expression.

“景子没有来参加爸爸的葬礼，对吧？”她终于说道。
“Keiko didn't come to Dad's funeral, did she?” she said, eventually.

“你明知道她没去干吗还问？”
“You know perfectly well she didn't so why ask?”

“我随口说说，没什么。”
“I was just saying, that's all.”

“你是要说因为她没有参加你爸爸的葬礼所以你也不参加她的葬礼？
“You mean you didn't come to her funeral because she didn't come to your father's?

别这么孩子气，妮基。”
Don't be so childish, Niki.”

“我不是孩子气。
“I'm not being childish.

我是说事实就是这样。
I'm just saying that's the way it was.

她从来不是我们生活的一部分——既不在我的生活里也不在爸爸的生活里。
She was never a part of our lives — not mine or Dad's anyway.

我从没想过她会来参加爸爸的葬礼。”
I never expected her to be at Dad's funeral.”

我没有回答，我们静静地坐在沙发上。
I did not reply and we sat silently in our armchairs.

然后妮基说：
Then Niki said:

“刚才真是不自在，和沃特斯太太说话的时候。
“It was odd just now, with Mrs Waters.

你好像很喜欢？”
It was almost like you enjoyed it.”

“喜欢什么？”
“Enjoyed what?”

“假装景子还活着。”
“Pretending Keiko was alive.”

“我不喜欢骗人。”
“I don't enjoy deceiving people.”

也许是我的话蹦得太快，妮基好像吓了一跳。
Perhaps I snapped a little, for Niki looked startled.

“我知道，”她轻声说。
“No, I suppose not,” she said, lamely.

那天晚上雨下了一整夜，第二天——妮基来的第四天——仍旧淅淅沥沥地下个不停。
It rained throughout that night, and the next day — the fourth day of Niki's stay — it was still raining steadily.

“今天晚上我换个房间可以吗？”
“Do you mind if I change rooms tonight?”

妮基说。
Niki said.

“我可以睡空房间。”
“I could use the spare bedroom.”

我们刚吃完早餐，正在厨房里洗盘子。
We were in the kitchen, washing the dishes after breakfast.

“空房间？”
“The spare bedroom?”

我笑了笑。
I laughed a little.

“这里现在都是空房间。
“They're all spare bedrooms now.

你要睡空房间当然可以，没有什么不可以。
No, there's no reason why you shouldn't sleep in the spare room.

你不喜欢你的旧房间了？”
Have you taken a dislike to your old room?”

“睡在那里我觉得不自在。”
“I feel a bit odd sleeping there.”

“太没良心了，妮基。
“How unkind, Niki.

我本来希望你还把它当作自己的房间的。”
I hoped you'd still feel it was your room.”

“我是这么想来着，”她急忙说。
“Yes, I do,” she said, hurriedly.

“我不是不喜欢那个房间。”
“It's not that I don't like it.”

她不说了，用干毛巾擦着刀子。
She fell silent, wiping some knives with a tea-towel.

最后她终于说：“是另外那间。
Finally she said: “It's that other room.

她的房间。
Her room.

就在正对面，让我觉得不自在。”
It gives me an odd feeling, that room being right opposite.”

我停下手里的事，板着脸看着她。
I stopped what I was doing and looked at her sternly.

“我忍不住，妈妈。
“Well, I can't help it, Mother.

一想到那间房间就在正对面我就觉得怪怪的。”
I just feel strange thinking about that room being right opposite.”

“睡空房间去吧，”我冷冷地说。
“Take the spare room by all means,” I said, coldly.

“可是你得自己铺床。”
“But you'll need to make up the bed in there.”

虽然我对妮基换房间的要求表现得很生气，但是我并不想难为她。
Although I had made a show of being upset by Niki's request to change rooms, I had no wish to make it difficult for her to do so.

因为我自己也曾对那个房间感到不安。
For I too had experienced a disturbing feeling about that room opposite.

在许多方面，那个房间是这栋房子里最好的房间，从那里看果园视野极好。
In many ways, that room is the most pleasant in the house, with a splendid view across the orchard.

但是很长时间里，它一直是景子极小心守护的私人领域，所以即使在她已经离开了六年后的今天，那里仍然笼罩着一股神秘的空气——这种感觉在景子死后更加强烈。
But it had been Keiko's fanatically guarded domain for so long, a strange spell seemed to linger there even now, six years after she had left it — a spell that had grown all the stronger now that Keiko was dead.

在她最终离开我们的前两三年，景子把自己关在那个房间里，把我们挡在她的世界之外。
For the two or three years before she finally left us, Keiko had retreated into that bedroom, shutting us out of her life.

她很少出来，虽然有时我们都上床睡觉后我听到她在房子里走动。
She rarely came out, although I would sometimes hear her moving around the house after we had all gone to bed.

我猜想她在房间里看杂志，听广播。
I surmised that she spent her time reading magazines and listening to her radio.

她没有朋友，也不许我们其他人进她的房间。
She had no friends, and the rest of us were forbidden entry into her room.

吃饭时，我把她的盘子留在厨房里，她会下来拿，然后又把自己锁起来。
At mealtimes I would leave her plate in the kitchen and she would come down to get it, then shut herself in again.

我发现房间里乱糟糟的。
The room, I realized, was in a terrible condition.

有发霉的香水和脏衣服的味道，我偶尔瞥见里面，地上是成堆的衣服和无数的时尚杂志。我只得连哄带骗叫她把衣服拿出来洗。
An odour of stale perfume and dirty linen came from within, and on the occasions I had glimpsed inside, I had seen countless glossy magazines lying on the floor amidst heaps of clothes.

最后我们达成共识：每几个星期，我会在她房间门口看见一袋要洗的衣服，我把衣服洗了，拿回去。
I had to coax her to put out her laundry, and in this at least we reached an understanding: every few weeks I would find a bag of washing outside her door, which I would wash and return.

后来，大家渐渐习惯了她的做法，而当她偶尔心血来潮冒险到客厅里来时，大家就都很紧张。她每次出来无一例外地都是以争吵收场，不是和妮基吵架，就是和我丈夫吵架，最后她又回到自己的房间里去。
In the end, the rest of us grew used to her ways, and when by some impulse Keiko ventured down into our living room, we would all feel a great tension. Invariably, these excursions would end with her fighting, with Niki or with my husband, and then she would be back in her room.

我没有见过景子在曼彻斯特的房间，她死的那个房间。
I never saw Keiko's room in Manchester, the room in which she died.

作为一个母亲，这么想可能有点病态，但是听到她自杀的消息时，我脑子里的第一个想法——甚至在我感到震惊之前——是：在他们发现之前她那么吊着多久了。
It may seem morbid of a mother to have such thoughts, but on hearing of her suicide, the first thought that ran through my mind — before I registered even the shock — was to wonder how long she had been there like that before they had found her.

在自己家里，我们都一连几天看不见她；在一个没有人认识她的陌生城市里，更别指望会很快被人发现。
She had lived amidst her own family without being seen for days on end; little hope she would be discovered quickly in a strange city where no one knew her.

后来，验尸官说她已经死亡“好几天了”。
Later, the coroner said she had been there “for several days”.

是房东太太开的门，她以为景子没有交房租就离开了。
It was the landlady who had opened the door, thinking Keiko had left without paying the rent.

我发现这个画面一直出现在我的脑海里——我的女儿在房间里吊了好几天。
I have found myself continually bringing to mind that picture — of my daughter hanging in her room for days on end.

画面的恐怖从未减弱，但是我早就不觉得这是什么病态的事了；就像人身上的伤口，久而久之你就会熟悉最痛的部分。
The horror of that image has never diminished, but it has long ceased to be a morbid matter; as with a wound on one's own body, it is possible to develop an intimacy with the most disturbing of things.

“在空房间里睡我至少能暖和些，”妮基说。
“I'll probably be warmer in the spare room anyhow,” Niki said.

“妮基，你晚上要是觉得冷，把暖气打开就好了。”
“If you're cold at night, Niki, you can simply turn up the heating.”

“我知道。”
“I suppose so.”

她叹了口气。
She gave a sigh.

“最近我总是睡不好。
“I haven't slept very well lately.

我想我老做噩梦，但是醒来后就想不起来了。”
I think I'm getting bad dreams, but I can never remember them properly once I wake up.”

“昨天晚上我做了一个梦，”我说。
“I had a dream last night,” I said.

“我想可能跟这里的安静有关。
“I think it might be to do with the quiet.

我不习惯晚上这么安静。”
I'm not used to it being so quiet at night.”

“我梦见了那个小女孩。
“I dreamt about that little girl.

昨天我们看见的那个。
The one we were watching yesterday.

公园里那个。”
The little girl in the park.”

“我在车上就能睡着，可是我不记得怎么在安静的地方睡觉了。”
“I can sleep right through traffic, but I've forgotten what it's like, sleeping in the quiet.”

妮基耸耸肩，把一些餐具扔进抽屉里。
Niki shrugged and dropped some cutlery into the drawer.

“也许在空房间里我能睡得好一点。”
“Perhaps I'll sleep better in the spare room.”

我跟妮基说起这个梦，在我第一次做这个梦的时候。这也许表明我从那时起就觉得这不是一个普通的梦。
The fact that I mentioned my dream to Niki, that first time I had it, indicates perhaps that I had doubts even then as to its innocence.

我肯定从一开始就怀疑——虽然不确定是为什么——这个梦跟我们看见的那个小女孩没多大关系，而是跟我两天前想起佐知子有关。
I must have suspected from the start — without fully knowing why — that the dream had to do not so much with the little girl we had watched, but with my having remembered Sachiko two days previously.

# 第一部 · 第四章 | PART ONE · Chapter Four

一天下午，我丈夫下班回来之前，我正在厨房里准备晚饭，突然听见客厅传来奇怪的声音。
I was in the kitchen one afternoon preparing the supper before my husband came home from work, when I heard a strange sound coming from the living room.

我停下手里的活侧耳倾听。
I stopped what I was doing and listened.

声音又响了——是很难听的小提琴声。
It came again — the sound of a violin being played very badly.

声音持续了几分钟，然后停了。
The noises continued for a few minutes then stopped.

当我终于来到客厅时，发现绪方先生正弯着腰坐在棋盘前。
When eventually I went into the living room, I found Ogata-San bowed over a chess-board.

夕阳照射进来，尽管开着电风扇，屋里还是湿气很重。
The late afternoon sun was streaming in and despite the electric fans a humidity had set in all around the apartment.

我把窗户开得更大些。
I opened the windows a little wider.

“你们昨晚没有把棋下完吗？”
“Didn't you finish your game last night?”

我走向他，问。
I asked, coming over to him.

“没有。二郎说他累了。
“No, Jiro claimed he was too tired.

我猜这是他的诡计。
A ploy on his part, I suspect.

你瞧，我在这里把他围住了。”
You see, I have him in a nice corner here.”

“这样啊。”
“I see.”

“他仰赖我现在的记性不好了。
“He's relying on the fact that my memory's so foggy these days.

所以我在温习我的步子。”
So I'm just going over my strategy again.”

“您真是厉害，爸爸。
“How resourceful of you, Father.

可是我想二郎不会这么狡猾的。”
But I doubt if Jiro's mind works quite so cunningly.”

“也许吧。
“Perhaps not.

我敢说现在你比我更了解他。”
I dare say you know him better than I do these days.”

绪方先生继续研究棋盘，过了一会儿，抬起头来，笑了笑。
Ogata-San continued to study the board for several moments, then looked up and laughed.

“你一定觉得很有趣吧。
“This must seem amusing to you.

二郎在公司里辛苦工作，而我在家里等他下班回来和我下棋。
Jiro sweating away in his office and here I am preparing a game of chess for when he comes home.

我就像一个孩子在等爸爸回来。”
I feel like a small child waiting for his father.”

“哦，我宁愿您还是下棋的好。
“Well, I'd much rather you occupied yourself with chess.

您刚才的琴声实在是太可怕了。”
Your musical recital earlier was hideous.”

“太没礼貌了。
“How disrespectful.

我还希望能感动你呢，悦子。”
And I thought you'd be moved, Etsuko.”

小提琴放在旁边的地板上，已经放回盒子里了。
The violin was on the floor nearby, put back in its case.

绪方先生看着我打开盒子。
Ogata-San watched me as I began opening the case.

“我看见它放在那边的架子上，就擅自拿下来了。”
“I noticed it up there on the shelf,” he said.

他说。
“I took the liberty of bringing it down.

“别担心，悦子。
Don't look so concerned, Etsuko.

我拿得很小心。”
I was very gentle with it.”

“我看不一定。
“I can't be sure.

正如您说的，爸爸现在像个小孩子。”
As you say, Father's like a child these days.”

我拿起小提琴仔细检查。
I held up the violin and examined it.

“只不过小孩子够不着那么高的架子。”
“Except small children can't reach up to high shelves.”

我把琴塞到下巴底下。
I tucked the instrument under my chin.

绪方先生一直看着我。
Ogata-San continued to watch me.

“给我拉一首吧，”他说。
“Play something for me,” he said.

“我肯定你拉得比我好。”
“I'm sure you can do better than me.”

“那是肯定的。”
“I'm sure I can.”

我把琴重新放下，搁在一旁。
Once more I held the violin out at arm's length.

“可是我好久没拉琴了。”
“But it's been such a long time.”

“你是说你都没有练习？
“You mean you haven't been practising?

太可惜了，悦子。
Now that's a pity, Etsuko.

你以前是那么喜欢这个乐器。”
You used to be so devoted to the instrument.”

“我想我以前是很喜欢。
“I suppose I was once.

可现在很少碰了。”
But I hardly touch it now.”

“太不应该了，悦子。
“A great shame, Etsuko.

你以前是那么喜欢。
And you were so devoted.

我还记得以前你三更半夜拉琴，把全家都吵醒了。”
I remember when you used to play in the dead of night and wake up the house.”

“把全家都吵醒了？
“Wake up the house?

我什么时候干过这种事？”
When did I do that?”

“有，我记得。
“Yes, I remember.

你刚来我们家住时。”
When you first came to stay with us.”

绪方先生笑了笑。
Ogata-San gave a laugh.

“别在意，悦子。
“Don't look so worried, Etsuko.

我们都原谅你了。
We all forgave you.

现在我想想，你以前最崇拜哪个作曲家来着？
Now let me see, who was the composer you used to admire so much?

是门德尔松吗？”
Was it Mendelssohn?”

“是真的吗？
“Is that true?

我把全家都吵醒了？”
I woke up the house?”

“别在意，悦子。
“Don't look so worried, Etsuko.

那是好几年前的事了。
It was years ago.

给我拉一首门德尔松的吧。”
Play me something by Mendelssohn.”

“可是你们干吗不阻止我？”
“But why didn't you stop me?”

“只是刚开始的几个晚上。
“It was only for the first few nights.

而且我们一点都不介意。”
And besides, we didn't mind in the least.”

我轻轻地拨了拨琴弦。
I plucked the strings lightly.

音已经走调了。
The violin was out of tune.

“我那时肯定成了您的负担，”我静静地说。
“I must have been such a burden to you in those days,” I said, quietly.

“胡说。”
“Nonsense.”

“可是家里其他人。
“But the rest of the family.

他们肯定觉得我是个疯丫头。”
They must have thought I was a mad girl.”

“他们才不会把你想得这么坏。
“They couldn't have thought too badly of you.

毕竟最后你跟二郎结了婚。
After all, it ended up with you marrying Jiro.

现在好了，悦子，别说这些了。
Now come on, Etsuko, enough of this.

给我拉一首吧。”
Play me something.”

“我那时候像什么样子呢，爸爸？
“What was I like in those days, Father?

我像个疯子吗？”
Was I like a mad person?”

“你被吓坏了，这是很自然的事。
“You were very shocked, which was only to be expected.

大家都吓坏了，我们这些幸存下来的人。
We were all shocked, those of us who were left.

现在，悦子，忘了这些事吧。
Now, Etsuko, let's forget these things.

我很抱歉提起这件事。”
I'm sorry I ever brought up the matter.”

我再次把琴放到下巴底下。
I brought the instrument up to my chin once more.

“啊，”他说，“门德尔松。”
“Ah,” he said, “Mendelssohn.”

我就这么把琴夹在下巴下。
I remained like that for several seconds, the violin under my chin.

过了几秒钟，我放下琴，叹了口气，说：“我现在拉不出来。”
Then I brought it down to my lap and sighed. “I hardly play it now,” I said.

“对不起，悦子。”
“I'm sorry, Etsuko.”

绪方先生说，声音变沉重了。
Ogata-San's voice had become solemn.

“也许我不应该碰琴的。”
“Perhaps I shouldn't have touched it.”

我抬起头来看他，笑着说：“瞧，小朋友现在知道错了。”
I looked up at him and smiled. “So,” I said, “the little child is feeling guilty now.”

“我在架子上看见它，想起了以前的事。”
“It's just that I saw it up there and I remembered it from those days.”

“我以后再拉给您听吧。
“I'll play it for you another time.

我练习练习。”
After I've practised a little.”

他微微地鞠了一躬，眼里又露出了喜悦。
He gave me a small bow, and the smile returned to his eyes.

“我会记着你说过的话的，悦子。
“I'll remember you promised, Etsuko.

说不定你还可以教教我。”
And perhaps you could teach me a little.”

“我不能什么都教您，爸爸。
“I can't teach you everything, Father.

您还说您要学做菜。”
You said you wanted to learn to cook.”

“啊对了。
“Ah yes.

还有那个。”
That too.”

“您下次来的时候我再拉给您听吧。”
“I'll play for you the next time you come to stay with us.”

“我会记着的，”他说。
“I'll remember you promised,” he said.

那天晚上吃完饭，二郎和父亲坐下来下棋。
After supper that evening, Jiro and his father settled down to their game of chess.

我收拾完晚餐的东西，拿了些针线活坐下来。
I cleared up the supper things and then sat down with some sewing.

棋下到一半时，绪方先生说：
At one point during their game, Ogata-San said:

“我刚想到了什么。
“I've just noticed something.

你不介意的话，我要重新走那步。”
If you don't mind, I'd like to make that move again.”

“当然可以，”二郎说。
“Certainly,” said Jiro.

“可是这样对你很不公平。
“But then it's rather unfair on you.

特别是现在我的形势比你有利。”
Especially since I seem to have the better of you at the moment.”

“没关系。
“No, not at all.

请重新走那步吧。”
Please take the move again.”

“你不介意？”
“You don't mind?”

“一点儿也不。”
“Not at all.”

他们继续静静地下棋。
They played on in silence.

“二郎，”几分钟后绪方先生说，“我在想，信你写了吗？
“Jiro,” Ogata-San said after several minutes, “I was just wondering. Have you written that letter yet?

给松田重夫的信？”
To Shigeo Matsuda?”

我停下手里的针线，抬起头来。二郎还在专心地下棋，他走完那一步才答道：“重夫？
I looked up from my sewing. Jiro appeared absorbed in the game and did not reply until he had moved his piece.

哦，还没。
“Shigeo? Well, not yet.

我打算写的。
I've been meaning to.

但是最近实在是太忙了。”
But I've been so busy just recently.”

“当然，我十分理解。
“Of course. I quite understand.

我刚好想到这件事，没什么。”
I just happened to think of it, that's all.”

“我最近实在是没时间。”
“I don't seem to have had much time just recently.”

“当然。
“Of course.

不急。
There's no hurry.

我并不是要老缠着你。
I don't mean to keep pestering you like this.

只是信早点写的好。
It's just that it might be more appropriate if he heard from you fairly soon.

他那篇文章已经登出来几个星期了。”
It's a few weeks now since his article appeared.”

“是，当然。
“Yes, certainly.

您说得很对。”
You're quite right.”

他们接着下棋。
They returned to their game.

有好几分钟，两个人都没有说话。
For some moments neither of them spoke.

突然绪方先生说：
Then Ogata-San said:

“你觉得他会是什么反应呢？”
“How do you suppose he'll react?”

“重夫？
“Shigeo?

我不知道。
I don't know.

我说过了，我现在跟他不熟。”
As I say, I don't know him very well these days.”

“你说他加入了共产党？”
“He's joined the Communist Party, you say?”

“我说不准。
“I'm not certain.

我上次见到他时，他确实说支持共产党。”
He certainly expressed such sympathies when I last saw him.”

“真遗憾。
“A great pity.

不过话说回来，现在日本发生了太多事情让年轻人动摇。”
But then there are so many things in Japan today to sway a young man.”

“是的，的确。”
“Yes, no doubt.”

“现在很多年轻人都被什么思想啊、理论啊冲昏了头。
“So many young men these days get carried away with ideas and theories.

不过他可能会收回前言并道歉的。
But perhaps he'll back down and apologize.

及时地提醒个人的责任之类的东西也没有。
There's nothing like a timely reminder of one's personal obligations.

你知道，我怀疑他都没有停下来想过自己在干什么。
You know, I suspect Shigeo never even stopped to consider what he was doing.

我想他写那篇文章时是一手拿着笔，一手拿着共产主义的书。
I think he wrote that article with a pen in one hand and his books about communism in the other.

他最后会收回前言的。”
He may well back down in the end.”

“很可能。
“Quite possibly.

我最近的工作实在是太多了。”
I've just had so much work recently.”

“当然，当然。
“Of course, of course.

工作第一。
Your work must take precedence.

别为这件事操心。
Please don't worry about it.

现在，是不是轮到我了？”
Now, was it my move?”

他们接着下棋，很少说话。
They continued their game, speaking little.

有一次，我听见绪方先生说：“你走的跟我想的一样。
Once I heard Ogata-San say: “You're moving just as I anticipated.

你要动动脑筋才能从那里突围。”
You'll need to be very clever to escape from that corner.”

他们下了好一会，突然有敲门声。
They had been playing for sometime when there was a knock at the door.

二郎抬起头来，给我递了个眼色。
Jiro looked up and threw me a glance.

我放下针线，站了起来。
I put down my sewing and got to my feet.

我打开门，看见两个男人笑嘻嘻地朝我鞠躬。
When I opened the door, I found two men grinning and bowing at me.

那时已经很晚了，一开始我以为他们走错门了。
It was quite late by then and I thought at first they had come to the wrong apartment.

可后来我认出他们是二郎的同事，就请他们进来。
But then I recognized them as two of Jiro's colleagues and asked them in.

他们站在玄关自顾自地笑着。
They stood in the entryway giggling to themselves.

其中一个矮矮胖胖的，脸很红。
One was a tubby little man whose face looked quite flushed.

另一个瘦一些，皮肤很白，像欧洲人的白；但是他好像也喝酒了，脸颊上露出粉色的斑。
His companion was thinner, with a pale complexion like that of a European; but it seemed he too had been drinking, for pink blotches had appeared on each of his cheeks.

他们系着的领带都松了，外套挂在手上。
They were both wearing ties, loosened untidily, and were holding jackets over their arms.

二郎见到他们很高兴，叫他们进去坐。
Jiro seemed pleased to see them and called to them to sit down.

可是他们只是站在玄关，笑个不停。
But they remained in the entryway, giggling.

“啊，绪方，”白皮肤的那个对二郎说，“我们可能来的不是时候。”
“Ah, Ogata,” the pale-faced man said to Jiro, “perhaps we've caught you at a bad time.”

“不会。
“Not at all.

不过你们在这附近做什么呢？”
What are you doing in these parts anyway?”

“我们去看村崎的哥哥。
“We've been to see Murasaki's brother.

其实，我们还没回家呢。”
In fact, we haven't been home yet.”

“我们不敢回家，所以来打扰你，”胖胖的那个插进来说。
“We came to disturb you because we're afraid to go home,” the tubby man put in.

“我们没有跟太太说我们要晚点回去。”
“We didn't tell our wives we'd be late.”

“真是混蛋，你们两个，”二郎说。
“What rabble you are, the pair of you,” said Jiro.

“你们干吗不脱鞋进来呢？”
“Why don't you take off your shoes and come up here?”

“我们来的不是时候，”白皮肤的那个又说。
“We've caught you at a bad time,” the pale-faced man said again.

“我看见你有客人。”
“I can see you've got a visitor.”

他朝绪方先生笑了笑，鞠了一躬。
He grinned and bowed towards Ogata-San.

“这是我父亲，可是你们不进来我怎么介绍呢？”
“This is my father, but how can I introduce you if you don't come in?”

客人终于脱了鞋，进来坐下。
The visitors finally took off their shoes and seated themselves.

二郎把他们介绍给父亲，他们再次鞠躬，又笑了起来。
Jiro introduced them to his father and they began once more to bow and giggle.

“你们是二郎公司的？”
“You gentlemen are from Jiro's firm?”

绪方先生问。
Ogata-San asked.

“是的，”矮矮胖胖的那个答道。
“Yes, indeed,” the tubby man replied.

“很荣幸，虽然他让我们很不好过。
“A great honour it is too, even if he does give us a tough time.

在办公室里我们叫你儿子‘法老’，因为他让我们像奴隶一样工作，自己却什么都不做。”
We call your son ‘Pharaoh’ in the office because he urges the rest of us to work like slaves while he does nothing himself.”

“胡说八道，”我丈夫说。
“What nonsense,” said my husband.

“是真的。
“It's true.

他像苦役一样驱使我们，然后自己坐下来看报纸。”
He orders us around like we're his dogsbodies. Then he sits down and reads the newspaper.”

绪方先生好像听得有点迷糊，但是看见其他人在笑，他也笑了笑。
Ogata-San seemed a little confused, but seeing the others laugh he joined in.

“啊，这是什么？”
“And what's this here?”

白皮肤的那个指了指棋盘。
The pale-faced man indicated the chess-board.

“瞧，我就知道我们会打扰你们。”
“You see, I knew we'd interrupted something.”

“我们只是在下棋打发时间，”二郎说。
“We were just playing chess to pass the time,” said Jiro.

“接着下吧。
“Go on playing then.

别让我们这种混蛋打断你们下棋。”
Don't let rabble like us interrupt.”

“别傻了。
“Don't be silly.

有你们这样的笨蛋在旁边，我怎么能集中精神。”
How could I concentrate with idiots like you around.” Jiro pushed away the chess-board.

说着二郎把棋盘推到一边。有一两个棋子倒了，他看也不看就把它们摆正。
One or two of the pieces fell over and he stood them up again without looking at the squares. “So.

“那么说，你们去看村崎的哥哥。悦子，给客人倒茶。”
You've been to see Murasaki's brother. Etsuko, get some tea for the gentlemen.”

我丈夫说这句话之前，我已经往厨房走去了。
My husband had said this despite the fact that I was already on my way to the kitchen.

可这时矮矮胖胖的那个突然拼命挥手。
But then the tubby man started to wave his hand frantically.

“夫人，夫人，坐下。
“Madam, madam, sit down.

请坐下。
Please.

我们一会儿就走。
We'll be going in just a moment.

您请坐。”
Please be seated.”

“不麻烦，”我笑着说。
“It's no trouble,” I said, smiling.

“不用，夫人，我求您”——他越说越大声——“正如您丈夫说的，我们只是两个混蛋。
“No, madam, I implore you” — he had started to shout quite loudly — “We're just rabble, like your husband says.

不用麻烦了，请坐下。”
Please don't make a fuss, please sit down.”

我正想遵照他的意思，突然看见二郎生气地看了我一眼。
I was about to obey him, but then I saw Jiro give me an angry look.

“至少喝杯茶再走，”我说。
“At least have some tea with us,” I said.

“一点儿也不麻烦。”
“It's no trouble at all.”

“既然坐下了，就多坐一会儿，”我丈夫对客人说。
“Now you've sat down, you may as well stay a while,” my husband said to the visitors.

“反正我也想听听村崎的哥哥的事。
“Anyway, I want to know about Murasaki's brother.

他真的像人们说的那样疯疯癫癫的吗？”
Is he as mad as they say he is?”

“他的确是个怪人，”矮矮胖胖的那个笑着说。
“He's a character all right,” the tubby man said, with a laugh.

“今晚确实没有让我们失望。
“We certainly weren't disappointed.

你听说过他妻子的事吗？”
And did anyone tell you about his wife?”

我欠了欠身，悄悄地到厨房去。
I bowed and made my way into the kitchen unnoticed.

我泡了茶，在盘子上放了几块那天早些时候做的蛋糕。
I prepared the tea and put on to a plate some cakes I had been making earlier that day.

我听见客厅传来笑声，我丈夫也在笑。
I could hear laughter coming from the living room, my husband's voice amongst them.

其中一个客人又很大声地叫了他一次“法老”。
One of the visitors was calling him “Pharaoh” again in a loud voice.

我回到客厅时，二郎和他的客人们聊得正欢。
When I returned to the living room, Jiro and his visitors seemed in high spirits.

矮矮胖胖的那个正在说一件趣闻，说一个内阁大臣遇见麦克阿瑟将军的事。
The tubby man was relating an anecdote, about some cabinet minister's encounter with General MacArthur.

我把蛋糕放在他们旁边，给他们倒了茶，然后在绪方先生身边坐下。
I put the cakes near them, poured out their tea, then sat down beside Ogata-San.

二郎的朋友又开了几个政治家的玩笑，然后白皮肤的那个假装生气了，因为另一个说了一位他敬仰的人物的坏话。
Jiro's friends made several more jokes concerning politicians and then the pale-faced man pretended to be offended because his companion had spoken disparagingly of some personage he admired.

大家笑他，他板起脸来。
He kept a straight face while the others teased him.

“对了，花田，”我丈夫对他说。
“By the way, Hanada,” my husband said to him.

“有一天我在办公室听说了一件有趣的事情。
“I heard an interesting story the other day at the office.

我听说在上次选举时，你威胁你太太说要用高尔夫球棍打她，因为她不跟你选同样的人。”
I was told during the last elections, you threatened to beat your wife with a golf club because she wouldn't vote the way you wanted.”

“你听谁胡说的？”
“Where did you pick up this rubbish?”

“消息可靠的人说的。”
“I got it from reliable sources.”

“没错，”矮矮胖胖的那个说。
“That's right,” the tubby man said.

“还有，你太太打算报告警察说你政治胁迫。”
“And your wife was going to call the police to report political intimidation.”

“胡说八道。
“What rubbish.

再说，我没有高尔夫球棍了。
Besides, I don't have golf clubs any more.

我去年都卖掉了。”
I sold them all last year.”

“你还有一根七号铁杆，”矮矮胖胖的那个说。
“You still have that seven-iron,” said the tubby man.

“上周在你家我看到过。
“I saw it in your apartment last week.

你可能是用那个。”
Maybe you used that.”

“可是你不能说没有这事吧，花田？”二郎说。
“But you can't deny it, can you, Hanada?” said Jiro.

“什么高尔夫球棍，都是胡说八道。”
“It's nonsense about the golf club.”

“可是你没能让她照你说的做，这是真的吧。”
“But it's true you couldn't get her to obey you.”

白皮肤的那个耸耸肩。
The pale-faced man shrugged.

“这个嘛，她要投给谁是她自己的权利。”
“Well, it's her personal right to vote any way she pleases.”

“那你为什么威胁她？”他的朋友问。
“Then why did you threaten her?” his friend asked.

“我自然是在试着跟她讲道理。
“I was trying to make her see sense, of course.

我太太投给吉田就因为他长得像她叔叔。
My wife votes for Yoshida just because he looks like her uncle.

女人就是这样。
That's typical of women.

她们不懂政治。
They don't understand politics.

她们以为可以像选衣服那样选国家领导人。”
They think they can choose the country's leaders the same way they choose dresses.”

“所以你就用七号铁杆打她，”二郎说。
“So you gave her a seven-iron,” said Jiro.

“是真的吗？”
“Is that really true?”

绪方先生问。
Ogata-San asked.

从我把茶拿来到现在，他都没有说话。
He had not spoken since I had come back in with the tea.

其他三人都不笑了，白皮肤的那个惊讶地看着绪方先生。
The other three stopped laughing and the pale-faced man looked at Ogata-San with a surprised expression.

“没有。”
“Well, no.”

他突然变得正经八百，微微鞠了一躬。
He became suddenly formal and gave a small bow.

“我没有真的打她。”
“I didn't actually hit her.”

“不，不，”绪方先生说。
“No, no,” said Ogata-San.

“我是说你太太和你——你们真的投给不同的政党？”
“I meant your wife and yourself — you voted for separate parties?”

“啊，是的。”
“Well, yes.”

他耸耸肩，然后苦笑了一下。
He shrugged, then giggled awkwardly.

“我能怎么办呢？”
“What could I do?”

“对不起。
“I'm sorry.

我不是要多管闲事。”
I didn't mean to pry.”

绪方先生低低地鞠了一躬，白皮肤的那个回敬了一个。
Ogata-San gave a low bow, and the pale-faced man returned it.

这一鞠好像成了信号，三个年轻人又开始说说笑笑起来。
As if the bowing were a signal, the three younger men started once more to laugh and talk amongst themselves.

他们不谈政治了，聊起公司里的同事来。
They moved off politics and began discussing various members of their firm.

添茶时，我注意到虽然我端了不少蛋糕出来，但是已经快没了。
When I was pouring more tea, I noticed that the cakes, despite my having put out a generous amount, had almost all disappeared.

我添完茶，回到绪方先生身旁坐下。
I finished refilling their teacups, then sat down again beside Ogata-San.

客人们待了一个小时左右。
The visitors stayed for an hour or so.

二郎送他们到门口，然后回来坐下，叹了口气。
Jiro saw them to the door then sat down again with a sigh.

“晚了，”他说。
“It's getting late,” he said.

“我得睡觉了。”
“I'll need to turn in soon.”

绪方先生正在研究棋盘。
Ogata-San was examining the chess board.

“我想有几个棋子摆错了，”他说。
“I think the pieces got jogged a little,” he said.

“我肯定马应该在这格，不是那格。”
“I'm sure the horse was on this square, not that one.”

“很可能。”
“Quite probably.”

“那我把它放在这里了。
“I'll put it here then.

同意吗？”
Are we agreed on this?”

“好，好。我肯定您是对的。
“Yes, yes, I'm sure you're right.

我们以后再把棋下完吧，爸爸。
We'll have to finish the game another time, Father.

我得赶快睡觉了。”
I'll need to retire very shortly.”

“再走几步吧。
“How about playing just the next few moves.

我们很快就能下完了。”
We may well finish it off.”

“说真的，还是算了吧。
“Really, I'd rather not.

我现在太累了。”
I'm feeling very tired now.”

“好吧。”
“Of course.”

我把刚才做的针线活收起来，坐着等其他人去睡觉。
I packed away the sewing I had been doing earlier in the evening and sat waiting for the others to retire.

可是二郎翻开一份报纸读了起来。
Jiro, however, picked up a newspaper and started to read the back page.

他看见盘子里还有一块蛋糕，就若无其事地拿起来吃。
Then he took the last remaining cake from the plate and began to eat nonchalantly.

过了一会儿，绪方先生说：
After several moments, Ogata-San said:

“我们还是现在把它下完吧。
“Perhaps we ought to just finish it off now.

只差几步了。”
It'll only take a few more moves.”

“爸爸，我现在真的很累了。
“Father, I really am too tired now.

我明天早上还得上班呢。”
I have work to go to in the morning.”

“是的，好吧。”
“Yes, of course.”

二郎继续一面看报纸一面吃蛋糕。
Jiro went back to his newspapers.

我看见有一些蛋糕屑掉在榻榻米上。
He continued to eat the cake and I watched several crumbs drop on to the tatami.

绪方先生又盯着棋盘看了一会儿。
Ogata-San continued to gaze at the chess-board for some time.

“太奇怪了，”他终于说道，“你朋友刚刚说的事。”
“Quite extraordinary”, he said, eventually, “what your friend was saying.”

“哦？
“Oh?

什么事？”
What was that?”

二郎的眼睛没有离开报纸。
Jiro did not look up from his newspaper.

“他和他太太投票给不同的政党的事。
“About him and his wife voting for different parties.

几年前这种事情是不可能的。”
A few years ago that would have been unthinkable.”

“没错。”
“No doubt.”

“如今的事情都太奇怪了。
“Quite extraordinary the things that happen now.

不过我想这就是所谓的民主吧。”
But that's what's meant by democracy, I suppose.”

绪方先生叹了口气。
Ogata-San gave a sigh.

“我们急着想从美国人那里学来的这些东西，不一定都是好的。”
“These things we've learnt so eagerly from the Americans, they aren't always to the good.”

“是的，确实不一定都好。”
“No, indeed they're not.”

“看看出了什么事。
“Look what happens.

丈夫和妻子投票给不同的政党。
Husband and wife voting for different parties.

再也不能在这些事上信任妻子，真是悲哀。”
It's a sad state of affairs when a wife can't be relied on in such matters any more.”

二郎边看他的报纸边说：“是啊，太可惜了。”
Jiro continued to read his newspaper. “Yes, it's regrettable,” he said.

“现在的妻子都忘了对家庭的忠诚。
“A wife these days feels no sense of loyalty towards the household.

想干什么就干什么，一时高兴的话就把票投给另一个党。
She just does what she pleases, votes for a different party if the whim takes her.

这事在现在的日本太典型了。
That's so typical of the way things have gone in Japan.

人人借着民主的名义丢掉忠诚。”
All in the name of democracy people abandon obligations.”

二郎抬头看了他父亲一眼，很快又把目光移回报纸。
Jiro looked up at his father for a brief moment, then turned his eyes back to his paper.

“您说得很对，”他说。
“No doubt you're very right,” he said.

“不过当然了，美国人带来的东西也不全是坏的。”
“But surely the Americans didn't bring all bad.”

“美国人，他们从来就不理解日本人的处世之道。
“The Americans, they never understood the way things were in Japan.

从来没有。
Not for one moment have they understood.

他们的做法也许很适合美国人，可是在日本情况就不一样，很不一样。”
Their ways may be fine for Americans, but in Japan things are different, very different.”

绪方先生又叹了一口气。
Ogata-San sighed again.

“纪律，忠诚，从前是这些东西把日本人团结在一起。
“Discipline, loyalty, such things held Japan together once.

也许听起来不太真实，可确实是这样的。
That may sound fanciful, but it's true.

人们都有一种责任感。
People were bound by a sense of duty.

对自己的家庭，对上级，对国家。
Towards one's family, towards superiors, towards the country.

可是现在人们不再讲这些了，而是讲什么民主。
But now instead there's all this talk of democracy.

当一个人想自私自利时，想丢掉责任时，就说民主。”
You hear it whenever people want to be selfish, whenever they want to forget obligations.”

“是的，您说得对。”
“Yes, no doubt you're right.”

二郎打了个哈欠，挠了挠侧脸。
Jiro yawned and scratched the side of his face.

“就拿我这一行来说吧。多年来，我们有一套自己精心建立并热爱的体系。
“Take what happened in my profession, for instance. Here was a system we'd nurtured and cherished for years.

美国人来了，不假思索地把这套体系废除了、粉碎掉。
The Americans came and stripped it, tore it down without a thought.

他们决定要把我们的学校变得像美国那样的，我们的孩子应该学美国孩子学的东西。
They decided our schools would be like American schools, the children should learn what American children learn.

而日本人对这些全都欢迎，大谈特谈什么民主”——他摇了摇头——“学校里很多好东西都被毁了。”
And the Japanese welcomed it all. Welcomed it with a lot of talk about democracy” — he shook his head — “Many fine things were destroyed in our schools.”

“是的，我想您说得很对。”
“Yes, I'm sure that's very true.”

二郎再次抬起头来。
Jiro glanced up once more.

“不过当然了，旧的教育体系里也有一些缺点，其他体系也是。”
“But surely there were some faults in the old system, in schools as much as anywhere.”

“二郎，你说什么？
“Jiro, what is this?

你在哪里看到的吗？”
Something you read somewhere?”

“只是我的看法。”
“It's just my opinion.”

“那是你在报纸上看到的吗？
“Did you read that in your newspaper?

我这一辈子都在教育年轻人。
I devoted my life to the teaching of the young.

后来我看着美国人把整个教育体系都给粉碎了。
And then I watched the Americans tear it all down.

现在的学校太奇怪了，他们教给孩子的为人处世之道太奇怪了。
Quite extraordinary what goes on in schools now, the way children are taught to behave.

而且很多东西都不教了。
Extraordinary.

你知道吗？
And so much just isn't taught any more.

现在的孩子离开学校时对自己国家的历史一无所知。”
Do you know, children leave school today knowing nothing about the history of their own country?”

“这确实令人遗憾。
“That may be a pity, admittedly.

不过我也记得我上学时的一些怪事。
But then I remember some odd things from my schooldays.

比如说，我记得以前老师教过神是怎样创造日本的。
I remember being taught all about how Japan was created by the gods, for instance.

我们这个民族是多么的神圣和至高无上。
How we as a nation were divine and supreme.

我们得把课本一个字、一个字地背下来。
We had to memorize the text book word for word.

有些事情也许并不是什么损失。”
Some things aren't such a loss, perhaps.”

“可是二郎，事情不是这么简单。
“But Jiro, things aren't as simple as that.

你根本不知道是怎么回事。
You clearly don't understand how such things worked.

事情绝不像你想的那么简单。
Things aren't nearly as simple as you presume.

我们献身教育，确保优良的传统传承下去，确保孩子们形成正确的国家观、民族观。
We devoted ourselves to ensuring that proper qualities were handed down, that children grew up with the correct attitude to their country, to their fellows.

以前的日本有一种精神把大家团结在一起。
There was a spirit in Japan once, it bound us all together.

想象一下现在的孩子是怎么样的。
Just imagine what it must be like being a young boy today.

在学校里他学不到什么价值观——也许除了说他应该向生活索取任何他想要的东西。
He's taught no values at school — except perhaps that he should selfishly demand whatever he wants out of life.

回到家里，他发现父母在打架，因为他母亲拒绝投票给他父亲支持的党。
He goes home and finds his parents fighting because his mother refuses to vote for his father's party.

这是什么世道？”
What a state of affairs.”

“是的，我明白您的意思。
“Yes, I see your point.

现在，爸爸，请原谅，我得去睡觉了。”
Now, Father, I'm sorry but I must go to bed.”

“我们尽了全力，像远藤和我这样的人，我们尽全力教导这个国家。
“We did our best, men like Endo and I, we did our best to nurture what was good in the country.

很多好东西都被毁了。”
A lot of good has been destroyed.”

“确实太遗憾了。”
“It's most regrettable.”

我丈夫站了起来。
My husband got to his feet.

“对不起，爸爸，可是我得睡了。
“Excuse me, Father, but I must sleep.

我明天还要忙一天呢。”
I have another busy day tomorrow.”

绪方先生抬头看着他的儿子，脸上有些惊讶。
Ogata-San looked up at his son, a somewhat surprised expression on his face.

“啊，当然。
“Why, of course.

我把你拖得这么晚真是太不应该了。”
How inconsiderate of me to have kept you so late.”

他微微地鞠了一躬。
He gave a small bow.

“没有的事。
“Not at all.

我很抱歉我们不能接着聊，可是我真的得去睡了。”
I'm sorry we can't talk longer, but I really ought to get some sleep now.”

“啊，当然。”
“Why, of course.”

二郎向他父亲道了晚安，离开客厅。
Jiro wished his father a good night's sleep and left the room.

绪方先生盯着二郎走出去的那扇门看了好几秒钟，好像在等他儿子随时会回来。
For a few seconds, Ogata-San gazed at the door through which Jiro had disappeared as if he expected his son to return at any moment.

然后他转向我，表情很不安。
Then he turned to me with a troubled look.

“我没注意到已经这么晚了，”他说。
“I didn't realize how late it was,” he said.

“我不是有意不让二郎睡觉的。”
“I didn't mean to keep Jiro up.”

# 第一部 · 第五章 | PART ONE · Chapter Five

“走了？
“Gone?

可他有没有在旅馆里留口信给你？”
And had he left you no message at his hotel?”

佐知子笑了。
Sachiko laughed.

“你太吃惊了，悦子，”她说。
“You look so astonished, Etsuko,” she said.

“没有，他什么也没留。
“No, he'd left nothing.

他们只知道他昨天上午离开的。
He'd gone yesterday morning, that's all they knew.

老实说，我猜到会这样。”
To tell you the truth, I half expected this.”

我才注意到我还端着盘子。
I realized I was still holding the tray.

我小心地把盘子放下，然后在佐知子对面的垫子上坐下。
I laid it down carefully then seated myself on a cushion opposite Sachiko.

那天早上，公寓里吹着凉爽的微风。
There was a pleasant breeze blowing through the apartment that morning.

“可是你多惨啊，”我说。
“But how terrible for you,” I said.

“你把东西都收拾好、准备妥当，在等着他。”
“And you were waiting with everything packed and ready.”

“这对我来说不新鲜，悦子。
“This is nothing new to me, Etsuko.

在东京的时候——我是在东京认识他的——在东京的时候，也发生过同样的事。
Back in Tokyo — that's where I first met him, you see — back in Tokyo, it was just the same thing.

所以这对我来说不新鲜了。
Oh no, this is nothing new to me.

我已经学会预料到这类情况。”
I've learnt to expect such things.”

“你还说你今晚要回到城里去？
“And you say you're going back into town tonight?

一个人去？”
On your own?”

“别大惊小怪的，悦子。
“Don't look so shocked, Etsuko.

跟东京比起来，长崎像是个沉闷的小镇。
After Tokyo, Nagasaki seems a tame little town.

如果他还在长崎的话，我今晚就能找到他。
If he's still in Nagasaki, I'll find him tonight.

旅馆可以换，可是他的习惯是不会改的。”
He may change his hotel, but he won't have changed his habits.”

“可是太让人伤心了。
“But this is all so distressing.

你需要的话，我可以去陪着万里子到你回来。”
If you wish, I'd be glad to come and sit with Mariko until you get back.”

“啊，你太好了。
“Why, how kind of you.

万里子一个人待着没问题，不过要是你今晚愿意去陪她一两个小时，那真是太谢谢你了。
Mariko's quite capable of being left on her own, but if you're prepared to spend a couple of hours with her tonight, that would be most kind.

不过我肯定事情自然会好起来的，悦子。
But I'm sure this whole thing will sort itself out, Etsuko.

你瞧，你要是有我的一些经历的话，你就懂得不为这种小小的挫折烦恼了。”
You see, when you've come through some of the things I have, you learn not to let small set-backs like this worry you.”

“可是要是他……我是说，要是他已经离开长崎了呢？”
“But what if he's … I mean, what if he's left Nagasaki altogether?”

“哦，他没有走远，悦子。
“Oh, he hasn't gone far, Etsuko.

再说，如果他真的要离开我的话，他会留个字条什么的，不是吗？
Besides, if he really meant to leave me, he would have left a note of some kind, wouldn't he?

所以说，他没有走远。
You see, he hasn't gone far.

他知道我会去找他。”
He knows I'll come and find him.”

佐知子微笑着看着我。
Sachiko looked at me and smiled.

我不知道该说什么。
I found myself at a loss for any reply.

“再说了，悦子，”她接着说，“他大老远地到这里来。
“Besides, Etsuko,” she went on, “he did come all the way down here.

他大老远地到长崎来我伯父家找我，大老远地从东京来。
He came down all this way to Nagasaki to find me at my uncle's house, all that way from Tokyo.

若不是为了他答应过的事，他为什么要这么做呢？
Now why would he have done that if he didn't mean everything he's promised?

要知道，悦子，他最想做的就是带我去美国。
You see, Etsuko, what he wants most is to take me to America.

这就是他想做的。
That's what he wants.

这一点没有改变，现在只不过是稍稍的耽搁。”
Nothing's changed really, this is just a slight delay.”

她干笑了一声。
She gave a quick laugh.

“你瞧，有时候他像个孩子。”
“Sometimes, you see, he's like a little child.”

“可是你的朋友这样走了是什么意思呢？
“But what do you think your friend means by going off like this?

我不明白。”
I don't understand.”

“没什么好明白的，悦子，这没什么大不了的。
“There's nothing to understand, Etsuko, it hardly matters.

他想做的就是带我去美国，过稳定、体面的生活。
What he really wants is to take me to America and lead a steady respectable life there.

这是他真正想做的。
That's what he really wants.

不然他干吗要大老远地来我伯父家找我呢？
Otherwise why would he have come all that way and found me at my uncle's house?

所以说，悦子，没什么好担心的。”
You see, Etsuko, this isn't anything to be so worried about.”

“是的，我想没什么好担心的。”
“No, I'm sure it isn't.”

佐知子好像还想说些什么，却停住不说了。
Sachiko seemed about to speak again, but then appeared to stop herself.

她低头看了看盘子里的茶具。
She stared down at the tea things on the tray.

“那现在，悦子，”她笑着说，“我们倒茶吧。”
“Well then, Etsuko,” she said, with a smile, “let's pour the tea.”

她静静地看着我倒茶。
She watched in silence as I poured.

期间我很快地瞥了她一眼，她笑了，像是在鼓励我接着倒。
Once when I glanced quickly towards her, she smiled as if to encourage me.

我倒完茶，我们静静地坐了一会儿。
I finished pouring the tea and for a moment or two we sat there quietly.

“对了，悦子，”佐知子说，“我想你已经跟藤原太太说了我的情况了吧。”
“Incidentally, Etsuko,” Sachiko said, “I take it you've spoken to Mrs Fujiwara and explained my position to her.”

“是的。
“Yes.

我前天见到她。”
I saw her the day before yesterday.”

“我想她一定在想我怎么了。”
“I suppose she'd been wondering what had become of me.”

“我告诉她有人要带你到美国去。
“I explained to her that you'd been called away to America.

她完全理解。”
She was perfectly understanding about it.”

“你瞧，悦子，”佐知子说，“我发现自己现在处境艰难。”
“You see, Etsuko,” said Sachiko, “I find myself in a difficult situation now.”

“是的，我可以理解。”
“Yes, I can appreciate that.”

“经济方面，和其他各个方面。”
“As regards finances, as well as everything else.”

“是的，我明白，”我说，并微微地鞠了一躬。
“Yes, I see,” I said, with a small bow.

“你要的话，我当然可以跟藤原太太说。
“If you wish, I could certainly talk to Mrs Fujiwara.

我相信在这种情况下她很乐意……”
I'm sure under the circumstances she'd be happy to …”

“不，不，悦子”——佐知子笑了起来——“我不想回她的小面馆。
“No, no, Etsuko” — Sachiko gave a laugh — “I've no desire to return to her little noodle shop.

我肯定很快就要离开、到美国去了。
I fully expect to be leaving for America in the near future.

只是稍稍推迟几天，没别的。
It's merely a case of things being delayed a little, that's all.

但是与此同时，你瞧，我需要一点钱。
But in the meantime, you see, I'll need a little money.

我记得，悦子，你以前说过可以帮我。”
And I was just remembering, Etsuko, how you once offered to assist me in that respect.”

她和蔼地微笑着看着我。
She was looking at me with a kindly smile.

我也看着她。
I looked back at her for a few moments.

片刻后，我鞠了一躬，说：
Then I bowed and said:

“我有一些私房钱。
“I have some savings of my own.

不是很多，但是我很乐意尽我所能。”
Not a great deal, but I'd be glad to do what I can.”

佐知子优雅地鞠了一躬，然后拿起她的茶杯，说：“我不会说个数让你为难。
Sachiko bowed gracefully, then lifted her teacup. “I won't embarrass you”, she said, “by naming any particular sum.

要借多少全看你自己。
That, of course, is entirely up to you.

你觉得多少合适，我都会感激地接受。
I'll gratefully accept whatever you feel is appropriate.

当然了，钱会及时归还，这点你尽管放心，悦子。”“那是，”我静静地说。
Of course, the loan will be returned in due course, you can rest assured of that, Etsuko.” “Naturally,” I said, quietly.

“我不担心这个。”
“I had no doubts on that.”

佐知子仍然和蔼地微笑着看着我。
Sachiko continued to regard me with her kindly smile.

我说了声“失陪”，走出房间。
I excused myself and left the room.

卧室里，阳光照射进来，照亮了空气中的灰尘。
In the bedroom, the sun was streaming in, revealing all the dust in the air.

我在柜子底部的一排小抽屉旁跪了下来。
I knelt beside a set of small drawers at the foot of our cupboard.

我打开最底下的那个抽屉，取出各种东西——相册、贺卡、一个装着我母亲画的水彩画的夹子——小心翼翼地将它们放在旁边的地板上。
From the lowest drawer I removed various items — photograph albums, greeting cards, a folder of water-colours my mother had painted — laying them carefully on the floor beside me.

抽屉的最底下放着一个黑色的漆制礼盒。
At the bottom of the drawer was the black lacquer gift-box.

打开盒子，里面装着一些我珍藏的信件——我丈夫不知道这些信件——和两三张小照片。
Lifting the lid, I found the several letters I had preserved — unknown to my husband — together with two or three small photographs.

我从盒子的最底下取出装着钱的信封。
From beneath these, I took out the envelope containing my money.

我小心翼翼地把东西放回原样，关上抽屉。
I carefully put back everything as it had been and closed the drawer.

离开卧室前，我打开衣橱，挑了一条样子合适的丝巾把信封包上。
Before leaving the room, I opened the wardrobe, chose a silk scarf of a suitably discreet pattern, and wrapped it around the envelope.

我回到客厅时，佐知子正在给自己添茶，没有抬起头来看我。
When I returned to the living room, Sachiko was refilling her teacup.

我把包好的丝巾放在她身旁的地板上时，她也没有看，继续倒茶。
She did not look up at me, and when I laid the folded scarf on the floor beside her, she carried on pouring the tea without glancing at it.

我坐下时她朝我点了一下头，然后喝起茶来。
She gave me a nod as I sat down, then began to sip from her cup.

只是在放下杯子时，她很快地用余光瞥了一下坐垫旁的那包东西。
Only once, as she was lowering her teacup, did she cast a quick sideways glance at the bundle beside her cushion.

“你好像有点误会，悦子，”她说。
“There's something you don't seem to understand, Etsuko,” she said.

“你瞧，对我所做的一切，我没有什么觉得丢脸或见不得人的。
“You see, I'm not ashamed or embarrassed about anything I've done.

你想问什么都可以。”
You can feel free to ask whatever you like.”

“是的，当然。”
“Yes, of course.”

“比如说，悦子，你为什么从来不问我‘我的朋友’的事？你坚持这么叫他。
“For instance, Etsuko, why is it you never ask me anything about ‘my friend’, as you insist on calling him?

真的没有什么可丢脸的。怎么了，悦子，你已经开始脸红了。”
There really isn't anything to get embarrassed about. Why, Etsuko, you're beginning to blush already.”

“我向你保证我没有觉得丢脸。
“I assure you I'm not getting embarrassed.

其实……”
In fact …”

“你有，悦子，我看得出来。”
“But you are, Etsuko, I can see you are.”

佐知子笑了一声，拍了一下掌。
Sachiko gave a laugh and clapped her hands together.

“可你为什么不明白我没有什么好隐瞒的，也没有什么好丢脸的？
“But why can't you understand I've nothing to hide, I've nothing to be ashamed of?

你为什么要脸红呢？
Why are you blushing like this?

就因为我提到弗兰克？”
Just because I mentioned Frank?”

“我没有觉得丢脸。
“But I'm not embarrassed.

我向你保证我从没想过……”
And I assure you I've never assumed anything …”

“你为什么从来不问我他的事，悦子？
“Why do you never ask me about him, Etsuko?

你肯定有很多问题想问。为什么不问呢？
There must be all sorts of questions you'd like to ask.

毕竟左邻右舍都很好奇，你一定也是，悦子。所以请别拘束，想问什么就问吧。”
So why don't you ask them? After all, everybody else in the neighbourhood seems interested enough, you must be too, Etsuko.

“可是我真的……”
So please feel free, ask me anything you like.”

“快点，悦子，我要你问。
“But really, I …” “Come on, Etsuko, I insist.

问我他的事。
Ask me about him.

我一定要你问。
I do want you to.

问我他的事吧，悦子。”
Ask me about him, Etsuko.”

“那好吧。”
“Very well then.”

“好？
“Well?

说啊，悦子，问吧。”
Go on, Etsuko, ask.”

“好吧。
“Very well.

他长什么样，你的朋友？”
What does he look like, your friend?”

“他长什么样？”
“What does he look like?”

佐知子又笑了。
Sachiko laughed again.

“你就想知道这个？
“Is that all you wish to know?

好吧，他和一般的老外一样高，他的头发开始变稀了。
Well, he's tall like most of these foreigners, and his hair's going a little thin.

他不老，你明白。
He's not old, you understand.

老外更容易秃头，你知道吗，悦子？
Foreigners go bald more easily, did you know that, Etsuko?

现在再问点别的吧。
Now ask me something else about him.

你肯定还有其他事情想知道。”
There must be other things you want to know.”

“这个，说真的……”
“Well, quite honestly …”

“快点，悦子，问啊。
“Come on, Etsuko, ask.

我要你问。”
I want you to ask.”

“可是我真的没有什么想……”
“But really, there's nothing I wish to …”

“肯定有，你为什么不问呢？
“But there must be, why won't you ask?

问我他的事吧，悦子，问我吧。”
Ask me about him, Etsuko, ask me.”

“好吧，其实，”我说，“我确实想知道一件事。”
“Well, in fact,” I said, “I did wonder about one thing.”

佐知子好像突然僵住了。
Sachiko seemed to suddenly freeze.

她把本来握在胸前的手放下，放回大腿上。
She had been holding her hands together in front of her, but now she lowered them and placed them back on her lap.

“我确实想知道，”我说，“他会不会说日语？”
“I did wonder”, I said, “if he spoke Japanese at all.”

有一会儿，佐知子没有做声。
For a moment, Sachiko said nothing.

然后她笑了，神情变轻松了。
Then she smiled and her manner seemed to relax.

她再次端起茶杯，抿了几口。
She lifted her teacup again and took several sips.

她开口说话时，声音听起来很恍惚。
Then when she spoke again, her voice sounded almost dreamy.

“老外学我们的语言很难，”她说，然后停了一下，出神地笑着。
“Foreigners have so much trouble with our language,” she said. She paused and smiled to herself.

“弗兰克的日语很糟糕，所以我们用英语交谈。
“Frank's Japanese is quite terrible, so we converse in English.

你懂英语吗，悦子？一点都不懂？
Do you know English at all, Etsuko? Not at all?

是这样，以前我父亲英语说得很好。他有亲戚在欧洲，所以他一直鼓励我学英语。
You see, my father used to speak good English. He had connections in Europe and he always used to encourage me to study the language.

不过后来当然了，结婚后，我就不学了。
But then of course, when I married, I stopped learning.

我丈夫不许我学。
My husband forbade it.

他把我的英语书都收走了。
He took away all my English books.

可是我没有忘记英语。
But I didn't forget it.

我在东京遇到老外时就都想起来了。”
When I met foreigners in Tokyo, it came back to me.”

我们静静地坐了一会儿。
We sat in silence for a little while.

然后佐知子疲惫地叹了口气。
Then Sachiko gave a tired sigh.

“我想我得赶快回去了，”她说。
“I suppose I'd better get back fairly soon,” she said.

她弯下腰拿起包好的丝巾，没有打开看，就把它放进手提包里。
She reached down and picked up the folded scarf. Then without inspecting it, she dropped it into her handbag.

“不再喝点茶吗？”
“You won't have a little more tea?”

我问。
I asked.

她耸了耸肩。
She shrugged.

“那就再来一点吧。”
“Just a little more perhaps.”

我给她满上。
I refilled the cups.

佐知子看着我，然后说：“要是不方便——我是说今天晚上——也没有关系。
Sachiko watched me, then said: “If it's inconvenient — about tonight, I mean — it wouldn't matter at all.

万里子这么大了，可以一个人待着。”
Mariko should be capable of being left on her own by now.”

“不要紧。
“It's no trouble.

我肯定我丈夫不会反对的。”
I'm sure my husband won't object.”

“你太好了，悦子，”佐知子有气无力地说。
“You're very kind, Etsuko,” Sachiko said, in a flat tone.

“也许我应该警告你。
Then she said: “I should warn you, perhaps.

我女儿这几天情绪很不好。”
My daughter has been in a somewhat difficult mood these past few days.”

“没关系，”我笑着说。
“That's all right,” I said, smiling.

“我得习惯小孩子的各种脾气。”
“I'll need to get used to children in every kind of mood.”

佐知子又慢慢地喝起茶来，好像并不急着回去。
Sachiko went on drinking her tea slowly. She seemed in no hurry to be returning.

然后放下茶杯，呆呆地看着自己的手背。过了好一会儿，她终于开口说道：“我知道那时长崎这里遭受了可怕的事情。
Then she put down her teacup and for some moments sat examining the back of her hands. “I know it was a terrible thing that happened here in Nagasaki,” she said, finally.

可是东京的情况也很坏。
“But it was bad in Tokyo too.

一周又一周，情况糟透了，不见好转。后来，我们都住在地道和破房子里，到处都是废墟。
Week after week it went on, it was very bad. Towards the end we were all living in tunnels and derelict buildings and there was nothing but rubble.

住在东京的人都目睹了一些可怕的事情。
Everyone who lived in Tokyo saw unpleasant things.

万里子也是。”
And Mariko did too.”

她还是盯着自己的手背。
She continued to gaze at the back of her hands.

“是的，”我说。
“Yes,” I said.

“那段时间一定很艰难。”
“It must have been a very difficult time.”

“这个女人。
“This woman.

你听万里子说起的这个女人。
This woman you've heard Mariko talk about.

是万里子在东京看到的。
That was something Mariko saw in Tokyo.

她在东京还目睹了一些其他的事情，一些可怕的事情，可是她一直记得那个女人。”
She saw other things in Tokyo, some terrible things, but she's always remembered that woman.”

她把手翻过来，看着手心，一会儿看看这手，一会儿看看那手，像是在作比较。
She turned over her hands and looked at the palms looking from one to the other as if to compare them.

“而这个女人，”我说。
“And this woman,” I said.

“在空袭中被炸死了？”
“She was killed in an air-raid?”

“她自杀了。
“She killed herself.

他们说她割断了自己的喉咙。
They said she cut her throat.

我不知道她是谁。
I never knew her.

事情是这样的，那天早上万里子跑了出去。
You see, Mariko went running off one morning.

我不记得她为什么跑出去了，可能是在为什么事情生气。
I can't remember why, perhaps she was upset about something.

反正她跑到街上去了，所以我去追她。
Anyway she went running off out into the streets, so I went chasing after her.

那时还很早，周围没有人。
It was very early, there was nobody about.

万里子跑进一条小巷子里，我跟了过去。
Mariko ran down an alleyway, and I followed after her.

小巷的尽头是一条运河，那个女人跪在那里，前臂浸在水里。
There was a canal at the end and the woman was kneeling there, up to her elbows in water.

一个年轻女人，很瘦。
A young woman, very thin.

我一看见她就知道有什么不对劲。
I knew something was wrong as soon as I saw her.

你瞧，悦子，她转过来，对万里子笑了笑。
You see, Etsuko, she turned round and smiled at Mariko.

我知道有什么不对劲，万里子肯定也感觉到了，因为她停下不跑了。
I knew something was wrong and Mariko must have done too because she stopped running.

一开始我以为那个女人是个瞎子，因为她的眼神，她的眼睛好像什么也看不见。
At first I thought the woman was blind, she had that kind of look, her eyes didn't seem to actually see anything.

然后，她把手臂从水里拿出来，让我们看她抱在水底下的东西。
Well, she brought her arms out of the canal and showed us what she'd been holding under the water.

是个婴儿。
It was a baby.

我拉住万里子，离开了那条巷子。”
I took hold of Mariko then and we came out of the alley.”

我没有说话，等着下文。
I remained silent, waiting for her to continue.

佐知子拿起茶壶给自己倒了些茶。
Sachiko helped herself to more tea from the pot.

“正如我刚才说的，”她说，“我听说那个女人自杀了。
“As I say,” she said, “I heard the woman killed herself.

几天以后。”
That was a few days afterwards.”

“那时万里子几岁？”
“How old was Mariko then?”

“五岁，快六岁了。
“Five, almost six.

她在东京还目睹了一些其他的事情。
She saw other things in Tokyo. But she always remembers that woman.”

可是她一直记得那个女人。”
“She saw everything? She saw the baby?”

“她全看见了？
“Yes.

她看见婴儿了？”“是的。其实，很长时间里，我以为她并不懂得她看见的事情。
Actually, for a long time I thought she hadn't understood what she'd seen.

那天之后她并没有提起这件事。那时她也没有特别不安。
She didn't talk about it afterwards. She didn't even seem particularly upset at the time.

直到一个月左右以后，她才第一次提起这件事。
She didn't start talking about it until a month or so later.

那时我们睡在一栋老建筑里。
We were sleeping in this old building then.

我半夜醒来，看见万里子站着，盯着门口看。
I woke up in the night and saw Mariko sitting up, staring at the doorway.

那里没有门，只有一个出入口。而万里子站着，盯着那里。
There wasn't a door, it was just this doorway, and Mariko was sitting up looking at it.

我吓坏了。
I was quite alarmed.

你知道，那个房子没有门，什么人都可以进去。
You see, there was nothing to stop anyone walking into the building.

我问万里子怎么了，她说有个女人站在那里看着我们。
I asked Mariko what was wrong and she said a woman had been standing there watching us.

我问是什么样的女人，她说是那天早上我们看见的那个。站在门口看着我们。
I asked what sort of woman and Mariko said it was the one we'd seen that morning.

我起来看了看，可是那里并没有人。当然了，很可能是有个女的曾站在那里。
Watching us from the doorway. I got up and looked around but there wasn't anyone there.

那里什么人都可以进去。”“我明白了。
It's quite possible, of course, that some woman was standing there.

万里子把她当作你们见到的那个人了。”
There was nothing to stop anyone stepping inside.”

“我猜想是这样的。
“I see. And Mariko mistook her for the woman you'd seen.”

不管是怎么回事，事情就是这样开始的，万里子对那个女人的幻想。
“I expect that's what happened. In any case, that's when it started, Mariko's obsession with that woman.

我以为她长大以后就会好了，可是最近又开始了。
I thought she'd grown out of it, but just recently it's started again.

如果今天晚上她又说起这个，请不要理她。”“好的，我知道了。”
If she starts to talk about it tonight, please don't pay her any attention.”

“你知道小孩子就是这样，”佐知子说。
“Yes, I see.” “You know how it is with children,” said Sachiko.

“他们编一些事情来玩，结果分不清哪些是真的、哪些是假的。”
“They play at make-believe and they get confused where their fantasies begin and end.”

“是的，我想这一点儿都不奇怪。”
“Yes, I suppose it's nothing unusual really.”

“你瞧，悦子，万里子出生的时候很艰难。”
“You see, Etsuko, things were very difficult when Mariko was born.”

“是的，一定是这样的，”我说。“我很幸运。
“Yes, they must have been,” I said. “I'm very fortunate, I know.”

我知道。”
“Things were very difficult.

“那时很艰难。也许我不应该那时结婚。
Perhaps it was foolish to have married when I did.

毕竟大家都看得出来战争快来了。
After all, everyone could see a war was coming.

可是话说回来，悦子，没有人知道战争是什么样的，那时没有。
But then again, Etsuko, no one knew what a war was really like, not in those days.

我嫁入了一个很有名望的家庭。
I married into a highly respected family.

我从没想到战争会造成这么大的影响。”
I never thought a war could change things so much.”

佐知子放下茶杯，一只手捋了一下头发。
Sachiko put down her teacup and passed a hand through her hair.

然后她很快地笑了一笑。
Then she smiled quickly.

“至于今天晚上，悦子，”她说，“我女儿很会自己跟自己玩。
“As regards tonight, Etsuko,” she said, “my daughter is quite capable of amusing herself.

所以请不用太费心。”
So please don't bother too much with her.”

说起儿子时，藤原太太的脸常常变得疲倦。
Mrs Fujiwara's face often grew weary when she talked about her son.

“他一天天变老，”她说。
“He's becoming an old man,” she was saying.

“很快他就只剩下老姑娘可挑了。”
“Soon he'll have only the old maids to choose from.”

我们坐在她的面摊前的水泥空地。
We were sitting in the forecourt of her noodle shop.

一旁几张桌子上有一些上班族在吃午饭。
Several tables were occupied by office-workers having their lunch.

“可怜的和夫，”我笑了笑，说。
“Poor Kazuo-San,” I said, with a laugh.

“不过我可以理解他的感受。
“But I can understand how he feels.

美智子小姐的事太令人伤心了。
It was so sad about Miss Michiko.

而且他们订婚很长时间了，对吧？”
And they were engaged for a long time, weren't they?”

“三年。
“Three years.

我从不明白干吗要订婚这么长时间。
I never saw the point in these long engagements.

没错，美智子是个好女孩。
Yes, Michiko was a nice girl.

我肯定她会第一个同意我的观点，和夫不应该再这样想着她了。
I'm sure she'd be the first to agree with me about Kazuo mourning her like this.

她会希望和夫继续好好地生活下去。”
She would have wanted him to continue with his life.”

“不过和夫一定很难过。
“It must be difficult for him though.

计划了那么多年的事情最后变成这个样子。”
To have built up plans for so long only for things to end like that.”

“可是这些都已经过去了，”藤原太太说。
“But that's all in the past now,” said Mrs Fujiwara.

“我们都应该把以前的事放在身后。
“We've all had to put things behind us.

你也是，悦子，我记得以前你难过极了。
You too, Etsuko, I remember you were very heartbroken once.

可是你挺过来了，继续生活。”
But you managed to carry on.”

“是的，不过我很幸运。
“Yes, but I was fortunate.

那个时候绪方先生对我很好。
Ogata-San was very kind to me in those days.

要是没有他，我不知道我会怎样。”
I don't know what would have become of me otherwise.”

“是啊，他对你很好。
“Yes, he was very kind to you.

而且当然了，你因此认识了你丈夫。
And of course, that's how you met your husband.

不过这是你应得的。”
But you deserved to be fortunate.”

“要是绪方先生没有收留我，我真不知道我现在会怎样。
“I really don't know where I'd be today if Ogata-San hadn't taken me in.

不过我可以理解他是多么伤心——我是指您的儿子。
But I can understand how difficult it must be — for your son, I mean.

即使是我，我有时也会想起中村君。
Even me I still think about Nakamura-San sometimes.

我忍不住。
I can't help it.

有时候我醒过来，忘了自己在哪里。
Sometimes I wake up and forget.

我以为我还在这里，在中川……”
I think I'm still back here, here in Nakagawa …”

“好了，悦子，别说了。”
“Now, Etsuko, that's no way to talk.”

藤原太太看了我好一会儿，然后叹了口气。
Mrs Fujiwara looked at me for some moments, then gave a sigh.

“不过我也是。
“But it happens to me too.

像你说的，早上，醒来的时候，这事趁你不注意的时候就会找上你。
Like you say, in the mornings, just as you wake, it can catch you unawares.

我常常醒过来，心想我得赶快起来给大家准备早饭。”
I often wake up thinking I'll have to hurry and get breakfast ready for them all.”

我们谁也不说话了。
We fell silent for a moment.

过了一会儿，藤原太太笑了笑。
Then Mrs Fujiwara laughed a little.

“你太坏了，悦子，”她说。
“You're very bad, Etsuko,” she said.

“瞧，你让我都说了这些话。”
“See, you've got me talking like this now.”

“我太傻了，”我说。
“It's very foolish of me,” I said.

“不管怎么说，中村君和我，我们之间从来都没有什么。
“In any case, Nakamura-San and I, there was never anything between us.

我是说，我们并没有定下什么事。”
I mean, nothing had been decided.”

藤原太太还是看着我，出神地点了点头。
Mrs Fujiwara went on looking at me, nodding to some private train of thought.

这时，空地那一边的一个客人站了起来，准备离开。
Then across the forecourt a customer stood up, ready to leave.

我看着藤原太太走向他，是个穿着衬衫的整洁的年轻人。
I watched Mrs Fujiwara go over to him, a neat young man in shirt-sleeves.

他们互相鞠躬，然后愉快地聊了起来。
They bowed to each other and began chatting cheerfully.

那人扣上公文包时说了些什么，藤原太太开心地笑了。
The man made some remark as he buttoned his briefcase and Mrs Fujiwara laughed heartily.

他们又互相鞠了一躬，然后那人消失在午后上班的人群里。
They exchanged bows once more, then he disappeared into the afternoon rush.

我刚好利用这个时间调整一下情绪。
I was grateful for the opportunity to compose my emotions.

藤原太太回来时，我说：
When Mrs Fujiwara came back, I said:

“我得走了。
“I'd better be leaving you soon.

眼下您忙得很。”
You're very busy just now.”

“你坐着休息吧。你才刚来。
“You just stay there and relax.

我给你弄点吃的。”
You've only just sat down.

“不，不用了。”
I'll get you some lunch.”

“听我说，悦子，你要是不在这里吃，可得再过一个小时才能吃到午饭。
“No, that's all right.” “Now, Etsuko, if you don't eat here, you won't eat lunch for another hour.

你知道现在规律的饮食对你来说多么重要。”
You know how important it is for you to eat regularly at this stage.”

“是，我想是的。”
“Yes, I suppose so.”

藤原太太细细地看了我一会儿，然后说：“你现在有那么多的盼头，悦子。
Mrs Fujiwara looked at me closely for a moment. Then she said: “You've everything to look forward to now, Etsuko.

你在为什么事情不开心呢？”
What are you so unhappy about?”

“不开心？
“Unhappy?

可我一点儿也没有不开心。”
But I'm not unhappy in the least.”

她还是看着我，我紧张地笑了笑。
She continued to look at me, and I laughed nervously.

“孩子出生以后，”她说，“你就会开心起来了，相信我。
“Once the child comes,” she said, “you'll be delighted, believe me.

而且你会是个好母亲的，悦子。”
And you'll make a splendid mother, Etsuko.” “I hope so.”

“我希望如此。”
“Of course you will.”

“你肯定会的。”
“Yes.” I looked up and smiled.

“是。”我抬起头来，笑了。
Mrs Fujiwara nodded, then rose to her feet once more.

藤原太太点了点头。然后再次站起身来。佐知子的小屋里越来越暗——屋里只有一盏灯笼——起先我以为万里子在盯着墙上的黑点。
The inside of Sachiko's cottage had grown increasingly dark — there was only one lantern in the room — and at first I thought Mariko was staring at a black mark on the wall.

她伸出一根指头，那个东西动了一下。
She reached out a finger and the shape moved a little.

这时我才发现是一只蜘蛛。
Only then did I realize it was a spider.

“万里子，别碰它。
“Mariko, leave that alone.

这样不好。”
That's not nice.”

她把双手都放到背后，不过还是盯着蜘蛛看。
She put both hands behind her back, but went on staring at the spider.

“以前我们养了一只猫，”她说。
“We used to have a cat once,” she said.

“在我们到这里来之前。
“Before we came here.

那只猫会抓蜘蛛。”
She used to catch spiders.”

“我知道了。
“I see.

住手，别碰它，万里子。”
No, leave it alone, Mariko.”

“可是它没有毒。”
“But it's not poisonous.”

“是没有毒，可是别碰它，很脏。”
“No, but leave it alone, it's dirty.”

“以前我们养的那只猫，它会吃蜘蛛。
“The cat we used to have, she could eat spiders.

我要是吃蜘蛛会怎么样？”
What would happen if I ate a spider?”

“我不知道，万里子。”
“I don't know, Mariko.” “Would I be sick?”

“我会生病吗？”
“I don't know.”

“我不知道。”
I went back to the sewing I had brought with me.

我接着做我带来的针线活。
Mariko continued to watch the spider.

万里子继续盯着蜘蛛。
Eventually she said: “I know why you came here tonight.”

最后她说：“我知道你今晚晚上为什么过来。”
“I came because it's not nice for little girls to be on their own.”

“我来是因为小女孩自己一个人待着不好。”
“It's because of the woman. It's because the woman might come again.”

“是因为那个女人。
“Why don't you show me some more drawings?

是因为那个女人可能会再来。”
The ones you showed me just now were lovely.”

“你干吗不再多拿些画给我看呢？你刚才给我看的那些很漂亮。”
Mariko did not reply. She moved over to the window and looked out into the darkness.

万里子没有回答，走向窗户，看着外面。
“Your mother won't be long now,” I said. “Why don't you show me some more drawings.”

“你妈妈很快就回来了，”我说。
Mariko continued to look into the darkness.

“你干吗不再多拿些画给我看呢？”万里子还是看着外面。最后，她回到去看蜘蛛前坐着的角落。
Eventually, she returned to the corner where she had been sitting before the spider had attracted her attention.

“你今天都做了什么，万里子？”
“How did you spend your day today, Mariko?”

我问。
I asked.

“你画画了吗？”
“Did you do any drawing?”

“我跟小胖和小美玩。”
“I played with Atsu and Mee-Chan.”

“太好了。
“That's nice.

他们住在哪里？
And where do they live?

公寓里吗？”
Are they from the apartments?”

“它是小胖”——她指了指身旁的一只黑色小猫——“它是小美。”
“That's Atsu” — she pointed to one of the small black kittens beside her — “and that's Mee-Chan.”

我笑了。
I laughed.

“哦，我明白了。
“Oh, I see.

是可爱的小猫，是吗？
They're lovely little kittens, aren't they?

不过你不和别的孩子玩吗？
But don't you ever play with other children?

住在公寓里的孩子？”
The children from the apartments?”

“我跟小胖和小美玩。”
“I play with Atsu and Mee-Chan.”

“可是你应该试着和别的孩子交朋友。
“But you should try and make friends with the other children.

我肯定他们都是好孩子。”
I'm sure they're all very nice.”

“他们偷了花花。
“They stole Suji-Chan.

那是我最喜欢的小猫。”
He was my favourite kitten.”

“他们偷了小猫？
“They stole him?

哦天啊，他们为什么要这么做？”
Oh dear, I wonder why they did that.”

万里子开始抚摸小猫。
Mariko began stroking a kitten.

“现在我没有花花了。”
“I've lost Suji-Chan now.”

“也许它很快就会出现了。
“Perhaps he'll turn up soon.

我肯定那些孩子只是玩一玩。”
I'm sure the children were just playing.”

“他们杀了它。
“They killed him.

现在我没有花花了。”
I've lost Suji-Chan now.”

“哦。
“Oh.

他们怎么会做这种事？”
I wonder why they did a thing like that.”

“我向他们扔石头。
“I threw stones at them.

因为他们说了难听的话。”
Because they said things.”

“啊，你不应该扔石头，万里子。”
“Well, you shouldn't throw stones, Mariko.”

“他们说了难听的话。
“They said things.

说妈妈。
About Mother.

我向他们扔石头，他们就偷走了花花，不把它还回来。”
I threw stones at them and they took Suji-Chan and wouldn't give him back.”

“咳，你还有其他的小猫啊。”
“Well, you've still got your other kittens.”

万里子又朝窗户走去。
Mariko moved across the room towards the window again.

她的个子刚好够让她把手肘靠在窗沿上。
She was just tall enough to lean her elbows on the ledge.

有几分钟的时间，她看着外面，脸贴在窗户上。
For a few minutes she looked into the darkness, her face close to the pane.

“我想出去，”她突然说。
“I want to go out now,” she said, suddenly.

“出去？
“Go out?

可是已经很晚了，外面很黑。
But it's far too late, it's dark outside.

而且你妈妈就快回来了。”
And your mother will be back any time now.”

“可是我想出去。”
“But I want to go out.”

“待在这里，万里子。”
“Stay here now, Mariko.”

她还是看着外面。
She continued to look outside.

我试着看看她看到了什么；从我坐的地方我只看到一片漆黑。
I tried to see what was visible to her; from where I sat I could see only darkness.

“也许你应该对其他孩子好一点。
“Perhaps you should be kinder to the other children.

这样你就可以和他们交朋友了。”
Then you could make friends with them.”

“我知道妈妈为什么叫你来。”
“I know why Mother asked you to come here.”

“你要是扔石头，怎么能交得到朋友呢？”
“You can't expect to make friends if you throw stones.”

“是因为那个女人。
“It's because of the woman.

是因为妈妈知道那个女人。”
It's because Mother knows about the woman.”

“我不知道你在说什么，万里子。
“I don't understand what you're talking about, Mariko-San.

再跟我说说你的小猫。
Tell me more about your kittens.

它们长大一些，你还会再给它们画画吗？”
Will you draw more pictures of them when they get bigger?”

“是因为那个女人可能会再来。
“It's because the woman might come again.

所以妈妈叫你来。”
That's why Mother asked you.”

“我想不是这样。”
“I don't think so.”

“妈妈见过那个女人。
“Mother's seen the woman.

前两天的一个晚上，她看见她了。”
She saw her the other night.”

我猛地停下手里的针线活，抬起头来看万里子。
I stopped sewing for a second and looked up at Mariko.

她不再看着窗外，而是面无表情地看着我，样子很奇怪。
She had turned away from the window and was gazing at me with a strangely expressionless look.

“你妈妈是在哪里看见这个——这个人的？”
“Where did your mother see this — this person?”

“那里。
“Out there.

在那里看见的。
She saw her out there.

所以她叫你来。”
That's why she asked you.”

万里子离开窗户，回到她的小猫身边。
Mariko came away from the window and returned to her kittens.

母猫出现了，小猫都偎依到妈妈怀里。
The older cat had appeared and the kittens had curled up to their mother.

万里子在它们旁边躺下，小声地说起话来。
Mariko lay down beside them and started to whisper.

她的低语让人隐隐地觉得不安。
Her whispering had a vaguely disturbing quality.

“你妈妈就快回来了，”我说。
“Your mother should be home soon,” I said.

“她现在会在干什么呢？”
“I wonder what she can be doing.”

万里子仍旧在低语。
Mariko continued whispering.

“她跟我说了好多弗兰克的事，”我说。
“She was telling me all about Frank-San,” I said.

“他听上去是个好人。”
“He sounds a very nice man.”

万里子不做声了。
The whispering noises stopped.

一刹那间，我们面面相觑。
We stared at each other for a second.

“他是个坏蛋，”万里子说。
“He's a bad man,” Mariko said.

“你这样说可不好，万里子。
“Now that's not a nice thing to say, Mariko-San.

你妈妈跟我说了好多弗兰克的事，他听上去确实是个好人。
Your mother told me all about him and he sounds very nice.

而且我相信他对你很好，不是吗？”
And I'm sure he's very kind to you, isn't he?”

她站起来，走向墙壁。
She got to her feet and went to the wall.

蜘蛛还在那里。
The spider was still there.

“对，我相信他是个好人。
“Yes, I'm sure he's a nice man.

他对你很好，不是吗，万里子？”
He's kind to you, isn't he, Mariko-San?”

万里子伸出手去。
Mariko reached forward.

蜘蛛沿着墙壁慢慢地爬着。
The spider moved quite slowly along the wall.

“万里子，别碰它。”
“Mariko, leave that alone.”

“我们在东京养的那只猫，它会抓蜘蛛。
“The cat we had in Tokyo, she used to catch spiders.

我们本来要把它带来的。”
We were going to bring her with us.”

蜘蛛挪了地方以后，我看得更清楚了。
I could see the spider more clearly in its new position.

它的腿又粗又短，每一条腿都在黄色的墙壁上投下一道阴影。
It had thick short legs, each leg casting a shadow on the yellow wall.

“它是只好猫，”万里子接着说。
“She was a good cat,” Mariko continued.

“它本来要和我们一起来长崎。”
“She was going to come with us to Nagasaki.”

“你们带它来了吗？”
“And did you bring her?”

“它不见了。
“She disappeared.

我们出发的前一天。
The day before we were leaving.

妈妈答应说我们可以带上它的，可是它不见了。”
Mother promised we could bring her, but she disappeared.” “I see.”

“这样啊。”
She moved suddenly and caught one of the spider's legs.

她突然伸出手去，抓住了蜘蛛的一条腿，把它从墙壁上拿下来。其他几条腿在空中疯狂地乱舞。
The remaining legs crawled frantically around her hand as she brought it away from the wall.

“万里子，放开它。
“Mariko, let that go.

它很脏。”
That's dirty.”

万里子把手翻过来，蜘蛛爬到她的手掌上。
Mariko turned over her hand and the spider crawled into her palm.

她把另一只手盖上，把蜘蛛关在里面。
She closed her other hand over it so that it was imprisoned.

“万里子，放开它。”
“Mariko, put that down.”

“它没有毒，”她说，向我走来。
“It's not poisonous,” she said, coming closer to me.

“没有毒，可是很脏。
“No, but it's dirty.

放回角落去。”
Put it back in the corner.”

“可是它没有毒。”
“It's not poisonous though.”

她站在我面前，蜘蛛合在她手里。
She stood in front of me, the spider inside her cupped hands.

我从她的手指缝里看见蜘蛛的一条腿在慢慢地、有节奏地抖动。
Through a gap in her fingers, I could see a leg moving slowly and rhythmically.

“把它放回角落去，万里子。”
“Put it back in the corner, Mariko.”

“我把它吃了会怎么样？
“What would happen if I ate it?

它没有毒。”
It's not poisonous.”

“你会得重病的。
“You'd be very sick.

好了，万里子，把它放回角落去。”
Now, Mariko, put it back in the corner.”

万里子把蜘蛛拿到嘴边，张开嘴巴。
Mariko brought the spider closer to her face and parted her lips.

“别傻了，万里子。
“Don't be silly, Mariko.

很脏。”
That's very dirty.”

她张大嘴巴，然后分开合着的手，蜘蛛掉在我的正前方。
Her mouth opened wider, and then her hands parted and the spider landed in front of my lap.

我吓得往后退。
I started back.

蜘蛛飞快地沿着榻榻米跑进我身后的黑暗里去。
The spider sped along the tatami into the shadows behind me.

我过了一会儿才回过神来，这时万里子已经跑出小屋了。
It took me a moment to recover, and by then Mariko had left the cottage.

# 第一部 · 第六章 | PART ONE · Chapter Six

我不知道那天晚上我找她找了多久。
I cannot be sure now how long I spent searching for her that night.

应该是挺久的，因为那时我的肚子已经很大了，我总是当心行动不能太匆忙。
Quite possibly it was for a considerable time, for I was advanced in my pregnancy by then and careful to avoid hurried movements.

而且，到了外面，我突然发现走在河边十分惬意。
Besides, once having come outside, I was finding it strangely peaceful to walk beside the river.

河岸上有块地方草长得很高。
Along one section of the bank, the grass had grown very tall.

那天晚上我一定是穿着木屐，因为我清楚地记得草在我脚边的感觉。
I must have been wearing sandals that night for I can remember distinctly the feel of the grass on my feet.

我走着，身边一直萦绕着昆虫的叫声。
As I walked, there were insects making noises all around me.

最后我终于听出来其中有个沙沙的声音，像有条蛇在我身后的草地里爬行。
Then eventually I became aware of a separate sound, a rustling noise as if a snake were sliding in the grass behind me.

我停下来细听，发现了声音的来源；一条旧绳子缠在我的脚踝上，我在草地里一直拖着它。
I stopped to listen, then realized what had caused it; an old piece of rope had tangled itself around my ankle and I had been dragging it through the grass.

我小心地把它从脚上解下来。
I carefully released it from around my foot.

我把它拿到月光底下，它在我手指里湿漉漉的，满是泥。
When I held it up to the moonlight it felt damp and muddy between my fingers.

“喂，万里子，”我喊道，她就坐在我前面不远的草丛里，蜷起腿，下巴靠在膝盖上。
“Hello, Mariko,” I said, for she was sitting in the grass a short way in front of me, her knees hunched up to her chin.

一棵柳树——河岸上有几株柳树——垂到她坐的地方。
A willow tree — one of several that grew on the bank — hung over the spot where she sat.

我往前走了几步，把她的脸看得更清楚些。
I took a few steps towards her until I could make out her face more clearly.

“那是什么？”她问。
“What's that?” she asked.

“没什么。
“Nothing.

我走路时，它缠住我的脚了。”
It just tangled on to my foot when I was walking.”

“到底是什么？”
“What is it though?”

“没什么，只是一条旧绳子。
“Nothing, just a piece of old rope.

你为什么跑到这里来？”
Why are you out here?”

“你要一只小猫吗？”
“Do you want to take a kitten?”

“一只小猫？”
“A kitten?”

“妈妈说我们不能带着小猫。
“Mother says we can't keep the kittens.

你要一只吗？”
Do you want one?”

“我不想要。”
“I don't think so.”

“可是我们得赶快帮它们找到一个家。
“But we have to find homes for them soon.

不然妈妈说我们就得把它们淹死。”
Or else Mother says we'll have to drown them.”

“那太遗憾了。”
“That would be a pity.”

“你可以要小胖。”
“You could have Atsu.”

“这得看看。”
“We'll have to see.”

“你干吗拿着那个？”
“Why have you got that?”

“我说了，没什么。
“I told you, it's nothing.

它缠住我的脚了。”
It just caught on to my foot.”

我往前一步。
I took a step closer.

“你这是做什么，万里子？”
“Why are you doing that, Mariko?”

“做什么？”
“Doing what?”

“你刚刚的表情很奇怪。”
“You were making a strange face just now.”

“我没有。
“I wasn't making a strange face.

你干吗拿着绳子？”
Why have you got the rope?”

“你刚刚的表情很奇怪。
“You were making a strange face.

非常奇怪。”
It was a very strange face.”

“你干吗拿着绳子？”
“Why have you got the rope?”

我注视了她一会儿。
I watched her for a moment.

她的脸上露出害怕的样子。
Signs of fear were appearing on her face.

“那么，你不想要小猫吗？”她问。
“Don't you want a kitten then?” she asked.

“不，我不想要。
“No, I don't think so.

你是怎么了？”
What's the matter with you?”

万里子站了起来。
Mariko got to her feet.

我走到柳树底下，看见小屋在不远处，屋顶的颜色比天空深。
I came forward until I reached the willow tree. I noticed the cottage a short distance away, the shape of its roof darker than the sky.

我听见万里子跑进黑暗里的脚步声。
I could hear Mariko's footsteps running off into the darkness.

我回到小屋的门口，听见里面传来佐知子生气的声音。
When I reached the door of the cottage, I could hear Sachiko's voice from within, talking angrily.

我进屋时，母女俩都转过来看我。
They both turned to me as I came in.

佐知子站在屋子中央，她女儿在她面前。
Sachiko was standing in the middle of the room, her daughter before her.

她精心打扮的脸在灯笼的照射下像一张面具。
In the light cast by the lantern, her carefully prepared face had a mask-like quality.

“恐怕万里子给你添麻烦了，”她对我说。
“I fear Mariko's been giving you trouble,” she said to me.

“啊，她跑到外面去了……”
“Well, she ran outside …”

“跟悦子道歉。”
“Say sorry to Etsuko-San.”

她狠狠地抓着万里子的胳膊。
She gripped Mariko's arm roughly.

“我还要出去。”
“I want to go outside again.”

“你不许动。
“You won't move.

马上道歉。”
Now apologize.”

“我要出去。”
“I want to go outside.”

佐知子举起一只手重重地打孩子的大腿背。
With her free hand, Sachiko slapped the child sharply on the back of her thigh.

“马上跟悦子道歉。”
“Now, apologize to Etsuko-San.”

万里子的眼睛里闪烁着小小的泪珠。
Small tears were appearing in Mariko's eyes.

她很快地瞥了我一眼，然后转向她妈妈。
She looked at me briefly, then turned back to her mother.

“你为什么老是出去？”
“Why do you always go away?”

佐知子再次举起手来警告她。
Sachiko raised her hand again warningly.

“你为什么老是和弗兰克出去？”
“Why do you always go away with Frank-San?”

“你要不要道歉？”
“Are you going to say you're sorry?”

“弗兰克像猪一样撒尿。
“Frank-San pisses like a pig.

他是臭水沟里的猪。”
He's a pig in a sewer.”

佐知子吃惊地看着她的孩子，手停在半空中。
Sachiko stared at her child, her hand still poised in the air.

“他喝自己的尿。”
“He drinks his own piss.”

“住嘴。”
“Silence.”

“他喝自己的尿，还在床上大便。”
“He drinks his own piss and he shits in his bed.”

佐知子还是生气地盯着她，人却呆住了。
Sachiko continued to glare, but remained quite still.

“他喝自己的尿。”
“He drinks his own piss.”

万里子挣开佐知子的手臂，若无其事地走过客厅。
Mariko pulled her arm free and walked across the room with an air of nonchalance.

走到玄关，她转过身来，回瞪着她妈妈。
At the entryway she turned and stared back at her mother.

“他像猪一样撒尿，”她又说了一遍，然后跑了出去。
“He pisses like a pig,” she repeated, then went out into the darkness.

佐知子还是盯着玄关，显然忘了我的存在。
Sachiko stared at the entryway for some moments, apparently oblivious of my presence.

“不去追她吗？”
“Shouldn't someone go after her?”

过了一会儿，我说。
I said, after a while.

佐知子看着我，好像稍微缓过来了。
Sachiko looked at me and seemed to relax a little.

“不用，”她边说边坐下来。
“No,” she said, sitting down.

“别管她。”
“Leave her.”

“可是已经很晚了。”
“But it's very late.”

“别管她。
“Leave her.

她高兴了就会回来了。”
She can come back when she pleases.”

水壶已经在炉子上滚了好一会儿了。
A kettle had been steaming on the open stove for some time.

佐知子把它从火上拿开，开始泡茶。
Sachiko took it off the flame and began making tea.

我看了她一会儿，然后静静地问：
I watched her for several moments, then asked quietly:

“找到你的朋友了吗？”
“Did you find your friend?”

“是的，悦子，”她说。
“Yes, Etsuko,” she said.

“我找到他了。”
“I found him.”

她继续泡茶，没有抬起头来看我。
She continued with her tea-making, not looking up at me.

然后她说：“太谢谢你今天晚上到这里来了。
Then she said: “It was very kind of you to have come here tonight.

我为万里子的事道歉。”
I do apologize about Mariko.”

我还是看着她。
I continued to watch her.

最后，我说：“你现在打算怎么办？”
Eventually, I said: “What are your plans now?”

“打算怎么办？”
“My plans?”

佐知子添满茶壶，把剩下的水倒到火里。
Sachiko finished filling the teapot, then poured the remaining water on to the flame.

“悦子，我跟你说过很多次了，对我来说最重要的是我女儿的幸福。
“Etsuko, I've told you many times, what is of the utmost importance to me is my daughter's welfare.

这是我优先考虑的。
That must come before everything else.

毕竟我是个母亲。
I'm a mother, after all.

我不是什么不懂得自重的年轻酒吧女郎。
I'm not some young saloon girl with no regard for decency.

我是个母亲，我女儿的利益是第一位的。”
I'm a mother, and my daughter's interests come first.”

“当然。”
“Of course.”

“我打算给我的伯父写信。
“I intend to write to my uncle.

我要告诉他我的行踪，他有权知道我现在的情况，我会都告诉他。
I'll inform him of my whereabouts and I'll tell him as much as he has a right to know about my present circumstances.

然后他同意的话，我要跟他商量我们有没有可能回那里去。”
Then if he wishes, I'll discuss with him the possibilities of our returning to his house.”

佐知子双手拿起茶壶，轻轻地摇晃起来。
Sachiko picked up the teapot in both hands and began to shake it gently.

“事实上，悦子，我很高兴事情变成这个样子。
“As a matter of fact, Etsuko, I'm rather glad things have turned out like this.

想象一下我女儿会多么的不习惯，突然发现自己在一个都是老外的地方，一个都是老美的地方。
Imagine how unsettling it would have been for my daughter, finding herself in a land full of foreigners, a land full of Ame-kos.

突然有一个老美做爸爸，想象一下她会多么不知所措。
And suddenly having an Ame-ko for a father, imagine how confusing that would be for her.

你明白我说的话吗，悦子？
Do you understand what I'm saying, Etsuko?

她这辈子已经有太多的动荡不安了，她应该找个地方安顿下来。
She's had enough disturbance in her life already, she deserves to be somewhere settled.

事情变成这个样子也好。”
It's just as well things have turned out this way.”

我嘟囔了一声表示同意。
I murmured something in assent.

“孩子，悦子，”她接着说，“就意味着责任。
“Children, Etsuko,” she went on, “mean responsibility.

你很快就会明白这点了。
You'll discover that yourself soon enough.

这就是他害怕的，谁都看得出来。
And that's what he's really scared of, anyone can see that.

他怕万里子。
He's scared of Mariko.

这个，我不能接受，悦子。
Well, that's not acceptable to me, Etsuko.

我必须先考虑我的女儿。
My daughter comes first.

事情变成这个样子也好。”
It's just as well things have turned out this way.”

她的手还在摇晃着茶壶。
She went on rocking the teapot in her hands.

“你一定很失望吧，”最后，我说道。
“This must be very distressing for you,” I said, eventually.

“失望？”
“Distressing?”

——佐知子笑了——“悦子，你以为这种小事会让我失望吗？
— Sachiko laughed — “Etsuko, do you imagine little things like this distress me?

我在你这个年纪时也许会。
When I was your age, perhaps.

可是现在不会了。
But not any more.

过去这几年，我经历了太多的事情。
I've gone through too much over the last few years.

不管怎样，我料到会这样。
In any case, I was expecting this to happen.

哦没错，我一点也不惊讶。
Oh yes, I'm not surprised at all.

我料到了。
I expected this.

上次，在东京，也差不多是这样。
The last time, in Tokyo, it was much the same.

他不见了，把我们的钱都花光了，三天内全都喝光了。
He disappeared and spent all our money, drank it all in three days.

其中很多是我的钱。
A lot of it was my money too.

你知道吗？悦子，我甚至在旅馆里当女佣。
Do you know, Etsuko, I actually worked as a maid in a hotel?

没错，当女佣。
Yes, as a maid.

可是我不抱怨，我们钱凑得差不多了，再过几个星期我们就可以坐船去美国了。
But I didn't complain, and we almost had enough, a few more weeks and we could have got a ship to America.

可是他把钱全喝光了。
But then he drank it all.

那么多个星期，我跪在地上擦地板，可是他三天内就全都喝光了。
All those weeks I spent scrubbing floors on my knees and he drank it all up in three days.

这次他又来了，和一文不值的酒吧女郎泡在酒吧里。
And now there he is again, in a bar with his worthless saloon girl.

我怎么能把我女儿的未来交到他这种人的手上？
How can I place my daughter's future in the hands of a man like that?

我是个母亲，我必须先考虑我的女儿。”
I'm a mother, and my daughter comes first.”

我们又都不说话了。
We fell silent again.

佐知子把茶壶放下，盯着它。
Sachiko put the teapot down in front of her and stared at it.

“我希望你伯父能理解你，”我说。
“I hope your uncle will prove understanding,” I said.

她耸了耸肩。
She gave a shrug.

“至于我伯父，悦子，我会和他商量的。
“As far as my uncle's concerned, Etsuko, I'll discuss the matter with him.

我愿意为了万里子而这么做。
I'm willing to do so for Mariko's sake.

他要是不同意，我就再想别的办法。
If he proves unhelpful, then I'll just find some alternative course.

反正我不打算陪着一个洋酒鬼去美国。
In any case, I've no intention of accompanying some foreign drunkard to America.

我很高兴他找了个酒吧女郎陪他喝酒，我肯定他们真是般配。
I'm quite happy he's found some saloon girl to drink with him, I'm sure they deserve one another.

可是至于我，我要做对万里子最好的事情，这就是我的决定。”
But as far as I'm concerned, I'm going to do what's best for Mariko, and that's my decision.”

佐知子又盯着茶壶看了一会儿。
For some time, Sachiko continued to stare at the teapot.

然后她叹了一口气，站了起来，走向窗户，往外看。
Then she sighed and got to her feet. She went over to the window and peered out into the darkness.

“我们现在不去找她吗？”
“Should we go and look for her now?”

我说。
I said.

“不用，”佐知子边看着窗外边说。
“No,” Sachiko said, still looking out.

“她很快就会回来了。
“She'll be back soon.

她想待在外面就让她待在外面吧。”
Let her stay out if that's what she wants.”

如今的我无限追悔以前对景子的态度。
I feel only regret now for those attitudes I displayed towards Keiko.

毕竟在这个国家，像她那个年纪的年轻女孩想离开家不是想不到的。
In this country, after all, it is not unexpected that a young woman of that age should wish to leave home.

我做成的事似乎就是让她在最后真的离开家时——事情已经过去快六年了——切断了和我的所有关系。
All I succeeded in doing, it would seem, was to ensure that when she finally left — now almost six years ago — she did so severing all her ties with me.

可是我怎么也想不到她这么快就消失得无影无踪；我所能预见的是待在家里不开心的女儿会发现承受不了外面的世界。
But then I never imagined she could so quickly vanish beyond my reach; all I saw was that my daughter, unhappy as she was at home, would find the world outside too much for her.

我是为了她好才一直强烈反对她的。
It was for her own protection I opposed her so vehemently.

那天早上——妮基来的第五天——我很早就醒过来，脑子里的第一个念头是我没有听到这几个晚上和清晨都能听到的雨声。
That morning — the fifth day of Niki's visit — I awoke during the early hours. What occurred to me first was that I could no longer hear the rain as on previous nights and mornings.

然后我想起了是什么让我醒过来。
Then I remembered what had awoken me.

我躺在被窝里，来来回回地看在微光中依稀可见的东西。
I lay under the covers looking in turn at those objects visible in the pale light.

几分钟后，我感觉平静了一些，就又闭上眼睛。
After several minutes, I felt somewhat calmer and closed my eyes again.

可是我并没有睡。
I did not sleep, however.

我想着那个房东——景子的房东——想着她是怎样终于打开曼彻斯特的房门的。
I thought of the landlady — Keiko's landlady — and how she had finally opened the door of that room in Manchester.

我睁开眼睛，又看着房间里的东西。
I opened my eyes and once more looked at the objects in the room.

最后我爬起来，穿上晨衣，去盥洗室。
Finally I rose and put on my dressing gown.

我小心不吵醒睡在我隔壁客房里的妮基。
I made my way to the bathroom, taking care not to arouse Niki, asleep in the spare room next to mine.

当我走出盥洗室时，我在楼梯口站了一会儿。
When I came out of the bathroom, I remained standing on the landing for some time.

楼梯的那边，走廊的尽头，可以看见景子的房门。
Beyond the staircase, at the far end of the hallway, I could see the door of Keiko's room.

门和平时一样关着。
The door, as usual, was shut.

我直盯着门，然后往前迈开步子。
I went on staring at it, then moved a few steps forward.

最后我来到了房门前。
Eventually, I found myself standing before it.

我站在那里，好像听见一个细小的声音，是里面传来的动静。
Once, as I stood there, I thought I heard a small sound, some movement from within.

我又听了一会儿，可是什么也听不见了。
I listened for a while but the sound did not come again.

我伸出手去，打开门。
I reached forward and opened the door.

灰暗的光线里，景子的房间显得凄凉；床上只有一条床单，旁边是她的白色梳妆台，地上有几个纸板箱，装着她没有带到曼彻斯特去的东西。
Keiko's room looked stark in the greyish light; a bed covered with a single sheet, her white dressing table, and on the floor, several cardboard boxes containing those of her belongings she had not taken with her to Manchester.

我走进房间。
I stepped further into the room.

窗帘开着，我能看见下面的果园。
The curtains had been left open and I could see the orchard below.

天空露出鱼肚白；似乎没有在下雨。
The sky looked pale and white; it did not appear to be raining.

窗户下、草地上，两只鸟在啄着掉下来的苹果。
Beneath the window, down on the grass, two birds were pecking at some fallen apples.

这时，我开始觉得冷，于是回到自己的房间。
I started to feel the cold then and returned to my room.

“我的一个朋友在写一首关于你的诗，”妮基说。
“A friend of mine's writing a poem about you,” said Niki.

我们正在厨房里吃早饭。
We were eating breakfast in the kitchen.

“关于我？
“About me?

为什么呢？”
Why on earth is she doing that?”

“我跟她说了你的事，她就决定要写一首诗。
“I was telling her about you and she decided she'd write a poem.

她是个才华横溢的诗人。”
She's a brilliant poet.”

“一首关于我的诗？
“A poem about me?

太荒唐了。
How absurd.

有什么可写的？
What is there to write about?

她都不认识我。”
She doesn't even know me.”

“我说了，妈妈，我跟她说了你的事。
“I just said, Mother. I told her about you.

她理解人的能力真是惊人。
It's amazing how well she understands people.

你瞧，她自己也经历了很多事情。”
She's been through quite a bit herself, you see.”

“我明白了。
“I see.

你这个朋友几岁？”
And how old is this friend of yours?”

“妈妈，你总是关心别人几岁。
“Mother, you're always so obsessed about how old people are.

人重要的不是年龄，而是经历。
It doesn't matter how old someone is, it's what they've experienced that counts.

有的人活到一百岁也没经历过什么事。”
People can get to be a hundred and not experience a thing.”

“我想是的。”
“I suppose so.”

我笑了，瞥了一眼窗子。
I gave a laugh and glanced towards the windows.

外面下起了蒙蒙细雨。
Outside, it had started to drizzle.

“我跟她说了你的事，”妮基说。
“I was telling her about you,” Niki said.

“你的、爸爸的，还有你们是怎么离开日本的。
“About you and Dad and how you left Japan.

她听了以后印象深刻。
She was really impressed.

她能体会事情是什么样的，知道做起来并不像听起来的那么容易。”
She appreciates what it must have been like, how it wasn't quite as easy as it sounds.”

我盯着窗子看了一会儿。
For a moment, I went on gazing at the windows.

然后我很快地说：“我相信你的朋友一定能写出一首好诗。”
Then I said quickly: “I'm sure your friend will write a marvellous poem.”

我从水果篮里拿了一个苹果，妮基看着我拿起小刀来削。
I took an apple from the fruit basket and Niki watched as I began to peel it with my knife.

“很多女人，”她说，“被孩子和讨厌的丈夫捆住手脚，过得很不开心。
“So many women”, she said, “get stuck with kids and lousy husbands and they're just miserable.

可是她们没有勇气改变一切。
But they can't pluck up the courage to do a thing about it.

就这么过完一生。”
They'll just go on like that for the rest of their lives.”

“嗯哼。
“I see.

所以你是说她们应该抛弃孩子，是吗，妮基？”
So you're saying they should desert their children, are you, Niki?”

“你知道我的意思。
“You know what I mean.

人浪费生命是悲惨的。”
It's pathetic when people just waste away their lives.”

我没有做声，虽然我女儿停了下来，像是在等着我回答。
I did not speak, although my daughter paused as if expecting me to do so.

“一定很不容易，你做的那些，妈妈。
“It couldn't have been easy, what you did, Mother.

你应该为你所做的感到自豪。”
You ought to be proud of what you did with your life.”

我继续削苹果。
I continued to peel the apple.

削完后，拿纸巾擦干手指。
When I had finished, I dried my fingers on the napkin.

“我的朋友们也都这么想，”妮基说。
“My friends all think so too,” said Niki.

“那些知道你的事的。”
“The ones I've told anyway.”

“我真是受宠若惊。
“I'm very flattered.

谢谢你那些了不起的朋友。”
Please thank your marvellous friends.”

“我只是说说而已。”
“I was just saying, that's all.”

“你已经把意思说得很清楚了。”
“Well, you've made your point quite clearly now.”

也许那天早上我没有必要敷衍她，不过妮基一直觉得应该在这些事情上把我劝开。
Perhaps I was unnecessarily curt with her that morning, but then it was presumptious of Niki to suppose I would need reassuring on such matters.

再者，其实她并不知道我们在长崎的最后那段日子究竟发生了什么。
Besides, she has little idea of what actually occurred during those last days in Nagasaki.

她可能是通过她父亲告诉她的事构建了一些图画。
One supposes she has built up some sort of picture from what her father has told her.

这样的图画不可避免是不准确的。
Such a picture, inevitably, would have its inaccuracies.

事实上，虽然我的丈夫写了很多令人印象深刻的关于日本的文章，但是他从不曾理解我们的文化，更不理解二郎这样的人。
For, in truth, despite all the impressive articles he wrote about Japan, my husband never understood the ways of our culture, even less a man like Jiro.

我并非在深情地怀念二郎，可是他绝不是我丈夫想的那种呆呆笨笨的人。
I do not claim to recall Jiro with affection, but then he was never the oafish man my husband considered him to be.

二郎努力为家庭尽到他的本分，他也希望我尽到我的本分；在他自己看来，他是个称职的丈夫。
Jiro worked hard to do his part for the family and he expected me to do mine; in his own terms, he was a dutiful husband.

而确实，在他当女儿父亲的那七年，他是个好父亲。
And indeed, for the seven years he knew his daughter, he was a good father to her.

不管在最后的那段日子里，我如何说服自己，我从不假装景子不会想念他。
Whatever else I convinced myself of during those final days, I never pretended Keiko would not miss him.

不过这些事情都已经过去了，我也不愿再去想它们。
But such things are long in the past now and I have no wish to ponder them yet again.

我离开日本的动机是正当的，而且我知道我时刻把景子的利益放在心上。
My motives for leaving Japan were justifiable, and I know I always kept Keiko's interests very much at heart.

再想这些也没什么用了。
There is nothing to be gained in going over such matters again.

我正在修剪窗台上的盆栽，弄着弄着，突然发觉妮基很安静。
I had been pruning the pot plants along the window ledge for some time when I realized how quiet Niki had become.

我转过头去看她，她站在壁炉前，视线越过我，看着外面的园子。
When I turned to her, she was standing in front of the fireplace, looking past me out into the garden.

我回头看窗外，顺着她的视线看她在看什么；虽然玻璃上有雾，但仍然可以看清楚花园。
I turned back to the window, trying to follow her gaze; despite the mist on the pane, the garden was still clearly discernible.

妮基好像是在看着篱笆附近，那里风和雨打进来，打乱了支撑幼小的西红柿的藤。
Niki, it seemed, was gazing over to a spot near the hedge, where the rain and wind had put into disarray the canes which supported the young tomato plants.

“我想那些西红柿今年是不行了，”我说。
“I think the tomatoes are ruined for this year,” I said.

“我都没怎么去管它们。”
“I've really rather neglected them.”

我仍旧看着那些藤，突然听见抽屉被打开的声音。我再次转过头去，妮基正在翻抽屉。
I was still looking at the canes when I heard the sound of a drawer being pulled open, and when I turned again, Niki was continuing with her search.

早饭后，她决定把她爸爸在报纸上发表的文章统统读一遍，一早上大部分时间花在了翻找家里的抽屉和书架上。
She had decided after breakfast to read through all her father's newspaper articles, and had spent much of the morning going through all the drawers and bookshelves in the house.

我继续整理我的盆栽；盆栽有不少，杂乱地堆满窗台。身后，我能听见妮基翻抽屉的声音。
For some minutes, I continued working on my pot plants; there were a large number of them, cluttering the window ledge. Behind me, I could hear Niki going through the drawers.

突然她又没有声响了。我转过头去时，她的视线再次越过我，看着外面的园子。
Then she became quiet again, and when I turned to her, she was once more gazing past me, out into the garden.

“我要去喂金鱼，”她说。
“I think I'll go and do the goldfish now,” she said.

“金鱼？”
“The goldfish?”

妮基没有回答就走了出去，一会儿我看见她大步走过草坪。
Without replying, Niki left the room, and a moment later I saw her go striding across the lawn.

我擦掉玻璃上的一块雾，看着她。
I wiped away a little mist from the pane and watched her.

妮基走到花园的尽头，走到假山中的鱼池。
Niki walked to the far end of the garden, to the fish-pond amidst the rockery.

她把饲料倒进鱼池，在那里站了几秒钟，盯着鱼池。
She poured in the feed, and for several seconds remained standing there, gazing into the pond.

我可以看见她的侧影；她很瘦，虽然穿着时髦衣服，却明显还是有些孩子气。
I could see her figure in profile; she looked very thin, and despite her fashionable clothes there was still something unmistakably childlike about her.

我看着风吹乱她的头发，心想她怎么不穿外衣就出去了。
I watched the wind disturb her hair and wondered why she had gone outside without a jacket.

往回走时，她在西红柿边上停下。尽管雨点不小，她还是站在那里观察了它们一会儿。
On her way back, she stopped beside the tomato plants and in spite of the heavy drizzle stood contemplating them for some time.

接着她走近几步，开始小心翼翼地把藤弄直起来。
Then she took a few steps closer and with much care began straightening the canes.

她扶起几根完全倒下去的藤，然后蹲了下来，膝盖几乎碰到了湿漉漉的草地，把我放在地上、用来赶走偷吃的鸟儿的网弄正。
She stood up several that had fallen completely, then, crouching down so her knees almost touched the wet grass, adjusted the net I had laid above the soil to protect the plants from marauding birds.

“谢谢你，妮基，”她进屋时我对她说。
“Thank you, Niki,” I said to her when she came in.

“你太有心了。”
“That was very thoughtful of you.”

她嘟囔了一声，在长靠背椅上坐下。
She muttered something and sat down on the settee.

我注意到她变得有些不好意思。
I noticed she had become quite embarrassed.

“我今年真的没怎么去管那些西红柿，”我又说道。
“I really have been rather neglectful about those tomatoes this year,” I went on.

“不过我想也没什么关系。
“Still, it doesn't really matter, I suppose.

现在那么多的西红柿我都不知道该怎么办。
I never know what to do with so many tomatoes these days.

去年，我把大部分都给了莫里森夫妇。”
Last year, I gave most of them to the Morrisons.”

“哦天啊，”妮基说，“莫里森夫妇。
“Oh God,” said Niki, “the Morrisons.

亲爱的莫里森老两口怎么样了？”
And how are the dear old Morrisons?”

“妮基，莫里森夫妇都是很好的人。
“Niki, the Morrisons are perfectly kind people.

我想不通你干吗要这么瞧不起他们。
I've never understood why you need to be so disparaging.

以前你和卡西还是最好的朋友。”
You and Cathy used to be the best of friends once.”

“哦没错，卡西。
“Oh yes, Cathy.

她最近怎么样了？
And how's she these days?

还住在家里吧，我想？”
Still living at home, I suppose?”

“啊，是的。
“Well, yes.

她现在在银行上班。”
She works in a bank now.”

“很像她。”
“Typical enough.”

“在我看来，她这个年纪做这个再适合不过了。
“That seems to me a perfectly sensible thing to be doing at her age.

还有，玛里琳结婚了，你知道吗？”
And Marilyn's married now, did you know?”

“哦是吗？
“Oh yes?

她嫁给谁了？”
And who did she marry?”

“我不记得她丈夫是做什么的了。
“I don't remember what her husband does.

我见过他一次。
I met him once.

他看来很讨人喜欢。”
He seemed very pleasant.”

“我猜他是个教区牧师之类的。”
“I expect he's a vicar or something like that.”

“好了，妮基，我真是想不通你为什么非得用这种语气。
“Now, Niki, I really don't see why you have to adopt this tone.

莫里森夫妇一直对我们很好。”
The Morrisons have always been extremely kind to us.”

妮基不耐烦地叹了口气，说：“他们做事的方式就是让我讨厌。
Niki sighed impatiently. “It's just the way they do things,” she said. “It makes me sick.

比如说他们教育孩子的方式。”
Like the way they've brought up their kids.”

“可是你好几年没见到莫里森夫妇了。”
“But you've hardly seen the Morrisons in years.”

“我以前认识卡西时已经见得够多的了。
“I saw them often enough when I used to know Cathy.

他们那种人真是无药可救。
People like that are so hopeless.

我想我应该替卡西难过。”
I suppose I ought to feel sorry for Cathy.”

“你就因为卡西没有像你一样到伦敦去住而责怪她？
“You're blaming her because she hasn't gone to live in London like you have?

我得说，妮基，这可不像你和你的朋友们所标榜的宽容大度。”
I must say, Niki, that doesn't sound like the broadmindedness you and your friends seem so proud of.”

“哦，没关系。
“Oh, it doesn't matter.

反正你也不明白我在讲什么。”
You don't understand what I'm talking about anyway.”

她瞥了我一眼，然后又叹了一口气。
She glanced towards me, then heaved another sigh.

“没关系，”她看着另一边，又说了一次。
“It doesn't matter,” she repeated, looking the other way.

我又盯着她看了一会儿。
I continued to stare at her for a moment.

最后，我转回窗台，继续摆弄我的盆栽，没有说话。
Eventually, I turned back to the window ledge and for some minutes worked on in silence.

“你知道，妮基，”几分钟后我说道，“我很高兴你有处得来的好朋友。
“You know, Niki,” I said, after some time, “I'm very pleased you have good friends you enjoy being with.

毕竟，现在你要过自己的生活。
After all, you must lead your own life now.

这是自然的。”
That's only to be expected.”

我的女儿没有做声。
My daughter gave no reply.

我看了她一眼，她正在看从抽屉里找到的一份报纸。
When I glanced at her, she was reading one of the newspapers she had found in the drawer.

“我很想见见你的朋友，”我说。
“I'd be interested to meet your friends,” I said.

“随时欢迎你带他们到这里来。”
“You're always welcome to bring any of them here.”

妮基轻轻地甩了一下头，不让头发遮住视线，继续看报纸，脸上露出专注的神情。
Niki flicked her head to prevent her hair falling across her vision, and continued to read. A look of concentration had appeared on her face.

我重新回到盆栽上，因为这些信号我再明白不过了。
I went back to my plants, for I could read these signals well enough.

每当我打探她在伦敦的生活，妮基就摆出一副微妙的、但是相当斩钉截铁的态度；她用这种方式告诉我，我不应该再问下去，不然会后悔。
There is a certain subtle and yet quiet emphatic manner Niki adopts whenever I display curiosity concerning her life in London; it is her way of telling me I will regret it if I persist.

结果，我对她目前生活的认识大部分都是靠猜想。
Consequently, my picture of her present life is built largely upon speculation.

可是，在她的信里——妮基总是记得写信——她提到了一些在谈话中不可能涉及的东西。
In her letters, however — and Niki is very good about remembering to write — she mentions certain things she would never touch upon in conversation.

比如说，我就是从信里知道她的男朋友叫大卫，在伦敦的一所大学里学政治。
That is how I have learnt, for instance, that her boyfriend's name is David and that he is studying politics at one of the London colleges.

可是在谈话中，要是我问到他好吗，我知道那道障碍马上就会严严实实地落下。
And yet, during conversation, if I were even to enquire after his health, I know that barrier would come firmly down.

如此强烈地保护自己的隐私让我想起了她的姐姐。
This rather aggressive regard for privacy reminds me very much of her sister.

因为事实上，我的两个女儿有很多共同点，比我丈夫承认的要多得多。
For in truth, my two daughters had much in common, much more than my husband would ever admit.

在他看来，她们是完全不同的；而且，他形成这么一种看法，认为景子天生就是一个难相处的人，对此我们无能为力。
As far as he was concerned, they were complete opposites; furthermore, it became his view that Keiko was a difficult person by nature and there was little we could do for her.

其实，虽然他从未直说出来，但是他会暗示说景子从她爸爸那里继承了这种性格。
In fact, although he never claimed it outright, he would imply that Keiko had inherited her personality from her father.

我没有反驳，因为这是最简单的解释：怪二郎，不怪我们。
I did little to contradict this, for it was the easy explanation, that Jiro was to blame, not us.

当然了，我丈夫并不知道小时候的景子是什么样的；他要是知道的话，就会发现这两个女孩在小时候有多像。
Of course, my husband never knew Keiko in her early years; if he had, he may well have recognized how similar the two girls were during their respective early stages.

都是火爆脾气，都有很强的占有欲；生气的话，不会像其他孩子那样很快忘记他们的怒火，而是会闷闷不乐一整天。
Both had fierce tempers, both were possessive; if they became upset, they would not like other children forget their anger quickly, but would remain moody for most of the day.

可是，一个长成了快乐、自信的年轻姑娘——我对妮基的未来充满信心——另一个越来越不快乐，最终结束了自己的生命。
And yet, one has become a happy, confident young woman — I have every hope for Niki's future — while the other, after becoming increasingly miserable, took her own life.

我并不像我丈夫那样，觉得可以把原因简单地归咎于天性或二郎。
I do not find it as easy as my husband did to put the blame on Nature, or else on Jiro.

可是，这些事情都已经过去了，再想也没什么用了。
However, such things are in the past now, and there is little to be gained in going over them here.

“对了，妈妈，”妮基说。
“By the way, Mother,” said Niki.

“今天早上是你吧？”
“That was you this morning, wasn't it?”

“今天早上？”
“This morning?”

“早上我听见一些动静。
“I heard these sounds this morning.

很早的时候，大概四点吧。”
Really early, about four o'clock.”

“很抱歉吵到你了。
“I'm sorry I disturbed you.

对，是我。”
Yes, that was me.”

我笑了起来。
I began to laugh.

“怎么了，你以为还会是谁呢？”
“Why, who else did you imagine it was?”

我还在笑，一时停不下来。
I continued to laugh, and for a moment could not stop.

妮基瞪着我，报纸还摊在她面前。
Niki stared at me, her newspaper still held open before her.

“哦，对不起我把你吵醒了，妮基，”我终于止住了笑，说道。
“Well, I'm sorry I woke you, Niki,” I said, finally controlling my laughter.

“没关系，反正我已经醒了。
“It's all right, I was awake anyway.

这几天我好像都睡不好。”
I can't seem to sleep properly these days.”

“换了房间也睡不好？
“And after all that fuss you made about the rooms.

你可能得去看医生。”
Perhaps you should see a doctor.”

“我可能会去。”
“Maybe I will.”

妮基说道，又继续看报纸。
Niki went back to her newspaper.

我放下一直拿着的大剪刀，转向她。
I laid down the clippers I had been using and turned to her.

“你知道，很奇怪。
“You know, it's strange.

今天早上我又做了那个梦。”
I had that dream again this morning.”

“什么梦？”
“What dream?”

“我昨天跟你说的那个，不过我想那时你没有在听。
“I was telling you about it yesterday, but I don't suppose you were listening.

我又梦见了那个小女孩。”
I dreamt about that little girl again.”

“哪个小女孩？”
“What little girl?”

“那天我们在村里喝咖啡时看见的，在荡秋千的那个。”
“The one we saw playing on the swing the other day. When we were in the village having coffee.”

妮基耸了耸肩。
Niki shrugged.

“哦，那个，”她没有抬头，说。
“Oh, that one,” she said, not looking up.

“其实，根本不是那个小女孩。
“Well, actually, it isn't that little girl at all.

今天早上我意识到这一点。
That's what I realized this morning.

看似是她，但其实不是。”
It seemed to be that little girl, but it wasn't.”

妮基又一次抬起头来看着我，然后说：“我想你是指她。
Niki looked at me again. Then she said: “I suppose you mean it was her.

景子。”
Keiko.”

“景子？”
“Keiko?”

我微微地笑了。
I laughed a little.

“多奇怪的想法。
“What a strange idea.

为什么是景子呢？
Why should it be Keiko?

不，跟景子没有关系。”
No, it was nothing to do with Keiko.”

妮基还是不确定地看着我。
Niki continued to look at me uncertainly.

“只是我以前认识的一个小女孩，”我说。
“It was just a little girl I knew once,” I said to her.

“很久以前。”
“A long time ago.”

“哪个小女孩？”
“Which little girl?”

“你不认识。
“No one you know.

我很久以前认识的。”
I knew her a long time ago.”

妮基又耸了耸肩。
Niki gave another shrug.

“我甚至压根就无法入睡。
“I can't even get to sleep in the first place.

我想昨天晚上我只睡了大概四个小时。”
I think I only slept about four hours last night.”

“太让人担心了，妮基。
“That's rather disturbing, Niki.

特别是在你这种年纪。
Especially at your age.

你可能得去看医生。
Perhaps you should see a doctor.

你随时可以去找弗格森医生。”
You can always go and see Dr Ferguson.”

妮基又做了个不耐烦的动作，继续看她爸爸登在报纸上的文章。
Niki made another of her impatient gestures and went back to her father's newspaper article.

我看了她一会儿。
I watched her for a moment.

“其实，今天早上我还意识到别的事情，”我说。
“In fact, I realized something else this morning,” I said.

“关于那个梦的。”
“Something else about the dream.”

我女儿似乎没有在听。
My daughter did not seem to hear.

“你瞧，”我说，“那个小女孩根本不是在秋千上。
“You see,” I said, “the little girl isn't on a swing at all.

一开始好像是秋千。
It seemed like that at first.

但其实她不是在秋千上。”
But it's not a swing she's on.”

妮基嘟囔了句什么，继续看报纸。
Niki murmured something and carried on reading.

# 第二部 · 第七章 | PART TWO · Chapter Seven

夏天越来越热，公寓区旁的那片空地也让人越来越不能忍受。
As the summer grew hotter, the stretch of wasteground outside our apartment block became increasingly unpleasant.

大部分的土干得裂开了，而雨季里积的雨水却还留在凹下去的沟和坑里。
Much of the earth lay dried and cracked, while water which had accumulated during the rainy season remained in the deeper ditches and craters.

空地滋生各种虫子，其中蚊子最多，随处可见。
The ground bred all manner of insects, and the mosquitoes in particular seemed everywhere.

公寓里的人一直在抱怨，可是几年以后，对那块空地的愤怒逐渐变成了听之任之、冷嘲热讽。
In the apartments there was the usual complaining, but over the years the anger over the wasteground had become resigned and cynical.

那年夏天我经常要穿过那块空地到佐知子的小屋去，这段路真够讨厌的；虫子飞进你的头发，地面的裂缝里看得到大大小小的蚊子。
I crossed that ground regularly that summer to reach Sachiko's cottage, and indeed it was a loathsome journey; insects often caught in one's hair, and there were grubs and midges visible amidst the cracked surface.

我至今仍清楚地记得那段路，那一趟趟来回——还有对即将做妈妈的担心，还有绪方先生的来访——使得那个夏天与众不同。
I still remember those journeys vividly, and they — like those misgivings about motherhood, like Ogata-San's visit — serve today to bring a certain distinctness to that summer.

可是除此之外，那个夏天跟别的夏天没什么两样。
And yet in many ways, that summer was much like any other.

很多时候——后来几年也是——我都呆呆地望着窗外的景色。
I spent many moments — as I was to do throughout succeeding years — gazing emptily at the view from my apartment window.

晴朗一些的日子里，我能看见河对岸的树后面淡淡的山的轮廓，映着白云。
On clearer days, I could see far beyond the trees on the opposite bank of the river, a pale outline of hills visible against the clouds.

那景色还挺好看，有时还能带给我难得的消遣，打发我在公寓里的那一个个漫长、无聊的下午。
It was not an unpleasant view, and on occasions it brought me a rare sense of relief from the emptiness of those long afternoons I spent in that apartment.

除了空地的事，那年夏天小区的人还关心其他话题。
Apart from the matter of the wasteground, there were other topics which preoccupied the neighbourhood that summer.

报纸上都在说占领快结束了，东京的政客们忙着吵来吵去。
The newspapers were full of talk about the occupation coming to an end and in Tokyo politicians were busy in argument with each other.

公寓里的人也经常谈论这件事，但跟讲起空地一样，带着冷嘲热讽。
In the apartments, the issue was discussed frequently enough, but with much the same cynicism as coloured talk concerning the wasteground.

大家更关心的是儿童谋杀案的报道，案件震惊了当时的长崎。
Received with more urgency were the reports of the child murders that were alarming Nagasaki at the time.

先是一个男孩，后来是一个小女孩发现被殴打致死。
First a boy, then a small girl had been found battered to death.

当发现第三名受害者时——又一个小女孩被吊死在树上——小区里的妈妈们几乎惊慌失措。
When a third victim, another little girl, had been found hanging from a tree there was near-panic amongst the mothers in the neighbourhood.

虽说事件都发生在城市的另一头，但这丝毫不能减轻人们的恐惧：小区里几乎看不见小孩子的身影，尤其是在晚上。
Understandably, little comfort was taken from the fact that the incidents had taken place on the other side of the city: children became a rare sight around the housing precinct, particularly in the evening hours.

我不清楚当时的那些报道让佐知子担心到什么程度。
I am not sure to what extent these reports worried Sachiko at the time.

诚然她似乎不像以前那样把万里子一个人留下，可是后来我怀疑这更主要的是因为她生活中的其他进展；她收到了她伯父的回信，说愿意让她们回去住，之后我很快就发现佐知子对小女孩的态度变了：她对孩子似乎更有耐心、更加随和了。
Certainly she seemed less inclined to leave Mariko unattended, but then I suspect this had more to do with other developments in her life; she had received a reply from her uncle, expressing his willingness to take her back into his household, and soon after this news, I noticed a change come over Sachiko's attitude to the little girl: she seemed somehow more patient and relaxed with the child.

收到她伯父的来信后，佐知子大大地松了一口气，一开始我毫不怀疑她会回去。
Sachiko had betrayed much relief about her uncle's letter, and at first I had little reason to doubt she would return to his house.

然而，日子一天天过去，我开始怀疑她的打算。
However, as the days went by, my suspicions grew about her intentions.

一方面，收到信后的几天，我发现佐知子没有把这件事情告诉万里子。
For one thing, I discovered some days after the arrival of the letter that Sachiko had not yet mentioned the matter to Mariko.

后来，几周过去了，佐知子不仅没有准备离开，我发现她也没有给她伯父回信。
And then, as the weeks went on, not only did Sachiko make no preparations for moving, she had not, so I discovered, sent a reply to her uncle.

要不是佐知子特别不愿提起她伯父家，我想我不会去想这个事情。我越来越好奇。
Had Sachiko not been so peculiarly reluctant to talk about her uncle's household, I doubt if it would have occurred to me to ponder such a topic.

虽然佐知子三缄其口，我还是知道了一些事情；比如说，这个伯父似乎并不是佐知子的血亲，而是她丈夫那边的亲戚；佐知子是在到他家来的几个月前才知道他的。
As it was, I grew curious, and despite Sachiko's reticence I managed to gather certain impressions; for one thing, the uncle was not, it seemed, related by blood, but was a relative of Sachiko's husband; Sachiko had never known him prior to arriving at his house several months earlier.

这个伯父很有钱，他的房子不是一般的大——而且就只住着他、他女儿和一个女佣——所以足以腾出空间来让佐知子和她的小女儿住。其实佐知子不只一次地说到那所房子大部分都是空的，静悄悄的。
The uncle was wealthy, and since his house was an unusually large one — and his daughter and a housemaid the only other occupants — there had been plenty of room for Sachiko and her little girl. Indeed, one thing Sachiko did mention more than once was her recollection of how large parts of that house had remained empty and silent.

我对这个伯父的女儿特别好奇。据我所知，她与佐知子年纪相仿，没有结婚。
In particular, I became curious about the uncle's daughter, who I gathered to be an unmarried woman of roughly Sachiko's age.

佐知子很少提起她的表姐，可是我清楚地记得那时的一次交谈。
Sachiko would say little about her cousin, but then I do recall one conversation we had around that time.

当时我认为佐知子之所以迟迟不回她伯父家去是因为她和她的表姐不和。那天早上我一定是试探着跟佐知子说起这个，因而打开了她的话匣子，佐知子很少直说她在她伯父家里的生活，那次是少有的几次之一。
I had by then formed an idea that Sachiko's slowness in returning to her uncle had to do with some tension which existed between herself and the cousin. I must have tentatively put this to Sachiko that morning, for it provoked one of the few occasions upon which she talked explicitly about the time she had spent at her uncle's house.

那次交谈如今仍历历在目；那是八月中旬的一个没有风的、干燥的早上，我们站在山顶的桥上等进城的电车。我不记得那天我们是要去哪里，也不记得是在哪里离开万里子的——我记得孩子没有和我们在一起。
The conversation comes back to me quite vividly; it was one of those dry windless mornings of mid-August, and we were standing on the bridge at the top of our hill, waiting for a tram to take us into the city. I cannot remember where it was we were going that day, or where we had left Mariko — for I recall the child was not with us.

佐知子看着远处的风景，举起一只手来挡着脸，遮住太阳。
Sachiko was gazing out at the view from the bridge, holding up a hand to shield her face from the sun.

“我搞不懂，悦子，”她说，“你怎么会有这种想法。
“It puzzles me, Etsuko,” she said, “how you ever managed to get hold of such an idea.

恰恰相反，安子和我是最好的朋友，我也很想再见到她。
On the contrary, Yasuko and I were the best of friends, and I'm greatly looking forward to seeing her again.

我真不明白你怎么会想得刚好相反，悦子。”
I really don't understand how you could have thought otherwise, Etsuko.”

“对不起，我一定是弄错了，”我说。
“I'm sorry, I must have been mistaken,” I said.

“不知怎么的，我觉得你不大想回那里去。”
“For some reason, I supposed you had some reservations about returning there.”

“没有的事，悦子。
“Not at all, Etsuko.

我们刚认识时，确实是，那时我正在考虑其他的可能性。
When you first met me, it's quite true, I was in the process of considering certain other possibilities.

可是一个母亲应该考虑出现的、给孩子的各种机会，难道应该为此受到责备吗？
But a mother can't be blamed for considering the different options that arise for her child, can she?

只是有一阵子，我们似乎有一个不错的选择。
It just so happened that for a while there seemed an interesting option open to us.

但是进一步考虑之后，我放弃了。
But having given it further consideration, I've now rejected it.

事情就是这样，悦子，现在我对这些计划都没有兴趣了。
That's all there is to it, Etsuko, I've no further interest in these other plans that were suggested to me.

我很高兴事情有了最好的结局，现在我盼着回到我伯父家去。
I'm glad everything has turned out for the best, and I'm looking forward to returning to my uncle's house.

至于安子，我们都十分尊敬对方。
As for Yasuko-San, we have the highest regard for each other.

我不明白是什么让你有相反的想法，悦子。”
I don't understand what could have made you suppose otherwise, Etsuko.”

“真的很抱歉。
“I do apologize.

我只是记得有一次你提到了吵架什么的。”
It's just that I thought you once mentioned a quarrel of some kind.”

“吵架？”
“A quarrel?”

她看了我一会儿，然后脸上露出了笑容。
She looked at me for a second, and then a smile spread over her face.

“哦，我知道你指什么了。
“Oh, now I understand what you're referring to.

不，悦子，那不是吵架。
No, Etsuko, that was no quarrel.

那只是小小的口角。
That was just some trivial tiff we had.

为了什么来着？
What was it about now?

你瞧，我都不记得是为了什么事了，太小的事了。
You see, I don't even remember, it was so trivial.

哦对了，没错，我们在争谁来准备晚饭。
Oh yes, that's right, we were arguing about which of us should prepare the supper.

对，没错，就为了这个。
Yes, really, that's all it was.

你瞧，悦子，那时我们轮流做饭。
You see, Etsuko, we used to take it in turns.

女佣做一个晚上，再来是我表姐，然后轮到我。
The housemaid would cook one night, my cousin the next, then it would be my turn.

一天轮到女佣做饭，她却病了，安子和我两个人都争着要做。
The housemaid was taken ill on one of her nights, and Yasuko and I both wanted to cook.

你千万别误会，悦子，我们通常相处得很好。
Now you mustn't misunderstand, Etsuko, we generally got on very well.

只是当你老是见到同一个人、见不到别人时，有时难免会有摩擦。”
It's just that when you see so much of one person and no one else, things can get out of proportion at times.”

“是的，我很理解。
“Yes, I do understand.

对不起，我误会了。”
I'm sorry, I was quite mistaken.”

“要知道，悦子，当有女佣帮你做所有的杂事时，时间就过得出奇的慢。
“You see, Etsuko, when you have a housemaid to do all the little jobs for you, it's surprising how slowly the time goes by.

安子和我都找些这样、那样的事来做，可是整天除了坐着聊天以外实在是没什么好做的。
Yasuko and I, we tried to occupy ourselves one way or another, but really there was little to do other than sit and talk all day.

那几个月，我们一起坐在那所房子里，几乎见不到什么外人。
All those months we sat in that house together, we hardly saw an outsider the whole time.

我们没有真的吵起来真是奇迹。
It's a wonder we didn't really quarrel.

也许吧，我的意思是。”
Properly, I mean.”

“是的，确实如此。
“Yes, it certainly is.

之前是我误会您了。”
I obviously misunderstood you before.”

“是啊，悦子，恐怕你是误会了。
“Yes, Etsuko, I'm afraid you did.

我记得这件事只是因为这是在我们离开之前不久发生的，从那以后我就再也没有见过我的表姐了。
I only happen to remember the incident because it occurred just before we left and I haven't seen my cousin since.

不过说那是吵架还真是好笑。”
But it's absurd to call it a quarrel.”

她笑了笑。
She gave a laugh.

“其实，我想安子要是想起这件事也会笑出来的。”
“In fact, I expect Yasuko's thinking of it and laughing too.”

也许就是在那天早上我们决定在佐知子离开前，要找一天一起去哪里走走。
Perhaps it was that same morning, we decided that before Sachiko went away, we would go together on a day's outing somewhere.

而事实上，不久之后的一个炎热的下午，我陪佐知子母女去了稻佐山。
And indeed, one hot afternoon not long afterwards, I accompanied Sachiko and her daughter to Inasa.

稻佐山是长崎的山区，俯视港口，山上的景色很有名；稻佐山离我们住的地方不远——其实我从公寓的窗口看见的就是稻佐山——可是那时候，我极少外出，去稻佐山就成了一次远足。
Inasa is the hilly area of Nagasaki overlooking the harbour, renowned for its mountain scenery; it was not so far from where we lived — in fact it was the hills of Inasa I could see from my apartment window — but in those days, outings of any sort were rare for me, and the trip to Inasa seemed like a major excursion.

我记得那时我盼了好几天；我想这是我那些日子的美好回忆之一。
I remember I looked forward to it for days; it is, I suppose, one of the better memories I have from those times.

我们在下午最热的时候坐渡船到稻佐山去。
We crossed to Inasa by ferry at the height of the afternoon.

港口的嘈杂声跟随着我们的船——铁锤的叮当声，机器的轰鸣声，时不时传来的低沉的船的汽笛声——在那个时候的长崎，这些声音可不是什么噪声；它们是重建的声音，当时仍然可以振奋人心。
Noises from the harbour followed us across the water — the clang of hammers, the whine of machinery, the occasional deep sound from a ship's horn — but in those days, in Nagasaki, such sounds were not unpleasing; they were the sounds of recovery and they were still capable then of bringing a certain uplifting feeling to one's spirits.

到了对岸，那里的海风比较大，天气没有那么闷热了。
Once we had crossed the water, the sea-winds seemed to blow more freely and the day no longer felt so stifling.

我们坐在缆车站空地的长椅上，仍旧可以听到风传来的港口的声音。
The sounds of the harbour, carried in the wind, still reached us as we sat on a bench in the forecourt of the cable-car station.

凉风习习，空地上还有难得的遮阳的地方，我们心里更加感激；这里只不过是一块水泥空地——那天空地上大多是母亲带着孩子——像个学校的操场。
We were all the more grateful for the breeze, for the forecourt offered scant shelter from the sun; it was simply an open area of concrete which — being peopled that day largely by children and their mothers — resembled a school playground.

空地的一边，在一排旋转栅门后是缆车靠站的木站台。
Over to one side, behind a set of turnstiles, we could see the wooden platforms where the cable-cars came to rest.

有好一会儿，我们坐在那里出神地看着缆车上上下下；一辆缆车慢慢地向山上升去，渐渐地变成空中的一个小点，而另一辆则越来越低，越来越大，最后停在站台上。
For some moments we sat mesmerized by the sight of the cable-cars climbing and falling; one car would go rising away into the trees, gradually turning into a small dot against the sky, while its companion came lower, growing larger, until it heaved itself to a halt at the platform.

栅门旁的小屋里，一个男的在控制一些操作杆；他戴着一顶帽子，每次缆车安全地停下来以后，他都要探出身来和围过来看的孩子们聊天。
Inside a small hut beside the turnstiles, a man was operating some levers; he wore a cap, and after each car had come down safely, he would lean out and chat to a group of children who had gathered to watch.

我们决定坐缆车到山顶去，由此那天第一次遇见了那个美国女人。
The first of our encounters that day with the American woman occurred as a result of our deciding to take the cable-car to the hilltop.

佐知子和女儿去买票，我一个人坐在长椅上。
Sachiko and her daughter had gone to buy the tickets and for a moment I was left sitting alone on the bench.

突然我注意到空地的另一头有个卖糖果和玩具的小摊。
Then I noticed at the far end of the forecourt a small stall selling sweets and toys.

我想说不定可以买糖给万里子，就站起来走过去。
Thinking I would perhaps buy some candy for Mariko, I got to my feet and walked over to it.

两个孩子在我前面，争吵着要买什么。
Two children were there before me, arguing about what to buy.

我等着他们，发现玩具里有一副塑料双筒望远镜。
While I waited for them, I noticed among the toys a pair of plastic binoculars.

那两个孩子还在吵，我回头看了一眼空地。
The children continued to quarrel, and I glanced back across the forecourt.

佐知子和万里子还站在栅门旁；佐知子好像在和两个女人讲话。
Sachiko and Mariko were still standing by the turnstiles; Sachiko seemed to be in conversation with two women.

“您要什么，夫人？”
“Can I be of service, madam?”

孩子们走了。
The children had gone.

小摊后站着一个穿着整洁的夏季制服的小伙子。
Behind the stall was a young man in a neat summer uniform.

“我能试试这个吗？”
“May I try these?”

我指了指双筒望远镜。
I pointed to the binoculars.

“当然可以，夫人。
“Certainly, madam.

虽然只是玩具，但是能看得挺远的。”
It's just a toy, but quite effective.”

我举起望远镜，抬头看山坡；望远镜居然能看得很清楚。
I put the binoculars to my face and looked towards the hill-slope; they were surprisingly powerful.

我转向空地，发现佐知子母女在镜头里。
I turned to the forecourt and found Sachiko and her daughter in the lenses.

佐知子今天穿着一件浅色和服，系着一条精致的腰带——我想那腰带是特殊场合才拿出来系的——她的姿态在人群里很优雅。
Sachiko had dressed for the day in a light-coloured kimono tied with an elegant sash — a costume, I suspected, reserved only for special occasions — and she cut a graceful figure amidst the crowd.

她还在和那两个女人讲话，其中一个像是外国人。
She was still talking to the two women, one of whom looked like a foreigner.

“又是一个大热天啊，夫人，”我递给小伙子钱时他说。
“A hot day again, madam,” the young man said, as I handed him the money.

“你们要坐缆车吗？”
“Are you riding on the cable-car?”

“我们正要去坐。”
“We're just about to.”

“上面的风景很棒。
“It's a magnificent view.

山顶上那个是我们建的电视塔。
That's a television tower we're building on the top.

到了明年，缆车就能直通那里了，直通山顶。”
By next year, the cable-car will go right up to it, right to the top.”

“太好了。
“How splendid.

祝你今天过得愉快。”
Have a nice day, won't you.”

“谢谢您，夫人。”
“Thank you, madam.”

我拿着双筒望远镜走回去。
I made my way back across the forecourt with the binoculars.

虽然那时我并不懂英语，但是我马上猜到那个外国女人是美国人。
Although at that time I did not understand English, I guessed at once that the foreign woman was American.

她很高，一头红色的波浪发，戴着一副边角往上翘的眼镜。
She was tall, with red wavy hair and glasses which pointed up at the corners.

她在大声跟佐知子说话。
She was addressing Sachiko in a loud voice, and I noted with surprise the ease with which Sachiko replied in English.

看见佐知子那么自如地用英语回答她我很是吃惊。
The other woman was Japanese; she had noticeably plump features, and appeared to be around forty or so.

另外一个女人是日本人；胖胖的，四十岁上下，身边有个八九岁的敦实的小男孩。
Beside her was a tubby little boy of about eight or nine.

我走过去，向他们鞠躬问好，然后把双筒望远镜递给万里子。
I bowed to them as I arrived, wished them a pleasant day, then handed Mariko the binoculars.

“只是个玩具，”我说。
“It's just a toy,” I said.

“不过可以看见不少东西。”
“But you might be able to see a few things.”

万里子打开包装，认真地研究望远镜。
Mariko opened the wrapping and examined the binoculars with a serious expression.

她举起望远镜，先是看看空地，然后抬头看山坡。
She looked through them, first around the forecourt, then up at the hill-slope.

“说谢谢，万里子，”佐知子说。
“Say thank you, Mariko,” Sachiko said.

万里子只顾着看。
Mariko continued to look through the binoculars.

然后她放下望远镜，把塑料绳套到脖子上。
Then she brought them away from her face and put the plastic strap over her head.

“谢谢悦子阿姨，”她有点不情愿地说。
“Thank you, Etsuko-San,” she said, a little grudgingly.

那个美国女人指着望远镜，用英语说了什么，笑了。
The American woman pointed to the binoculars, said something in English and laughed.

双筒望远镜同样引起了那个敦实的小男孩的注意。
The binoculars had also attracted the attention of the tubby boy, who previously had been watching the hill-slope and the descending cable-car.

他原本在看着山坡和下降的缆车，现在走近万里子，眼睛盯着望远镜。
He took a few steps towards Mariko, his eyes on the binoculars.

“太谢谢了，悦子，”佐知子说。
“That was very kind of you, Etsuko,” said Sachiko.

“没什么。
“Not at all.

只是一个玩具。”
It's just a toy.”

缆车到了，我们走过栅门，走上凹下去的木板。
The cable-car arrived and we went through the turnstiles, on to the hollow wooden boards.

好像除了我们以外，那两个女人和那个男孩便是仅有的乘客了。
The two women and the tubby boy, it seemed, were to be the only other passengers.

戴帽子的男人走出他的小屋，引领我们一个个走进缆车。
The man with the cap came out of his hut and ushered us one by one into the car.

车厢里光秃秃的，就是个金属壳子。
The interior looked stark and metallic.

四面都有大窗户，两面长的墙壁下各有一条长椅。
There were large windows on all sides and benches ran along the two larger walls.

缆车没有马上开动，而是在站台上停留了几分钟，那个敦实的小男孩开始不耐烦地走来走去。
The car remained at the platform for several more minutes and the tubby boy began to walk around impatiently.

在我身边，万里子跪在长椅上看窗外。
Beside me, Mariko was looking out of the window, her knees up on the bench.

从我们这边的窗户可以看见空地和聚集在栅门旁的小观众们。
From our side of the car, we could see the forecourt and the gathering of young spectators at the turnstiles.

万里子像是在测试望远镜的性能，一会儿把望远镜拿到眼前，一会儿又拿开。
Mariko seemed to be testing the effectiveness of her binoculars, holding them to her eyes one moment, taking them away the next.

这时，敦实的小男孩走过来，也跪在她旁边的椅子上。
Then the tubby boy came and knelt on the bench beside her.

一开始两个孩子谁也没有理谁。
For a little while, the two children ignored each other.

最后，那个男孩说：
Finally, the boy said:

“现在我要看。”
“I want to have a look now.”

说着伸手去要望远镜。
He held out his hand for the binoculars.

万里子冷冷地看着他。
Mariko looked at him coldly.

“阿明，不能这样要东西，”他妈妈说。
“Akira, don't ask like that,” said his mother.

“好好地跟小姐姐要。”
“Ask the little lady nicely.”

小男孩把手拿开，看着万里子。
The boy took his hand away and looked at Mariko.

万里子回瞪着他。
The little girl stared back.

小男孩转身走到另一边的窗户去。
The boy turned and went to another window.

缆车启动了，栅门旁的孩子们朝我们挥手。
The children at the turnstiles waved as the car began to pull away.

我本能地抓住窗户旁的铁栏杆，那个美国女人紧张地叫了一声，笑了。
I instinctively reached for the metal bar running along the window, and the American woman made a nervous noise and laughed.

空地越变越小，接着，山坡在我们底下移动；我们渐渐升高，缆车轻轻地摇晃着；有一会儿，树顶像是擦着窗户，突然我们的脚下空了，出现了一个巨大的山壑，我们悬在空中了。
The forecourt was growing smaller and then the hillside began to move beneath us; the cable-car swayed gently as we climbed higher; for a moment, the treetops seemed to brush against the windows, then suddenly a large dip opened beneath us and we were hanging in the sky.

佐知子轻轻地笑了笑，指了指窗外的什么东西。
Sachiko laughed softly and pointed to something out of the window.

万里子又拿起望远镜看。
Mariko continued to look through her binoculars.

缆车到了终点，我们小心翼翼地一个接一个出来，像是不能肯定自己已经到了坚实的地面。
The cable-car finished its climb and we filed out cautiously as if uncertain we had arrived on solid ground.

上面的这个站台没有水泥地，走出木地板就是一小片草地。
The higher station had no concrete forecourt, and we stepped off the wooden boards into a small grass clearing.

除了引导我们出站台的穿着制服的男人以外，看不见其他人。
Other than the uniformed man who ushered us out, there were no other people in sight.

草地后立着几张野餐用的木桌，几乎掩映在松树林里。
At the back of the clearing, almost amidst the pine trees, stood several wooden picnic tables.

草地的这边，我们下车的地方，有一道铁栅栏围住悬崖。
The near edge of the clearing where we had disembarked was marked by a metal fence, which separated us from a cliff-edge.

我们大致搞清楚所在的方位后就走到栅栏边去看缓缓向下的山坡。
When we had regained our bearings a little, we wandered over to the fence and looked out over the falling mountainside.

过了一会儿，那两个女人和那个男孩也走了过来。
After a moment, the two women and the boy joined us.

“太壮观了，不是吗？”那个日本女人对我说。
“Quite breathtaking, isn't it?” the Japanese woman said to me.

“我带我的朋友饱览风光。
“I'm just showing my friend all the interesting sights.

她以前没来过日本。”
She's never been in Japan before.”

“这样啊。
“I see.

我希望她在这里玩得开心。”
I hope she's enjoying it here.”

“我希望如此。
“I hope so.

可惜我的英语说得不好。
Unfortunately, I don't understand English so well.

你的朋友说得比我好多了。”
Your friend seems to speak it much better than I do.”

“是啊，她说得很好。”
“Yes, she speaks it very well.”

我们俩都看了一眼佐知子。
We both glanced towards Sachiko.

她和那个美国女人又用英语聊开了。
She and the American woman were again exchanging remarks in English.

“受到这么好的教育真好，”日本女人对我说。
“How nice to be so well educated,” the woman said to me.

“好了，祝你们今天全都玩得愉快。”
“Well, I hope you all have a nice day.”

我们互相鞠了鞠躬，日本女人朝她的美国客人招了招手，示意他们该走了。
We exchanged bows, then the woman made gestures to her American guest, suggesting they move off.

“我能看一下吗？”
“Please may I look,” the tubby boy said, in an angry voice.

敦实的小男孩生气地问，再次伸出手去。
Again, he was holding out his hand.

万里子像在缆车里那样盯着他。
Mariko stared at him, as she had done in the cable-car.

“我想看，”小男孩说得更凶了。
“I want to see it,” the boy said, more fiercely.

“阿明，记住好好地跟小姐姐要。”
“Akira, remember to ask the little lady nicely.”

“求你！
“Please!

我想看。”
I want to see it.”

万里子又看了他一小会儿，才把塑料绳从脖子上拿下来，把望远镜递给小男孩。
Mariko continued to look at him for a second, then took the plastic strap from around her neck and handed the boy the binoculars.

男孩举起望远镜朝栅栏那边看去。
The boy put them to his face and for some moments gazed over the fence.

“这个一点都不好，”他看了好一会儿后跟他妈妈说道。
“These aren't any good,” he said finally, turning to his mother.

“没有我的那个好。
“They aren't nearly as good as mine.

妈妈，你看，都看不清楚那边的树。
Mother, look, you can't even see those trees over there properly.

你看啊。”
Take a look.”

他要把望远镜给他妈妈。
He held the binoculars towards his mother.

万里子伸出手去拿，可是男孩一把闪开，又递给他妈妈。
Mariko reached for them but the boy snatched them away and again offered them to the woman.

“你看啊，妈妈。
“Take a look, Mother.

都看不见那边的树，近处的那些。”
You can't even see those trees, the near ones.”

“阿明，把望远镜还给小姐姐。”
“Akira, give them back to the little lady now.”

“这个没有我的那个好。”
“They aren't nearly as good as mine.”

“好了，阿明，这么说话没有礼貌。
“Now, Akira, that's not a nice thing to say.

你知道不是每个人都像你这么幸运。”
You know everyone isn't as lucky as you.”

万里子伸手去拿望远镜，这次男孩放手了。
Mariko reached for the binoculars and this time the boy let go.

“跟小姐姐说谢谢，”他妈妈说。
“Say thank you to the little lady,” said his mother.

小男孩什么也没说就走开了。
The boy said nothing and started to walk away.

他妈妈笑了笑。
The mother laughed a little.

“谢谢你，”她对万里子说。
“Thank you very much,” she said to Mariko.

“你真好。”
“You were very kind.”

接着她又依次对佐知子和我笑了笑。
Then she smiled in turn towards Sachiko and myself.

“景色很漂亮，不是吗？”她说。
“Splendid scenery, isn't it?” she said.

“祝愿你们今天玩得愉快。”
“I do hope you have a nice day.”

山路上满是松针，沿着山坡蜿蜒而上。我们慢慢地走，时不时停下来休息。
The path was covered with pine needles and rose up the side of the mountain in zig-zags. We walked at an easy pace, often stopping to rest.

万里子很安静，而且——让我很意外——一点都没有要淘气的样子，只是奇怪不愿意跟她妈妈和我走在一起。
Mariko was quiet and — rather to my surprise — showed no signs of wishing to misbehave. She did however display a curious reluctance to walk alongside her mother and myself.

她一会儿落在后面，让我们担心地回过头去看；一会儿又跑过去，走在前头。
One moment she would be lagging behind, causing us to cast anxious glances over our shoulders; the next moment, she would go running past us and walk on ahead.

在我们从缆车上下来约一个小时以后，我们第二次遇到那个美国女人。
We met the American woman for the second time an hour or so after we had disembarked from the cable-car.

她和她的同伴正从山上下来，认出了我们，高兴地打招呼。
She and her companion were coming back down the path and, recognizing us, gave cheerful greetings.

胖胖的小男孩走在她们后面，没有跟我们打招呼。
The tubby boy, coming behind them, ignored us.

美国女人走过去时用英语跟佐知子说了什么，听了佐知子的回答以后笑了起来。
As she passed, the American woman said something to Sachiko in English, and when Sachiko replied, gave a loud laugh.

她好像想停下来交谈，可是日本女人跟她儿子没有停下脚步；美国女人挥挥手，继续往前走。
She seemed to want to stop and talk, but the Japanese woman and her son did not break their step; the American woman waved and walked on.

当我称赞佐知子的英语时，她笑了笑，没说什么。
When I complimented Sachiko on her command of English, she laughed and said nothing.

我注意到这次偶遇在她身上产生了奇怪的效应。
The encounter, I noticed, had had a curious effect upon her.

她变得很安静，边走边陷入了沉思。
She became quiet, and walked on beside me as if lost in thought.

当万里子又冲到前面去时，她对我说：
Then, when Mariko had once more rushed on ahead, she said to me:

“我父亲是个很受人尊敬的人，悦子。
“My father was a highly respected man, Etsuko. Highly respected indeed.

德高望重。可是他的海外关系差点毁了我的婚事。”
But his foreign connections almost resulted in my marriage proposal being withdrawn.”

她微微一笑，摇了摇头说，“真奇怪，悦子。
She smiled slightly and shook her head. “How odd, Etsuko.

现在这些都恍若隔世。”
That all seems like another age now.”

“是啊，”我说。
“Yes,” I said.

“一切都大变样了。”
“Things have changed so much.”

山路转了一个大弯，又是上坡。
The path bent sharply and began to climb again.

树木变少了，突然在我们周围天空豁然开朗。
The trees fell away and suddenly the sky seemed huge all around us.

前头，万里子叫了起来，指着什么东西，然后兴冲冲地往前跑去。
Up ahead, Mariko shouted something and pointed. Then she hurried on excitedly.

“我很少见到我父亲，”佐知子说。
“I never saw a great deal of my father,” Sachiko said.

“他大部分时间都在国外，在欧洲和美国。
“He was abroad much of the time, in Europe and America.

我小时候曾经梦想有一天我会去美国，去那里变成电影明星。
When I was young, I used to dream I'd go to America one day, that I'd go there and become a film actress.

我妈妈笑话我，可是爸爸说我要是把英语学好了，就能很容易地成为一个女商人。
My mother used to laugh at me. But my father told me if I learnt my English well enough, I could easily become a business girl.

我以前很喜欢学英语。”
I used to enjoy learning English.”

万里子在一个像是平地的地方停下来，又朝我们不知道喊了什么。
Mariko had stopped at what looked like a plateau. She shouted something to us again.

“我记得有一次，”佐知子接着说，“我父亲从美国带了一本书给我，英文版的《圣诞颂歌》。
“I remember once,” Sachiko went on, “my father brought a book back from America for me, an English version of A Christmas Carol.

它成了我的目标，悦子。
That became something of an ambition of mine, Etsuko.

我想学好英语，看懂那本书。
I wanted to learn English well enough to read that book.

可惜没有机会实现。
Unfortunately, I never had the chance.

结婚以后，我丈夫不准我继续学。
When I married, my husband forbade me to continue learning.

事实上，他让我把那本书扔掉。”
In fact, he made me throw the book away.”

“太可惜了，”我说。
“That seems rather a pity,” I said.

“我丈夫就是这样，悦子。
“My husband was like that, Etsuko.

很严厉，很爱国。
Very strict and very patriotic.

他从来不是一个体谅别人的人。
He was never the most considerate of men.

但是他的家庭出身很好，我父母觉得门当户对。
But he came from a highly distinguished family and my parents considered it a good match.

他禁止我学英语时我没有反对。
I didn't protest when he forbade me to study English.

毕竟没有意义了。”
After all, there seemed little point any more.”

我们走到万里子站的地方；小路的边上有一块突出去的四方形平地，周围围着几块大石头。
We reached the spot where Mariko was standing; it was a square area of ground that jutted off the edge of the path, bound in by several large boulders.

一根倒下来的巨大树干表面被刨光、弄平，做成长椅。
A thick tree trunk fallen on to its side had been converted into a bench, the top surface having been smoothed and flattened.

佐知子和我坐下来歇口气。
Sachiko and I sat down to recover our breath.

“别太靠近边上，万里子，”佐知子喊道。
“Don't go too near the edge, Mariko,” Sachiko called.

小女孩已经走到大石头那里去，拿起望远镜看。
The little girl had walked out to the boulders and was looking at the view with her binoculars.

坐在山的边缘俯视这番景色，我有一种忐忑不安的心情；在我们底下很远的地方可以看见港口，像个掉在水里的精密的机器零部件。
I had a rather precarious feeling, perched on the edge of that mountain looking out over such a view; a long way down below us, we could see the harbour looking like a dense piece of machinery left in the water.

港口过去，对岸是通向长崎的群山。
Across the harbour, on the opposite bank, rose the series of hills that led into Nagasaki.

山脚下房屋密布，高高低低。
The land at the foot of the hills was busy with houses and buildings.

远处右手边是港口的入海口。
Far over to our right, the harbour opened out on to the sea.

我们在那里稍坐片刻，歇口气、吹吹风。
We sat there for a while, recovering our breath and enjoying the breeze.

这时我说道：
Then I said:

“你不会想到这里曾经发生的一切，不是吗？
“You wouldn't think anything had ever happened here, would you?

一切看上去是那么生机勃勃。
Everything looks so full of life.

可是下面那一整片”——我朝底下的景色挥了挥手——“那一整片在炸弹掉下来的时候受了多么严重的打击。
But all that area down there” — I waved my hand at the view below us — “all that area was so badly hit when the bomb fell.

可是看看现在。”
But look at it now.”

佐知子点点头，然后笑着转向我，说：“你今天心情真不错啊，悦子。”
Sachiko nodded, then turned to me with a smile. “How cheerful you are today, Etsuko,” she said.

“到这里来走走真是太好了。
“But it's so good to come out here.

我决定从今往后要乐观。
Today I've decided I'm going to be optimistic.

我以后一定要过得幸福。
I'm determined to have a happy future.

藤原太太一直对我说往前看是多么重要。
Mrs Fujiwara always tells me how important it is to keep looking forward.

她是对的。
And she's right.

假设人们没有往前看，那么这里”——我又指了指底下的景色——“这里就都还是废墟一片。”
If people didn't do that, then all this” — I pointed again at the view — “all this would still be rubble.”

佐知子又笑了。
Sachiko smiled again.

“是啊，你说得对，悦子。
“Yes, as you say, Etsuko.

这里就都还是废墟一片。”说完，她又回头看着下面的风景。
It would all be rubble.” For a few moments, she continued to gaze at the view below us.

过了一会儿她说：“对了，悦子，你的朋友，藤原太太，我想她在战争中失去了她的家人是吧。”
“Incidentally, Etsuko,” she said, after a while, “your friend, Mrs Fujiwara. I assume she lost her family in the war.”

我点点头。
I nodded.

“以前她有五个孩子。
“She had five children.

她丈夫还是长崎的重要人物。
And her husband was an important man in Nagasaki.

炸弹掉下来的时候，除了大儿子以外都死了。
When the bomb fell, they all died except her eldest son.

她一定受了很大的打击，可是她还一直坚持。”
It must have been such a blow to her, but she just kept going.”

“是啊，”佐知子慢慢地点着头，说，“我猜有这类事情。
“Yes,” said Sachiko, nodding slowly, “I thought something of that nature had happened.

那她一直都是开面馆的吗？”
And did she always have that noodle shop of hers?”

“没有，当然没有了。
“No, of course not.

她丈夫是个要人。
Her husband was an important man.

是后来，她失去了一切以后才有面馆的。
That was only afterwards, after she lost everything.

每次我看见她，都对自己说：我应该像她那样，我应该往前看。
Whenever I see her, I think to myself I have to be like her, I should keep looking forward.

因为从很多方面来说，她失去的比我多。
Because in many ways, she lost more than I did.

毕竟看看我现在。
After all, look at me now.

我要开始组建自己的家庭了。”
I'm about to start a family of my own.”

“是啊，你说得太对了。”
“Yes, how right you are.”

风吹乱了佐知子梳得整整齐齐的头发。
The wind had disturbed Sachiko's carefully combed hair.

她捋了一下头发，然后深深地吸了一口气，“你说得太对了，悦子，我们不应该老想着过去。
She passed her hand through it, then took a deep breath, “How right you are Etsuko, we shouldn't keep looking back to the past.

战争毁了我的很多东西，可是我还有我的女儿。
The war destroyed many things for me, but I still have my daughter.

正如你说的，我们应该往前看。”
As you say, we have to keep looking forward.”

“你知道吗，”我说，“我是最近几天才认真地想这件事的。
“You know,” I said, “it's only in the last few days I've really thought about what it's going to be like.

我是指为人父母。
To have a child, I mean.

现在我没有那么害怕了。
I don't feel nearly so afraid now.

我要高高兴兴地迎接它。
I'm going to look forward to it.

从今往后我要乐观。”
I'm going to be optimistic from now on.”

“你就应该这样，悦子。
“And so you should, Etsuko.

毕竟你还有很多盼头。
After all, you have a lot to look forward to.

其实你很快就会发现，是做母亲让生活变得真正有意义。
In fact, you'll discover soon enough, it's being a mother that makes life truly worthwhile.

住在我伯父家里闷了点又有什么关系呢？
What do I care if life is a little dull at my uncle's house?

我只要给我女儿最好的。
All I want is what's best for my daughter.

我们要给她请最好的家庭教师，她很快就会把功课赶上。
We'll get her the best private tuition and she'll catch up on her schoolwork in no time.

正如你说的，悦子，我们必须对生活乐观。”
As you say, Etsuko, we must look forward to life.”

“你这么想我真高兴，”我说。
“I'm so glad you feel like that,” I said.

“我们俩真的都应该心存感激。
“We should both of us be grateful really.

我们也许在战争中失去了很多，但是还有那么多盼头。”
We may have lost a lot in the war, but there's still so much to look forward to.”

“是啊，悦子。
“Yes, Etsuko.

还有很多盼头。”
There's a lot to look forward to.”

万里子走过来，站在我们面前。
Mariko came nearer and stood in front of us.

也许她听见了我们的一些谈话，因为她对我说：
Perhaps she had overheard some of our conversation, for she said to me:

“我们又要和安子阿姨一起住了。
“We're going to live with Yasuko-San again.

妈妈有没有告诉你？”
Did Mother tell you?”

“有，”我说，“她告诉我了。
“Yes,” I said, “she did.

你很想再回到那里去住吗，万里子？”
Are you looking forward to living there again, Mariko-San?”

“现在我们可以留着小猫了，”小女孩说。
“We might be able to keep the kittens now,” the little girl said.

“安子阿姨的房子很大。”
“There's plenty of room at Yasuko-San's house.”

“这件事还要再看，万里子，”佐知子说。
“We'll have to see about that, Mariko,” said Sachiko.

万里子看了她妈妈一会儿，然后说：“可是安子阿姨喜欢猫。
Mariko looked at her mother for a moment. Then she said: “But Yasuko-San likes cats.

再说，反正圆圆本来就是我们从她那里拿过来的。
And anyway, Maru was Yasuko-San's cat before we took her.

所以那些小猫也是她的。”
So the kittens are hers too.”

“是没错，万里子，可是我们还得看看。
“Yes, Mariko, but we'll have to see.

我们得看看安子阿姨的爸爸怎么说。”
We'll have to see what Yasuko-San's father will say.”

小女孩生气地看了她妈妈一眼，然后又转向我，表情严肃地说：“我们可以留着小猫。”
The little girl regarded her mother with a sullen look, then turned to me once more. “We might be able to keep them,” she said, with a serious expression.

下午快过去的时候，我们回到了下缆车时的空旷地。
Towards the latter part of the afternoon, we found ourselves back at the clearing where we had first stepped off the cable-car.

我们的午餐盒里还有一些饼干和巧克力，我们就在一张野餐桌上坐下，吃了起来。
There still remained in our lunch-boxes some biscuits and chocolates, so we sat down for a snack at one of the picnic tables.

空地的那头，一些人站在铁栏杆旁，等下山的缆车。
At the other end of the clearing, a handful of people were gathered near the metal fence, awaiting the cable-car that would take them back down the mountain.

我们坐了几分钟，突然听见有人叫我们。
We had been sitting at the picnic table for several minutes when a voice made us look up.

那个美国女人大踏步地从空地的那头走过来，笑容满脸。
The American woman came striding across the clearing, a broad smile on her face.

她一屁股坐下，一点儿也没有觉得不好意思，朝我们一个个笑了笑之后就跟佐知子说起英语来。
Without the least sign of bashfulness, she sat down at our table, smiled to us in turn, then began to address Sachiko in English.

我想她很高兴有机会交谈，而不是用手比划。
She was, I supposed, grateful for the chance to communicate other than by means of gestures.

我朝周围看了看，果然看见那个日本女人就在附近，在给她儿子穿外套。
Looking around, I spotted the Japanese woman nearby, putting a jacket on her son.

她不是很想跟我们一起的样子，但最后还是微笑地走过来。
She appeared less enthusiastic for our company, but eventually she came towards our table with a smile.

她在我对面坐下，她儿子坐在她身旁，这时我发现母子俩的体型很像，都是圆圆胖胖的；最明显的是两个人的脸颊都有垂肉，有点像斗牛犬。
She sat down opposite me, and when her son sat beside her, I could see the extent to which mother and child shared the same plump features; most noticeably, their cheeks had a kind of fleshy sagginess to them, not unlike the cheeks of bulldogs.

美国女人一直高声地跟佐知子讲个不停。
The American woman, all the while, continued to talk loudly to Sachiko.

在陌生人到来之前，万里子已经打开她的素描本，开始画画。
At the arrival of the strangers, Mariko had opened her sketchbook and begun to draw.

胖脸女人跟我寒暄过后转向小女孩。
The plump-faced woman, after exchanging a few pleasantries with me, turned to the little girl.

“你今天玩得开心吗？”她问万里子。
“And have you enjoyed your day?” she asked Mariko.

“这上面很漂亮，不是吗？”
“It's very pretty up here, isn't it?”

万里子仍旧低着头画画。
Mariko continued to crayon her page, not looking up.

可是女人一点儿也没有在意。
The woman, however, did not seem in the least deterred.

“你在画什么呢？”她问。
“What are you drawing there?” she asked.

“很漂亮的样子。”
“It looks very nice.”

这次万里子停了下来，冷冷地看着日本女人。
This time, Mariko stopped drawing and looked at the woman coldly.

“很漂亮的样子。
“That looks very nice.

可以让我们看看吗？”女人伸手拿过素描本。
May we see?” The woman reached forward and took the sketchbook.

“是不是很漂亮，阿明？”她对她儿子说。
“Aren't these nice, Akira,” she said to her son.

“小姐姐是不是很聪明？”
“Isn't the little lady clever?”

男孩趴到桌子上来，好看得清楚些。
The boy leaned across the table for a better view.

他饶有兴趣地看着万里子的画，但是没说什么。
He regarded the drawings with interest, but said nothing.

“真是漂亮。”
“They're very nice indeed.”

女人翻着素描本。
The woman was turning over the pages.

“这些都是今天画的吗？”
“Did you do all these today?”

一开始万里子没有答话。
Mariko remained silent for a moment.

但过了一会儿，她说道：“这些蜡笔是新的。
Then she said: “The crayons are new.

今天早上才买的。
We bought them this morning.

新蜡笔比较不好画。”
It's harder to draw with new crayons.”

“这样啊。
“I see.

是啊，新蜡笔比较不好画，不是吗？
Yes, new crayons are harder, aren't they?

阿明也画画，是不是，阿明？”
Akira here draws too, don't you, Akira?”

“画画很简单，”男孩说。
“Drawing's easy,” the boy said.

“这些小画是不是很漂亮，阿明？”
“Aren't these nice little pictures, Akira?”

万里子指着翻开的那一页，说：“我不喜欢这一张。
Mariko pointed to the open page. “I don't like that one there.

蜡笔还磨得不够。
The crayons weren't worn in enough.

下面一张比较好。”
The one on the next page is better.”

“哦是啊。
“Oh yes.

这张真漂亮！”
This one's lovely!”

“这张是在港口画的，”万里子说。
“I did it down at the harbour,” said Mariko.

“可是那里又吵又热，所以我匆匆忙忙地画的。”
“But it was noisy and hot down there, so I hurried.”

“可是画得很好。
“But it's very good.

你喜欢画画吗？”
Do you enjoy drawing?”

“喜欢。”
“Yes.”

佐知子和美国女人也都转过来看素描本。
Sachiko and the American woman had both turned towards the sketchbook.

美国女人指着上面的画，大声地用日语说了好几次“太棒了”。
The American woman pointed at the drawing and uttered loudly several times the Japanese word for “delicious”.

“这是什么？”胖脸女人又问道。
“And what's this?” the plump-faced woman continued.

“是蝴蝶啊！
“A butterfly!

把蝴蝶画这么好一定很不容易吧。
It must have been very hard to draw it so well.

蝴蝶不会一直呆着不动。”
It couldn't have stayed still for very long.”

“我记得它的样子，”万里子说。
“I remembered it,” said Mariko.

“我之前看见一只。”
“I saw one earlier on.”

女人点点头，然后转向佐知子。
The woman nodded, then turned to Sachiko.

“你女儿真聪明。
“How clever your daughter is.

我想一个小孩会用记忆和想象是很值得表扬的。
I think it's very commendable for a child to use her memory and imagination.

这个年纪的很多孩子都还只会照着书上的画。”
So many children at this age are still copying out of books.”

“是啊，”佐知子说。
“Yes,” said Sachiko.

“我想是这样。”
“I suppose so.”

佐知子的语气里带着轻蔑，让我很是惊讶，因为她一直在极其友好地跟美国女人说话。
I was rather surprised at the dismissiveness of her tone, for she had been talking to the American woman in her most gracious manner.

敦实的男孩趴得更近了些，用手指指着画页。
The tubby boy leaned further across the table and put his finger to the page.

“那些船太大了，”他说。
“Those ships are too big,” he said.

“如果那个是树的话，那船应该要画得小很多。”
“If that's supposed to be a tree, then the ships would be much smaller.”

他妈妈想了想，说：“啊，也许。
His mother considered this for a moment. “Well, perhaps,” she said.

可这幅画还是很漂亮。你不觉得吗，阿明？”
“But it's a lovely little drawing all the same. Don't you think so, Akira?”

“船画得太大了，”男孩说。
“The ships are far too big,” said the boy.

女人笑了笑。
The woman gave a laugh.

“你可千万别生阿明的气，”她对佐知子说。
“You must excuse Akira,” she said to Sachiko.

“你瞧，他有一个非常优秀的美术家庭教师，所以他明显比大部分同龄的孩子在这些方面更有眼力。
“But you see, he has a quite distinguished tutor for his drawing, and so he's obviously much more discerning about these things than most children his age.

你女儿有教画画的家庭教师吗？”
Does your daughter have a tutor for her drawing?”

“没有。”
“No, she doesn't.”

佐知子的语气仍旧很冷淡。
Again, Sachiko's tone was unmistakably cold.

可是那个女人丝毫没有察觉。
The woman, however, appeared to notice nothing.

“请人来教画画根本不是什么坏主意，”她接着说。
“It's not a bad idea at all,” she went on. “My husband was against it at first.

“我丈夫一开始不同意。他觉得阿明有数学和科学的家庭教师就够了。
He thought it was quite enough for Akira to have home tuition for maths and science.

但是我认为画画也很重要。
But I think drawing is important too.

孩子应该从小培养他的想象力。
A child should develop his imagination while he's young.

学校的老师也同意我的看法。
The teachers at school all agreed with me.

可是他学得最好的是数学。我认为数学很重要，你说呢？”
But he gets on best with maths, I think maths is very important, don't you?”

“是，确实，”佐知子说。
“Yes, indeed,” said Sachiko.

“我相信数学很有用。”
“I'm sure it's very useful.”

“数学能提高孩子的智力。
“Maths sharpens children's minds.

你会发现大多数数学学得好的孩子其他方面也都很好。
You'll find most children good at maths are good at most other things.

关于请数学老师我丈夫和我没有异议。
My husband and I were in no disagreement about getting a maths tutor.

结果很值得。
And it's been well worth it.

去年，阿明在班上一直是第三、第四名，可今年一直是第一。”
Last year, Akira always came third or fourth in his class, but this year he's been top throughout.”

“数学很简单，”男孩说道。
“Maths is easy,” the boy announced.

接着他问万里子：“你会九九乘法表吗？”
Then he said to Mariko: “Do you know the nine times table?”

他妈妈又笑了。
His mother laughed again.

“我猜这个小姑娘一定也很聪明。
“I expect the little lady's very clever too.

从她的画就能看出来。”
Her drawing certainly shows promise.”

“数学很简单，”男孩再次说道。
“Maths is easy,” the boy said again.

“九九乘法表简单得不得了。”
“The nine times table is easy as anything.”

“是啊，阿明已经会整张乘法表了。
“Yes, Akira knows all his multiplication now.

很多同龄的孩子只会算到三或四。
A lot of children his age only know it up to three or four.

阿明，九乘以五得多少？”
Akira, what's nine times five?”

“九五四十五！”
“Nine times five make forty-five!”

“那九乘以九呢？”
“And nine times nine?”

“九九八十一！”
“Nine times nine make eighty-one!”

美国女人问了佐知子什么，佐知子点点头，美国女人就拍了拍手，又用日语说了几次“太棒了”。
The American woman asked Sachiko something, and when Sachiko nodded she clapped her hands and once more repeated the word “delicious” several times.

“你女儿看来很聪明，”胖脸女人对佐知子说。
“Your daughter seems a bright little lady,” the plump-faced woman said to Sachiko.

“她喜欢上学吗？
“Does she enjoy school?

阿明几乎喜欢学校里的所有科目。
Akira likes almost everything at school.

除了数学和画图，他的地理也很好。
Apart from maths and drawing, he gets on very well with geography.

我的这位朋友很惊讶地发现阿明知道美国所有大城市的名字。
My friend here was very surprised to find Akira knew the names of all the large cities in America.

是不是，苏西小姐？”
Weren't you, Suzie-San?”

女人转向她的朋友，说了几个结结巴巴的英语单词。
The woman turned to her friend and spoke several faltering words of English.

美国女人没听懂，但是朝男孩赞许地笑了笑。
The American woman did not appear to understand, but smiled approvingly towards the boy.

“可阿明最喜欢的科目是数学。
“But maths is Akira's favourite subject.

是不是，阿明？”
Isn't it, Akira?”

“数学很简单！”
“Maths is easy!”

“这个小姑娘最喜欢的科目是什么呢？”女人再次转向万里子，问道。
“And what does the little lady enjoy most at school?” the woman asked, turning again to Mariko.

万里子没有马上回答。
Mariko did not answer for a moment.

过了一会儿，她说：“我也喜欢数学。”
Then she said: “I like maths too.”

“你也喜欢数学。
“You like maths too.

太好了。”
That's splendid.”

“那九乘以六是多少？”男孩生气地问她。
“What's nine times six then?” the boy asked her angrily.

“孩子喜欢学校的功课真是太好了，不是吗？”他妈妈说。
“It's so nice when children take an interest in their schoolwork, isn't it?” said his mother.

“快点啊，九乘以六是多少？”
“Go on, what's nine times six?”

我问：“阿明君长大以后想做什么？”
I asked: “What does Akira-San want to do when he grows up?”

“阿明，告诉这位阿姨你长大以后想当什么。”
“Akira, tell the lady what you're going to become.”

“三菱公司的董事长！”
“Head Director of Mitsubishi Corporation!”

“他爸爸的公司，”他母亲解释道。
“His father's firm,” his mother explained.

“阿明已经下定决心了。”
“Akira's already very determined.”

“是，我知道了，”我笑着说。
“Yes, I see,” I said, smiling.

“多好啊。”
“How wonderful.”

“你爸爸在哪里工作？”男孩问万里子。
“Who does your father work for?” the boy asked Mariko.

“好了，阿明，别问东问西的，没有礼貌。”
“Now, Akira, don't be too inquisitive, it's not nice.”

女人又转向佐知子。
The woman turned to Sachiko again.

“很多同龄的男孩子都还只会说想当警察啊、消防员啊。
“A lot of boys his age are still saying they want to be policemen or firemen.

可是阿明很小的时候就想到三菱工作了。”
But Akira's wanted to work for Mitsubishi since he was much younger.”

“你爸爸在哪里工作？”男孩又问了一次。
“Who does your father work for?” the boy asked again.

这次他妈妈没有阻止他，而是好奇地看着万里子。
This time his mother, instead of intervening, looked towards Mariko expectantly.

“他是动物园里的饲养员，”万里子说。
“He's a zoo-keeper,” said Mariko.

一时间没有人说话。
For a brief moment, no one spoke.

奇怪的是，万里子的回答似乎挫了男孩的锐气，他阴沉着脸坐回椅子上。
Curiously, the answer seemed to humble the boy, and he sat back on his bench with a sulky expression.

这时，他母亲有点不知所措地说：
Then his mother said a little uncertainly:

“多有意思的职业啊。
“What an interesting occupation.

我们都很喜欢动物。
We're very fond of animals.

你丈夫的动物园在这附近吗？”
Is your husband's zoo near here?”

佐知子还没来得及回答，万里子就窸窸窣窣地爬下椅子，一声不响地朝附近的树丛走去。
Before Sachiko could reply, Mariko had clambered off the bench noisily. Without a word, she walked away from us, towards a cluster of trees nearby.

我们都看着她。
We all watched her for a moment.

“她是你最大的孩子吗？”女人问佐知子。
“Is she your eldest?” the woman asked Sachiko.

“我只有一个。”
“I have no others.”

“哦，这样。
“Oh, I see.

这也不是什么坏事。
It's no bad thing really.

独生子女更独立。
A child can become more independent that way.

而且我想独生子女通常也更刻苦。
I think a child often works harder too.

我们这个”——她把手放到男孩的头上——“和老大相差六岁。”
There's six years’ difference between this one” — she put her hand on the boy's head — “and the eldest one.”

美国女人惊呼一声，拍起手来。
The American woman produced a loud exclamation and clapped her hands.

万里子正稳稳地爬上树枝。
Mariko was progressing steadily up the branches of a tree.

胖脸女人在座位上转过身去，担心地看着万里子。
The plump-faced woman turned in her seat and looked up at Mariko worriedly.

“你女儿真像个假小子，”她说。
“Your daughter's quite a tomboy,” she said.

美国女人开心地重复了一遍“假小子”，又拍起手来。
The American woman repeated the word “tomboy” gleefully, and clapped her hands again.

“这样安全吗？”胖脸女人问。
“Is it safe?” the plump-faced woman asked.

“她可能会掉下来。”
“She might fall.”

佐知子笑了笑，对那个女人的态度突然变得热情得多。
Sachiko smiled, and her manner towards the woman seemed to grow suddenly warmer.

“你不习惯孩子爬树吗？”她问。
“Are you not used to children climbing trees?” she asked.

胖脸女人仍旧担心地看着万里子。
The woman continued to watch anxiously.

“你肯定这样安全吗？
“Are you sure it's safe?

树枝可能会断掉。”
A branch may break.”

佐知子笑了一声。
Sachiko gave a laugh.

“我肯定我女儿知道自己在做什么。
“I'm sure my daughter knows what she's doing.

谢谢你的关心。
Thank you all the same for your concern.

你真好心。”
It's so kind of you.”

说着优雅地鞠了一躬。
She gave the woman an elegant bow.

这时美国女人跟佐知子说了什么，她们俩又用英语聊开了。
The American woman said something to Sachiko, and they began conversing again in English.

胖脸女人把视线从树上收回来。
The plump-faced woman turned away from the trees.

“请千万别怪我多管闲事，”她一只手搭在我的胳膊上，说，“可是我忍不住注意到，这是你的第一胎吧？”
“Please don't think me impertinent,” she said, putting a hand on my arm, “but I couldn't help noticing. Will this be your first time?”

“是的，”我笑着说。
“Yes,” I said, with a laugh.

“预产期在秋天。”
“We're expecting it in the autumn.”

“多好啊。
“How splendid.

对了，你丈夫也是饲养员吗？”
And your husband, is he also a zoo-keeper?”

“哦，不是。
“Oh no.

他在电器公司工作。”
He works for an electronics firm.”

“真的？”
“Really?”

胖脸女人开始给我一些照顾婴儿方面的建议。
The woman began to give me advice concerning the care of babies.

这时，我越过她的肩膀看见男孩离开桌子，朝万里子爬的树走去。
Meanwhile, I could see over her shoulder the boy wandering away from the table towards Mariko's tree.

“应该让孩子多听好的音乐，”女人说。
“And it's an idea to let the child hear a lot of good music,” the woman was saying.

“我肯定效果很明显。
“I'm sure that makes a lot of difference.

孩子从一开始就应该听好音乐。”
A child should hear good music amongst his earliest sounds.”

“是的，我很喜欢音乐。”
“Yes, I'm very fond of music.”

男孩站在树下，抬头困惑地看着万里子。
The boy was standing at the foot of the tree, looking up at Mariko with a puzzled expression.

“我们大儿子的音乐鉴赏力没有阿明好，”女人接着说。
“Our older son doesn't have as fine an ear for music as Akira,” the woman went on.

“我丈夫说是因为他很小的时候没有听够多的好音乐，我认为他说得对。
“My husband says this is because he didn't hear enough good music when he was a baby, and I tend to think he's right.

那时的广播放了太多的军乐。
In those days, the radio was broadcasting so much military music.

我确信一点儿好处都没有。”
I'm sure it did no good at all.”

胖脸女人说话时，我看见男孩试着在树干上找一个踏脚的地方。
As the woman continued to talk, I could see the boy trying to find a foothold in the tree-trunk.

万里子爬下来一些，像是在教他。
Mariko had come lower and appeared to be advising him.

在我身旁，美国女人一直大笑不停，时不时蹦出几个日语单词。
Beside me, the American woman kept laughing loudly, occasionally uttering single words of Japanese.

男孩终于成功地离开地面；他一只脚踩在树缝里，双手紧紧握住一根树枝。
The boy finally managed to hoist himself off the ground; he had one foot pressed into a crevice and was holding on to a branch with both hands.

虽然离地面只有几厘米，但他看上去很紧张。
Although only a few centimetres off the ground, he seemed in a state of high tension.

很难说万里子是不是故意的，只是万里子在下来时，狠狠地踩在了男孩的手指上。
It was hard to say if she did so deliberately, but as she lowered herself, the little girl trod firmly on the boy's fingers.

男孩尖叫一声，笨重地摔了下来。
The boy gave a shriek, falling clumsily.

他母亲惊恐地转过头去。
The mother turned in alarm.

佐知子和美国女人不知道发生了什么，也都看了过来。
Sachiko and the American woman, neither of whom had seen the incident, also turned towards the fallen boy.

男孩侧躺在地上，号啕大哭。
He was lying on his side making a loud noise.

他母亲赶忙跑过去，跪下去检查他的腿。
His mother ran to him and kneeling beside him began to feel his legs.

男孩不停地哭。
The boy continued his noises.

空地那头等缆车的乘客都往这边看。
Across the clearing, passengers waiting for the cable-car were all looking our way.

大约一分钟以后，男孩呜咽着被他妈妈带回桌子这边。
After a minute or so, the boy came sobbing to the table, guided by his mother.

“爬树很危险，”女人生气地说。
“Tree-climbing is so dangerous,” the woman said, angrily.

“他摔得不重，”我安慰她说。
“He didn't fall far,” I assured her.

“他根本没有爬多高。”
“He was hardly on the tree at all.”

“他可能摔断骨头。
“He might have broken a bone.

我想应该阻止孩子爬树。
I think children should be discouraged from climbing trees.

爬树太愚蠢了。”
It's so silly.”

“她踢我，”男孩哭着说。
“She kicked me,” the boy sobbed.

“她把我从树上踢下来。
“She kicked me off the tree.

她要杀我。”
She tried to kill me.”

“她踢你？
“She kicked you?

小姑娘踢你？”
The little girl kicked you?”

我看见佐知子瞥了她女儿一眼。
I saw Sachiko cast a glance towards her daughter.

万里子又爬到高高的树上去了。
Mariko was once more high up the tree.

“她要杀我。”
“She tried to kill me.”

“小姑娘踢你？”
“The little girl kicked you?”

“你儿子只是脚踩滑了，”我赶紧插嘴说。
“Your son just slipped,” I interrupted quickly.

“我都看见了。
“I saw it all.

他根本没摔着。”
He hardly fell any distance.”

“她踢我。
“She kicked me.

她要杀我。”
She tried to kill me.”

女人也转过头去看那棵树。
The woman also turned and glanced towards the tree.

“他只是脚踩滑了，”我重复道。
“He just slipped,” I said again.

“你不应该做这种蠢事，阿明，”女人生气地说。
“You shouldn't be doing such silly things, Akira,” the woman said, angrily.

“爬树很危险。”
“It's very very dangerous to climb trees.”

“她要杀我。”
“She tried to kill me.”

“你不准再爬树。”
“You're not to go up trees.”

男孩继续抽泣着。
The boy continued to sob.

比起英国，日本城市里的旅馆、茶馆、商店似乎更加喜欢夜幕降临；天还没黑，窗户上的灯笼、门口的霓虹招牌早早就亮了起来。
In Japanese cities, much more so than in England, the restaurant owners, the teahouse proprietors, the shopkeepers all seem to will the darkness to fall; long before the daylight has faded, lanterns appear in the windows, lighted signs above doorways.

那天傍晚，当我们重新走上长崎的街道时，已经灯火通明了；我们快傍晚时离开稻佐山，在浜屋百货公司里的美食街吃了晚饭。
Nagasaki was already full of the colours of night-time as we came back out into the street that evening; we had left Inasa in the late afternoon and had been eating supper on the restaurant floor of the Hamaya department store.

晚饭后，我们还不想回去，在巷子里慢慢地溜达，并不急着去电车站。
Afterwards, reluctant to end the day, we found ourselves strolling through the sidestreets, in little hurry to reach the tram depot.

我记得那时的年轻情侣流行在街上手牵手——我和二郎从来没有过——我们一路走着，看见很多这样的情侣在寻找晚上的娱乐。
In those days, I remember it had become the vogue for young couples to be seen in public holding hands — something Jiro and I had never done — and as we walked we saw many such couples seeking their evening's entertainment.

夏季傍晚的天空变成了浅紫色。
The sky, as often on those summer evenings, had become a pale purple colour.

路旁有很多卖鱼的小摊，傍晚的这个时候，渔船都回港了，你经常能看到肩上扛着满满一箱刚打上来的鱼的男人穿梭在拥挤的巷子里。
Many of the stalls sold fish, and at that time of the evening, when the fishing boats were coming into the harbour, one would often see men pushing their way through the crowded sidestreets, carrying on their shoulders baskets heavy with freshly caught fish.

就是在这样一条有很多垃圾和悠闲漫步者的巷子里，我们遇到了那个抓阄儿的小摊。
It was in one such sidestreet, filled with litter and casually strolling people, that we came across the kujibiki stand.

我从来不去那种小摊凑热闹，在英国也没有那种小摊——也许集市里有——所以要不是想起那个傍晚，我可能已经不记得那种东西了。
Since it was never my habit to indulge in kujibiki and since it has no equivalents here in England — except perhaps in fairgrounds — I might well have forgotten the existence of such a thing were it not for my memory of that particular evening.

我们站在人群后面看。
We stood at the back of the crowd and watched.

一个女人抱着一个两三岁的小男孩；台上，一个绑着头巾的男人弯下腰来，好让男孩能够到碗。
A woman was holding up a young boy of around two or three; up on the platform, a man with a handkerchief tied around his head was stooping forward with the bowl so the child could reach.

小男孩好不容易从碗里抽出一个签来，却似乎不知道该怎么办。
The boy managed to pick out a ticket, but did not seem to know what to do with it.

他把签捏在手里，茫然地看着周围的一张张笑脸。
He held it in his hand and looked emptily at the amused faces all around him.

绑着头巾的男人把腰弯得更低，对小男孩说了什么，惹得旁边的人想笑。
The man with the handkerchief bent lower and made some remark to the child which caused the people round about to laugh.

最后，母亲把孩子放下来，拿过他手里的签，递给那个男人。
In the end, the mother lowered her child, took the ticket from him, and handed it to the man.

小男孩抽中了一支口红，女人笑着收下了。
The ticket won a lipstick, which the woman accepted with a laugh.

万里子踮起脚尖看小摊的后面摆着些什么奖品。
Mariko was standing on her tip-toes, trying to see the prizes displayed at the back of the stall.

突然她转向佐知子，说：“我要抽一次签。”
Suddenly she turned to Sachiko and said: “I want to buy a ticket.”

“这纯粹是浪费钱，万里子。”
“It's rather a waste of money, Mariko.”

“我要抽一次签。”
“I want to buy a ticket.”

她显得很急迫，真让人奇怪。
There was a curious urgency in her manner.

“我想试试这个抓阄儿。”
“I want to try the kujibiki.”

“给你，万里子。”
“Here you are, Mariko-San.”

我递给她一个硬币。
I offered her a coin.

她有点吃惊地转向我，然后接过硬币，挤到人群的前面去。
She turned to me, a little surprised. Then she took the coin and pushed her way through to the front of the crowd.

又有几个人试了试手气；一个女人抽中一块糖果，一个中年男子抽中一个橡皮球。
A few more contestants tried their luck; a woman won a piece of candy, a middle-aged man won a rubber ball.

接着轮到万里子。
Then came Mariko's turn.

“好了，小妹妹，”——男人慢慢地摇了摇碗——“闭上眼睛，努力地想那边的那只大熊。”
“Now, little princess,” — the man shook the bowl with deliberation — “close your eyes and think hard about that big bear over there.”

“我不要熊，”万里子说。
“I don't want the bear,” said Mariko.

男人做了个鬼脸，大家都笑了。
The man made a face and the people laughed.

“你不要那只大毛绒熊？
“You don't want that big furry bear?

好，好，小妹妹，那你要什么呢？”
Well, well, little princess, what is it you want then?”

万里子指着小摊的后面，说：“那个篮子。”
Mariko pointed to the back of the stall. “That basket,” she said.

“那个篮子？”
“The basket?”

男人耸了耸肩。
The man shrugged.

“好吧，小妹妹，紧紧地闭上眼睛，想着你的篮子。
“All right, princess, close your eyes tight and think about your basket.

准备好了吗？”
Ready?”

万里子抽中了一个花盆。
Mariko's ticket won a flowerpot.

她回到我们站的地方，把奖品递给我。
She came back to where we were standing and handed me her prize.

“你不想要吗？”
“Don't you want it?”

我问。
I asked.

“你抽中的。”
“You won it.”

“我要那个篮子。
“I wanted the basket.

小猫们现在需要有自己的篮子。”
The kittens need a basket of their own now.”

“好了，别在意。”
“Well, never mind.”

万里子转向她妈妈。
Mariko turned to her mother.

“我想再试一次。”
“I want to try once more.”

佐知子叹了口气。
Sachiko sighed.

“天晚了。”
“It's getting late now.”

“我想再试一次。
“I want to try.

就一次。”
Just once more.”

万里子再次挤到台子那去。
Again, she pushed her way to the platform.

我们等她时，佐知子转向我，说：
As we waited, Sachiko turned to me and said:

“真奇怪，我对她的印象不是那样的。
“It's funny, but I had a quite different impression of her.

我指你的朋友，藤原太太。”
Your friend, Mrs Fujiwara, I mean.”

“哦？”
“Oh?”

佐知子侧过头去看了看抓阄儿的人群，说：“不，悦子，恐怕我的看法跟你不一样。
Sachiko leaned her head to see past the spectators. “No, Etsuko,” she said, “I'm afraid I never saw her in quite the way you do.

我的印象是你的朋友已经一无所有了。”
Your friend struck me as a woman with nothing left in her life.”

“不是的，”我说。
“But that's not true,” I said.

“哦？
“Oh?

那她还有什么指望呢，悦子？
And what does she have to look forward to, Etsuko?

她靠什么活下去呢？”
What does she have to live for?”

“她有一家店。
“She has her shop.

虽然不大，但是对她来说很重要。”
It's nothing grand, but it means a lot to her.”

“她的店？”
“Her shop?”

“还有她的儿子，事业正蒸蒸日上。”
“And she has her son. Her son has a very promising career.”

佐知子又转过头去看着小摊。
Sachiko was looking again towards the stall.

“对，我想是这样，”她疲惫地笑了笑说。
“Yes, I suppose so,” she said, with a tired smile.

“我想她还有她的儿子。”
“I suppose she has her son.”

这次万里子抽中一支铅笔，生气地走回来。
This time Mariko won a pencil, and came back to us with a sullen expression.

我们要走了，可万里子还在看着抓阄儿的小摊。
We started to go, but Mariko was still looking towards the Kujibiki stand.

“走了，”佐知子说。
“Come on,” Sachiko said.

“悦子阿姨要回家了。”
“Etsuko-San needs to be getting home now.”

“我想再试一次。
“I want to try once more.

就一次。”
Just once more.”

佐知子不耐烦地叹了口气，然后看看我。
Sachiko sighed impatiently, then looked at me.

我耸耸肩，笑了笑。
I shrugged and gave a laugh.

“好吧，”佐知子说。
“All right,” said Sachiko.

“再试一次。”
“Try once more.”

又有几个人抽中奖品。
Several more people won prizes.

有一次一个年轻女子抽中一个粉饼盒，大家觉得这个奖品太适合她了，鼓了鼓掌。
Once a young woman won a face-compact and the appropriateness of the prize provoked some applause.

看见万里子第三次出现，绑着头巾的男人又做了一个鬼脸。
On seeing Mariko appear for the third time, the man with the handkerchief pulled another of his amusing faces.

“啊，小妹妹，又回来了！
“Well, little princess, back again!

还想要那个篮子？
Still want the basket?

你不觉得那只大毛绒熊更好吗？”
Wouldn't you prefer that big furry bear?”

万里子没有回答，默默地等着男人把碗递给她。
Mariko said nothing, waiting for the man to offer her the bowl.

万里子抽出一支，男人仔细地看了看，然后瞥了一眼身后放奖品的地方，又仔细地看了一次万里子的签，最后终于点点头。
When she had picked out a ticket, the man examined it closely, then glanced behind him to where the prizes were exhibited. He scrutinized the ticket once more, then finally gave a nod.

“你没有抽中篮子。
“You haven't won the basket.

不过你抽中了——一个大奖！”
But you have won — a major prize!”

四周响起笑声和掌声。
There was laughter and applause all around.

男人走到小摊的后面，拿来一个像是只大木盒子的东西。
The man went to the back of the stall and returned with what looked like a large wooden box.

“给你妈妈装菜！”他说——不是对万里子，而是对人群——并把奖品展示了一小会儿。
“For your mother to keep her vegetables in!” he announced — to the crowd rather than to Mariko — and for a brief moment held up the prize.

我身旁的佐知子笑了出来，跟着鼓起掌来。
Beside me, Sachiko burst into laughter and joined in the applause.

大家让开一条路让万里子拿着奖品出来。
A gangway formed to allow Mariko through with her prize.

我们离开人群时佐知子还在笑，笑得流出了泪珠儿；她擦了擦眼睛，然后看着那个盒子。
Sachiko was still laughing as we came away from the crowd. She had laughed so much that small tears had appeared in her eyes; she wiped them away and looked at the box.

“真是个怪模怪样的东西，”她一面递给我，一面说。
“What a strange-looking thing,” she said, passing it to me.

那盒子跟装橙子的盒子一般大，异常的轻；木头很光滑，但没有上漆，盒子的一侧有两块铁丝网做的滑板。
It was the size of an orange box and surprisingly light; the wood was smooth but unvarnished, and on one side were two sliding panels of wire gauze.

“也许会很有用，”我打开其中一个滑板说。
“It may come in useful,” I said, sliding open a panel.

“我抽中了大奖，”万里子说。
“I won a major prize,” said Mariko.

“是，干得好，”佐知子说。
“Yes, well done,” Sachiko said.

“我有一次抽中过一件和服，”万里子对我说。
“I won a kimono once,” Mariko said to me.

“在东京，我有一次抽中过一件和服。”
“In Tokyo, I won a kimono once.”

“啊，你又抽中了。”
“Well, you've won again.”

“悦子，能帮我拿一下包吗？
“Etsuko, perhaps you could carry my bag.

我好把这个东西带回去。”
Then I could carry this object home.”

“我抽中了大奖，”万里子说。
“I won a major prize,” said Mariko.

“是，你做得太好了，”她妈妈轻声笑着说。
“Yes, you were very good,” said her mother, and laughed a little.

我们离开抓阄儿的小摊。
We walked away from the kujibiki stand.

街上丢着废报纸和各种垃圾。
The street was littered with discarded newspapers and all manner of rubbish.

“小猫们可以住在里面，不是吗？”
“The kittens could live in there, couldn't they?”

万里子说。
Mariko said.

“我们可以在里面放些垫子，就成了它们的家了。”
“We could put rugs inside it and that could be their house.”

佐知子不确定地看着怀里的盒子。
Sachiko looked doubtfully at the box in her arms.

“我不知道它们会不会喜欢这东西。”
“I'm not sure they'd like it so much.”

“盒子可以做它们的家。
“That could be their house.

我们要搬到安子阿姨家去时，可以把它们放在里面。”
Then when we go to Yasuko-San's house, we could carry them in there.”

佐知子疲惫地笑了笑。
Sachiko smiled tiredly.

“可以吧，妈妈？
“We could, couldn't we, Mother?

我们可以把小猫们放在里面。”
We could carry the kittens in there.”

“是，我想可以，”佐知子说。
“Yes, I suppose so,” said Sachiko.

“是，好。
“Yes, all right.

我们到时把小猫们放在里面。”
We'll carry the kittens in there.”

“这么说我们可以留着小猫咯？”
“So we can keep the kittens then?”

“对，我们可以留着小猫。
“Yes, we can keep the kittens.

我想安子阿姨的父亲不会反对。”
I'm sure Yasuko-San's father won't object.”

万里子往前跑了一段，等着我们。
Mariko ran a little way ahead, then waited for us to catch up.

“那么我们再也不用帮它们找家了？”
“So we won't have to find homes for them any more?”

“对，现在不用了。
“No, not now.

我们要搬到安子阿姨家去，所以我们可以留着小猫。”
We're going to Yasuko-San's house, so we'll keep the kittens after all.”

“那我们不用帮它们找主人了。
“We won't have to find owners then.

我们可以把它们全留着。
We can keep them all.

我们可以把它们放在盒子里，对不对，妈妈？”
We could take them in the box, couldn't we, Mother?”

“对，”佐知子说，把头向后一仰，又笑了起来。
“Yes,” said Sachiko. Then she tossed back her head and once more began to laugh.

我经常想起那天晚上回家的电车上万里子的脸。
I often find myself recalling Mariko's face the way I saw it that evening on the tram going home.

她看着窗外，额头贴在玻璃上；男孩子气的脸，被窗外不断闪过的流光溢彩照亮。
She was staring out of the window, her forehead pressed against the glass; a boyish face, caught in the changing lights of the city rattling by outside.

万里子一路上都没有说话，佐知子和我也说得不多。
Mariko remained silent throughout that journey home, and Sachiko and I conversed little.

我记得她问了我说：
Once, I remember, Sachiko asked:

“你丈夫会不会生气？”
“Will your husband be angry with you?”

“很可能，”我微微一笑，说。
“Quite possibly,” I said, with a smile.

“不过昨天我已经告诉他我可能会晚回。”
“But I did warn him yesterday I might be late.”

“今天玩得真开心。”
“It's been an enjoyable day.”

“是啊。
“Yes.

二郎只能坐着生气。
Jiro will just have to sit and get angry.

我今天玩得很开心。”
I've enjoyed today very much.”

“我们以后一定要再出来玩，悦子。”
“We must do it again, Etsuko.”

“是啊，一定。”
“Yes, we must.”

“我们搬家以后你要记得来看我。”
“Remember, won't you, to come and visit me after I move.”

“会，我会记得。”
“Yes, I'll remember.”

之后我们就没有说话了。
We fell silent again after that.

不久，电车减速准备靠站，我感到佐知子突然吓了一跳。
It was a little later, just as the tram slowed for a stop, I felt Sachiko give a sudden start.

她看着下客门，那里站着两三个人。
She was looking down the carriage, to where two or three people had gathered near the exit.

其中一个女人在看着万里子。
A woman was standing there looking at Mariko.

女人三十岁上下，消瘦的脸，疲惫的神情。
She was around thirty or so, with a thin face and tired expression.

她很可能只是无意地看着万里子，要不是因为佐知子的反应，我想我不会觉得有什么不对劲。
It was conceivable she was gazing at Mariko quite innocently, and but for Sachiko's reaction I doubt if my suspicions would have been aroused.

万里子一直在看着窗外，没有注意到那个女人。
In the meantime, Mariko continued to look out of the window, quite unaware of the woman.

女人注意到佐知子在看她，就转了过去。
The woman noticed Sachiko looking at her and turned away.

电车靠站了，门开了，女人下了车。
The tram came to a stop, the doors opened and the woman stepped out.

“你认识那个人？”
“Did you know that person?”

我轻声问。
I asked, quietly.

佐知子笑了笑。
Sachiko laughed a little.

“不，我认错了。”
“No. I just made a mistake.”

“你把她当作别人了？”
“You mistook her for someone else?”

“就一小会儿工夫。
“Just for a moment.

其实一点都不像。”
There wasn't even a resemblance really.”

她又笑了一声，然后瞧瞧外面，看我们到哪了。
She laughed again, then glanced outside to check where we were.

# 第二部 · 第八章 | PART TWO · Chapter Eight

回想起来，那年夏天，绪方先生跟我们待在一起那么久的用意很明显。
In retrospect it seems quite clear why Ogata-San remained with us for as long as he did that summer.

知子莫若父，他一定已经猜到二郎要怎么处理松田重夫那篇登在杂志上的文章惹出的事情；我丈夫只是在等绪方先生回福冈，这件事就会被忘掉。
Knowing his son well enough, he must have recognized Jiro's strategy over the matter concerning Shigeo Matsuda's magazine article; my husband was simply waiting for Ogata-San to return home to Fukuoka so the whole affair could be forgotten.

而他可以继续欣然同意：这种侮辱家族名声的事应该迅速地、坚决地予以回应；这件事不仅是他父亲关心的，也是他关心的；他一有时间就会给他的老同学写信。
Meanwhile, he would continue to agree readily that such an attack on the family name should be dealt with both promptly and firmly, that the matter was his concern as much as his father's, and that he would write to his old schoolfriend as soon as he had time.

现在回想起来，这就是二郎面对可能的尴尬局面时的一贯做法。
I can see now, with hindsight, how typical this was of the way Jiro faced any potentially awkward confrontation.

如果多年之后，他在面对另一场危机时不是采取同一种态度，我也许不会离开长崎。
Had he not, years later, faced another crisis in much the same manner, it may be that I would never have left Nagasaki.

但这是后话了。
However, that is by the way.

我在前面已经讲了有天晚上，我丈夫的两个喝得醉醺醺的同事来到家里，打断了他和绪方先生下棋。那晚我铺床时，很想就松田重夫的整件事情和二郎谈谈；我并不希望二郎违心地写这封信，但我越来越强烈地希望他能把他的立场更清楚地告诉他父亲。
I have recounted earlier some details of the evening my husband's two drunken colleagues arrived to interrupt the chess game between Jiro and Ogata-San. That night, as I prepared for bed, I felt a strong urge to talk to Jiro about the whole business concerning Shigeo Matsuda; while I did not wish Jiro to write such a letter against his will, I was feeling more and more keenly that he should make his position clearer to his father.

但结果，那晚，和前几次一样，我最终没有说出口。
As it was, however, I refrained from mentioning the subject that night, just as I had done on previous occasions.

一来，我丈夫会觉得对这件事情我不应该说话；二来，晚上的那个时候，二郎总是很累，和他说话只会让他不耐烦。
For one thing, my husband would have considered it no business of mine to comment on such a matter. Furthermore, at that time of night, Jiro was invariably tired and any attempts to converse would only make him impatient.

总之，我们夫妇间从不开口讨论这样的事情。
And in any case, it was never in the nature of our relationship to discuss such things openly.

第二天，绪方先生一整天都待在公寓里，时不时研究那盘棋，他告诉我说，昨天晚上棋下到关键时候被打断了。
Throughout the following day, Ogata-San remained in the apartment, often studying the chess game which — so he told me — had been interrupted at a crucial stage the previous night.

到了晚上，晚饭后约一小时，他又把棋盘拿出来，开始研究棋子。
Then that evening, an hour or so after we had finished supper, he brought out the chess-board again and began once more to study the pieces.

忽然，他抬起头来对我丈夫说：
Once, he looked up and said to my husband:

“那么，二郎，明天就是大日子啦。”
“So, Jiro. Tomorrow's the big day then.”

二郎把眼睛从报纸上移开，笑了笑，说：“没什么大不了的。”
Jiro looked up from his newspaper and gave a short laugh. “It's nothing to make a fuss about,” he said.

“胡说。
“Nonsense.

明天可是你的大日子。
It's a big day for you.

当然了，为公司尽全力是你的本分，但要我说，不管明天结果如何，这件事本身就很了不起。
Of course, it's imperative you do your best for the firm, but in my view this is a triumph in itself, whatever the outcome tomorrow.

你的资历不深，就能叫你代表公司，这事在今天，也是很少见的。”
To be asked to represent the firm at this level, so early in your career, that can't be usual, even these days.”

二郎耸了耸肩。
Jiro gave a shrug.

“是不多见。
“I suppose not.

当然了，即使明天进行得异常顺利，也并不保证我能获得提升。
Of course, even if tomorrow goes exceptionally well, that's no guarantee I'll get the promotion.

可是我想经理应该会对我今年的业绩感到满意。”
But I suppose the manager must be reasonably pleased with my efforts this year.”

“要我说，大家都觉得他对你很有信心。
“I should think he has great faith in you, by all accounts.

你觉得明天会怎么样？”
And how do you think it will go tomorrow?”

“我当然希望一切顺利。
“Smoothly enough, I should hope.

现阶段需要参与各方通力合作。
At this stage all the parties involved need to co-operate.

这只是为秋天的正式谈判做准备。
It's more a case of laying the groundwork for the real negotiations in the autumn.

没什么特别的。”
It's nothing so special.”

“我们就等着瞧吧。
“Well, we'll have to just wait and see how it goes.

现在，二郎，我们把这盘棋下完怎么样？
Now, Jiro, why don't we finish off this game.

我们已经下了三天了。”
We've been at it for three days.”

“哦，对了，下棋。
“Oh yes, the game.

当然了，爸爸，您知道不管明天我多成功，都不一定保证我能获得提升。”
Of course, Father, you realize however successful I am tomorrow, that's no guarantee I'll be given the promotion.”

“我当然知道了，二郎。
“Of course not, Jiro, I realize these things.

我自己也是从残酷的职场竞争中过来的。
I came up through a competitive career myself.

我再清楚不过了。
I know only too well how it is.

有时那些哪方面都比不上你的人却被选中了。
Sometimes others are chosen in preference who by all rights shouldn't even be considered your equals.

但你不能让这些事妨碍你。
But you mustn't let such things deter you.

你只要坚持，最后一定会成功。
You persevere and triumph in the end.

现在，把棋下完吧。”
Now, how about finishing off this game.”

我丈夫瞥了一眼棋盘，却没有要上前去的意思。
My husband glanced towards the chess-board, but showed no sign of moving nearer it.

“我没记错的话，您快赢了。”他说。
“You'd just about won, if I remember,” he said.

“局面是对你不利，可是是有办法化解的。
“Well, you're in quite a difficult corner, but there's a way out if you can find it.

记得吗，二郎，我第一次教你下棋时，是怎么一直警告你不要太早出车的？
Do you remember, Jiro, when I first taught you this game, how I always warned you about using the castles too early?

你现在还是犯同样的错误。
And you still make the same mistake.

看出来了吗？”
Do you see?”

“车，是啊。
“The castles, yes.

您说得对。”
As you say.”

“还有，顺便说一下，二郎，我想你下棋前没有先想好步子，是吧？
“And incidentally, Jiro, I don't think you're thinking your moves out in advance, are you?

记不记得以前我是怎么费老大劲教你至少要先想好三步？
Do you remember how much trouble I once took to make you plan at least three moves ahead.

可是我想你没有。”
But I don't think you've been doing that.”

“先想三步？
“Three moves ahead?

不，我没有。
Well, no, I suppose I haven't.

我不像您那么会下棋，爸爸。
I can't claim to be an expert like yourself, Father.

反正我想您已经赢了。”
In any case, I think we can say you've won.”

“其实，二郎，这盘棋你老早就没有先想好步子，真叫人心痛。
“In fact, Jiro, it became painfully obvious very early in the game, that you weren't thinking your moves out.

我告诉过你多少次？
How often have I told you?

一个好棋手得想好了再走棋，至少要先想好三步。”
A good chess player needs to think ahead, three moves on at the very least.”

“对，我想是这样。”
“Yes, I suppose so.”

“比如说，你为什么要把马走到这里来？
“For instance, why did you move this horse here?

二郎，看过来，你连看都没看。
Jiro, look, you're not even looking.

记得你为什么要把这个走到这里来吗？”
Can you even remember why you moved this here?”

二郎瞥了一眼棋盘。
Jiro glanced towards the board.

“说实话，我不记得了，”他说，“那时可能很有理由应该那么走。”
“To be honest, I don't remember,” he said. “There was probably a good enough reason at the time.”

“很有理由？
“A good enough reason?

胡说八道，二郎。
What nonsense, Jiro.

前几步，你是想好了步子，我看得出来。
For the first few moves, you were planning ahead, I could see that.

你那时其实是有一个战略的。
You actually had a strategy then.

可一旦我打乱了你的战略，你就放弃了，你就开始走一步想一步了。
But as soon as I broke that down, you gave up, you began playing one move at a time.

你不记得我以前总是跟你说：下棋就是不停地贯彻战略。
Don't you remember what I always used to tell you? Chess is all about maintaining coherent strategies.

就是敌人破坏了你的计划也不放弃，而是马上想出另一个战略。
It's about not giving up when the enemy destroys one plan, but to immediately come up with the next.

胜负并不是在王被将时决定的。当棋手放弃运用任何战略时，胜负就已经定局了。
A game isn't won and lost at the point when the king is finally cornered. The game's sealed when a player gives up having any strategy at all.

你的兵七零八落，没有共同的目标，走一步想一步，这时你就输了。”
When his soldiers are all scattered, they have no common cause, and they move one piece at a time, that's when you've lost.”

“很对，爸爸，我承认。
“Very well, Father, I admit it.

我输了。
I've lost.

现在让我们忘了这件事吧。”
Now perhaps we can forget about it.”

绪方先生瞥了我一眼，又转向二郎。
Ogata-San glanced towards me, then back at Jiro.

“这是什么话？
“Now what kind of talk is that?

今天我很认真地研究了这盘棋，发现你至少有三种方法可以解围。”
I studied this board quite hard today and I can see three separate means by which you can escape.”

我丈夫放下报纸。
My husband lowered his newspaper.

“请原谅，可要是我没理解错，”他说，“是您自己说：不能始终贯彻战略的棋手就一定会输。
“Forgive me if I'm mistaken,” he said, “but I believe you just said yourself, the player who cannot maintain a coherent strategy is inevitably the loser.

而您也一再指出：我走一步想一步。那就没必要再下了吧。
Well, as you've pointed out so repeatedly, I've been thinking only one move at a time, so there seems little point in carrying on.

现在请您原谅，我要读完这篇报道。”
Now if you'll excuse me, I'd like to finish reading this report.”

“什么，二郎，这纯粹是投降主义。
“Why, Jiro, this is sheer defeatism.

我说了，你还没输呢。
The game's far from lost, I've just told you.

你现在应该组织防守，稳住阵脚，然后再向我进攻。
You should be planning your defence now, to survive and fight me again.

二郎，你从小就有些投降主义。
Jiro, you always had a streak of defeatism in you, ever since you were young.

我真希望把它从你身上根除，可到头来，还是老样子。”
I'd hoped I'd taken it out of you, but here it is again, after all this time.”

“请原谅，可我看不出这跟投降主义有什么关系。
“Forgive me, but I fail to see what defeatism has to do with it.

这只是一盘棋……”
This is merely a game …”

“也许这确实只是一盘棋。
“It may indeed be just a game.

但是知子莫若父。
But a father gets to know his son well enough.

一位父亲能看出这些讨厌的特征的苗头。
A father can recognize these unwelcome traits when they arise.

你的这种品格，我可一点儿也不觉得骄傲，二郎。
This is hardly a quality I'm proud of in you, Jiro.

第一个战略失败了，你就马上放弃。
You gave up as soon as your first strategy collapsed.

现在要你防守，你就生气，不想再下了。
And now when you're forced on to the defensive, you sulk and don't want to play the game any more.

啊，这跟你九岁时一模一样。”
Why, this is just the way you were at nine years old.”

“爸爸，胡说什么啊。
“Father, this is all nonsense.

我一整天有很多事要做，哪有时间想下棋的事？”
I have better things to do than think about chess all day.”

二郎说得很大声，把绪方先生吓了一跳。
Jiro had spoken quite loudly, and for a moment Ogata-San looked somewhat taken aback.

“对您来说没问题，爸爸，”我丈夫接着说。
“It may be very well for you, Father,” my husband continued.

“您有一整天的时间来想您的战略和计划。
“You have the whole day to dream up your strategies and ploys.

而我有更重要的事要做。”
Personally, I have better things to do with my time.”

说完，我丈夫又回到报纸上。
With that, my husband returned to his paper.

他父亲则一直吃惊地盯着他。
His father continued to stare at him, an astonished look on his face.

最后，绪方先生笑了起来。
Then finally, Ogata-San began to laugh.

“好了，二郎，”他说，“我们像两个渔夫的妻子在吵架。”
“Come, Jiro,” he said, “we're shouting at each other like a pair of fishermen's wives.”

说着又笑了一声。
He gave another laugh.

“像两个渔夫的妻子。”
“Like a pair of fishermen's wives.”

二郎没有抬起头来。
Jiro did not look up.

“好了，二郎，我们别吵了。
“Come on, Jiro, let's stop our argument.

你要是不想下了，我们就别下了。”
If you don't want to finish the game, we don't have to finish it.”

我丈夫还是没有听到的样子。
My husband still gave no sign of having heard.

绪方先生又笑了一声。
Ogata-San laughed again.

“好了，你赢了。
“All right, you win.

我们不下了。
We won't play any more.

但是让我来告诉你怎么走出这小小的困境。
But let me show you how you could have got out of this little corner here.

有三种方法。
There's three things you could have done.

第一种最简单，而且对此我束手无策。
The first one's the most simple and there's little I could have done about it.

看，二郎，看这边。
Look, Jiro, look here.

二郎，看，我在教你。”
Jiro, look, I'm showing you something.”

二郎仍旧没有理他父亲，一副专心致志地看报纸的样子。
Jiro continued to ignore his father. He had all the appearance of someone solemnly absorbed in his reading.

他翻了一页，继续看。
He turned over a page and carried on reading.

绪方先生对着自个儿点点头，轻声笑了笑。
Ogata-San nodded to himself, laughing quietly.

“跟小时候一样，”他说。
“Just like when he was a child,” he said.

“不称心时就生气，拿他一点儿办法也没有。”
“When he doesn't get his own way, he sulks and there's nothing to be done with him.”

他看了我一眼，苦笑着，然后又转向他儿子。
He glanced towards where I was sitting and laughed rather oddly. Then he turned back to his son.

“二郎，看，至少看看这个。
“Jiro, look. Let me show you this at least.

很简单。”
It's simplicity itself.”

突然间，我丈夫扔下报纸，朝他父亲的方向直起身。
Quite suddenly, my husband flung down his newspaper and made a movement towards his father.

很明显，他是想把棋盘和上面的棋子统统打翻。
Clearly, what he had intended was to knock the chess-board across the floor and all the pieces with it.

可一个不小心，还没打到棋盘，先把脚边的茶壶给踢倒了。
But he moved clumsily and before he could strike the board, his foot had upset the teapot beside him.

茶壶侧滚，壶盖哐当一声开了，茶水立刻流到了榻榻米上。
The pot rolled on to its side, the lid fell open with a rattle, and the tea ran swiftly across the surface of the tatami.

二郎不知道发生了什么，转过头来瞪着流出来的茶水，然后又转回去盯着棋盘。
Jiro, not sure what had occurred, turned and stared at the spilt tea.

看见棋子还立在格子上好像让他更加恼火。
Then he turned back and glared at the chess-board.

一时间我以为他会再去把它们打翻。
The sight of the chessmen, still upright on their squares, seemed to anger him all the more, and for a moment I thought he would make another attempt to upset them.

可是他站起来，抓起报纸，一言不发地走了出去。
As it was, he got to his feet, snatched up his newspaper, and left the room without a word.

我赶紧朝茶水流出来的地方跑去。
I went over quickly to where the tea had spilt.

有些水已经开始渗到二郎坐的垫子里去了。
Some of the liquid had begun to soak into the cushion Jiro had been sitting on.

我拿开垫子，用围裙的角擦了擦。
I moved the cushion and rubbed at it with the edge of my apron.

“跟以前一个样，”绪方先生说，眼角泛着淡淡的微笑。
“Just like he used to be,” Ogata-San said. A faint smile had appeared around his eyes.

“孩子长成了大人，却没有变多少。”
“Children become adults but they don't change much.”

我跑到厨房去找了一块布。
I went out into the kitchen and found a cloth.

回来时，绪方先生仍那么坐着，眼角仍浮着微笑。
When I returned, Ogata-San was sitting just as I had left him, the smile still hovering around his eyes.

他盯着榻榻米上的水渍，陷入沉思，似乎着了迷。
He was gazing at the puddle on the tatami and looked deep in thought.

我犹豫了一下才跪下来把它擦掉。
Indeed, he seemed so absorbed by the sight of the tea, I hesitated a little before kneeling down to wipe it away.

“你千万别为这件事生气，悦子，”他终于开口说道，“没什么好生气的。”
“You mustn't let this upset you, Etsuko,” he said, eventually. “It's nothing to upset yourself about.”

“是。”我一边擦地板一边说道。
“No.” I continued to wipe the tatami.

“好了，我想我们也赶紧睡吧。
“Well, I suppose we might as well turn in fairly soon.

偶尔早点睡对身体好。”
It's good to turn in early once in a while.”

“是。”
“Yes.”

“你千万别为这件事生气，悦子。
“You mustn't let this upset you, Etsuko.

二郎明天早上就会忘了整件事的，你看着吧。
Jiro will have forgotten the whole thing by tomorrow, you'll see.

我记得很清楚他这种一时的脾气。
I remember these spells of his very well.

其实，真让人怀念啊，看见这种小小的场面。
In fact, it makes you quite nostalgic, witnessing a little scene like that.

让我想起他小时候的样子来。
It reminds me so much of when he was small.

对，真是让人怀念。”
Yes, it's enough to make you quite nostalgic.”

我仍旧擦着地板。
I continued to wipe away the tea.

“好了，悦子，”他说，“没什么好生气的。”
“Now, Etsuko,” he said. “This is nothing to upset yourself about.”

到第二天早晨之前，我没有再和我丈夫说话。
I exchanged no further words with my husband until the following morning.

他一边吃早饭一边扫几眼我放在碗边的早报。
He ate his breakfast glancing occasionally at the morning newspaper I had placed beside his bowl.

他很少说话，对于他父亲没有出现也没有说什么。
He spoke little and made no comment on the fact that his father had not yet emerged.

而我仔细地听绪方先生房里的动静，但什么也没听到。
For my part, I listened carefully for sounds from Ogata-San's room, but could hear nothing.

“我希望今天一切顺利，”我们好几分钟没有说话，我打破沉默说。
“I hope it all goes well today,” I said, after we had sat in silence for some minutes.

我丈夫耸耸肩，说：“没什么大不了的。”
My husband gave a shrug. “It's nothing to make a fuss about,” he said.

然后他抬起头来看着我说：“我今天本来想系那条黑色的丝绸领带，可你好像拿去弄什么了。
Then he looked up at me and said: “I wanted my black silk tie today, but you seem to have done something with it.

我希望你别老乱动我的领带。”
I wish you wouldn't meddle with my ties.”

“那条黑色的丝绸领带？
“The black silk one?

和其他领带一起挂在架子上啊。”
It's hanging on the rail with your other ties.”

“刚才没有看见。
“It wasn't there just now.

我希望你别老乱动它们。”
I wish you'd stop meddling with them all the time.”

“丝绸的那条应该也在那里的，”我说，“我前天烫好了，因为我知道你今天要戴，我肯定放回去了。
“The silk one should be there with the others,” I said. “I ironed it the day before yesterday, because I knew you'd be wanting it for today, but I made sure to put it back.

你确定不在那里吗？”
Are you sure it wasn't there?”

我丈夫不耐烦地叹了口气，低头看报纸。
My husband sighed impatiently and looked down at the newspaper.

“没关系，”他说，“这条也行。”
“It doesn't matter,” he said. “This one will have to do.”

他继续默默地吃着早饭，与此同时仍不见绪方先生出现。
He continued to eat in silence.

最后，我站起来，到他的房门口去。
Meanwhile, there was still no sign of Ogata-San and eventually I rose to my feet and went to listen outside his door.

我站了一会儿，没有听见任何动静，于是准备开个小缝看看。
When after several seconds I had not heard a sound, I was about to slide open the door a little way.

这时我丈夫转过来，说：
But my husband turned and said:

“你在干什么呢？
“What are you up to?

要知道我可没有一早上的时间。”
I haven't got all morning, you know.”

说着递出茶杯。
He pushed his teacup forward.

我再次坐下，把他吃完的碗盘放到一边，倒上茶。
I seated myself again, put his used dishes away to one side, and poured him some tea.

他很快地抿着，一边扫着报纸的头版。
He sipped it rapidly, glancing over the front page of the newspaper.

“今天对我们很重要，”我说，“我希望事情顺利。”
“This is an important day for us,” I said. “I hope it goes well.”

“没什么大不了的，”他低着头说。
“It's nothing to make such a fuss about,” he said, not looking up.

可是，那天出门前，二郎却在玄关那里的镜子前仔仔细细地照了照，整了整领带，看了看下巴，检查是不是刮干净了。
However, before he left that morning, Jiro studied himself carefully in the mirror by the entryway, adjusting his tie and examining his jaw to check he had shaved efficiently.

他离开以后，我再次来到绪方先生的房门口听动静。
When he had left, I went over once more to Ogata-San's door and listened.

还是什么都没听到。
I still could hear nothing.

“爸爸？”
“Father?”

我轻声叫道。
I called softly.

“啊，悦子，”我听见里面传来绪方先生的声音。
“Ah, Etsuko,” I heard Ogata-San's voice from within.

“我该猜到你不会让我睡懒觉。”
“I might have known you wouldn't let me lie in.”

我松了一口气，回到厨房，新泡了一壶茶，然后把绪方先生的早饭准备好。
Somewhat relieved, I went to the kitchen to prepare a fresh pot of tea, then laid the table ready for Ogata-San's breakfast.

当绪方先生终于坐下来吃早饭时，他轻描淡写地说道：
When he eventually sat down to eat, he remarked casually:

“我想二郎已经走了吧。”
“Jiro's left already, I suppose.”

“哦是，他早走了。
“Oh yes, he went a long time ago.

我正准备把爸爸的早饭倒掉。
I was just about to throw Father's breakfast away.

我以为他懒得中午前都不想起床。”
I thought he'd be far too lazy to get up much before noon.”

“啊，别那么不近人情，悦子。
“Now, don't be cruel, Etsuko.

等你到了我这个年纪，你就会想偶尔放松一下。
When you get to my age, you like to relax once in a while.

再说，跟你们在一起，我就像放假一样。”
Besides, this is like a vacation for me, staying here with you.”

“好了，我想就这一次，可以原谅爸爸这么偷懒。”
“Well, I suppose just this once then, Father can be forgiven for being so lazy.”

“回到福冈以后我就没有机会像今天这样睡懒觉了，”他拿起筷子说，接着，深深地叹了口气。
“I won't get the opportunity to lie in like this once I get back to Fukuoka,” he said, taking up his chopsticks. Then he sighed deeply.

“我想我差不多该回去了。”
“I suppose it's time I was getting back soon.”

“回去？
“Getting back?

可是不急啊，爸爸。”
But there's no hurry, Father.”

“不，我真的差不多该回去了。
“No, I really have to be getting back soon.

还有很多工作要接着做。”
There's plenty of work to be getting on with.”

“工作？
“Work?

什么工作？”
What work is that?”

“这个嘛，首先，我得给阳台装上新的护板。
“Well, for a start, I need to build new panels for the veranda.

再就是假山。
Then there's the rockery.

这个我都还没开始弄呢。
I haven't even started on it yet.

石头几个月前就运来了，放在花园里，等着我回去。”他叹了口气，开始吃早饭。
The stones were delivered months ago and they've just been sitting there in the garden waiting for me.” he gave a sigh and began to eat.

“回去以后我确实没有机会像今天这样睡懒觉了。”
“I certainly won't get to lie in like this once I get back.”

“可是没有必要急着回去不是，爸爸？
“But there's no need to go just yet, is there, Father?

假山可以再等一等。”
Your rockery can wait a little longer.”

“你太好了，悦子。
“You're very kind, Etsuko.

可是时间紧迫。
But time's pressing on now.

你瞧，我想我女儿和她丈夫今年秋天又会南下，我得在他们来之前把所有的事做完。
You see, I'm expecting my daughter and her husband down again this autumn, and I'll need to get all this work finished before they come.

去年和前年，他们都在秋天时来看我。
Last year and the year before, they came to see me in the autumn.

所以我想今年他们会再来。”
So I rather suspect they'll want to come again this year.”

“我明白了。”
“I see.”

“没错，他们今年秋天一定想再来。
“Yes, they're bound to want to come again this autumn.

那个时候对纪久子的丈夫最方便。
It's the most convenient time for Kikuko's husband.

纪久子在信里总是说她多想看看我的新房子。”
And Kikuko's always saying in her letters how curious she is to see my new house.”

绪方先生不由自主地点点头，然后端起碗接着吃饭。
Ogata-San nodded to himself, then carried on eating from his bowl.

我看了他一会儿。
I watched him for a while.

“纪久子真是个孝顺的女儿啊，爸爸，”我说，“大老远地从大阪过来。
“What a loyal daughter Kikuko-San is to you, Father,” I said. “It's a long way to come, all that way from Osaka.

她一定很想念您。”
She must miss you.”

“我想她是觉得有必要偶尔离开一下她的公公。
“I suppose she feels the need to get away from her father-in-law once in a while.

除此之外我想不到她为什么要跑这么老远。”
I can't think why else she would want to come so far.”

“您太坏了，爸爸。
“How unkind, Father.

我肯定她是想您了。
I'm sure she misses you.

我要把您的话告诉她。”
I'll have to tell her what you're saying.”

绪方先生笑了。
Ogata-San laughed.

“可这是真的。
“But it's true.

老渡边像个军阀似的统治他们。
Old Watanabe rules over them like a war-lord.

每次南下，他们都要说他变得多么的让人难以忍受。
Whenever they come down, they're forever talking about how intolerable he's getting.

我自己是相当喜欢这位老人的，但不可否认他是个老军阀。
Personally I rather like the old man, but there's no denying he's an old war-lord.

我猜他们会喜欢一个类似这里的地方，悦子，一间属于他们自己的公寓。
I expect they'd like some place like this, Etsuko, an apartment like this just to themselves.

不是什么坏事，年轻夫妇跟父母分开住。
It's no bad thing, young couples living away from the parents.

现在越来越多的夫妇这样做。
More and more couples do it now.

年轻人不想一直受专制的老人的统治。”
Young people don't want overbearing old men ruling over them for ever.”

绪方先生好像突然想起碗里的饭，赶紧吃了起来。
Ogata-San seemed to remember the food in his bowl and began to eat hurriedly.

吃完早饭后，他站起来，走到窗边。
When he had finished, he got to his feet and went over to the window.

他在那里站了一会儿，背对着我，看着窗外的风景。
For a moment he stood there, his back to me, looking at the view.

然后他调整了一下窗户，让更多空气进来，深深地吸了一口气。
Then he adjusted the window to let in more air, and took a deep breath.

“您喜欢您的新房子吗，爸爸？”
“Are you pleased with your new house, Father?”

我问。
I asked.

“我的房子？
“My house?

怎么，是的。
Why, yes.

正如我说的，有这里那里还需要弄一弄。
It'll need a little more work here and there, as I say.

但它小多了。
But it's much more compact.

长崎的房子对一个老人来说太大了。”
The Nagasaki house was far too large for just one old man.”

他依旧看着窗外；在早晨强烈的阳光下，我看不清他的头和肩膀。
He continued to gaze out of the window; in the sharp morning light, all I could see of his head and shoulders was a hazy outline.

“可那是栋好房子，旧的那栋，”我说。
“But it was a nice house, the old house,” I said.

“我要是往那里走的话，还会停下来看看它。
“I still stop and look at it if I'm walking that way.

其实，上周我从藤原太太那里回来时就路过了。”
In fact, I went past it last week on my way back from Mrs Fujiwara's.”

他没有做声，依旧看着外面的风景，我就以为他没有听见我的话。
I thought he had not heard me, for he continued to gaze silently out at the view.

但过了一会儿，他说：
But a moment later, he said:

“老房子怎么样了？”
“And how did it look, the old house?”

“哦，跟以前差不多。
“Oh, much the same.

新住户一定是喜欢原来的样子。”
The new occupants must like it the way Father left it.”

他微微转向我。
He turned towards me slightly.

“那那些杜鹃花呢，悦子？
“And what about the azaleas, Etsuko?

还在门口吗？”
Were the azaleas still in the gateway?”

亮光仍旧使我看不清他的脸，但是我从他的声音听出他在微笑。
The brightness still prevented me from seeing his face clearly, but I supposed from his voice that he was smiling.

“杜鹃花？”
“Azaleas?”

“啊，我想你不会记得的。”
“Well, I suppose there's no reason why you should remember.”

他转回去，伸了伸胳膊。
He turned back to the window and stretched out his arms.

“我那天种在门口的。
“I planted them in the gateway that day.

事情最后定下来的那天。”
The day it was all finally decided.”

“什么事情定下来？”
“The day what was decided?”

“你和二郎结婚的事。
“That you and Jiro were to be married.

但是我从来没有告诉你杜鹃花的事，所以我想我不应该指望你记得它们。”
But I never told you about the azaleas, so I suppose it's rather unreasonable of me to expect you to remember about them.”

“您为我种了一些杜鹃花？
“You planted some azaleas for me?

多好的想法。
Now that was a nice thought.

可是没有，我不记得您提起过。”
But no, I don't think you ever mentioned it.”

“可要知道，悦子，是你要我种的。”
“But you see, Etsuko, you asked for them.”

他再次转向我。
He had turned towards me again.

“事实上，你断然要求我种在门口。”
“In fact, you positively ordered me to plant them in the gateway.”

“什么？”
“What?

——我笑了——“我要求您的？”
— I laughed —” I ordered you?”

“是的，你要求我的。
“Yes, you ordered me.

把我当成雇来的花匠。
Like I was some hired gardener.

你不记得了？
Don't you remember?

当我以为终于一切都定下来了，你终于要成为我的媳妇时，你对我说还有一件事，你不会住在一所门口没有杜鹃花的房子里。
Just when I thought it was all settled at last, and you were finally to become my daughter-in-law, you told me there was one thing more, you wouldn't live in a house without azaleas in the gateway.

要是我不种杜鹃花，整件事就都告吹。
And if I didn't plant azaleas then the whole thing would be called off.

所以我能怎么办呢？
So what could I do?

我立刻出去，种了杜鹃花。”
I went straight out and planted azaleas.”

我笑了笑，说：“您这么一说，我想起来像是有那么回事。
I laughed a little. “Now you mention it,” I said, “I remember something like that.

可是太可笑了，爸爸。
But what nonsense, Father.

我从来没有强迫您。”
I never forced you.”

“哦不，你有，悦子。
“Oh yes, you did, Etsuko.

你说你不会住在一所门口没有杜鹃花的房子里。”
You said you wouldn't live in a house without azaleas in the gateway.”

他离开窗户，再次在我对面坐下。
He came away from the window and sat down opposite me again.

“没错，悦子，”他说，“当成雇来的花匠。”
“Yes, Etsuko,” he said “just like a hired gardener.”

我们俩都笑了，我开始倒茶。
We both laughed and I began to pour out the tea.

“您瞧，杜鹃花一直是我最喜欢的花，”我说。
“Azaleas were always my favourite flowers, you see,” I said.

“是，你说过。”
“Yes. So you said.”

我倒完茶，我们静静地坐着，看着蒸汽从茶杯里冒出来。
I finished pouring and we sat silently for a few moments, watching the steam rise from the teacups.

过了一会儿我说：“那时我对二郎的计划一无所知。”
“And I had no idea then,” I said. “About Jiro's plans, I mean.”

“是啊。”
“No.”

我伸出手去把一碟小蛋糕放在他的茶杯旁。
I reached forward and placed a plate of small cakes by his teacup.

绪方先生微笑地看着它们。
Ogata-San regarded them with a smile.

最后，他说道：
Eventually, he said:

“杜鹃花长得很漂亮。
“The azaleas came up beautifully.

可是那时，当然了，你们已经搬走了。
But by that time, of course, you'd moved away.

但这也不是什么坏事，年轻夫妇自己住。
Still, it's no bad thing at all, young couples living on their own.

看看纪久子和她丈夫。
Look at Kikuko and her husband.

他们想搬出来自己住，可是老渡边让他们想都别想。
They'd love to have a little place of their own, but old Watanabe won't even let them consider it.

他真是个老军阀。”
What an old war-lord he is.”

“现在想想，”我说，“上周门口是有杜鹃花。
“Now I think of it,” I said, “there were azaleas in the gateway last week.

新住户一定同意我的看法。
The new occupants must agree with me.

房子门口一定要有杜鹃花。”
Azaleas are essential for a gateway.”

“我很高兴它们还在。”
“I'm glad they're still there.”

绪方先生呷了一口茶。
Ogata-San took a sip from his teacup.

然后他叹了口气，笑了一声，说：“那个渡边真是个老军阀。”
Then he sighed and said with a laugh: “What an old war-lord that Watanabe is.”

早饭后不久，绪方先生建议我们应该去长崎逛逛——用他的话说“像游客那样”。
Shortly after breakfast, Ogata-San suggested we should go and look around Nagasaki — “like the tourists do”, as he put it.

我立刻同意，我们坐电车进城。
I agreed at once and we took a tram into the city.

我记得我们先在一个美术馆里待了一会儿，然后，快中午前，我们去参观离市中心不远的一个大型开放公园里的和平纪念雕像。
As I recall, we spent some time at an art gallery, and then, a little before noon, we went to visit the peace memorial in the large public park not far from the centre of the city.

这个公园一般被叫做“和平公园”——我一直不知道这是不是它的正式名称——而确实，尽管有孩子和鸟儿的叫声，这一大片绿地上却笼罩着一种肃穆的气氛。
The park was commonly known as “Peace Park” — I never discovered whether this was the official name — and indeed, despite the sounds of children and birds, an atmosphere of solemnity hung over that large expanse of green.

公园里常见的装饰，诸如灌木和喷泉，少之又少，而且都很朴素；平坦的草地、广阔的夏日天空以及雕像本身——一尊巨大的白色雕像，纪念原子弹的遇难者——占据了公园的主要部分。
The usual adornments, such as shrubs and fountains, had been kept to a minimum, and the effect was a kind of austerity; the flat grass, a wide summer sky, and the memorial itself — a massive white statue in memory of those killed by the atomic bomb — presiding over its domain.

雕像貌似一位希腊男神，伸开双臂坐着。
The statue resembled some muscular Greek god, seated with both arms outstretched.

他的右手指向天空，炸弹掉下来的地方；另一只手向左侧伸展开去，意喻挡住邪恶势力。
With his right hand, he pointed to the sky from where the bomb had fallen; with his other arm — stretched out to his left — the figure was supposedly holding back the forces of evil.

他双眼紧闭，在祈祷。
His eyes were closed in prayer.

我一直觉得那尊雕像长得很丑，而且我无法将它和炸弹掉下来那天发生的事以及随后的可怕的日子联系起来。
It was always my feeling that the statue had a rather cumbersome appearance, and I was never able to associate it with what had occurred that day the bomb had fallen, and those terrible days which followed.

远远看近乎可笑，像个警察在指挥交通。
Seen from a distance, the figure looked almost comical, resembling a policeman conducting traffic.

我一直觉得它就只是一尊雕像，虽然大多数长崎人似乎把它当作一种象征，但我怀疑大家的感觉和我一样。
It remained for me nothing more than a statue, and while most people in Nagasaki seemed to appreciate it as some form of gesture, I suspect the general feeling was much like mine.

如今我要是偶尔回忆起长崎的那尊大白色雕像，我总是首先想起我和绪方先生去参观和平公园的那个早晨，以及他的明信片的事。
And today, should I by chance recall that large white statue in Nagasaki, I find myself reminded primarily of my visit to Peace Park with Ogata-San that morning, and that business concerning his postcard.

“照片上看起来不怎么样，”我记得绪方先生举起他刚买的雕像的明信片说。
“It doesn't look quite so impressive in a picture,” I remember Ogata-San saying, holding up the postcard of the statue which he had just bought.

我们站在离雕像五十码开外的地方。
We were standing some fifty yards or so from the monument.

“我一直想寄张明信片，”他接着说，“虽然现在我随时都会回福冈去，但我想还是值得寄的。
“I've been meaning to send a card for some time,” he continued. “I'll be going back to Fukuoka any day now, but I suppose it's still worth sending.

悦子，你有笔吗？
Etsuko, do you have a pen?

也许我应该马上就寄，不然一定会忘记。”
Perhaps I should send it straight away, otherwise I'm bound to forget.”

我在手提包里找到一支笔，我们在附近的长椅上坐下。
I found a pen in my handbag and we sat down on a bench nearby.

我发现他一直盯着卡片空白的那面，笔拿在手上，却没有写。我感到奇怪。
I became curious when I noticed him staring at the blank side of the card, his pen poised but not writing.

有一两次，我看见他抬头看看雕像，像是在寻找灵感。
Once or twice, I saw him glance up towards the statue as if for inspiration.

最后我问他：
Finally I asked him:

“您是要寄给福冈的朋友吗？”
“Are you sending it to a friend in Fukuoka?”

“哦，只是一个熟人。”
“Well, just an acquaintance.”

“爸爸看上去做贼心虚，”我说，“我在想他会是在写给谁呢。”
“Father's looking very guilty,” I said. “I wonder who it can be he's writing to.”

绪方先生惊讶地朝上一看，然后大笑起来。“心虚？
Ogata-San glanced up with a look of astonishment. Then he burst into loud laughter.

真的吗？”
“Guilty? Am I really?”

“真的，很心虚。
“Yes, very guilty.

我在想要是没有人看着爸爸，他会干什么呢。”
I wonder what Father gets up to when there's no one to keep an eye on him.”

绪方先生大笑个不停，笑得我觉得椅子在晃。
Ogata-San continued to laugh loudly.

等他笑得不那么厉害时，他说：“很好，悦子。你抓住我了。
He was laughing so much I could feel the bench shake. He recovered a little and said: “Very well, Etsuko.

你抓住我在给我的女朋友写信”——“女朋友”这个词他用的是英语。
You've caught me. You've caught me writing to my girl-friend — he used the English word.

“当场抓住。”
“Caught me red-handed.”

说着又笑了起来。
He began laughing again.

“我一直猜想爸爸在福冈的生活很精彩。”
“I always suspected Father led a glamorous life in Fukuoka.”

“是，悦子”——他仍轻轻地笑着——“很精彩的生活。”
“Yes, Etsuko” — he was still laughing a little — “a very glamorous life.”

接着他深吸了一口气，再次低头看明信片。
Then he took a deep breath and looked down once more at his postcard.

“你知道，我真的不晓得该写什么。
“You know, I really don't know what to write.

也许我可以什么都不写，就这样寄出去。
Perhaps I could just send it with nothing written.

毕竟我只是想让她看看雕像长什么样。
After all, I only wanted to show her what the memorial looks like.

但话说回来，这样可能太随便了。”
But then again, perhaps that's rather too informal.”

“啊，我不能给您建议，爸爸，除非您告诉我这位神秘的女士是谁。”
“Well, I can't advise you, Father, unless you reveal who this mysterious lady is.”

“这位神秘的女士，悦子，在福冈开一家小饭馆。
“The mysterious lady, Etsuko, runs a small restaurant in Fukuoka.

离我的房子很近，所以我经常去那里吃晚饭。
It's quite near my house so I usually go there for my evening meals.

有时我和她聊聊，她人不错，我答应要寄给她一张和平纪念雕像的明信片。
I talk to her sometimes, she's pleasant enough, and I promised I'd send her a postcard of the peace memorial.

恐怕事情就是这样。”
I'm afraid that's all there is to it.”

“我知道了，爸爸。
“I see, Father.

可我还是不相信。”
But I'm still suspicious.”

“人很不错的一位老太太，但过一会儿就让人觉得烦了。
“Quite a pleasant old woman, but she gets tiresome after a while.

如果只有我一个客人，她就整顿饭的工夫站着，讲个不停。
If I'm the only customer, she stands and talks all through the meal.

不幸的是附近没有多少合适的吃饭的地方。
Unfortunately there aren't many other suitable places to eat nearby.

你瞧，悦子，你要是像你答应过的那样教我做饭，我就不必忍受她那种人了。”
You see, Etsuko, if you'd teach me to cook, as you promised, then I wouldn't need to suffer the likes of her.”

“可这是白费力气，”我笑着说，“爸爸不可能学会的。”
“But it would be pointless,” I said, laughing. “Father would never get the hang of it.”

“胡说。
“Nonsense.

你只是怕我超过你。
You're simply afraid I'll surpass you.

你太自私了，悦子。
It's most selfish of you, Etsuko.

好了我想想”——他再次看看明信片——“我该跟这位老太太说些什么呢？”
Now let me see” — he looked at his postcard once more — “What can I say to the old lady?”

“您还记得藤原太太吗？”
“Do you remember Mrs Fujiwara?”

我问，“她现在在开一家面馆。
I asked. “She runs a noodle shop now.

在爸爸的老房子附近。”
Near Father's old house.”

“是，我听说了。
“Yes, so I hear.

太遗憾了。
A great pity.

像她那种地位的人开起了面馆。”
Someone of her position running a noodle shop.”

“可她很喜欢。
“But she enjoys it.

面馆让她有事可做。
It gives her something to work for.

她经常问起您。”
She often asks after you.”

“太遗憾了，”他重复道。
“A great pity,” he said again.

“她丈夫是个很有地位的人。
“Her husband was a distinguished man.

我很尊敬他。
I had much respect for him.

可如今她开起了面馆。
And now she's running a noodle shop.

不可思议。”
Extraordinary.”

他沉重地摇摇头。
He shook his head gravely.

“我想去拜访她、向她问好，可我想这会让她觉得很难堪。
“I'd call in and pay my respects, but then I suppose she'd find that rather awkward.

我是说就她的现状。”
In her present circumstances, I mean.”

“爸爸，她并不觉得开面馆是件丢脸的事。
“Father, she's not ashamed to be running a noodle shop.

她觉得自豪。
She's proud of it.

她说她一直想做生意，不管是多么小的生意。
She says she always wanted to run a business, however humble.

我想您去看她，她会很高兴的。”
I expect she'd be delighted if you called on her.”

“你说她的店在中川？”
“Her shop is in Nakagawa, you say?”

“对。
“Yes.

离老房子很近。”
Quite near the old house.”

绪方先生似乎考虑了一会儿。
Ogata-San seemed to consider this for some time.

然后他转向我说：“那好，悦子。
Then he turned to me and said: “Right, then, Etsuko.

我们去看她吧。”
Let's go and pay her a visit.”

他匆匆地在明信片上写了几句，把笔还给我。
He scribbled quickly on the postcard and gave me back the pen.

“您是说现在，爸爸？”
“You mean, go now, Father?”

我被他的突然决定吓了一跳。
I was a little taken aback by his sudden decisiveness.

“对，干吗不呢？”
“Yes, why not?”

“很好。
“Very well.

我想她可以给我们午饭吃。”
I suppose she could give us lunch.”

“对，也许。
“Yes, perhaps.

但我可不想让那位好太太觉得丢脸。”
But I've no wish to humiliate the good lady.”

“她会很乐意做午饭给我们吃的。”
“She'd be pleased to give us lunch.”

绪方先生点点头，没有说话。
Ogata-San nodded and for a moment did not speak.

沉默片刻后，他慢慢说道：“其实，悦子，我早就想去中川了。
Then he said with some deliberation: “As a matter of fact, Etsuko, I'd been thinking of visiting Nakagawa for some time now.

我想拜访那里的一个人。”
I'd like to call in on a certain person there.”

“哦？”
“Oh?”

“我在想这会儿他在不在家。”
“I wonder if he'd be in at this time of day.”

“您想去拜访谁，爸爸？”
“Who is it you wish to call on, Father?”

“重夫。
“Shigeo.

松田重夫。
Shigeo Matsuda.

我一直想去拜访他。
I've been intending to pay him a call for some time.

他可能回家吃午饭，这样的话我就能找到他。
Perhaps he takes his lunch at home, in which case I may just catch him.

比去学校打搅他好。”
That would be preferable to disturbing him at his school.”

许久，绪方先生凝视着雕像的方向，脸上露出有点拿不定主意的表情。
For a few minutes, Ogata-San gazed towards the statue, a slightly puzzled look on his face.

我不做声，看着他把明信片拿在手里转啊转。
I remained silent, watching the postcard he was rotating in his hands.

突然，他拍了一下膝盖，站起来。
Then suddenly he slapped his knees and stood up.

“好，悦子，”他说，“就这么办吧。
“Right, Etsuko,” he said, “let's do that then.

我们先去找重夫，然后去拜访藤原太太。”
We'll try Shigeo first, then we could call in on Mrs Fujiwara.”

我们搭上去往中川的电车时一定已经是中午时分了；车厢内又挤又闷，车厢外的马路上满是吃午饭的人群。
It must have been around noon that we boarded the tram to take us to Nakagawa; the car was stiflingly crowded and the streets outside were filled with the lunch time hordes.

但当我们渐渐离开市中心时，乘客越来越少，电车到达终点站中川时，就只剩下几个人了。
But as we came away from the city centre, the passengers became more sparse, and by the time the car reached its terminus at Nakagawa, there were only a handful of us left.

走出电车，绪方先生站了一会儿，摸着下巴。很难说他是在品味重回这里的滋味，还是只是在想松田重夫家怎么走。
Stepping out of the tram, Ogata-San paused for a moment and stroked his chin. It was not easy to tell whether he was savouring the feeling of being back in the district, or whether he was simply trying to remember the way to Shigeo Matsuda's house.

我们站在一个水泥院子里，周围停着几辆空电车，头顶上是横七竖八的黑色电线。
We were standing in a concrete yard surrounded by several empty tram cars. Above our heads, a maze of black wires crossed the air.

太阳很大，照得油漆的车身十分晃眼。
The sun was shining down with some force, causing the painted surfaces of the cars to gleam sharply.

“真热啊，”绪方先生擦了擦额头，说道。
“What heat,” Ogata-San remarked, wiping his forehead.

然后他迈开步子，朝电车庭院那头后面的一排房子走去。我跟着他。
Then he began to walk, leading the way towards a row of houses which began on the far side of the tram yard.

几年来，这一带并没有变多少。
The district had not changed greatly over the years.

我们走在弯弯曲曲的小路上，一会儿上、一会儿下。
As we walked, the narrow roads twisted, climbed and fell.

山上哪儿能盖房子，房子就矗立在哪儿，其中的很多房子我依然熟悉；有的站在斜坡上摇摇欲坠，有的挤在看不见的角落里。
Houses, many of them still familiar to me, stood wherever the hilly landscape would permit; some were perched precariously on slopes, others squeezed into unlikely corners.

很多阳台上挂着毯子啦、洗的衣服啦。
Blankets and laundry hung from many of the balconies.

我们走着，经过几间看上去气派一点的房子，但我们既没有经过绪方先生的老房子，也没有经过以前我和父母住在一起的房子。
We walked on, past other houses more grand-looking, but we passed neither Ogata-San's old house nor the house I had once lived in with my parents.

事实上，我怀疑绪方先生是不是故意选了一条避开它们的路。
In fact, the thought occurred to me that perhaps Ogata-San had chosen a route so as to deliberately avoid them.

我猜想我们最多走了十或者十五分钟，但太阳和陡坡让我们筋疲力尽。
I doubt if we walked for much more than ten or fifteen minutes in all, but the sun and the steep hills became very tiring.

最后我们在一个陡坡的中央停了下来，绪方先生拉我到人行道旁一棵茂密的树下乘凉。
Eventually we stopped halfway up a steep path, and Ogata-San ushered me underneath the shelter of a leafy tree that hung over the pavement.

接着他指着马路对面一栋旧式大斜瓦屋顶、样子舒适的老房子，说：
Then he pointed across the road to a pleasant-looking old house with large sloping roof-tiles in the traditional manner.

“那就是重夫家。
“That's Shigeo's place,” he said.

我跟他父亲很熟。
“I knew his father quite well.

就我所知，他母亲仍跟他住在一起。”
As far as I know, his mother still lives with him.”

说完，绪方先生又开始摸下巴，像刚下电车时那样。
Then Ogata-San began to stroke his chin, just as he had done on first stepping off the tram.

我没说什么，只是等着。
I said nothing and waited.

“他很可能不在家，”绪方先生说，“他有可能和同事一起待在教研室里午休。”
“Quite possibly he won't be home,” said Ogata-San. “He'll probably spend the lunch break in the staff room with his colleagues.”

我仍旧是等着，不做声。
I continued to wait silently.

绪方先生依然站在我旁边，凝视着那所房子。
Ogata-San remained standing beside me, gazing at the house.

最后，他说：
Finally, he said:

“悦子，这里离藤原太太那多远？
“Etsuko, how far is it to Mrs Fujiwara's from here?

你知道吗？”
Have you any idea?”

“几分钟就到了。”
“It's just a few minutes’ walk.”

“我在想，也许最好是你先过去，我去找你。
“Now I think of it, perhaps it may be best if you went on ahead, and I could meet you there.

这样可能最好。”
That may be the best thing.”

“好的。
“Very well.

要是您希望如此。”
If that's what you wish.”

“其实是我做事太欠考虑。”
“In fact, this was all very inconsiderate of me.”

“我不是弱不禁风，爸爸。”
“I'm not an invalid, Father.”

他笑了一声，然后又瞥了一眼房子。
He laughed quickly, then glanced again towards the house.

“我想最好这样，”他重复道，“你先过去。”
“I think it might be best,” he said again. “You go on ahead.”

“好的。”
“Very well.”

“我不会很久。
“I don't expect to be long.

其实”——他又瞥了一眼房子——“其实，你干吗不在这里等着，我去按门铃。
In fact” — he glanced once more towards the house — “in fact, why don't you wait here until I pull the bell.

要是看见我进去，你就先到藤原太太那里去。
If you see me go in, then you can go on to Mrs Fujiwara's.

我太欠考虑了。”
This has all been very inconsiderate of me.”

“一点儿都不要紧，爸爸。
“It's perfectly all right, Father.

现在您听好了，不然您永远也别想找到面馆。
Now listen carefully, or else you'll never find the noodle shop.

您记得以前那个医生的诊所吗？”
You remember where the doctor used to have his surgery?”

但这时绪方先生已经没有在听了。
But Ogata-San was no longer listening.

马路对面的大门开了，一个瘦瘦的、戴着眼镜的年轻人走出来。
Across the road, the entrance gate had slid open, and a thin young man with spectacles had appeared.

他穿着衬衫，腋下夹着一只小公文包。
He was dressed in his shirtsleeves and held a small briefcase under his arm.

走到太阳底下时，他眯了眯眼睛。接着他转向公文包，开始找东西。
He squinted a little as he stepped further into the glare, then bent over the briefcase and began searching through it.

松田重夫比我之前见过的几次看起来更瘦、更年轻。
Shigeo Matsuda looked thinner and more youthful than I remembered him from the few occasions I had met him in the past.

# 第二部 · 第九章 | PART TWO · Chapter Nine

松田重夫扣上公文包的扣子，然后一边心烦意乱地看看周围，一边朝马路这边走来。
Shigeo Matsuda tied the buckle of his briefcase, then glancing about him with a distracted air came walking over to our side of the road.

他扫了我们这边一眼，却没有认出我们，继续往前走。
For a brief moment he glanced our way but, not recognizing us, went walking on.

绪方先生看着他走过去。
Ogata-San watched him go by.

当年轻人走了几码远时，他才喊道：“啊，重夫！”
Then when the young man had gone several yards down the road, he called out: “Ah, Shigeo!”

松田重夫停下脚步，转过身来，然后迷惑不解地朝我们走来。
Shigeo Matsuda stopped and turned. Then he came towards us with a puzzled look.

“你好吗，重夫？”
“How are you, Shigeo?”

年轻人透过镜片细细看来，接着高兴地笑了起来。
The young man peered through his spectacles, then burst into cheerful laughter.

“啊呀，绪方先生！
“Why, Ogata-San!

太意外了！”
Now this is an unexpected surprise!”

他鞠了一躬，然后伸出手来。
He bowed and held out his hand.

“真是个惊喜。
“What a splendid surprise.

啊，还有悦子！
Why Etsuko-San too!

你们好吗？
How are you?

真高兴又见到你们。”
How nice to meet again.”

我们互相鞠了躬，他还和我们都握了手。
We exchanged bows, and he shook hands with us both.

接着他对绪方先生说：
Then he said to Ogata-San:

“你们是要去找我吗？
“Were you by any chance about to visit me?

太不巧了，我的午休时间快到了。”
This is bad luck, my lunch break's almost over now.”

他看了看表。
He glanced at his watch.

“但我们还可以进去坐几分钟。”
“But we could go back inside for a few minutes.”

“不，不，”绪方先生赶忙说。
“No, no,” said Ogata-San hurriedly.

“别让我们打搅了你的工作。
“Don't let us interrupt your work.

我们只是刚好路过这里，我想起来你住在这里，正把你家指给悦子看。”
It just so happened we were passing this way, and I remembered you lived here. I was just pointing out your house to Etsuko.”

“不客气，我能腾出几分钟来。
“Please, I can spare a few minutes.

至少喝杯茶吧。
Let me offer you some tea at least.

这天外面热得要命。”
It's a sweltering day out here.”

“不，不。
“No, no.

你得工作。”
You must get to work.”

一时间两个人站着对视。
For a moment the two men stood looking at each other.

“最近怎么样，重夫？”
“And how is everything, Shigeo?”

绪方先生问。
Ogata-San asked.

“学校里怎么样？”
“How are things at the school?”

“哦，老样子。
“Oh, much the same as ever.

您知道的。
You know how it is.

而您，绪方先生，但愿您退休后过得愉快？
And you, Ogata-San, you're enjoying your retirement, I hope?

我不知道您在长崎。
I had no idea you were in Nagasaki.

我和二郎现在几乎都失去联系了。”
Jiro and I seem to have lost touch these days.”

接着他转向我，说：“我一直想写信，但老是忘记。”
Then he turned to me and said: “I'm always meaning to write, but I'm so forgetful.”

我笑了笑，说了几句客套话。
I smiled and made some polite comment.

然后两人又对视着。
Then the two men looked at each other again.

“您看上去气色真不错，绪方先生，”松田重夫说。
“You're looking splendidly well, Ogata-San,” Shigeo Matsuda said.

“您喜欢福冈吗？”
“You find Fukuoka to your liking?”

“喜欢，一座好城市。
“Yes, a fine city.

我的老家，你知道。”
My hometown, you know.”

“真的？”
“Really?”

又是一阵沉默。
There was another pause.

接着绪方先生说：“千万别让我们耽搁了你。
Then Ogata-San said: “Please don't let us keep you.

你要是赶时间的话，我很理解。”
If you have to hurry away, I quite understand.”

“不，不。
“No, no.

我还有几分钟。
I have a few minutes yet.

真可惜您没有早点路过这里。
A pity you weren't passing a little earlier.

也许您离开长崎前可以来找我。”
Perhaps you'd care to call in before you leave Nagasaki.”

“好，我尽量。
“Yes, I'll try to.

可我有很多人要去拜访。”
But there's so many people to visit.”

“是，我理解。”
“Yes, I can understand how it is.”

“还有你母亲，她好吗？”
“And your mother, is she well?”

“是，她很好。
“Yes, she's fine.

谢谢您。”
Thank you.”

一时间，两人又不说话了。
For a moment, they fell silent again.

“我很高兴一切都好，”绪方先生打破沉默，说道，“对，我们刚好路过这里，我在告诉悦子你住在这里。
“I'm glad everything's going well,” Ogata-San said, eventually. “Yes, we were just passing this way and I was telling Etsuko-San you lived here.

事实上，我刚刚想起你以前常来我们家和二郎玩，你们都还是小孩子的时候。”
In fact, I was just remembering how you used to come and play with Jiro, when you were both little boys.”

松田重夫笑了。
Shigeo Matsuda laughed.

“时间过得真快啊，不是吗？”他说。
“Time really flies by, doesn't it?” he said.

“是啊。
“Yes.

我刚还在跟悦子说呢。
I was just saying as much to Etsuko.

事实上，我正要告诉她一件奇怪的小事。
In fact, I was just about to tell her about a curious little thing.

我看见你家时突然想起来的。
I happened to remember it, when I saw your house.

一件奇怪的小事。”
A curious little thing.”

“哦，是吗？”
“Oh yes?”

“是的。
“Yes.

我看见你家时刚好想起来，就这么回事。
I just happened to remember it when I saw your house, that's all.

是这样，有一天我读到一篇东西。
You see, I was reading something the other day.

一本期刊里的一篇文章。
An article in a journal.

我想是叫《新教育文摘》。”
The New Education Digest, I think it was called.”

一时间年轻人没有做声，过了一会儿他调整了一下在人行道上的站姿，放下公文包。
The young man said nothing for a moment, then he adjusted his position on the pavement and put down his briefcase.

“嗯哼，”他说。
“I see,” he said.

“读了以后我有点吃惊。
“I was rather surprised to read it.

事实上是很惊讶。”
In fact, I was quite astonished.”

“是。
“Yes.

我想您会的。”
I suppose you would be.”

“文章很奇怪，重夫。
“It was quite extraordinary, Shigeo.

很奇怪。”
Quite extraordinary.”

松田重夫深吸了一口气，然后看着地板。
Shigeo Matsuda took a deep breath and looked down at the ground.

他点点头，但没有说什么。
He nodded, but said nothing.

“我早想来找你谈谈，”绪方先生接着说，“但自然了，我把这件事忘了。
“I'd meant to come and speak to you for some days now,” Ogata-San continued. “But of course, the matter slipped my mind.

重夫，老实告诉我，你相信你写的东西吗？
Shigeo, tell me honestly, do you believe a word of what you wrote?

解释一下是什么让你写那些东西。
Explain to me what made you write such things.

解释给我听，重夫，这样我才能安心地回到福冈去。
Explain it to me, Shigeo, then I can go home to Fukuoka with my mind at rest.

现在我很迷惑。”
At the moment, I'm very puzzled.”

松田重夫用鞋跟踢着一块小石头。
Shigeo Matsuda was prodding a pebble with the end of his shoe.

最后他叹了口气，抬头看绪方先生，正了正眼镜。
Finally he sighed, looked up at Ogata-San and adjusted his spectacles.

“这几年很多事都变了，”他说。
“Many things have changed over the last few years,” he said.

“啊，自然是这样。
“Well, of course they have.

我看得出来。
I can see that much.

可这算什么回答，重夫？”
What kind of answer is that, Shigeo?”

“绪方先生，让我解释给您听。”
“Ogata-San, let me explain.”

他停顿了一下，又低头看地板，中间挠了一下耳朵。
He paused and looked down at the ground again. For a second or two, he scratched at his ear.

“您瞧，您必须理解。
“You see, you must understand.

现在很多事都变了。
Many things have changed now.

而且还在变。我们现在的生活和过去……过去您是位有影响力的人物时不一样了。”
And things are changing still. We live in a different age from those days when … when you were an influential figure.”

“但是，重夫，这和事情有什么关系？
“But, Shigeo, what has this to do with anything?

时代可能是变了，但为什么写那种文章？
Things may change, but why write such an article?

我做了什么冒犯你的事了吗？”
Have I ever done something to offend you?”

“没有，从来没有。
“No, never.

至少对我个人没有。”
At least, not to me personally.”

“我想也是。
“I should think not.

还记得那天我把你介绍给现在学校的校长吗？
Do you remember the day I introduced you to the principal at your school?

不是很久以前的事吧。
That wasn't so long ago, was it?

或者说那也是另一个时代的事？”
Or was that perhaps a different era too?”

“绪方先生”——松田重夫提高了嗓门，神态里似乎透出一丝权威——“绪方先生，我真希望您早一个小时来，那样我也许能解释得清楚些。
“Ogata-San” — Shigeo Matsuda had raised his voice, and an air of authority seemed to enter his manner — “Ogata-San, I only wish you'd called in an hour earlier. Then perhaps I'd have been able to explain at greater length.

现在没有时间把整件事情讲清楚。
There isn't time to talk the whole thing over now.

但是让我就说这么多。
But let me just say this much.

是的，我相信我文章里写的每一个字，现在仍然相信。
Yes, I believed everything I wrote in that article and still do.

您那个时候，老师教给日本的孩子们可怕的东西。
In your day, children in Japan were taught terrible things.

他们学到的是最具破坏力的谎言。
They were taught lies of the most damaging kind.

最糟糕的是，老师教他们不能看、不能问。
Worst of all, they were taught not to see, not to question.

这就是为什么我们国家会卷入有史以来最可怕的灾难。”
And that's why the country was plunged into the most evil disaster in her entire history.”

“我们也许是打了败仗，”绪方先生打断他说，“但不能因此而照搬敌人的那一套。
“We may have lost the war,” Ogata-San interrupted, “but that's no reason to ape the ways of the enemy.

我们打败仗是因为我们没有足够的枪和坦克，不是因为我们的人民胆小，不是因为我们的社会浮浅。
We lost the war because we didn't have enough guns and tanks, not because our people were cowardly, not because our society was shallow.

重夫，你不知道我们多么辛勤地工作，我们这些人，像我，像远藤老师，你在文章里也侮辱了他。
You have no idea, Shigeo, how hard we worked, men like myself, men like Dr Endo, whom you also insulted in your article.

我们深切地关心我们的国家，辛勤工作让正确的价值观保留下来，并传承下去。”
We cared deeply for the country and worked hard to ensure the correct values were preserved and handed on.”

“我不怀疑这些。
“I don't doubt these things.

我不怀疑您的真诚和辛勤工作。
I don't doubt you were sincere and hard working.

我从来没有质疑过这点。
I've never questioned that for one moment.

可是您的精力用在了不对的地方，罪恶的地方。
But it just so happens that your energies were spent in a misguided direction, an evil direction.

您当时不会发觉，但恐怕这是事实。
You weren't to know this, but I'm afraid it's true.

如今一切都过去了，我们惟有感激。”
It's all behind us now and we can only be thankful.”

“太奇怪了，重夫。
“This is extraordinary, Shigeo.

你真的相信这些？
Can you really believe this?

谁教你说这些的？”
Who taught you to say such things?”

“绪方先生，坦诚一些吧。
“Ogata-San, be honest with yourself.

您一定心知肚明我说的都是真的。
In your heart of hearts, you must know yourself what I'm saying is true.

而且说句公道话，不应该责备您没有认识到您的行为的真正后果。
And to be fair, you shouldn't be blamed for not realizing the true consequences of your actions.

当时很少有人认识到局势发展的方向，而那些少数认清时局的人却因直抒己见而被投进监狱。
Very few men could see where it was all leading at the time, and those men were put in prison for saying what they thought.

不过现在他们被释放了，他们将带领我们走向新的黎明。”
But they're free now, and they'll lead us to a new dawn.”

“新的黎明？
“A new dawn?

胡说八道些什么？”
What nonsense is this?”

“好了，我得走了。
“Now, I must be on my way.

很抱歉我们不能多谈谈。”
I'm sorry we couldn't discuss this any longer.”

“这是什么话，重夫？
“What is this, Shigeo?

你怎么能说出这种话？
How can you say these things?

你显然不知道像远藤老师这样的人为工作付出了多少努力和心血。
You obviously have no idea of the effort and devotion men like Dr Endo gave to their work.

那时你还是小孩子，你怎么可能知道事情是什么样的？
You were just a small boy then, how could you know how things were?

你怎么可能知道我们付出了什么，取得了什么？”
How can you know what we gave and what we achieved?”

“事实上，我碰巧熟悉您的职业的某些方面。
“As a matter of fact, I do happen to be familiar with certain aspects of your career.

比如说，在西坂小学解雇并监禁了五名教师。
For instance, the sacking and imprisoning of the five teachers at Nishizaka.

我没记错的话是1938年4月。
April of 1938, if I'm not mistaken.

不过现在那些人被释放了，他们将帮助我们迈向新的黎明。
But those men are free now, and they'll help us reach a new dawn.

现在请原谅。”
Now please excuse me.”

松田重夫拎起公文包，朝我们依次鞠了躬。
He picked up his briefcase and bowed to us in turn.

“代我向二郎问好，”他补充道，然后转身离去。
“My regards to Jiro,” he added, then turned and walked away.

绪方先生看着年轻人走下山去，消失不见。
Ogata-San watched the young man disappear down the hill.

之后他仍在原地站了好一会儿，没有说话。
He continued to stand there for several more moments, not speaking.

当他最终转向我时，眼角泛着微笑。
Then when he turned to me, there was a smile around his eyes.

“多么自信的年轻人啊，”他说，“我想我以前也是一样。
“How confident young men are,” he said. “I suppose I was much the same once.

坚持己见。”
Very sure of my opinions.”

“爸爸，”我说，“现在我们该去看藤原太太了吧。
“Father,” I said. “Perhaps we should go and see Mrs Fujiwara now.

我们该吃午饭了。”
It's time we ate lunch.”

“哎呀，当然了，悦子。
“Why, of course, Etsuko.

我太粗心了，让你这么大热天地站着。
This is very inconsiderate of me, making you stand about in this heat.

对，我们去看那位好太太吧。
Yes, let's go and see the good lady.

我很高兴能再见到她。”
I'll be very pleased to see her again.”

我们走下山，接着走过一条小河上的一座木桥。
We made our way down the hill, then crossed a wooden bridge over a narrow river.

桥下有一群孩子在河边玩耍，其中几个拿着鱼竿。
Below us, children were playing along the riverbank, some with fishing poles.

路上我对绪方先生说：
Once, I said to Ogata-San:

“他都是在胡说八道。”
“What nonsense he was speaking.”

“谁？
“Who?

你指重夫？”
You mean Shigeo?”

“都是些可耻的话。
“What vile nonsense.

我觉得您根本不用在意，爸爸。”
I don't think you should pay the slightest attention, Father.”

绪方先生笑了笑，但没有回答。
Ogata-San laughed, but made no reply.

和平时一样，那个钟点，那一带的商业街挤满了人。
As always at that hour, the shopping area of the district was busy with people.

走进面馆阴凉的前院时，我欣喜地看见几张桌子上坐着客人。
On entering the shaded forecourt of the noodle shop, I was pleased to see several of the tables occupied with customers.

藤原太太看见我们，走了过来。
Mrs Fujiwara saw us and came across the forecourt.

“哎呀，绪方先生，”她一眼就认出他来，惊呼道，“再次见到您真是太好了。
“Why, Ogata-San,” she exclaimed, recognizing him immediately, “how splendid to see you again.

很久不见了，不是吗？”
It's been a long time, hasn't it?”

“确实是很久了。”
“A long time indeed.”

绪方先生回敬藤原太太的鞠躬。
Ogata-San returned the bow Mrs Fujiwara gave him.

“是啊，很久了。”
“Yes, a long time.”

看见他们如此热情地打招呼，我很是感动，因为据我所知，他们并不熟识。
I was struck by the warmth with which they greeted each other, for as far as I knew Ogata-San and Mrs Fujiwara had never known one another well.

他们没完没了地鞠躬来鞠躬去，最后藤原太太才去给我们取东西吃。
They exchanged what seemed an endless succession of bows, before Mrs Fujiwara went to fetch us something to eat.

她很快就端来两碗热腾腾的面，抱歉说没有什么更好的东西来招待我们。
She returned presently with two steaming bowls, apologizing that she had nothing better for us.

绪方先生感激地鞠了一躬，吃起来。
Ogata-San bowed appreciatively and began to eat.

“我还以为您早把我忘了呢，藤原太太，”他微笑着说。
“I thought you'd have forgotten me long ago, Mrs Fujiwara,” he remarked with a smile.

“说真的，好久了。”
“Indeed, it's been a long time.”

“像这样久别重逢真是件高兴的事。”
“It's such a pleasure to meet again like this,” Mrs Fujiwara said, seating herself on the edge of my bench.

藤原太太在我那张长凳的角上坐下，说，“悦子跟我说您现在住在福冈。
“Etsuko tells me you reside in Fukuoka these days.

我去过福冈几次。
I visited Fukuoka several times.

很好的城市，不是吗？”
A fine city, isn't it?”

“是的，没错。
“Yes, indeed.

福冈是我的老家。”
Fukuoka is my hometown.”

“福冈是您的老家？
“Fukuoka your hometown?

可是您在这里生活、工作了那么多年。
But you lived and worked here for years, Ogata-San.

难道长崎没有值得您留念的吗？”
Don't we have any claim on you in Nagasaki?”

绪方先生笑了，把头歪向一边。
Ogata-San laughed and leaned his head to one side.

“一个人也许会在一个地方工作、奉献，但是到了最后”——他耸耸肩，怀念地笑了笑——“到了最后，他仍旧想回到他生长的故乡去。”
“A man might work and make his contribution in one place, but at the end of it all” — he shrugged and smiled wistfully — “at the end of it all, he still wants to go back to the place where he grew up.”

藤原太太点点头，表示理解，然后说道：“绪方先生，我刚刚在想您当秀一学校校长的那时候。
Mrs Fujiwara nodded understandingly. Then she said: “I was just remembering, Ogata-San, the days when you were the headmaster at Suichi's school.

他以前可怕您了。”
He used to be so frightened of you.”

绪方先生笑了。
Ogata-San laughed.

“是，我清楚地记得您的秀一。
“Yes, I remember your Suichi very well.

一个聪明的男孩子。
A bright little boy.

很聪明。”
Very bright.”

“您真的还记得他，绪方先生？”
“Do you really remember him still, Ogata-San?”

“是，当然，我记得秀一。
“Yes, of course, I remember Suichi.

他学习很用功。
He used to work very hard.

是个好孩子。”
A good little boy.”

“是啊，他是个好孩子。”
“Yes, he was a good little boy.”

绪方先生用筷子指了指碗，说：“太好吃了。”
Ogata-San pointed at his bowl with his chopsticks. “This is really marvellous,” he said.

“瞎说。
“Nonsense.

很抱歉没有什么更好的东西来招待你们。”
I'm sorry I have nothing better to give you.”

“不，真的，很好吃。”
“No, really, it's delicious.”

“让我想想，”藤原太太说。
“Now let me see,” said Mrs Fujiwara.

“那个时候有个老师，她对秀一很好。
“There was a teacher in those days, she was very kind to Suichi.

她叫什么名字来着？
Now what was her name?

我想是铃木，铃木小姐。
Suzuki, I think it was, Miss Suzuki.

您知道她后来怎么样了吗，绪方先生？”
Have you any idea what became of her, Ogata-San?”

“铃木小姐？
“Miss Suzuki?

啊，是，我想起来了。
Ah, yes, I recall her quite well.

但是很遗憾我不知道她现在在哪里。”
But I'm afraid I've no idea where she could be now.”

“她对秀一很好。
“She was very kind to Suichi.

还有另外一个老师，名字叫黑田。
And there was that other teacher, Kuroda was his name.

一个很棒的年轻人。”
An excellent young man.”

“黑田……”绪方先生慢慢地点点头。
“Kuroda …” Ogata-San nodded slowly.

“啊，是，黑田。
“Ah yes, Kuroda.

我记得他。
I remember him.

是位好老师。”
A splendid teacher.”

“是啊，一个与众不同的年轻人。
“Yes, a most impressive young man.

我丈夫对他印象特别深刻。
My husband was very struck by him.

您知道他后来怎么样了吗？”
Do you know what became of him?”

“黑田……”绪方先生仍若有所思地点着头。一缕阳光照在他脸上，照亮了他眼睛周围的许多皱纹。
“Kuroda …” Ogata-San was still nodding to himself. A streak of sunlight had fallen across his face, lighting up the many wrinkles around his eyes.

“黑田，让我想想。
“Kuroda, now let me see.

我有一次遇到过他，很偶然的，战争开始的时候。
I ran into him once, quite by accident. That was at the start of the war.

我想他参战了。从那以后我就再也没有他的消息了。
I suppose he went off to fight. I've never heard of him since.

是，是位好老师。
Yes, an excellent teacher.

以前的很多人都没有消息了。”
There are so many from those days I never hear of now.”

有人叫藤原太太，我们看着她匆匆地走过水泥地到客人的桌子那去。
Someone called out to Mrs Fujiwara and we watched her go hurriedly across the forecourt to her customer's table.

她站在那里行了好一会儿的礼，然后收拾桌上的碗盘，走进厨房。
She stood there bowing for several moments, then cleared some dishes from the table and disappeared into the kitchen.

绪方先生看着她，然后摇摇头。
Ogata-San watched her, then shook his head.

“看见她这样真是遗憾，”他低声说。
“A great pity to see her like this,” he said, in a low voice.

我没说什么，只是吃饭。
I said nothing and continued to eat.

过了一会儿绪方先生从桌子那头俯过身来，问：“悦子，你以前说她儿子叫什么名字来着？
Then Ogata-San leaned across the table and asked: “Etsuko, what did you say was the name of her son?

我是指活着的那个。”
The one who's still alive, I mean.”

“和夫，”我小声说。
“Kazuo,” I whispered.

他点点头，接着吃面。
He nodded, then returned to his bowl of noodles.

过了一会儿藤原太太回来。
Mrs Fujiwara came back a few moments later.

“没有什么更好的东西来招待你们，真是不好意思，”她说。
“Such a shame I don't have something better to offer you,” she said.

“瞎说，”绪方先生说。
“Nonsense,” said Ogata-San.

“面很好吃。
“This is delicious.

对了，和夫最近怎么样？”
And how is Kazuo-San these days?”

“他很好。
“He's fine.

他身体健康，工作也顺利。”
He's in good health, and he enjoys his work.”

“很好。
“Splendid.

悦子刚才跟我说他在一家汽车公司上班。”
Etsuko was telling me he works for a motor car company.”

“是，他在那里做得很好。
“Yes, he's doing very well there.

而且他正在考虑再婚。”
What's more, he's thinking of marrying again.”

“真的？”
“Really?”

“以前他说他不会再结婚，但是现在他开始向前看了。
“He said once he'd never marry again, but he's starting to look ahead to things now.

他目前还没有考虑的对象，但至少他开始考虑未来了。”
He has no one in mind as of yet, but at least he's started to think ahead.”

“这样想才对，”绪方先生说。
“That sounds like good sense,” Ogata-San said.

“啊，他还年轻，不是？”
“Why, he's still quite a young man, isn't he?”

“当然了。
“Of course he is.

他还有一大把日子呢。”
He still has all his life ahead of him.”

“当然了。
“Of course he has.

他的日子还长着呢。
His whole life ahead of him.

你一定要给他找一个好姑娘，藤原太太。”
You must find him a nice young lady, Mrs Fujiwara.”

她笑了。
She laughed.

“您以为我没试过？
“Don't think I haven't tried.

不过现在的女孩子大不一样了。
But young women are so different these days.

太让我吃惊了，世道变得如此之大、如此之快。”
It amazes me, how things have changed so much so quickly.”

“确实，您说得很对。
“Indeed, how right you are.

现在的女孩子都任性得很。
Young women these days are all so headstrong.

而且整天在讲什么洗衣机啦、洋裙啦。
And forever talking about washing-machines and American dresses.

悦子也是。”
Etsuko here's no different.”

“胡说，爸爸。”
“Nonsense, Father.”

藤原太太又笑了，然后说：“我记得我第一次听说洗衣机时，我不敢相信有人会想要那玩意。
Mrs Fujiwara laughed again, then said: “I remember the first time I heard of a washing-machine, I couldn't believe anyone would want such a thing.

明明有一双好好的手可以干活，干吗要花那个钱？
Spending all that money, when you had two good hands to work with.

不过我相信悦子不会同意我的看法的。”
But I'm sure Etsuko wouldn't agree with me.”

我正想说什么，却被绪方先生抢先一步：“我跟您说我前些天听说的一件事。
I was about to say something, but Ogata-San spoke first: “Let me tell you,” he said, “what I heard the other day.

其实是二郎的一个同事告诉我的。
A man was telling me this, a colleague of Jiro's, in fact.

显然是在上次的选举中，要投给哪个政党，他妻子和他意见不合。
Apparently at the last elections, his wife wouldn't agree with him about which party to vote for.

他就打她，但是他妻子仍然没有让步。
He had to beat her, but she still didn't give way.

所以最后，他们分别投给了不同的政党。
So in the end, they voted for separate parties.

您能想像过去会发生这种事吗？
Can you imagine such a thing happening in the old days?

太奇怪了。”
Extraordinary.”

藤原太太摇摇头。
Mrs Fujiwara shook her head.

“世道变太多了，”她叹了口气，说。
“Things are so different now,” she said, and sighed.

“不过我听悦子说二郎现在在公司里干得很好。
“But I hear from Etsuko, Jiro-San is getting on splendidly now.

您一定很为他骄傲，绪方先生。”
You must be proud of him, Ogata-San.”

“是，我想那孩子确实干得不错。
“Yes, I suppose that boy's getting on well enough.

事实上，今天他将代表他们公司参加一个很重要的会议。
In fact, today he'll be representing his firm at a most important meeting.

看来他们正在考虑再次提拔他。”
It appears they're thinking of promoting him again.”

“太了不起了。”
“How marvellous.”

“他去年才刚刚获得提升。
“It was only last year he was promoted.

我想领导一定对他评价很高。”
I suppose his superiors must have a high opinion of him.”

“太了不起了。
“How marvellous.

您一定很为他骄傲。”
You must be very proud of him.”

“那小子是个工作很努力的人。
“He's a determined worker, that one.

从小就是。
He always was from an early age.

我记得小时候，其他父亲都在使劲地叫孩子要更刻苦地学习，我却要不断地叫他多去玩一玩，学得那么刻苦对身体不好。”
I remember when he was a boy, and all the other fathers were busy telling their children to study harder, I was obliged to keep telling him to play more, it wasn't good for him to work so hard.”

藤原太太笑了，摇摇头说：“是啊，和夫也工作得很拼命，常常看文件看到半夜。
Mrs Fujiwara laughed and shook her head. “Yes, Kazuo's a hard worker too,” she said. “He's often reading through his paperwork right into the night.

我劝他不要工作得这么辛苦，可他不听。”
I tell him he shouldn't work so hard, but he won't listen.”

“是，他们根本不听。
“No, they never listen.

但是我得承认，我以前也是这样。
And I must admit, I was much the same.

当你相信你做的是对的时，你就不愿意浪费一分一秒。
But when you believe in what you're doing, you don't feel like idling away the hours.

我妻子也常劝我多休息，可我就是不听。”
My wife was always telling me to take it easy, but I never listened.”

“是啊，和夫就是这样。
“Yes, that's just the way Kazuo is.

可他要是再结婚了，就得改改了。”
But he'll have to change his ways if he marries again.”

“别指望结了婚就会改变，”绪方先生笑着说。
“Don't depend on it,” Ogata-San said, with a laugh.

说完，他把筷子整齐地搁在碗上。
Then he put his chopsticks neatly together across his bowl.

“哎呀，太好吃了。”
“Why, that was a splendid meal.”

“瞎说。
“Nonsense.

很抱歉没有什么更好的东西来招待你们。
I'm sorry I couldn't offer you something better.

您还要吗？”
Would you care for some more?”

“有多的话，我很乐意。
“If you have more to spare me, I'd be delighted.

要知道，我得趁这些日子多享受享受这么好的饭菜。”
These days, I have to make the best of such good cooking, you know.”

“瞎说，”藤原太太站起来，再次说道。
“Nonsense,” said Mrs Fujiwara again, getting to her feet.

我们回到家后不久，二郎也下班回家了，比平时早一个小时左右。
We had not been back long when Jiro came in from work, an hour or so earlier than usual.

他愉快地向他父亲问好——完全忘了前一天晚上发脾气的事——然后洗澡去了。
He greeted his father cheerfully — his show of temper the previous night apparently quite forgotten — before disappearing to take his bath.

洗完澡出来时，他换上了和服，哼着小曲儿。
He returned a little later, dressed in a kimono, humming a song to himself.

他在垫子上坐下，开始用毛巾擦头发。
He seated himself on a cushion and began to towel his hair.

“那么，事情怎么样？”
“Well, how did it go?”

绪方先生问。
Ogata-San asked.

“什么事情？
“What's that?

哦，您是指那个会啊。
Oh, the meeting, you mean.

还不错。
It wasn't so bad.

不算太糟。”
Not so bad at all.”

我正要去厨房，但在门口停了下来，想听听二郎接下来会说些什么。
I had been on the point of going into the kitchen, but paused at the doorway, waiting to hear what else Jiro had to say.

他父亲也一直看着他。
His father, too, continued to look at him.

而二郎只是擦着头发，没有看我们。
For several moments, Jiro went on towelling his hair, looking at neither of us.

“事实上，”他终于开口说道，“我想我干得还不错。
“In fact,” he said at last, “I suppose I did rather well.

我说服他们的代表签了一份协议。
I persuaded their representatives to sign an agreement.

不是合同，但差不离了。
Not exactly a contract, but to all purposes the same thing.

我的老板相当吃惊。
My boss was quite surprised.

他们很少像这样答应下来。
It's unusual for them to commit themselves like that.

老板让我提早下班。”
He told me to take the rest of the day off.”

“哎呀，真是好消息，”绪方先生说道，然后笑了一声。
“Why, that's splendid news,” Ogata-San said, then gave a laugh.

他朝我看了一眼，又转向他儿子。
He glanced towards me, then back at his son.

“真是好消息。”
“That's splendid news.”

“恭喜，”我对着我丈夫微笑地说道。
“Congratulations,” I said, smiling at my husband.

“我太高兴了。”
“I'm so glad.”

二郎抬起头来，好像这才注意到我。
Jiro looked up, as if noticing me for the first time.

“你干吗那样站在那里？”他问。
“Why are you standing there like that?” he asked.

“你知道我不介意来点茶。”他放下毛巾，开始梳头。
“I wouldn't mind some tea, you know.” He put down his towel and began combing his hair.

那天晚上，为了庆祝二郎谈判成功，我准备了比平时丰盛的晚餐。
That evening, in order to celebrate Jiro's success, I prepared a more elaborate meal than usual.

不管是晚餐时，还是晚餐后直到睡觉，绪方先生都没有提起白天见到松田重夫的事。
Neither during supper, nor during the rest of the evening, did Ogata-San mention anything of his encounter with Shigeo Matsuda that day.

可是晚餐刚开始时，他突然说道：
However, just as we began to eat, he said quite suddenly:

“哦，二郎，我明天要回去了。”
“Well, Jiro, I'll be leaving you tomorrow.”

二郎抬起头来。
Jiro looked up.

“您要回去了？
“You're leaving?

哦，太遗憾了。
Oh, a pity.

我希望您这几天住得开心。”
Well, I hope you enjoyed your visit.”

“是，我好好地休息了一番。
“Yes, I've had a good rest.

事实上，我比原计划多待了好一阵子。”
In fact, I've been with you rather longer than I planned.”

“我们欢迎您住在这里，爸爸，”二郎说。
“You're welcome, Father,” said Jiro.

“不用急着回去，我向您保证。”
“No need to rush, I assure you.”

“谢谢你们，可我该回去了。
“Thank you, but I must be getting back now.

有些事情要接着做。”
There's a few things I have to be getting on with.”

“方便的时候，请一定要再来。”
“Please come and visit us again, whenever it's convenient.”

“爸爸，”我说，“孩子出生以后您一定要来看孩子。”
“Father,” I said. “You must come and see the baby when it arrives.”

绪方先生微笑着说：“那大概在新年吧。
Ogata-San smiled. “Perhaps at New Year then,” he said.

在那之前我不会来打搅你的，悦子。
“But I won't bother you much earlier than that, Etsuko.

你会有够多的事要忙，哪有时间照顾我？”
You'll have enough on your hands without having to contend with me.”

“真遗憾您来的不是时候，”我丈夫说，“也许下一次我的工作就没有逼得这么紧了，我们就有时间多聊聊了。”
“A pity you caught me at such a busy time,” my husband said. “Next time, perhaps, I won't be so hard pressed and we'll have more time to talk.”

“好了，别担心了，二郎。
“Now, don't worry, Jiro.

没有什么比看到你如此投入工作更让我高兴的了。”
Nothing has pleased me more than to see how much you devote yourself to your work.”

“现在这笔生意终于谈成了，”二郎说，“我的时间就多一些了。
“Now this deal's finally gone through,” said Jiro, “I'll have a little more time.

真遗憾您这时候要回去。
A shame you have to go back just now.

我正在考虑请两天假呢。
And I was thinking of taking a couple of days off too.

但我想是无济于事了。”
Still, it can't be helped, I suppose.”

“爸爸，”我打断二郎的话，“要是二郎能请两天假，您不能多待一个星期吗？”
“Father,” I said, interrupting, “if Jiro's going to take a few days off, can't you stay another week?”

我丈夫停下在吃饭的手，但没有抬头。
My husband stopped eating, but did not look up.

“很诱人的提议，”绪方先生说，“但我想我真的该回去了。”
“It's tempting,” Ogata-San said, “but I really think it's time I went back.”

二郎接着吃饭。
Jiro began to eat once more.

“真遗憾，”他说。
“A pity,” he said.

“没错，我真的得在纪久子和她丈夫来之前把阳台弄好。
“Yes, I really must get the veranda finished before Kikuko and her husband come.

他们秋天时一定会想来的。”
They're bound to want to come down in the autumn.”

二郎没有回答，我们静静地吃着晚饭。
Jiro did not reply, and we all ate in silence for a while.

过了一会儿，绪方先生说：
Then Ogata-San said:

“而且我不能整天坐在这里想着下棋。”
“Besides, I can't sit here thinking about chess all day.”

他有点不自然地笑了笑。
He laughed, a little strangely.

二郎点点头，但没有说什么。
Jiro nodded, but said nothing.

绪方先生又笑了一声，我们继续静静地吃饭。
Ogata-San laughed again, then for several moments we continued to eat in silence.

“您最近喝清酒吗，爸爸？”
“Do you drink sake these days, Father?”

过了好一会儿二郎问道。
Jiro asked eventually.

“清酒？
“Sake?

有时喝一点。
I take a drop sometimes.

不常喝。”
Not often.”

“既然这是您住在这里的最后一晚，我们喝点酒吧。”
“Since this is your last evening with us, perhaps we should take some sake.”

绪方先生像是想了好一会儿。
Ogata-San seemed to consider this for a moment.

最后他微笑着说：“没有必要为了我一个糟老头瞎忙活。
Finally, he said with a smile: “There's no need to make a fuss about an old man like me.

但我和你喝一杯，庆祝你美好的前程。”
But I'll join you in a cup to celebrate your splendid future.”

二郎冲我点点头。
Jiro nodded to me.

我走向碗柜，取出一个酒瓶和两个杯子。
I went to the cupboard and brought out a bottle and two cups.

这时绪方先生说：“我一直相信你会成功。
“I always thought you'd go far,” Ogata-San was saying.

你总是很有前途。”
“You always showed promise.”

“就凭今天的事并不保证他们一定会提升我，”我丈夫说。
“Just because of what happened today, that's no guarantee they'll give me the promotion,” my husband said.

“但我想我今天的努力也没什么坏处。”
“But I suppose my efforts today will have done no harm.”

“当然没有，”绪方先生说。
“No, indeed,” said Ogata-San.

“不会有什么坏处。”
“I doubt if you did yourself much harm today.”

他俩都静静地看着我倒酒。
They both watched in silence as I poured out the sake.

然后绪方先生放下筷子，举起酒杯。
Then Ogata-San laid down his chopsticks and raised his cup.

“为你的将来干杯，二郎，”他说。
“Here's to your future, Jiro,” he said.

我丈夫嘴里还吃着东西，也举起酒杯。
My husband, some food still in his mouth, also raised his cup.

“也为您干杯，爸爸，”他说。
“And to yours, Father,” he said.

回忆，我发现，可能是不可靠的东西；常常被你回忆时的环境所大大地扭曲，毫无疑问，我现在在这里的某些回忆就是这样。
Memory, I realize, can be an unreliable thing; often it is heavily coloured by the circumstances in which one remembers, and no doubt this applies to certain of the recollections I have gathered here. For instance.

比如说，我发现这种想法很诱人，即：那天下午我看见了一个先兆；那天我脑子里闪过的可怕的画面和一个人长时间地无聊时做的各种白日梦是完全不同的，来得更加强烈、更加逼真。
I find it tempting to persuade myself it was a premonition I experienced that afternoon, that the unpleasant image which entered my thoughts that day was something altogether different — something much more intense and vivid — than the numerous day-dreams which drift through one's imagination during such long and empty hours.

很可能根本不是什么大不了的事。
In all possibility, it was nothing so remarkable.

一个小女孩被发现吊死在树上的惨剧——更甚于之前的那几起儿童谋杀案——震惊了整个小区。所以那年夏天我不会是唯一一个被这类幻象所困扰的人。
The tragedy of the little girl found hanging from a tree — much more so than the earlier child murders — had made a shocked impression on the neighbourhood, and I could not have been alone that summer in being disturbed by such images.

那是我们去稻佐山一两天之后，下午晚些时候，我正在公寓里忙着一些零活，无意间瞥了一眼窗外。
It was the latter part of the afternoon, a day or two after our outing to Inasa, and I was occupying myself with some small chores around the apartment when I happened to glance out of the window.

从我第一次看见那辆美国大车以来，那片废弃的空地肯定已经变硬了很多，因为现在我看见车在凹凸不平的路面上行驶并没有什么困难。
The wasteground outside must have hardened significantly since the first occasion I had watched that large American car, for now I saw it coming across the uneven surface without undue difficulty.

车越来越近，然后跌跌撞撞地开上了我们窗户底下的水泥路。
It continued to come nearer, then bumped up on to the concrete beneath my window.

反光的挡风玻璃让我看不清车里，但我确定车里不只司机一个。
The glare on the windscreen prevented me from seeing clearly, but I received a distinct impression the driver was not alone.

车在住宅区这兜了一下，然后开出了我的视线。
The car moved around the apartment block and out of my vision.

一定是在那个时候，当我有些困惑地看着小木屋时，我看见了那个幻象。
It must have been just then that it happened, just as I was gazing towards the cottage in a somewhat confused state of mind.

没有任何明显的征兆，那个毛骨悚然的画面就突然闯进我的脑海。
With no apparent provocation, that chilling image intruded into my thoughts, and I came away from the window with a troubled feeling.

我不安地从窗户边走开，继续做我的家务，努力把那个画面赶出脑海，但过了好几分钟，我才觉得摆脱掉了它，思绪回到再次出现的白色大车上。
I returned to my housework, trying to put the picture out of my mind, but it was some minutes before I felt sufficiently rid of it to give consideration to the reappearance of the large white car.

大约一个小时以后我看见一个人穿过空地朝木屋走去。
It was an hour or so later I saw the figure walking across the wasteground towards the cottage.

我遮起眼睛好看得更清楚些；是个女人——瘦瘦的——慢慢地、小心翼翼地走着。
I shaded my eyes to see more clearly; it was a woman — a thin figure — and she walked with a slow deliberate step.

她在小屋外停了一会儿，然后消失在斜斜的屋顶后面。
The figure paused outside the cottage for some time, then disappeared behind the sloping roof.

我一直盯着那里，但她没有再出现；显然她进去了。
I continued to watch, but she did not re-emerge; to all appearances, the woman had gone inside.

我在窗口站了一会儿，不知道该怎么办。
For several moments, I remained at the window, unsure what to do.

最后，我穿上木屐，走出公寓。
Then finally, I put on some sandals and left the apartment.

外面正是一天中最热的时候，穿过干巴巴的空地的那段不长的路却似乎永远也走不完。
Outside, the day was at its hottest, and the journey across those few dried acres seemed to take an eternity.

当我终于走到小屋时，我累得忘了我来干什么。
Indeed, the walk to the cottage tired me so much that when I arrived I had almost forgotten my original purpose.

这时，我听见屋里的说话声，有点吓了一跳。
It was with a kind of shock, then, that I heard voices from within the cottage.

一个声音是万里子的；另一个声音我不认识。
One of the voices was Mariko's; the other I did not recognize.

我走近门口，但听不清楚她们在说什么。
I stepped closer to the entrance, but could make out no words.

我在那里站了站，拿不准该怎么办。
For several moments I remained there, not sure what I should do.

最后我打开门叫了起来。
Then I slid open the entrance and called out.

说话声停止了。
The voices stopped.

我等了一下，然后走了进去。
I waited another moment, then stepped inside.

# 第二部 · 第十章 | PART TWO · Chapter Ten

从亮晃晃的外头进来，小屋里似乎又冷又暗。
After the brightness of the day outside, the interior of the cottage seemed cool and dark.

阳光从各处狭窄的缝隙里强烈地照射进来，在榻榻米上投下一个个小光斑。
Here and there, the sun came in sharply through narrow gaps, lighting up small patches on the tatami.

木头的潮味还跟以前一样重。
The odour of damp wood seemed as strong as ever.

过了一两秒钟我的眼睛才适应过来。
It took a second or two for my eyes to adjust.

一位老妇人坐在榻榻米上，万里子坐在她面前。
There was an old woman sitting on the tatami, Mariko in front of her.

老妇人转过来看我时很小心地摆头，像是怕伤着脖子。
In turning to face me, the old woman moved her head with caution as if in fear of hurting her neck.

她的脸瘦瘦的，而且粉笔般苍白，开始时令我有点不安。
Her face was thin, and had a chalky paleness about it which at first quite unnerved me.

她看上去七十岁上下，虽说她脆弱的脖子和肩膀可能是因为上了年纪，也可能是因为身体不好。
She looked to be around seventy or so, though the frailness of her neck and shoulders could have derived from ill-health as much as from age.

她穿着一般在葬礼上才穿的暗黑色和服，眼睛有点凹，面无表情地看着我。
Her kimono was of a dark sombre colour, the kind normally worn in mourning. Her eyes were slightly hooded and watched me with no apparent emotion.

“你好，”她终于开口说道。
“How do you do,” she said, eventually.

我微微欠了欠身，也说了句“您好”。
I bowed slightly and returned some greeting.

我们尴尬地对视了一两秒钟。
For a second or two, we looked at each other awkwardly.

“你是邻居？”老妇人问。
“Are you a neighbour?” the old woman asked.

她说话是一个字、一个字慢慢地吐出来。
She had a slow way of speaking her words.

“是的，”我说，“一个朋友。”
“Yes,” I said. “A friend.”

她又看了我一会儿，然后问：“你知道主人上哪儿去了吗？
She continued to look at me for a moment, then asked: “Have you any idea where the occupant has gone?

她把孩子一个人扔下了。”
She's left the child here on her own.”

小女孩换了位置，和陌生人并排坐着。
The little girl had shifted her position so that she was sitting alongside the stranger.

听到老妇人问的问题，万里子目不转睛地看着我。
At the old woman's question, Mariko looked at me intently.

“不，我不知道，”我说。
“No, I've no idea,” I said.

“真奇怪，”妇人说。
“It's odd,” said the woman.

“孩子好像也不知道。
“The child doesn't seem to know either.

她会去哪儿了呢？
I wonder where she could be.

我不能待很久。”
I cannot stay long.”

我们又对视了一会儿。
We gazed at each other for a few moments more.

“您从远处来的吗？”
“Have you come far?”

我问。
I asked.

“相当远。
“Quite far.

请原谅我的服装。
Please excuse my clothes.

我刚参加了一个葬礼。”
I've just been attending a funeral.”

“我知道了。”
“I see.”

我又鞠了一躬。
I bowed again.

“伤感的场合，”老妇人说道，出神地慢慢点起头来。
“A sorrowful occasion,” the old woman said, nodding slowly to herself.

“我父亲以前的一个同事。
“A former colleague of my father.

家父身体虚弱，不能出门，让我代为致意。
My father is too ill to leave the house.

是个伤感的场合。”
He sent me to pay his respects.

她环顾了一下小屋的内部，摆头时同样是很小心。
It was a sorrowful occasion.”

“你不知道她去哪儿了？”
She passed her gaze around the inside of the cottage, moving her head with the same carefulness.

她又问了一遍。
“You have no idea where she is?” she asked again.

“是的，很遗憾我不清楚。”
“No, I'm afraid not.”

“我不能等太久。
“I cannot wait long.

家父会担心的。”
My father will be getting anxious.”

“有没有什么话我可以代为转达？”
“Is there perhaps some message I could pass on?”

我问。
I asked.

老妇人没有马上回答。
The old woman did not answer for a while.

过了一会儿，她说：“也许你可以告诉她我来找过她，向她问好。
Then she said: “You could perhaps tell her I came here and was asking after her.

我是她的亲戚。
I am a relative.

我叫川田安子。”
My name is Yasuko Kawada.”

“安子女士？”
“Yasuko-San?”

我努力掩饰我的惊讶。
I did my best to conceal my surprise.

“您是安子女士，佐知子的表姐？”
“You're Yasuko-San, Sachiko's cousin?”

老妇人鞠了一躬，鞠躬时肩膀微微颤抖。
The old woman bowed, and as she did so her shoulders trembled slightly.

“请告诉她我来找过她，向她问好。
“If you would tell her I was here and that I was asking after her.

你不知道她去哪儿了？”
You have no idea where she could be?”

我再次否认知道任何消息。
Again, I denied any knowledge.

妇人又一次出神地点起头来。
The woman began nodding to herself once more.

“如今的长崎大不一样了，”她说。
“Nagasaki is very different now,” she said.

“今天下午我都认不出来了。”
“This afternoon, I could hardly recognize it.”

“是，”我说。
“Yes,” I said.

“我想是变了很多。
“I suppose it's greatly changed.

可是您不住在长崎吗？”
But do you not live in Nagasaki?”

“我们已经在长崎住了好多年了。
“We've lived in Nagasaki now for many years.

正如你说的，长崎变了很多。
It's greatly changed, as you say.

出现了很多新楼，还有新的街道。
New buildings have appeared, even new streets.

我上一次到城里来一定是在春天的时候。
It must have been in the spring, the last time I came out into the town.

可即便在这段时间里也盖起了新楼。
And even since then, new buildings have appeared.

我肯定春天的时候是没有那些楼的。
I'm certain they were not there in the spring.

事实上，我想那次我也是来参加一个葬礼。
In fact, on that occasion too, I believe I was attending a funeral.

没错，山下先生的丧礼。
Yes, it was Yamashita-San's funeral.

不知为何，春天的葬礼似乎更加伤感。
A funeral in the spring seems all the sadder somehow.

你说你是邻居？
You are a neighbour, you say?

很高兴认识你。”
Then I'm very pleased to make your acquaintance.”

她的脸抖动了一下，我看见她在微笑；她的眼睛眯得细细的，嘴角向下弯，而不是向上。
Her face trembled and I saw she was smiling; her eyes had become very thin, and her mouth was curving downwards instead of up.

站在玄关我觉得不舒服，但又不敢走到榻榻米上去。
I felt uncomfortable standing in the entryway, but did not feel free to step up to the tatami.

“很高兴见到您，”我说。
“I'm very pleased to meet you,” I said.

“佐知子常提起您。”
“Sachiko often mentions you.”

“她提起我？”
“She mentions me?”

妇人似乎回味了一下这句话。
The woman seemed to consider this for a moment.

“我们在等着她搬来和我们住。
“We were expecting her to come and live with us.

跟家父和我。
With my father and myself.

也许她跟你说了。”
Perhaps she told you as much.”

“是的，她说过。”
“Yes, she did.”

“我们三个星期前就开始等。
“We were expecting her three weeks ago.

可她一直没来。”
But she has not yet come.”

“三个星期前？
“Three weeks ago?

这个嘛，我想这里面一定有什么误会。
Well, I suppose there must have been some misunderstanding.

我知道她一直在准备搬家。”
I know she's preparing to move any day.”

老妇人再次环顾了一下小屋。
The old woman's eyes passed around the cottage once more.

“真遗憾她不在家，”她说。
“A pity she isn't here,” she said.

“不过如果你是她的邻居，那我很高兴认识你。”
“But if you are her neighbour, then I'm very glad to have made your acquaintance.”

她再次鞠了一躬，然后一直盯着我看。
She bowed to me again, then went on gazing at me.

“也许你能替我传个话给她，”她说。
“Perhaps you will pass a message to her,” she said.

“啊，当然可以。”
“Why, certainly.”

妇人沉默了一会儿才开口说道：“我们发生了小小的争执，她和我。
The woman remained silent for some time.

也许她告诉过你。
Finally, she said: “We had a slight disagreement, she and I. Perhaps she even told you about it.

只不过是个小误会，没什么。
Nothing more than a misunderstanding, that was all.

结果第二天我惊讶地发现她已经收拾好东西，离开了。
I was very surprised to find she had packed and left the next day.

我确实很惊讶。
I was very surprised indeed.

我无意冒犯她。
I didn't mean to offend her.

家父说是我的错。”
My father says I am to blame.”

她停顿了一下。
She paused for a moment.

“我无意冒犯她，”她重复道。
“I didn't mean to offend her,” she repeated.

我从没想到过佐知子的伯父和表姐不知道她有个美国朋友。
It had never occurred to me before that Sachiko's uncle and cousin would know nothing of the existence of her American friend.

我再次鞠了一躬，不知道回答什么。
I bowed again, at a loss for a suitable reply.

“我承认她走了以后我很想她，”老妇人接着说。
“I've missed her since she left, I confess it,” the old woman continued.

“我也想念万里子。
“I've missed Mariko-San also.

我很喜欢她们的陪伴，我不应该发脾气、说了那些话。”
I enjoyed their company and it was foolish of me to have lost my temper and said the things I did.”

她再次停下，脸转向万里子，再转回来。
She paused again, turned her face towards Mariko, then back to me.

“家父虽然方式不同，但也想念她们。
“My father, in his own way, misses them also.

你瞧，他听得出来。
He can hear, you see.

他能听到房子里安静了好多。
He can hear how much quieter the house is.

一天早上我发现他醒着，他对我说房子安静得让他想到坟墓。
The other morning I found him awake and he said it reminded him of a tomb.

就像个坟墓，他说。
Just like a tomb, he said.

她们搬回去对家父大有好处。
It would do my father much good to have them back again.

也许佐知子愿意为了家父而搬回去。”
Perhaps she will come back for his sake.”

“我一定把您的感受传达给佐知子，”我说。
“I'll certainly convey your feelings to Sachiko-San,” I said.

“也是为了她自己，”老妇人说。
“For her own sake too,” the old woman said.

“毕竟一个女人不能没有一个男人来引导她。
“After all, it isn't good that a woman should be without a man to guide her.

否则只会带来不良后果。
Only harm can come of such a situation.

家父虽然有病在身，但没有生命危险。
My father is ill, but his life is in no danger.

她现在该回来了，不为别的也该为了她自己。”
She should come back now, for her own wellbeing if for nothing else.”

老妇人开始解开放在身旁的方巾。
The old woman began to untie a kerchief lying at her side.

“事实上，我把它们带来了，”她说。
“In fact, I brought these with me,” she said.

“没什么，只是我自己织的几件开襟毛衣。
“Just some cardigans I knitted, nothing more.

不过是好羊毛。
But it's fine wool.

我本打算她们回去以后给她们，但我今天带来了。
I'd intended to offer them when she came back, but I brought them with me today.

起初我织了一件要给万里子，后来我想也给她母亲织一件好了。”
I first knitted one for Mariko, then I thought I may as well knit another for her mother.”

她举起一件毛衣，然后看看小女孩。
She held up a cardigan, then looked towards the little girl.

她笑的时候嘴角再次向下弯。
Her mouth curved downwards again as she smiled.

“真漂亮，”我说。
“They look splendid,” I said.

“您一定花了很多时间。”
“It must have taken you a long time.”

“是好羊毛，”妇人重复道。
“It's fine wool,” the woman said again.

她把毛衣重新包起来，然后把方巾小心地系好。
She wrapped the kerchief back around the cardigans, then tied it carefully.

“现在我得回去了。
“Now I must return.

家父要担心了。”
My father will be anxious.”

老妇人站起来，走下榻榻米。
She got to her feet and came down off the tatami.

我帮她穿好木屐。
I assisted her in putting on her wooden sandals.

万里子也来到榻榻米边，老妇人轻轻地碰了碰孩子的头顶。
Mariko had come to the edge of the tatami and the old woman lightly touched the top of the child's head.

她说：“万里子，要记住把我对你说的话告诉你妈妈。
“Remember then, Mariko-San,” she said, “tell your mother what I told you.

还有，你不用担心你的小猫。
And you're not to worry about your kittens.

房子里有足够的地方给它们住。”
There's plenty of room in the house for them all.”

“我们很快就会回去，”万里子说。
“We'll come soon,” Mariko said.

“我会告诉妈妈的。”
“I'll tell Mother.”

妇人又笑了笑。
The woman smiled again.

然后她转向我，鞠了一躬。
Then she turned to me and bowed.

“很高兴认识你。
“I'm glad to have made your acquaintance.

我不能再久留了。
I cannot stay any longer.

你瞧，家父身体不好。”
My father, you see, is unwell.”

“哦，是你啊，悦子，”佐知子说。那天晚上我又回到她的小屋。
“Oh, it's you, Etsuko,” Sachiko said, when I returned to her cottage that evening.

然后她笑了一声，说：“别那么吃惊的样子。
Then she laughed and said: “Don't look so surprised.

你早知道我不会永远住在这里，不是吗？”
You didn't expect me to stay here for ever, did you?”

衣服、毯子和无数其他的东西堆得榻榻米上到处都是。
Articles of clothing, blankets, numerous other items lay scattered over the tatami.

我做了恰当的回答，然后找了个不碍事的地方坐下。
I made some appropriate reply and sat down where I would not be in the way.

我注意到身旁的地板上有两件看起来很漂亮的和服，我从没见佐知子穿过。
On the floor beside me, I noticed two splendid-looking kimonos I had never seen Sachiko wear.

我还看见了——地板中央，一个硬纸盒里——她那套精美的浅白色陶瓷茶具。
I saw also — in the middle of the floor, packed into a cardboard box — her delicate teaset of pale white china.

佐知子已经把中间的几扇拉门都打开了，让最后的日光照进屋来；然而，昏暗还是在迅速地袭来，从走廊射进来的余晖基本上照不到万里子坐着的那个远远的角落。
Sachiko had opened wide the central partitions to allow the last of the daylight to come into the cottage; despite that, a dimness was fast setting in, and the sunset coming across the veranda barely reached the far corner where Mariko sat watching her mother quietly.

她静静地看着她妈妈。旁边，两只小猫在嬉戏打闹；小女孩怀里抱着另外一只。
Near her, two of the kittens were fighting playfully; the little girl was holding a third kitten in her arms.

“我想万里子告诉你了，”我对佐知子说。
“I expect Mariko told you,” I said to Sachiko.

“早些时候有人来找你。
“There was a visitor for you earlier.

你表姐来过这里。”
Your cousin was here.”

“是。
“Yes.

万里子告诉我了。”
Mariko told me.”

佐知子继续收拾她的箱子。
Sachiko continued to pack her trunk.

“你明天早上离开？”
“You're leaving in the morning?”

“对，”她有点不耐烦地说。
“Yes,” she said, with a touch of impatience.

然后她叹了一口气，抬头看我。
Then she gave a sigh and looked up at me.

“对，悦子，我们明天早上离开。”
“Yes, Etsuko, we're leaving in the morning.”

她叠了件什么放进箱子的角落里。
She folded something away into a corner of her trunk.

“你的行李这么多，”我终于说道。
“You have so much luggage,” I said, eventually.

“要怎么全都搬走呢？”
“How will you ever carry it all?”

佐知子没有马上回答。
For a little while, Sachiko did not answer.

过了一会儿，她一边收拾，一边说：“你是知道的，悦子。
Then, continuing to pack, she said: “You know perfectly well, Etsuko.

我们有车。”
We'll put it in the car.”

我不说话了。
I remained silent.

佐知子深深地叹了口气，从房间那头朝我坐的地方看了一眼。
She took a deep breath, and glanced across the room to where I was sitting.

“对，我们要离开长崎了，悦子。
“Yes, we're leaving Nagasaki, Etsuko.

我向你保证，我本打算全都收拾好了以后就去道别。
I assure you, I had every intention of coming to say goodbye once all the packing was finished.

我不会不跟你道谢就离开的，你对我那么好。
I wouldn't have left without thanking you, you've been most kind.

对了，至于借的钱，我会通过邮局还给你。
Incidentally, as regards the loan, it will be returned to you through the post.

这点请不用担心。”
Please don't worry about that.”

她又开始收拾。
She began to pack again.

“你们要搬去哪里？”
“Where is it you're going?”

我问。
I asked.

“神户。
“Kobe.

现在所有的事情都定下来了，不会再改变了。”
Everything's decided now, once and for all.”

“神户？”
“Kobe?”

“对，悦子，神户。
“Yes, Etsuko, Kobe.

然后从那里去美国。
Then after that, America.

弗兰克已经把所有的事情都安排好了。
Frank has arranged everything.

你不替我高兴吗？”
Aren't you pleased for me?”

她很快扬了扬嘴角，又转开了。
She smiled quickly, then turned away again.

我还是盯着她。
I went on watching her.

万里子也一直看着她。
Mariko, too, was watching her.

她怀里的小猫挣扎着想去和榻榻米上的小猫一起玩，可是小女孩紧紧地抱住它。
The kitten in her arms was struggling to join its companions on the tatami, but the little girl continued to hold it firmly.

她身边，屋子的角上，我看见了她在抓阄摊上赢的那只装菜的盒子；看来万里子已经把盒子改造成了小猫们的家。
Beside her, in the corner of the room, I saw the vegetable box she had won at the kujibiki stall; Mariko, it appeared, had converted the box into a house for her kittens.

“对了，悦子，那边那堆”——佐知子指了指——“那些东西我带不走了。
“Incidentally, Etsuko, that pile over there” — Sachiko pointed — “those items I'll just have to leave behind.

我没想到东西这么多。
I had no idea there was so much.

那里有些质量还不错。
Some of it is of decent enough quality.

你要的话就请拿去用吧。
Please make use of it if you wish.

我当然没有冒犯的意思。
I don't mean any offence, of course.

仅仅是因为有些东西质量挺好。”
It's merely that some of it is of good quality.”

“可是你伯父怎么办？”
“But what about your uncle?”

我说。
I said.

“还有你的表姐？”
“And your cousin?”

“我伯父？”
“My uncle?”

她耸耸肩。
She gave a shrug.

“很谢谢他请我去他家住。
“It was kind of him to have invited me into his household.

可是恐怕现在我另有打算。
But I'm afraid I've made other plans now.

你不知道，悦子，离开这个地方我是多么如释重负。
You have no idea, Etsuko, how relieved I'll be to leave this place.

我相信我再也不会见到这种破地方了。”
I trust I've seen the last of such squalor.”

她又朝我看了一眼，笑了。
Then she looked across to me once more and laughed.

“我知道你在想什么。
“I can see exactly what you're thinking.

我向你保证，悦子，你想错了。
I can assure you, Etsuko, you're quite wrong.

这次他不会再让我失望了。
He won't let me down this time.

明天一大早他就会开车过来。
He'll be here with the car, first thing tomorrow morning.

你不替我高兴吗？”
Aren't you pleased for me?”

佐知子看了看满地的行李，叹了口气。
Sachiko looked around at the luggage strewn over the floor and sighed.

然后她跨过一堆衣服，在装茶具的盒子边跪下，开始往里面装一卷卷的羊毛。
Then stepping over a pile of clothes, she knelt beside the box containing the teaset, and began filling it with rolls of wool.

“你决定了吗？”
“Have you decided yet?”

万里子突然问。
Mariko said, suddenly.

“现在没时间谈这个，万里子，”她妈妈说。
“We can't talk about it now, Mariko,” said her mother.

“我这会儿很忙。”
“I'm busy now.”

“可是你说过我可以留着它们。
“But you said I could keep them.

你不记得了吗？”
Don't you remember?”

佐知子轻轻摇了摇纸箱；瓷器仍然嘎嘎作响。
Sachiko shook the cardboard box gently; the china still rattled.

她看了看周围，找到一块布，把它撕成碎布条。
She looked around, found a piece of cloth and began tearing it into strips.

“你说过我可以留着它们，”万里子重复道。
“You said I could keep them,” Mariko said again.

“万里子，请你稍微考虑一下眼前的情况。
“Mariko, please consider the situation for a moment.

我们怎么可能带上那些畜牲呢？”
How can we possibly take all those creatures with us?”

“可是你说过我可以留着它们。”
“But you said I could keep them.”

佐知子叹了口气，有一会儿像是在想事情。
Sachiko sighed, and for a moment seemed to be considering something.

她低头看看茶具，手里捏着碎布条。
She looked down at the teaset, the pieces of cloth held in her hands.

“你说过的，妈妈，”万里子说。
“You did, Mother,” Mariko said.

“你不记得了吗？
“Don't you remember?

你说过我可以留着的。”
You said I could.”

佐知子抬头看看她女儿，然后又看看那些小猫。
Sachiko looked up at her daughter, then over towards the kittens.

“如今情况不同了，”她疲惫地说。
“Things are different now,” she said, tiredly.

这时，一股怒气划过她的脸，她一把扔掉那些布条。
Then a wave of irritation crossed her face, and she flung down the pieces of cloth.

“万里子，你老想着那些畜牲干吗？
“Mariko, how can you think so much of these creatures?

我们怎么可能带上它们？
How can we possibly take them with us?

不行，我们只能把它们留在这里。”
No, we'll just have to leave them here.”

“可是你说过我可以留着它们。”
“But you said I could keep them.”

佐知子看了她女儿一会儿。
Sachiko glared at her daughter for a moment.

“你就不能考虑一下其他事情吗？”她说，声音变得很低。
“Can't you think of anything else?” she said, lowering her voice almost to a whisper.

“你难道还小，看不出除了这些肮脏的小东西以外，还有其他更重要的事情？你得懂事一点了。
“Aren't you old enough yet to see there are other things besides these filthy little animals? You'll just have to grow up a little.

你不能总是对这些东西恋恋不舍。这些只是……只是动物，你看不出来吗？
You simply can't have these sentimental attachments for ever. These are just … just animals don't you see?

你不明白这个吗，孩子？
Don't you understand that, child?

你不明白吗？”
Don't you understand?”

万里子也瞪着她妈妈。
Mariko stared back at her mother.

“你喜欢的话，万里子，”我插进去说，“我可以时不时地来喂它们。
“If you like, Mariko-San,” I put in, “I could come and feed them from time to time.

它们最后都会找到家的。
Then eventually they'll find homes for themselves.

不用担心。”
There's no need to worry.”

小女孩转向我说：“妈妈说过我可以留着小猫。”
The little girl turned to me. “Mother said I could keep the kittens,” she said.

“别再孩子气了，”佐知子说。
“Stop being so childish,” said Sachiko, sharply.

“你只是在故意捣乱，跟平时一样。
“You're being deliberately awkward, as you always are.

这些肮脏的小畜牲有什么大不了的呢？”
What does it matter about the dirty little creatures?”

她站起来，走向万里子的角落。
She rose to her feet and went over to Mariko's corner.

榻榻米上的小猫急忙后退；佐知子低头看看它们，然后深吸了一口气。
The kittens on the tatami scurried back; Sachiko looked down at them, then took a deep breath.

她相当镇定地把蔬菜盒子侧翻过来——这样，铁丝网的滑板就朝上了——弯下腰，把小猫一只只地扔进盒子里。
Quite calmly, she turned the vegetable box on to its side — so that the wire-grid panels were facing upwards — reached down and dropped the kittens one by one into the box.

然后她转向她女儿；万里子紧紧抱住剩下的一只小猫。
She then turned to her daughter; Mariko was still clutching the remaining kitten.

“把它给我，”佐知子说。
“Give me that,” said Sachiko.

万里子抱着小猫不放。
Mariko continued to hold the kitten.

佐知子走上前去，伸出一只手。
Sachiko stepped forward and put out her hand.

小女孩转过来看我。
The little girl turned and looked at me.

“这只是小胖，”她说。
“This is Atsu,” she said.

“你想不想看看它，悦子阿姨？
“Do you want to see him, Etsuko-San?

这只是小胖。”
This is Atsu.”

“把那东西给我，万里子，”佐知子说。
“Give me that creature, Mariko,” Sachiko said.

“你不明白吗，那只是一只动物。
“Don't you understand, it's just an animal.

你怎么就不明白呢，万里子？
Why can't you understand that, Mariko?

你真的还小吗？
Are you really too young?

那不是你的小宝宝，只是一只动物，就像老鼠啊、蛇啊。
It's not your little baby, it's just an animal, just like a rat or a snake.

现在把它给我。”
Now give it to me.”

万里子抬头瞪着她妈妈，然后慢慢地把小猫放下。小猫落在了她面前的榻榻米上，挣扎着被佐知子抓了起来。
Mariko stared up at her mother. Then slowly, she lowered the kitten and let it drop to the tatami in front of her.

佐知子把它也扔进了蔬菜盒子里，然后“啪”地关上铁丝网。
The kitten struggled as Sachiko lifted it off the ground. She dropped it into the vegetable box and slid shut the wire grid.

“待在这里，”她对女儿说，然后拎起盒子。
“Stay here,” she said to her daughter, and picked the box up in her arms.

她经过我身边时，对我说：“真是太傻了，它们只是几只动物，有什么大不了的？”
Then as she came past, she said to me: “It's so stupid, these are just animals, what does it matter?”

万里子站了起来，像是要跟着她妈妈。
Mariko rose to her feet and seemed about to follow her mother.

佐知子在玄关那里回过头来说：“照我说的做。
Sachiko turned at the entryway and said: “Do as you're told.

待在这里。”
Stay here.”

有一会儿，万里子站在榻榻米的边上不动，看着她妈妈消失在门口。
For a few moments, Mariko remained standing at the edge of the tatami, looking at the doorway where her mother had disappeared.

“在这里等你妈妈，万里子，”我对她说。
“Wait for your mother here, Mariko-San,” I said to her.

小女孩转过来看了我一眼，然后就跑出去了。
The little girl turned and looked at me. Then the next moment, she had gone.

起先，我没有动。
For a minute or two, I did not move.

一两分钟以后，我站起来、穿上木屐。
Then eventually I got to my feet and put on my sandals.

在门口，我看见佐知子到河边去了，蔬菜盒子放在她脚边；她似乎没有注意到她女儿站在她身后几码的地方，就在陡坡上面。
From the doorway, I could see Sachiko down by the water, the vegetable box beside her feet; she appeared not to have noticed her daughter standing several yards behind her, just at the point where the ground began to slope down steeply.

我离开小屋，朝万里子站着的地方走去。
I left the cottage and made my way to where Mariko was standing.

“我们回到屋里去吧，万里子，”我轻声说。
“Let's go back to the house, Mariko-San,” I said, gently.

小女孩仍旧看着她妈妈，面无表情。
The little girl's eyes remained on her mother, her face devoid of any expression.

在我们下方，佐知子在河边小心翼翼地蹲下，把盒子拉近了一点。
Down in front of us, Sachiko knelt cautiously on the bank, then moved the box a little nearer.

“我们进去吧，万里子，”我又说了一遍，可小女孩还是没有理我。
“Let's go inside, Mariko,” I said again, but the little girl continued to ignore me.

我离开她，走下泥泞的斜坡，朝佐知子蹲着的地方走去。
I left her and walked down the muddy slope to where Sachiko was kneeling.

夕阳透过树枝照在对岸，河边的芦苇在我们周围的泥地上投下长长的影子。
The sunset was coming through the trees on the opposite bank, and the reeds that grew along the water's edge cast long shadows on the muddy ground around us.

虽然佐知子找了块有草的地方蹲下，但那里也都是泥。
Sachiko had found some grass to kneel on, but that too was thick with mud.

“我们不能放了它们吗？”
“Can't we let them loose?”

我静静地说。
I said, quietly.

“谁知道呢。
“You never know.

也许有人要它们。”
Someone may want them.”

佐知子低头看着铁丝网里的小猫。她“啪”地把盒子打开，取出一只小猫，然后又把盒子关上。
Sachiko was gazing down into the vegetable box through the wire gauze. She slid open a panel, brought out a kitten and shut the box again.

她双手抓住小猫，看了一会儿，然后抬头看了我一眼，说：“这只是一只动物，悦子。
She held the kitten in both hands, looked at it for a few seconds, then glanced up at me. “It's just an animal, Etsuko,” she said.

就只是一只动物。”
“That's all it is.”

她把小猫放进水里、按住。
She put the kitten into the water and held it there.

她保持这个姿势，眼睛盯着水里，双手都在水下。
She remained like that for some moments, staring into the water, both hands beneath the surface.

她穿着一件日常的夏季和服，两只袖子的袖口都碰到了水。
She was wearing a casual summer kimono, and the corners of each sleeve touched the water.

突然佐知子第一次转过头去看了一眼她女儿，手依旧放在水里。
Then for the first time, without taking her hands from the water, Sachiko threw a glance over her shoulder towards her daughter.

我本能地顺着她的视线看去，一刹那间，我们俩都回头看着万里子。
Instinctively, I followed her glance, and for one brief moment the two of us were both staring back up at Mariko.

小女孩站在斜坡顶上，依旧面无表情地看着。
The little girl was standing at the top of the slope, watching with the same blank expression.

看见她母亲的脸转向她，她微微地把头转开；然后一动不动，双手背在身后。
On seeing her mother's face turn to her, she moved her head very slightly; then she remained quite still, her hands behind her back.

佐知子把手从水里拿出来，看着仍旧抓在手里的小猫。
Sachiko brought her hands out of the water and stared at the kitten she was still holding.

她把小猫拿得近一点，水流下她的手腕和手臂。
She brought it closer to her face and the water ran down her wrists and arms.

“还活着，”她疲倦地说。
“It's still alive,” she said, tiredly.

然后她转向我说：“看看这水，悦子。
Then she turned to me and said: “Look at this water, Etsuko.

太脏了。”
It's so dirty.”

她厌恶地把湿漉漉的小猫扔回盒子里，关上盖子。
With an air of disgust, she dropped the soaked kitten back into the box and shut it.

“这些小东西在顽抗，”她嘟囔道，举起手腕，给我看上面的抓痕。
“How these things struggle,” she muttered, and held up her wrists to show me the scratch-marks.

不知怎么的，佐知子的头发也湿了；一滴水，然后又一滴从垂到她脸上的一小撮头发上流下来。
Somehow, Sachiko's hair had also become wet; one drop, then another fell from a thin strand which hung down one side of her face.

佐知子换了个姿势，把蔬菜盒子推向河边；盒子滑了下来，掉进水里。
Sachiko adjusted her position then pushed the vegetable box over the edge of the bank; the box rolled and landed in the water.

佐知子伸出手去抓住盒子，不让它漂走。
To prevent it floating, Sachiko leaned forward and held it down.

河水几乎没到了铁丝网的半腰。
The water came almost halfway up the wire-grid.

她仍旧抓着盒子不放，最后双手把盒子一推。
She continued to hold down the box, then finally pushed it with both hands.

盒子漂进水里，冒着泡泡，沉得更下去了。
The box floated a little way into the river, bobbed and sank further.

佐知子站了起来，我们俩一起注视着盒子。
Sachiko got to her feet, and we both of us watched the box.

盒子漂着，然后一股水流冲来，盒子加速往下游漂去。
It continued to float, then caught in the current and began moving more swiftly downstream.

这时什么东西从我眼前闪过，我猛地转头。
Some movement caught my eye and made me turn.

万里子跑下河边，跑到几码远处的一块突进水里的浅滩上。
Mariko had run several yards down the river's edge, to a spot where the bank jutted out into the water.

她站在那里看着漂流的盒子，脸上依旧没有表情。
She stood there watching the box float on, her face still expressionless.

盒子被芦苇缠住，松开了又继续前进。
The box caught in some reeds, freed itself and continued its journey.

万里子又跑了起来。
Mariko began to run again.

她沿着河岸跑了一段，然后又停下来，看着盒子。
She ran on some distance along the bank, then stopped again to watch the box.

这时，盒子只剩一个小角露在水面上了。
By this time, only a small corner was visible above the surface.

“这水真脏，”佐知子说。
“This water's so dirty,” Sachiko said.

她甩了甩手上的水，把和服两边的袖口一一拧干，然后掸掉膝盖上的泥。
She had been shaking the water off her hands. She squeezed in turn the sleeve-ends of her kimono, then brushed the mud from her knees.

“我们进去吧，悦子。
“Let's go back inside, Etsuko.

这里的虫子越来越让人受不了了。”
The insects here are becoming intolerable.”

“我们不去找万里子吗？
“Shouldn't we go and get Mariko?

天很快就黑了。”
It will be dark soon.”

佐知子转过去叫她女儿的名字。
Sachiko turned and called her daughter's name.

万里子已经跑到五十码开外了，眼睛仍然看着河水，似乎没有听见在叫她。
Mariko was now fifty yards or so away, still looking at the water. She did not seem to hear and Sachiko gave a shrug.

佐知子耸耸肩，说：“她一会儿会回来的。现在我得趁天没黑赶紧把东西收拾完。”
“She'll come back in time,” she said. “Now, I must finish packing before the light goes completely.”

说完爬上斜坡，朝小屋走去。
She began to walk up the slope towards the cottage.

佐知子点亮灯笼，挂在一处低木梁上。
Sachiko lit the lantern and hung it from a low wooden beam.

“别担心，悦子，”她说。
“Don't worry yourself, Etsuko,” she said.

“她很快就会回来了。”
“She'll be back soon enough.”

她走过一地板的各种各样的东西，跟刚才一样在敞开的拉门前坐下。
She made her way through the various items strewn over the tatami, and seated herself, as before, in front of the open partitions.

身后，夕阳已经褪去，天色昏暗。
Behind her, the sky had become pale and faded.

佐知子接着收拾东西。
She began packing again.

我在房间的另一头坐下，看着她。
I sat down at the opposite side of the room and watched her.

“你现在怎么打算的？”
“What are your plans now?”

我问。
I asked.

“到了神户以后要干什么？”
“What will you do once you arrive in Kobe?”

“全都安排好了，悦子，”她回答说，没有抬头。
“Everything's been arranged, Etsuko,” she said, without looking up.

“不用担心。
“There's no need to worry.

弗兰克都安排好了。”
Frank has seen to everything.”

“可为什么是神户？”
“But why Kobe?”

“他有朋友在那里。
“He has friends there.

在美军基地。
At the American base.

他得到了一份货船上的工作，他很快就能回美国了。
He's been entrusted with a job on a cargo ship, and he'll be in America in a very short time.

然后他会寄给我们所需的钱，我们就去美国找他。
Then he'll send us the necessary amount of money, and we'll go and join him.

他都安排好了。”
He's seen to all the arrangements.”

“你是说，他要先你们离开日本？”
“You mean, he's leaving Japan without you?”

佐知子笑了一声。
Sachiko laughed.

“人要有耐心，悦子。
“One needs to be patient, Etsuko.

一旦他到了美国，他就能找到工作、寄钱来。
Once he arrives in America, he'll be able to work and send money.

这是目前最可行的方案。
It's by far the most sensible solution.

毕竟他回到美国后找工作会容易得多。
After all, it would be so much easier for him to find work once he's back in America.

我不介意多等一些时间。”
I don't mind waiting a little.”

“我知道了。”
“I see.”

“他都安排好了，悦子。
“He's seen to everything, Etsuko.

他在神户给我们找好了住的地方，他还安排好到时我们坐的船可以比一般价格低将近一半。”
He's found a place for us to stay in Kobe, and he's seen to it that we'll get on a ship at almost half the usual cost.”

说到这里，她叹了口气。
She gave a sigh.

“你不知道离开这个地方我有多高兴。”
“You have no idea how pleased I am to be leaving this place.”

佐知子又继续收拾东西。
Sachiko continued to pack.

屋外微弱的光线照在她的半张脸上，而她的手和袖子都在灯笼的亮光里。
The pale light from outside fell on one side of her face, but her hands and sleeves were caught in the glow from the lantern.

感觉很奇怪。
It was a strange effect.

“你在神户要等很久吗？”
“Do you expect to wait long in Kobe?”

我问。
I asked.

她耸耸肩。
She shrugged.

“我做好了耐心等待的准备，悦子。
“I'm prepared to be patient, Etsuko.

人要有耐心。”
One needs to be patient.”

光线很暗，我看不清楚她在叠什么；但似乎不好叠，她叠好又打开重新叠，反复了好几次。
I could not see in the dimness what it was she was folding; it seemed to be giving her some difficulty, for she opened and refolded it several times.

“不管怎样，悦子，”她接着说，“他若不是确确实实真心的，干吗要给自己找这个麻烦呢？
“In any case, Etsuko,” she went on, “why would he have gone to all this trouble if he wasn't absolutely sincere?

他干吗要特意为我做这些呢？
Why would he have gone to all this trouble on my behalf?

悦子，有时候你好像很怀疑。
Sometimes, Etsuko, you seem so doubting.

你应该为我高兴才是。
You should be happy for me.

事情总算开始好转了。”
Things are working out at last.”

“是，当然了。
“Yes, of course.

我很为你高兴。”
I'm very happy for you.”

“可说真的，悦子，他特意为我做了这些而你还怀疑他，这是不公平的。
“But really, Etsuko, it would be unfair to start doubting him after he's gone to all this trouble.

相当不公平。”
It would be quite unfair.”

“是。”
“Yes.”

“而且万里子在美国也会过得更好。
“And Mariko would be happier there.

美国更适合女孩子成长。
America is a far better place for a young girl to grow up.

在那里，她可以做各种各样的事。
Out there, she could do all kinds of things with her life.

她可以成为女商人。
She could become a business girl.

她可以进大学学画画，然后成为一个艺术家。
Or she could study painting at college and become an artist.

所有这些事情在美国要容易得多，悦子。
All these things are much easier in America, Etsuko.

日本不适合女孩子成长。
Japan is no place for a girl.

在这里她能有什么指望呢？”
What can she look forward to here?”

我没有回答。
I made no reply.

佐知子抬头看了我一眼，轻轻笑了笑。
Sachiko glanced up at me and gave a small laugh.

“笑一笑，悦子，”她说。
“Try and smile, Etsuko,” she said.

“事情最后会变好的。”
“Things will turn out well in the end.”

“是，我相信会的。”
“Yes, I'm sure they will.”

“当然会了。”
“Of course they will.”

“是。”
“Yes.”

佐知子又继续收拾了一分钟左右，她的手突然停下来，从房间那头朝我看过来。
For another minute or so, Sachiko continued with her packing.

脸上像我刚才描述的那样一半阴、一半亮。
Then her hands became still, and she gazed across the room towards me, her face caught in that strange mixture of light.

“我想你一定认为我是个傻瓜，”她静静地说。
“I suppose you think I'm a fool,” she said, quietly.

“是不是，悦子？”
“Don't you, Etsuko?”

我也看着她，有点吃惊。
I looked back at her, a little surprised.

“我知道我们可能永远见不到美国，”她说。
“I realize we may never see America,” she said.

“也知道即使见到了，有多少困难等着我们。
“And even if we did, I know how difficult things will be.

你以为我没想过这些吗？”
Did you think I never knew that?”

我没有回答，我们就这么对视着。
I gave no reply, and we went on staring at each other.

“可是那又怎么样？”佐知子说。
“But what of it?” said Sachiko.

“那又有什么关系呢？
“What difference does it make?

我为什么不应该去神户呢？
Why shouldn't I go to Kobe?

毕竟，悦子，我会损失什么呢？
After all, Etsuko, what do I have to lose?

我伯父的房子里没有什么可以给我的。
There's nothing for me at my uncle's house.

只有一些空房间，没别的了。
Just a few empty rooms, that's all.

我可以找一间坐着，然后慢慢变老。
I could sit there in a room and grow old.

除此之外什么都没有。
Other than that there'll be nothing.

只有空房间，没别的了。
Just empty rooms, that's all.

你是知道的，悦子。”
You know that yourself, Etsuko.”

“可万里子呢，”我说。
“But Mariko,” I said.

“万里子怎么办？”
“What about Mariko?”

“万里子？
“Mariko?

她会应付得过来的。
She'll manage well enough.

她得应付过来。”
She'll just have to.”

佐知子还是透过昏暗的灯光看着我，半张脸在阴影里。
Sachiko continued to gaze at me through the dimness, one side of her face in shadow.

她接着说：“你以为我认为自己是个好母亲？”
Then she said: “Do you think I imagine for one moment that I'm a good mother to her?”

我没有回答。
I remained silent.

突然，佐知子笑了起来。
Then suddenly, Sachiko laughed.

“我们干吗这样子说话？”她说道，双手又忙活了起来。
“Why are we talking like this?” she said, and her hands began to move busily once more.

“一切都会好的，我向你保证。
“Everything will turn out well, I assure you.

到了美国以后我会给你写信。
I'll write to you when I reach America.

也许，悦子，也许有一天你还能来看我们。带着你的孩子。”
Perhaps, Etsuko, you'll even come and visit us one day. You could bring your child with you.”

“是，没错。”
“Yes, indeed.”

“也许那个时候你已经孩子成群了。”
“Perhaps you'll have several children by then.”

“是，”我不自然地笑了笑。
“Yes,” I said, laughing awkwardly.

“谁知道呢。”
“You never know.”

佐知子叹了口气，举起双手。
Sachiko gave a sigh and lifted both hands into the air.

“要收拾的东西真多啊，”她咕哝道。
“There's so much to pack,” she murmured.

“有些东西只好不带了。”
“I'll just have to leave some of it behind.”

我坐在那里，看着她。几分钟以后，我终于开口说道：
I sat there for some moments, watching her.

“你愿意的话，我可以去找万里子。
“If you wish,” I said, eventually, “I could go and look for Mariko.

天很黑了。”
It's getting rather late.”

“你只会让自己受累，悦子。
“You'll only tire yourself, Etsuko.

我快收拾完了，到时她要是还没回来，我们一起出去找她。”
I'll finish packing and if she still hasn't come back we could go and look for her together.”

“没关系。
“It's all right.

我去找找她。
I'll see if I can find her.

天已经全黑了。”
It's nearly dark now.”

佐知子抬头看了一眼，耸耸肩，说：“你最好把灯笼带上，河边很滑。”
Sachiko glanced up, then shrugged. “Perhaps you'd best take the lantern with you,” she said. “It's quite slippery along the bank.”

我站起来，把灯笼从木梁上拿下来，朝门口走去。
I rose to my feet and took the lantern down from the beam.

阴影随着我的脚步掠过小屋。
The shadows moved across the cottage as I walked with it towards the doorway.

离开时，我回头看了一眼佐知子。
As I was leaving, I glanced back towards Sachiko.

我只看见她的剪影，坐在敞开的拉门前，身后的天空已经全黑了。
I could see only her silhouette, seated before the open partitions, the sky behind her turned almost to night.

我沿着河边走，蚊虫跟着我的灯笼。
Insects followed my lantern as I made my way along the river.

偶尔有虫子飞进灯笼里出不来，我只好停下来，拿稳灯笼，等虫子找到出来的路。
Occasionally, some creature would become trapped inside, and I would then have to stop and hold the lantern still until it had found its way out.

不久那座小木桥就出现在了我面前。
In time, the small wooden bridge appeared on the bank ahead of me.

走过木桥时，我在桥上停了一会儿，看着夜晚的天空。
While crossing it, I stopped for a moment to gaze at the evening sky.

我记得在桥上时，一股异样的宁静向我袭来。
As I recall, a strange sense of tranquillity came over me there on that bridge.

我倚在栏杆上站了几分钟，听着脚下河水的声音。
I stood there for some minutes, leaning over the rail, listening to the sounds of the river below me.

当我终于转身时，我看见了自己的影子，被灯光投在桥的木板条上。
When finally I turned, I saw my own shadow, cast by the lantern, thrown across the wooden slats of the bridge.

“你在这里做什么？”
“What are you doing here?”

我问。小女孩就在我面前，蜷缩在另一边的栏杆底下。
I asked, for the little girl was before me, sat crouched beneath the opposite rail.

我走上前去，好更清楚地看见灯笼底下的她。
I came forward until I could see her more clearly under my lantern.

她看着她的手掌，不发一语。
She was looking at her palms and said nothing.

“你是怎么了？”
“What's the matter with you?”

我说。
I said.

“你为什么这样子坐在这里？”
“Why are you sitting here like this?”

灯笼周围聚集了不少虫子。
The insects were clustering around the lantern.

我把灯笼拿到面前，放低，灯光把孩子的脸照得更亮了。
I put it down in front of me, and the child's face became more sharply illuminated.

过了好久，她才开口说道：“我不想走。
After a long silence, she said: “I don't want to go away.

明天我不想走。”
I don't want to go away tomorrow.”

我叹了口气。
I gave a sigh.

“你会喜欢的。
“But you'll like it.

每个人对新事物总是有点害怕。
Everyone's a little frightened of new things.

可你会喜欢那里的。”
You'll like it over there.”

“我不想走。
“I don't want to go away.

我不喜欢他。
And I don't like him.

他像头猪。”
He's like a Pig”

“你不能这么说话，”我生气地说。
“You're not to speak like that,” I said, angrily.

我们对视了一会儿，然后她又低头看着她的手。
We stared at each other for a moment, then she looked back down at her hands.

“你不能这么说话。”我说，语气变缓和了。
“You mustn't speak like that,” I said, more calmly.

“他很喜欢你，他会像个新爸爸。
“He's very fond of you, and he'll be just like a new father.

一切都会变好的，我向你保证。”
Everything will turn out well, I promise.”

孩子不做声。
The child said nothing.

我又叹了口气。
I sighed again.

“不管怎样，”我接着说，“你要是不喜欢那里，我们随时可以回来。”
“In any case,” I went on, “if you don't like it over there, we can always come back.”

这一次，她抬起头来，怀疑地看着我。
This time she looked up at me questioningly.

“是，我保证，”我说。
“Yes, I promise,” I said.

“你要是不喜欢那里，我们就马上回来。
“If you don't like it over there, we'll come straight back.

可我们得试试看，看看我们喜不喜欢那里。
But we have to try it and see if we like it there.

我相信我们会喜欢的。”
I'm sure we will.”

小女孩紧紧地盯着我。
The little girl was watching me closely.

“你拿着那个做什么？”她问。
“Why are you holding that?” she asked.

“这个？
“This?

照亮脚下的路而已，就这样。”
It just caught around my sandal, that's all.”

“你拿着它做什么？”
“Why are you holding it?”

“我说了。
“I told you.

照亮脚下的路而已。
It caught around my foot.

你是怎么了？”
What's wrong with you?”

我笑了一声。
I gave a short laugh.

“你干吗这样看着我？
“Why are you looking at me like that?

我不会伤害你的。”
I'm not going to hurt you.”

她一面盯着我，一面慢慢地站起来。
Without taking her eyes from me, she rose slowly to her feet.

“你是怎么了？”
“What's wrong with you?”

我又问了一遍。
I repeated.

孩子跑了起来，在木板上发出“咚咚咚”的声音。
The child began to run, her footsteps drumming along the wooden boards.

跑到桥头时，她停了下来，怀疑地看着我。
She stopped at the end of the bridge and stood watching me suspiciously.

我对她笑了笑，拿起灯笼。
I smiled at her and picked up the lantern.

孩子又跑了起来。
The child began once more to run.

半轮月亮出现在水里，我静静地待在桥上看了几分钟。
A half-moon had appeared above the water and for several quiet moments I remained on the bridge, gazing at it.

有一次，我想我在昏暗中看见万里子沿着河岸朝小屋的方向跑去。
Once, through the dimness, I thought I could see Mariko running along the riverbank in the direction of the cottage.

# 第二部 · 第十一章 | PART TWO · Chapter Eleven

起初我肯定有人经过我的床，走出房间，轻轻关上门。
At first, I was sure someone had walked past my bed and out of my room, closing the door quietly.

后来我清醒多了，发现这是多么荒唐的想法。
Then I became more awake, and I realized how fanciful an idea this was.

我躺在床上听着外面的动静。
I lay in bed listening for further noises.

很显然，我听到了隔壁妮基的声音；在这里她一直抱怨睡不好。
Quite obviously, I had heard Niki in the next room; she had complained throughout her stay of being unable to sleep well.

也有可能根本没有什么声响，我又习惯性地早早就醒过来。
Or possibly there had been no noises at all, I had awoken again during the early hours from habit.

外面传来鸟叫声，可我的房间里仍然一片漆黑。
The sound of birds came from outside, but my room was still in darkness.

几分钟后，我起来找晨衣。
After several minutes I rose and found my dressing gown.

我打开房门时，外面的天色还很朦胧。
When I opened my door, the light outside was very pale.

我朝楼梯平台走去，几乎是下意识地瞥了一眼走廊尽头景子的房门。
I stepped further on to the landing and almost by instinct cast a glance down to the far end of the corridor, towards Keiko's door.

突然，一刹那，我肯定从景子的房里传来声响，在屋外的鸟叫声中夹杂着一个微小但清晰的声响。
Then, for a moment, I was sure I had heard a sound come from within Keiko's room, a small clear sound amidst the singing of the birds outside.

我停下来听，然后迈开脚步朝房门走去。
I stood still, listening, then began to walk towards the door.

又传来了几个声响，这时我意识到是楼下厨房传来的声音。
There came more noises, and I realized they were coming from the kitchen downstairs.

我在平台上站了一会儿，然后走下楼梯。
I remained on the landing for a moment, then made my way down the staircase.

妮基从厨房里出来，看见我吓了一跳。
Niki was coming out of the kitchen and started on seeing me.

“哦，妈妈，你吓了我一大跳。”
“Oh, Mother, you gave me a real fright.”

在走廊朦朦胧胧的光线中，我看见她瘦瘦的身子穿着一件浅色晨衣，双手握着茶杯。
In the murky light of the hallway, I could see her thin figure in a pale dressing gown holding a cup in both her hands.

“对不起，妮基。
“I'm sorry, Niki.

我把你当作小偷了。”
I thought perhaps you were a burglar.”

我女儿深吸了一口气，但似乎仍惊魂未定。
My daughter took a deep breath, but still seemed shaken.

过了一会儿，她说：“我睡不着，就想不如起来冲杯咖啡。”
Then she said: “I couldn't sleep very well. So I thought I might as well make some coffee.”

“现在几点？”
“What time is it now?”

“我想大概五点。”
“About five, I suppose.”

她走进客厅，留下我一个人站在楼梯脚下。
She went into the living room, leaving me standing at the foot of the stairs.

我走进厨房冲了杯咖啡，然后也到客厅去。
I went to the kitchen to make myself coffee before going to join her.

客厅里，妮基已经拉开窗帘，叉开腿坐在一张硬靠背椅上，呆呆地看着花园。
In the living room, Niki had opened the curtains and was sitting astride a hard-backed chair, looking emptily out into the garden.

窗外灰蒙蒙的亮光照在她脸上。
The grey light from the window fell on her face.

“你觉得还会不会下雨？”
“Will it rain again, do you think?”

我问。
I asked.

她耸耸肩，继续看着窗外。
She shrugged and continued to look out of the window.

我在壁炉旁坐下，看着她。
I sat down near the fireplace and watched her.

过了一会儿，她疲惫地叹了口气，说道：
Then she sighed tiredly and said:

“我睡得不怎么好。
“I don't seem to sleep very well.

老是做噩梦。”
I keep having these bad dreams all the time.”

“真让人担心，妮基。
“That's worrying, Niki.

你这种年纪不应该有睡眠问题。”
At your age you should have no problems sleeping.”

她没说什么，仍旧看着花园。
She said nothing and went on looking at the garden.

“你做什么噩梦？”
“What kind of bad dreams do you have?”

我问。
I asked.

“哦，就是噩梦。”
“Oh, just bad dreams.”

“什么噩梦，妮基？”
“Bad dreams about what, Niki?”

“就是噩梦，”她说，突然就生气了。
“Just bad dreams,” she said, suddenly irritated.

“管它是什么噩梦？”
“What does it matter what they're about?”

我们都不说话了。
We fell silent for a moment.

过了一会儿，妮基头也不回地说道：
Then Niki said without turning:

“我想爸爸应该多关心她一点，不是吗？
“I suppose Dad should have looked after her a bit more, shouldn't he?

大多数时候爸爸都不管她。
He ignored her most of the time.

这样真是不公平。”
It wasn't fair really.”

我等着她是不是还要说些什么。
I waited to see if she would say more.

然后我说：“咳，可以理解。
Then I said: “Well, it's understandable enough.

他毕竟不是她的亲爸爸。”
He wasn't her real father, after all.”

“可是真是不公平。”
“But it wasn't fair really.”

我看见外面天快亮了。
Outside, I could see, it was nearly daylight.

一只孤零零的小鸟在窗子附近什么地方叽叽喳喳地叫着。
A lone bird was making its noises somewhere close by the window.

“你爸爸有时相当的理想主义，”我说。
“Your father was rather idealistic at times,” I said.

“你瞧，那个时候他真的相信我们能在这里给她一个幸福的生活。”
“In those days, you see, he really believed we could give her a happy life over here.”

妮基耸耸肩。
Niki shrugged.

我看了她好一会儿，然后说：“可是你瞧，妮基，我一开始就知道。
I watched her for a little longer, then said: “But you see, Niki, I knew all along.

我一开始就知道她在这里不会幸福的。
I knew all along she wouldn't be happy over here.

可我还是决定把她带来。”
But I decided to bring her just the same.”

我女儿似乎在思索着我的话，过了一会儿转向我说：“别傻了，你怎么会知道呢？
My daughter seemed to consider this for a moment. “Don't be silly,” she said, turning to me, “how could you have known?

而且你为她尽力了。
And you did everything you could for her.

您是最不应该受到责备的人。”
You're the last person anyone could blame.”

我没有回答。
I remained silent.

她没有化妆的脸显得很年轻。
Her face, devoid of any make-up, looked very young.

“不管怎样，”她说，“人有时就得冒险。
“Anyway,” she said, “sometimes you've got to take risks.

你做得完全正确。
You did exactly the right thing.

你不能看着生命白白浪费。”
You can't just watch your life wasting away.”

我放下一直握着的咖啡杯，越过她，看着外面的花园。
I put down the coffee cup I had been holding and stared past her, out into the garden.

没有要下雨的迹象，天空似乎比前几个早上晴朗。
There were no signs of rain and the sky seemed clearer than on previous mornings.

“要是你接受现实，留在原地，”妮基接着说，“那才是太愚蠢了。
“It would have been so stupid,” Niki went on, “if you'd just accepted everything the way it was and just stayed where you were.

至少你尽力了。”
At least you made an effort.”

“你说得对。
“As you say.

现在我们别说这个了。”
Now let's not discuss it any further.”

“人要是浪费生命真是太愚蠢了。”
“It's so stupid the way people just waste away their lives.”

“我们别说这个了，”我语气更加坚定地说。
“Let's not discuss it any further,” I said, more firmly.

“现在说这些有什么用呢？”
“There's no point in going over all that now.”

我女儿再次把脸转过去。
My daughter turned away again.

我们默默地坐了一会儿，然后我站起来，走近窗户。
We sat without talking for a little while, then I rose to my feet and came closer to the window.

“今天早上看来天气不错，”我说。
“It looks a much better morning today,” I said.

“也许会出太阳。
“Perhaps the sun will come out.

要是出太阳的话，妮基，我们出去散散步。
If it does, Niki, we could go for a walk.

散步很有好处。”
It would do us a lot of good.”

“我想是吧，”她咕哝道。
“I suppose so,” she mumbled.

我离开客厅时，我女儿仍旧叉开腿坐在椅子上，一手托着下巴，呆呆地看着外面的花园。
When I left the living room, my daughter was still sitting astride her chair, her chin supported by a hand, gazing emptily out into the garden.

电话响起来时，我和妮基正在厨房里吃早餐。
When the telephone rang, Niki and I were finishing breakfast in the kitchen.

这几天老有电话找她，所以自然是她去接电话。
It had rung for her so frequently during the previous few days that it seemed natural she should be the one to go and answer it.

等她接完电话回来，她的咖啡已经冷掉了。
By the time she returned, her coffee had grown cold.

“又是你的朋友？”
“Your friends again?”

我问。
I asked.

她点点头，走过去打开炉子烧水。
She nodded, then went over to switch on the kettle.

“是这样的，妈妈，”她说，“我下午得回去了。
“Actually, Mother,” she said, “I'll have to go back this afternoon.

行吗？”
Is that all right?”

她站在那里，一手放在水壶柄上，一手放在臀部。
She was standing with one hand on the handle of the kettle, the other on her hip.

“当然可以。
“Of course it's all right.

你能来这里我很高兴，妮基。”
It's been very nice having you here, Niki.”

“我很快会再来看你的。
“I'll come and see you again soon.

可现在我真的得回去了。”
But I've really got to be getting back now.”

“你用不着道歉。
“You don't have to apologize.

如今你过自己的生活很重要。”
It's very important you lead your own life now.”

妮基转过身去等水开。
Niki turned away and waited for her kettle.

水槽上方的窗户还有一些雾气，但外面已经出太阳了。
The windows above the sink unit had misted over a little, but outside the sun was shining.

妮基冲了咖啡，然后在桌子旁坐下。
Niki poured herself coffee, then sat down at the table.

“哦，对了，妈妈，”她说。
“Oh, by the way, Mother,” she said.

“你记得我跟你提起的那个朋友，在写关于你的诗的那个？”
“You know that friend I was telling you about, the one writing the poem about you?”

我微微一笑。
I smiled.

“哦，记得。
“Oh yes.

你的朋友。”
Your friend.”

“她想让我带张照片什么的回去。
“She wanted me to bring back a photo or something.

长崎的。
Of Nagasaki.

你有这样的东西吗？
Have you got anything like that?

旧明信片什么的？”
An old postcard or something?”

“我想我可以找一找。
“I should think I could find something for you.

太荒唐了”——我笑了一声——“她能写我什么呢？”
How absurd” — I gave a laugh — “Whatever can she be writing about me?”

“她是个很棒的诗人。
“She's a really good poet.

她经历了很多事情，你瞧。
She's been through a lot, you see.

所以我跟她说了你的事。”
That's why I told her about you.”

“我相信她一定会写出了不起的诗来，妮基。”
“I'm sure she'll write a marvellous poem, Niki.”

“就旧明信片什么的。
“Just an old postcard, anything like that.

让她看看一切都是什么样的。”
Just so she can see what everything was like.”

“这个嘛，妮基，我不敢肯定。
“Well, Niki, I'm not so sure.

得看得出一切都是什么样的，是吗？”
It has to show what everything was like, does it?”

“你知道我的意思。”
“You know what I mean.”

我又笑了一声。
I laughed again.

“我待会儿给你找找看。”
“I'll have a look for you later.”

妮基刚在一片烤面包上涂了些黄油，现在又把黄油刮掉一些。
Niki had been buttering a piece of toast, but now she began to scrape some butter off again.

我女儿从小就瘦，却担心变胖，让我觉得好笑。
My daughter has been thin since childhood, and the idea that she was concerned at becoming fat amused me.

我看了她一会儿。
I watched her for a moment.

“话说回来，”我终于说道，“真可惜你今天就要离开。
“Still,” I said, eventually, “it's a pity you're leaving today.

我本打算今晚一起去看电影。”
I was about to suggest we went to the cinema this evening.”

“看电影？
“The cinema?

为什么，在放什么？”
Why, what's on?”

“我不知道他们现在放些什么电影。
“I don't know what kind of films they show these days.

我以为你会清楚些。”
I was hoping you'd know more about it.”

“说真的，妈妈，我们好久没有一起看电影了，不是吗？
“Actually, Mother, it's ages since we went to a film together, isn't it?

从我长大以后。”
Not since I was little.”

妮基微笑了一下，霎时间她的脸变得孩子气。
Niki smiled, and for a moment her face became child-like.

接着，她放下小刀，盯着自己的杯子。
Then she put down her knife and gazed at her coffee cup.

“我也不常看电影，”她说。
“I don't go to see films much either,” she said.

“在伦敦总有一大堆电影看，可我们不常去。”
“There's always loads on in London, but we don't go much.”

“啊，你要是喜欢的话，也可以去看戏。
“Well, if you prefer, there's always the theatre.

如今有公车直达剧院。
The bus takes you right up to the theatre now.

我不知道他们现在在演什么，不过我们能查到。
I don't know what they have on at the moment, but we could find out.

本地的报纸是不是在那里，就在你后面？”
Is that the local paper there, just behind you?”

“好了，妈妈，别麻烦了。
“Well, Mother, don't bother.

没有什么意义。”
There's not much point.”

“我想他们不时会演些好戏。
“I think they do quite good plays sometimes.

相当现代的。
Some quite modern ones.

报上有。”
It'll say in the paper.”

“没有什么意义，妈妈。
“There's not much point, Mother.

我今天就得回去了。
I'll have to go back today anyhow.

我很想留下来，可是我真的得回去了。”
I'd like to stay, but I've really got to get back.”

“当然，妮基。
“Of course, Niki.

不必道歉。”
There's no need to apologize.”

我给了桌子那头的她一个微笑。
I smiled at her across the table.

“事实上，你有处得来的好朋友，我感到很欣慰。
“As a matter of fact, it's a great comfort to me you have good friends you enjoy being with.

随时欢迎你带他们来这里。”
You're always welcome to bring any of them here.”

“好的，妈妈，谢谢你。”
“Yes, Mother, thank you.”

妮基睡的空房间是个简陋的小房间；那天早上，阳光流泻了进来。
The spare bedroom Niki had been using was small and stark; the sun was streaming into it that morning.

“这个给你朋友行吗？”
“Will this do for your friend?”

我在门口问道。
I asked, from the doorway.

妮基正在床边收拾箱子，抬头看了一眼我找到的日历。
Niki was packing her suitcase on the bed and glanced up briefly at the calendar I had found.

“可以，”她说。
“That's fine,” she said.

我走进房间。
I stepped further into the room.

透过窗子，我可以看见下面的果园和一排排整齐的小树。
From the window, I could see the orchard below and the neat rows of thin young trees.

我手里的日历原本每个月份都有一张照片，如今撕得只剩下最后一张了。
The calendar I was holding had originally offered a photograph for each month, but all but the last had been torn away.

我盯着这最后一张照片看了一会儿。
For a moment, I regarded the remaining picture.

“别给我什么重要的东西，”妮基说。
“Don't give me anything important,” Niki said.

“没有的话也没关系。”
“If there isn't anything, it doesn't matter.”

我笑了，把照片跟她的其他东西一起放在床上。
I laughed and laid the picture down on the bed alongside her other things.

“只是一本旧日历，没什么。
“It's just an old calendar, that's all.

我也不知道为什么会留着。”
I've no idea why I've kept it.”

妮基拨了些头发到耳后，继续整理。
Niki pushed some hair back behind her ear, then continued packing.

“我想，”我终于开口说道，“你打算暂时继续住在伦敦。”
“I suppose,” I said, eventually, “you plan to go on living in London for the time being.”

她耸了耸肩。
She gave a shrug.

“这个，我在那里很开心。”
“Well, I'm quite happy there.”

“一定要替我向你的朋友们问好。”
“You must send my best wishes to all your friends.”

“好的，我会的。”
“All right, I will.”

“还有大卫。
“And to David.

这是他的名字吧？”
That was his name, wasn't it?”

她又耸了耸肩，没说什么。
She gave another shrug, but said nothing.

她带了三双不同的靴子回来，现在正想办法装到箱子里去。
She had brought with her three separate pairs of boots and now she was struggling to find a way of putting them in her case.

“妮基，我想你还没有打算结婚吧？”
“I suppose, Niki, you don't have any plans yet to be getting married?”

“我干吗打算结婚？”
“What do I want to get married for?”

“我问问而已。”
“I was just asking.”

“我干吗要结婚？
“Why should I get married?

意义何在？”
What's the point of that?”

“你打算就这么继续——住在伦敦，是吗？”
“You plan to just go on — living in London, do you?”

“我干吗要结婚呢？
“Well, why should I get married?

太愚蠢了，妈妈。”
That's so stupid, Mother.”

她把日历卷起来、收好。
She rolled up the calendar and packed it away.

“那么多女人被灌输这种思想，认为生活就是结婚，然后生一大堆孩子。”
“So many women just get brainwashed. They think all there is to life is getting married and having a load of kids.”

我还是看着她。
I continued to watch her.

过了一会儿，我说：“可说到底，妮基，没别的什么了。”
Then I said: “But in the end, Niki, there isn't very much else.”

“天啊，妈妈，我有很多事情可以干。
“God, Mother, there's plenty of things I could do.

我不想固定下来，然后整天围着丈夫和一大群吵吵闹闹的孩子团团转。
I don't want to just get stuck away somewhere with a husband and a load of screaming kids.

你怎么突然唠叨起这个了？”
Why are you going on about it suddenly anyway?”

箱子的盖子关不上，妮基不耐烦地直往下按。
The lid of her suitcase would not shut. She pushed down at it impatiently.

“我只是想知道你是怎么打算的，妮基，”我笑了下说。
“I was only wondering what your plans were, Niki,” I said, with a laugh.

“没必要生这么大的气。
“There's no need to get so cross.

你当然要照自己的想法生活。”
Of course, you must do what you choose.”

她把盖子重新打开，整了整里面的东西。
She opened the lid again and adjusted some of the contents.

“好了，妮基，没必要生这么大的气。”
“Now, Niki, there's no need to get so cross.”

这次，她总算把盖子给关上了。
This time, she managed to close the lid.

“天晓得我干吗带了这么多东西？”她小声自言自语道。
“God knows why I brought so much,” she muttered to herself.

“你要怎么跟别人说，妈妈？”
“What do you say to people, Mother?”

妮基问。
Niki asked.

“别人问我去哪儿了，你要怎么跟他们说？”
“What do you say when they ask where I am?”

我女儿决定她可以吃过午饭再走，我俩就从屋后的果园出来散步。
My daughter had decided she need not leave until after lunch and we had come out walking through the orchard behind the house.

太阳还在，可天气很冷。
The sun was still out, but the air was chilly.

我不解地看着她。
I gave her a puzzled look.

“我就告诉他们你住在伦敦啊，妮基。
“I just tell them you're living in London, Niki.

不是这样吗？”
Isn't that the truth?”

“我想是。
“I suppose so.

可他们不会问我在干什么吗？
But don't they ask what I'm doing?

像那天沃特斯老太太那样？”
Like that old Mrs Waters the other day?”

“是啊，他们有时候会问。
“Yes, sometimes they ask.

我就说你和朋友们住在一起。
I tell them you're living with your friends.

说真的，妮基，我不知道你那么在乎人们对你的看法。”
Really, Niki, I had no idea you were so concerned about what people thought of you.”

“我没有。”
“I'm not.”

我们继续慢慢地走着。
We continued to walk slowly.

许多地方很泥泞。
In many places, the ground had become marshy.

“我想你不太喜欢，对不对，妈妈？”
“I suppose you don't like it very much, do you, Mother?”

“喜欢什么，妮基？”
“Like what, Niki?”

“我的做法。
“The way things are with me.

你不喜欢我搬出去。
You don't like me living away.

还有和大卫住啊，等等。”
With David and all that.”

我们来到了果园尽头。
We had come to the end of the orchard.

妮基跨出园子，走上一条弯弯曲曲的小路；她走到路的对面，朝一片原野的几扇木门走去。
Niki stepped out on to a small winding lane and crossed to the other side, towards the wooden gates of a field.

我跟在她后面。
I followed her.

草地很大，从我们面前缓缓地升上去。
The grass field was large and rose gradually as it spread away from us.

在最高点有两棵瘦瘦的假挪威槭映着蓝天。
At its crest, we could see two thin sycamore trees against the sky.

“我并不为你感到羞耻，妮基，”我说。
“I'm not ashamed of you, Niki,” I said.

“你应该按照自己的想法生活。”
“You must live as you think best.”

我女儿注视着原野。
My daughter was gazing at the field.

“以前这里有马，不是吗？”她说，举起双手去摸木门。
“They used to have horses here, didn't they?” she said, putting her arms up on to the gate.

我放眼望去，没有看见马。
I looked, but there were no horses to be seen.

“说来奇怪，”我说道。
“You know, it's strange,” I said.

“我记得我刚结婚时，我和我丈夫吵了起来，因为他不想和他父亲住在一起。
“I remember when I first married, there was a lot of argument because my husband didn't want to live with his father.

你瞧，那时的日本，子女还是应该跟父母住一起的。
You see, in those days that was still quite expected in Japan.

我们为此吵个不停。”
There was a lot of argument about that.”

“我敢说你一定觉得轻松多了，”妮基说道，视线没有离开原野。
“I bet you were relieved,” Niki said, not taking her eyes from the field.

“轻松？
“Relieved?

为什么？”
About what?”

“因为不用和他父亲一起住。”
“About not having to live with his father.”

“相反，妮基。
“On the contrary, Niki.

我更愿意他和我们一起住。
I would have been happy if he'd lived with us.

再说，他妻子不在了。
Besides, he was a widower.

日本传统的生活方式一点儿也不坏。”
It's not a bad thing at all, the old Japanese way.”

“你现在当然会这么说了。
“Obviously, you'd say that now.

可我敢说你那时肯定不是这么想的。”
I bet that's not what you thought at the time though.”

“可是妮基，你真的不明白。
“But Niki, you really don't understand.

我非常喜欢我的公公。”
I was very fond of my father-in-law.”

我看了她一会儿，最后还是笑了笑。
I looked at her for a moment, then finally gave a laugh.

“也许你说得对。
“Perhaps you're right.

也许他不和我们一起住我是轻松多了。
Perhaps I was relieved he didn't come to live with us.

我记不清了。”
I don't remember now.”

我伸出手去摸木门的顶端。
I reached forward and touched the top of the wooden gate.

一些水汽沾到了我的手指上。
A little moisture came away on my fingers.

我发现妮基在看我，就把手举给她看。
I realized Niki was watching me and I held up my hand to show her.

“还有些霜，”我说。
“There's still some frost,” I said.

“你还常常想日本吗，妈妈？”
“Do you still think about Japan a lot, Mother?”

“我想是的。”
“I suppose so.”

我又转回去看着原野。
I turned back to the field.

“我会回忆一些往事。”
“I have a few memories.”

两匹小马出现在假挪威槭附近。
Two ponies had appeared near the sycamore trees.

一时间，它们静静地站在那里，并排站在阳光下。
For a moment they stood quite still, in the sunshine, side by side.

“我今天早上给你的那本日历，”我说。
“That calendar I gave you this morning,” I said.

“上面是长崎港口的风景。
“That's a view of the harbour in Nagasaki.

今天早上我想起有一次我们到那里去，一次郊游。
This morning I was remembering the time we went there once, on a day-trip.

港口周围的那些山非常漂亮。”
Those hills over the harbour are very beautiful.”

那两匹小马慢慢地走到树后面去。
The ponies moved slowly behind the trees.

“有什么特别的？”妮基问。
“What was so special about it?” said Niki.

“特别？”
“Special?”

“你们去港口的那天。”
“About the day you spent at the harbour.”

“哦，没什么特别的。
“Oh, there was nothing special about it.

我刚好想到，就这样。
I was just remembering it, that's all.

那天景子很高兴。
Keiko was happy that day.

我们坐了缆车。”
We rode on the cable-cars.”

我笑了一声，转向妮基。
I gave a laugh and turned to Niki.

“对，没什么特别的。
“No, there was nothing special about it.

只是件快乐的往事，仅此而已。”
It's just a happy memory, that's all.”

我女儿叹了口气，说：“这里好安静啊。
My daughter gave a sigh. “Everything's so quiet out here,” she said.

我都不记得有这么安静了。”
“I don't remember things being this quiet.”

“是啊，比起伦敦，这里一定显得很安静。”
“Yes, it must seem quiet after London.”

“我想你一个人住在这里有时候一定有点无聊。”
“I suppose it gets a bit boring sometimes, out here on your own.”

“可是我喜欢安静，妮基。
“But I enjoy the quiet, Niki.

我一直觉得这里最像英国。”
I always think it's so truly like England out here.”

我的视线离开原野，回头看着我们身后的果园。
I turned away from the field, and for a moment looked back towards the orchard behind us.

“我们刚来这里的时候没有那些树，”过了许久，我说道，“一整片都是原野，你从这里就可以看见房子。
“All those trees weren't here when we first came,” I said, eventually. “It was all fields, and you could see the house from here.

你父亲刚带我到这里来的时候，妮基，我记得我觉得这里的一切都那么像英国。
When your father first brought me down here, Niki, I remember thinking how so truly like England everything looked.

原野啊，房子啊。
All these fields, and the house too.

正是我一直以来想像中的英国的样子，我高兴极了。”
It was just the way I always imagined England would be and I was so pleased.”

妮基深吸了一口气，离开木门，说：“我们回去吧，我得赶紧走了。”
Niki took a deep breath and moved away from the gate. “We'd better be getting back,” she said. “I'll have to be going fairly soon.”

我们重新穿过果园时，天空似乎又布起了乌云。
As we walked back through the orchard, the sky seemed to cloud over.

“前些日子我突然想到，”我说，“也许现在我该把房子卖了。”
“I was just thinking the other day,” I said, “perhaps I should sell the house now.”

“卖了？”
“Sell it?”

“是啊。
“Yes.

也许该换个小一点的房子。
Move somewhere smaller perhaps.

我想想而已。”
It's just an idea.”

“你想把房子卖了？”
“You want to sell the house?”

我女儿担心地看着我。
My daughter gave me a concerned look.

“可这房子很好。”
“But it's a really nice house.”

“但如今太大了。”
“But it's so large now.”

“可这房子很好，妈妈。
“But it's a really nice house, Mother.

卖掉太可惜了。”
It'd be a shame.”

“我想也是。
“I suppose so.

我想想而已，妮基，没别的。”
It was just an idea, Niki, that's all.”

我本想送她去火车站——离这里不过几分钟的路——可这似乎会让她不自在。
I would like to have seen her to the railway station — it is only a few minutes’ walk — but the idea seemed to embarrass her.

午饭后不久她就走了，一副奇怪的、难为情的样子，好像她是没有经过我的同意离开的。
She left shortly after lunch with an oddly self-conscious air, as if she were leaving without my approval.

下午天空转阴了，起了风，我站在门口看着她走到车道尽头。
The afternoon had turned grey and windy, and I stood in the doorway as she walked down to the end of the drive.

她穿着和来时一样的紧身衣，有点费力地拖着箱子。
She was dressed in the same tight-fitting clothes she had arrived in, and her suitcase made her drag her step a little.

到门口时，妮基回头看了一眼，发现我还站在门口，似乎有点吃惊。
When she reached the gate, Niki glanced back and seemed surprised to find me still standing at the door.

我笑了笑，朝她挥挥手。
I smiled and waved to her.
