#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Local offline intelligent reader service (disguised as OCR Dataset Dev Server).
Zero third-party dependencies — Python 3 standard library only.
Binds strictly to 127.0.0.1.
"""

import argparse
import hashlib
import html
from html.parser import HTMLParser
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import mimetypes
import os
from pathlib import Path
import posixpath
import re
import shutil
import socket
import subprocess
import sys
import threading
import time
import urllib.parse
import urllib.request
import webbrowser
import xml.etree.ElementTree as ET
import zipfile

ROOT_DIR = Path(__file__).resolve().parent
NOVELS_DIR = ROOT_DIR / "novels"
DATA_DIR = ROOT_DIR / "data"
NOTES_DIR = DATA_DIR / "notes"
STATE_FILE = DATA_DIR / "reader_state.json"
PORT_FILE = DATA_DIR / "server.port"

SUPPORTED_EXTS = {".txt", ".md", ".epub"}
DEFAULT_PORT = 18765

DEFAULT_FILTER_PATTERNS = [
    r"请记住本书首发域名.*",
    r"天才一秒记住.*",
    r"手机版阅读网址.*",
    r"最新章节请访问.*",
    r"笔趣阁.*",
    r"本书由.*整理.*",
    r"www\.[a-z0-9.-]+\.[a-z]{2,}",
    r"https?://\S+",
    r"^[\s\-_=*~·•—─━═]{6,}$",
]

CHAPTER_RE = re.compile(
    r"^\s*("
    r"第[0-9０-９零一二三四五六七八九十百千万两〇]+[章节回卷集部篇幕].{0,36}|"
    r"(?:楔子|序章|序言|前言|引子|尾声|终章|后记|番外[0-9零一二三四五六七八九十]*).{0,24}|"
    r"Chapter\s+\d+.{0,36}|"
    r"【?\s*第?[0-9０-９]{1,4}[章节回、.\s]\s*.{1,30}】?|"
    r"#{1,6}\s+.+"
    r")\s*$",
    re.IGNORECASE,
)

STATE_LOCK = threading.RLock()
CACHE_LOCK = threading.RLock()
BOOK_CACHE = {}  # key: rel_name -> {"sig": tuple, "book": dict}


def ensure_dirs():
    NOVELS_DIR.mkdir(parents=True, exist_ok=True)
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    NOTES_DIR.mkdir(parents=True, exist_ok=True)


def default_state():
    return {
        "settings": {},
        "lastBook": "",
        "progress": {},
        "bookmarks": [],
        "stats": {
            "dailySeconds": {},
            "bookSeconds": {},
            "totalCharsRead": 0,
            "readingSpeedCpm": 450,
        },
        "cleanEnabled": True,
        "customFilterWords": [],
    }


def load_state():
    with STATE_LOCK:
        ensure_dirs()
        base = default_state()
        if STATE_FILE.exists():
            try:
                raw = json.loads(STATE_FILE.read_text(encoding="utf-8"))
                if isinstance(raw, dict):
                    for k in ("settings", "lastBook", "progress", "bookmarks", "cleanEnabled", "customFilterWords"):
                        if k in raw:
                            base[k] = raw[k]
                    if isinstance(raw.get("stats"), dict):
                        base["stats"].update(raw["stats"])
            except Exception:
                pass
        return base


def save_state(st):
    with STATE_LOCK:
        ensure_dirs()
        tmp = STATE_FILE.with_suffix(".json.tmp")
        tmp.write_text(json.dumps(st, ensure_ascii=False, indent=2), encoding="utf-8")
        os.replace(tmp, STATE_FILE)


def get_filter_signature(st):
    enabled = bool(st.get("cleanEnabled", True))
    words = st.get("customFilterWords") or []
    raw = json.dumps({"e": enabled, "w": words}, ensure_ascii=False)
    return hashlib.md5(raw.encode("utf-8")).hexdigest()


def build_filter_regexes(st):
    if not st.get("cleanEnabled", True):
        return []
    regs = [re.compile(p, re.IGNORECASE) for p in DEFAULT_FILTER_PATTERNS]
    for w in st.get("customFilterWords") or []:
        w = str(w).strip()
        if not w:
            continue
        try:
            regs.append(re.compile(w, re.IGNORECASE))
        except re.error:
            regs.append(re.compile(re.escape(w), re.IGNORECASE))
    return regs


def should_drop_line(line, filter_regs):
    if not filter_regs:
        return False
    for r in filter_regs:
        if r.search(line):
            return True
    return False


def decode_bytes(raw: bytes) -> str:
    if raw.startswith(b"\xef\xbb\xbf"):
        return raw[3:].decode("utf-8", errors="replace")
    if raw.startswith(b"\xff\xfe") or raw.startswith(b"\xfe\xff"):
        return raw.decode("utf-16", errors="replace")
    try:
        return raw.decode("utf-8")
    except UnicodeDecodeError:
        pass
    for enc in ("gb18030", "big5", "utf-16"):
        try:
            return raw.decode(enc)
        except UnicodeDecodeError:
            continue
    return raw.decode("utf-8", errors="replace")


def clean_md_line(line: str) -> str:
    line = re.sub(r"!\[[^\]]*\]\([^)]*\)", "", line)
    line = re.sub(r"\[([^\]]+)\]\([^)]*\)", r"\1", line)
    line = re.sub(r"(\*\*|__|~~|`)", "", line)
    line = re.sub(r"^\s*>\s?", "", line)
    line = re.sub(r"^\s*[-*+]\s+", "", line)
    return line


def trim_full(s: str) -> str:
    return s.strip(" \t\r\n\u3000\ufeff\xa0")


def parse_text_chapters(name: str, text: str, filter_regs):
    is_md = name.lower().endswith(".md")
    lines = text.replace("\r\n", "\n").replace("\r", "\n").split("\n")
    md_heading_re = re.compile(r"^\s*#{1,6}\s+.+$")
    has_md_headings = is_md and any(md_heading_re.match(l) for l in lines[:200])
    chapters = []
    current = None

    for raw_line in lines:
        trimmed = trim_full(raw_line)
        if not trimmed:
            continue

        is_heading = False
        if has_md_headings:
            is_heading = len(trimmed) <= 120 and bool(md_heading_re.match(trimmed))
        else:
            is_heading = (len(trimmed) <= 120 and bool(md_heading_re.match(trimmed))) or (
                len(trimmed) <= 44 and bool(CHAPTER_RE.match(trimmed))
            )

        if is_heading:
            title = re.sub(r"^#{1,6}\s+", "", trimmed)
            if is_md:
                title = trim_full(clean_md_line(title))
            current = {"title": title or "未命名章节", "paras": []}
            chapters.append(current)
            continue

        if is_md:
            raw_line = clean_md_line(raw_line)
        para = trim_full(raw_line)
        if not para or should_drop_line(para, filter_regs):
            continue

        if current is None:
            current = {"title": "前言", "paras": []}
            chapters.append(current)
        current["paras"].append(para)

    # 无章标题时按约 3000 字语义分段切章，并取首句摘要作标题
    if len(chapters) == 1 and chapters[0]["title"] == "前言":
        all_paras = chapters[0]["paras"]
        chunks = []
        buf = []
        count = 0
        for p in all_paras:
            buf.append(p)
            count += len(p)
            if count >= 3000:
                snippet = buf[0][:14].rstrip("，。！？、")
                chunks.append({"title": f"Part {len(chunks) + 1} · {snippet}", "paras": buf})
                buf = []
                count = 0
        if buf or not chunks:
            snippet = (buf[0][:14].rstrip("，。！？、")) if buf else "正文"
            chunks.append({"title": f"Part {len(chunks) + 1} · {snippet}", "paras": buf})
        chapters = chunks

    # 过滤空章（保留至少一章）
    chapters = [c for c in chapters if c["paras"] or c["title"]]
    if not chapters:
        chapters = [{"title": "空文件", "paras": ["（文件内容为空）"]}]
    return chapters


class _XHTMLParagraphExtractor(HTMLParser):
    BLOCK_TAGS = {
        "p", "div", "br", "li", "blockquote", "pre",
        "h1", "h2", "h3", "h4", "h5", "h6", "section", "article", "tr"
    }
    HEADING_TAGS = {"h1", "h2", "h3", "h4", "title"}

    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.skip_depth = 0
        self.in_heading = None
        self.heading_buf = []
        self.found_headings = []
        self.cur_buf = []
        self.paras = []

    def _flush(self):
        text = trim_full("".join(self.cur_buf))
        self.cur_buf = []
        if text:
            # 合并段内多余空白
            text = re.sub(r"[ \t\r\n]+", " ", text)
            self.paras.append(text)

    def handle_starttag(self, tag, attrs):
        t = tag.lower()
        if t in ("script", "style", "svg", "math"):
            self.skip_depth += 1
            return
        if self.skip_depth > 0:
            return
        if t in self.BLOCK_TAGS:
            self._flush()
        if t in self.HEADING_TAGS and self.in_heading is None:
            self.in_heading = t
            self.heading_buf = []

    def handle_endtag(self, tag):
        t = tag.lower()
        if t in ("script", "style", "svg", "math"):
            self.skip_depth = max(0, self.skip_depth - 1)
            return
        if self.skip_depth > 0:
            return
        if self.in_heading == t:
            h_txt = trim_full("".join(self.heading_buf))
            if h_txt:
                self.found_headings.append((t, h_txt))
            self.in_heading = None
            self.heading_buf = []
        if t in self.BLOCK_TAGS:
            self._flush()

    def handle_data(self, data):
        if self.skip_depth > 0:
            return
        if self.in_heading is not None:
            self.heading_buf.append(data)
            if self.in_heading == "title":
                return
        self.cur_buf.append(data)

    def finish(self):
        self._flush()
        best_title = ""
        for pref in ("h1", "h2", "h3", "h4", "title"):
            for tag, txt in self.found_headings:
                if tag == pref and txt:
                    best_title = txt
                    break
            if best_title:
                break
        return best_title, self.paras


def _local_name(tag: str) -> str:
    return tag.split("}", 1)[-1].lower() if "}" in tag else tag.lower()


def _norm_zip_path(base_dir: str, href: str) -> str:
    clean = urllib.parse.unquote(href.split("#", 1)[0].strip())
    joined = posixpath.join(base_dir, clean) if base_dir else clean
    return posixpath.normpath(joined).lstrip("/")


def _parse_epub_toc(zf: zipfile.ZipFile, opf_dir: str, manifest: dict) -> dict:
    """Return mapping: normalized_zip_path -> chapter_title."""
    toc_map = {}

    # 1. Try EPUB3 nav document
    nav_item = None
    ncx_item = None
    for item in manifest.values():
        props = (item.get("properties") or "").split()
        if "nav" in props:
            nav_item = item
        if item.get("media-type") == "application/x-dtbncx+xml" or item.get("href", "").lower().endswith(".ncx"):
            ncx_item = item

    if nav_item:
        nav_path = _norm_zip_path(opf_dir, nav_item["href"])
        nav_dir = posixpath.dirname(nav_path)
        try:
            root = ET.fromstring(zf.read(nav_path))
            for a in root.iter():
                if _local_name(a.tag) == "a" and a.attrib.get("href"):
                    target = _norm_zip_path(nav_dir, a.attrib["href"])
                    label = trim_full("".join(a.itertext()))
                    if target and label and target not in toc_map:
                        toc_map[target] = label
        except Exception:
            pass

    # 2. Fallback / supplement with EPUB2 NCX
    if ncx_item:
        ncx_path = _norm_zip_path(opf_dir, ncx_item["href"])
        ncx_dir = posixpath.dirname(ncx_path)
        try:
            root = ET.fromstring(zf.read(ncx_path))
            for np in root.iter():
                if _local_name(np.tag) == "navpoint":
                    label = ""
                    src = ""
                    for child in np:
                        ln = _local_name(child.tag)
                        if ln == "navlabel":
                            label = trim_full("".join(child.itertext()))
                        elif ln == "content":
                            src = child.attrib.get("src", "")
                    if src and label:
                        target = _norm_zip_path(ncx_dir, src)
                        if target not in toc_map:
                            toc_map[target] = label
        except Exception:
            pass

    return toc_map


def parse_epub_chapters(filepath: Path, filter_regs):
    chapters = []
    with zipfile.ZipFile(filepath, "r") as zf:
        names_set = set(zf.namelist())
        opf_path = ""
        if "META-INF/container.xml" in names_set:
            try:
                croot = ET.fromstring(zf.read("META-INF/container.xml"))
                for elem in croot.iter():
                    if _local_name(elem.tag) == "rootfile" and elem.attrib.get("full-path"):
                        opf_path = elem.attrib["full-path"]
                        break
            except Exception:
                pass
        if not opf_path:
            for n in zf.namelist():
                if n.lower().endswith(".opf"):
                    opf_path = n
                    break

        spine_paths = []
        toc_map = {}
        if opf_path and opf_path in names_set:
            opf_dir = posixpath.dirname(opf_path)
            opf_root = ET.fromstring(zf.read(opf_path))
            manifest = {}
            for elem in opf_root.iter():
                if _local_name(elem.tag) == "item":
                    iid = elem.attrib.get("id")
                    if iid:
                        manifest[iid] = {
                            "href": elem.attrib.get("href", ""),
                            "media-type": elem.attrib.get("media-type", ""),
                            "properties": elem.attrib.get("properties", ""),
                        }
            toc_map = _parse_epub_toc(zf, opf_dir, manifest)
            for elem in opf_root.iter():
                if _local_name(elem.tag) == "itemref":
                    idref = elem.attrib.get("idref")
                    if idref in manifest:
                        mt = manifest[idref].get("media-type", "")
                        if "html" in mt or manifest[idref]["href"].lower().endswith((".xhtml", ".html", ".htm")):
                            spine_paths.append(_norm_zip_path(opf_dir, manifest[idref]["href"]))

        if not spine_paths:
            spine_paths = sorted(
                n for n in zf.namelist()
                if n.lower().endswith((".xhtml", ".html", ".htm")) and "nav" not in n.lower()
            )

        for idx, zpath in enumerate(spine_paths):
            if zpath not in names_set:
                continue
            try:
                raw_html = decode_bytes(zf.read(zpath))
            except Exception:
                continue
            parser = _XHTMLParagraphExtractor()
            parser.feed(raw_html)
            parser.close()
            html_title, paras = parser.finish()
            paras = [p for p in paras if p and not should_drop_line(p, filter_regs)]
            if not paras:
                continue

            title = toc_map.get(zpath) or html_title or f"Chapter {len(chapters) + 1}"
            title = html.unescape(title)[:60]
            # 若正文第一段与标题完全相同，去重
            if paras and trim_full(paras[0]) == trim_full(title) and len(paras) > 1:
                paras = paras[1:]
            chapters.append({"title": title, "paras": paras})

    if not chapters:
        chapters = [{"title": "空 EPUB", "paras": ["（未解析到可读正文）"]}]
    return chapters


def safe_novel_path(rel_name: str) -> Path:
    if not rel_name or "\x00" in rel_name:
        raise ValueError("Invalid filename")
    norm = rel_name.replace("\\", "/").lstrip("/")
    if ".." in norm.split("/"):
        raise ValueError("Path traversal forbidden")
    target = (NOVELS_DIR / norm).resolve()
    base = NOVELS_DIR.resolve()
    if base not in target.parents:
        raise ValueError("Outside novels directory")
    return target


def sanitize_upload_name(raw_name: str) -> str:
    name = os.path.basename(raw_name.replace("\\", "/")).strip()
    name = re.sub(r'[<>:"/\\|?*\x00-\x1f]', "_", name)
    if not name:
        raise ValueError("Empty filename")
    ext = Path(name).suffix.lower()
    if ext not in SUPPORTED_EXTS:
        raise ValueError(f"Unsupported format: {ext}")
    return name


def scan_novel_files():
    ensure_dirs()
    items = []
    base = NOVELS_DIR.resolve()
    for p in sorted(base.rglob("*")):
        if not p.is_file():
            continue
        if p.suffix.lower() not in SUPPORTED_EXTS:
            continue
        rel = p.relative_to(base).as_posix()
        st = p.stat()
        items.append({
            "name": rel,
            "ext": p.suffix.lower(),
            "size": st.st_size,
            "mtime_ns": st.st_mtime_ns,
            "path": p,
        })
    return items


def compute_library_version(files, filter_sig: str) -> str:
    payload = "|".join(f"{f['name']}:{f['size']}:{f['mtime_ns']}" for f in files) + "|" + filter_sig
    return hashlib.md5(payload.encode("utf-8")).hexdigest()[:12]


def get_parsed_book(rel_name: str, state_obj=None):
    st = state_obj if state_obj is not None else load_state()
    fpath = safe_novel_path(rel_name)
    if not fpath.exists() or not fpath.is_file():
        raise FileNotFoundError(rel_name)
    stat = fpath.stat()
    filter_sig = get_filter_signature(st)
    sig = (stat.st_size, stat.st_mtime_ns, filter_sig)

    with CACHE_LOCK:
        cached = BOOK_CACHE.get(rel_name)
        if cached and cached["sig"] == sig:
            return cached["book"]

    filter_regs = build_filter_regexes(st)
    ext = fpath.suffix.lower()
    if ext == ".epub":
        chapters = parse_epub_chapters(fpath, filter_regs)
    else:
        raw_text = decode_bytes(fpath.read_bytes())
        chapters = parse_text_chapters(rel_name, raw_text, filter_regs)

    # 计算每章字数与累计偏移，方便精确计算全书进度与预估剩余时间
    total_chars = 0
    toc = []
    for idx, ch in enumerate(chapters):
        c_chars = sum(len(p) for p in ch["paras"])
        toc.append({
            "idx": idx,
            "title": ch["title"],
            "chars": c_chars,
            "startChar": total_chars,
        })
        total_chars += c_chars

    book = {
        "name": rel_name,
        "ext": ext,
        "size": stat.st_size,
        "totalChars": total_chars,
        "chapterCount": len(chapters),
        "toc": toc,
        "chapters": chapters,
    }
    with CACHE_LOCK:
        BOOK_CACHE[rel_name] = {"sig": sig, "book": book}
    return book


def export_book_notes(book_name: str, st: dict) -> dict:
    ensure_dirs()
    bookmarks = [b for b in (st.get("bookmarks") or []) if b.get("book") == book_name]
    safe_stem = re.sub(r'[<>:"/\\|?*\x00-\x1f]', "_", Path(book_name).stem)
    out_file = NOTES_DIR / f"{safe_stem}_notes.md"

    lines = [
        f"# 《{Path(book_name).stem}》阅读笔记与摘录",
        "",
        f"- 导出时间：{time.strftime('%Y-%m-%d %H:%M:%S')}",
        f"- 共计书签/批注：{len(bookmarks)} 条",
        "",
        "---",
        "",
    ]
    if not bookmarks:
        lines.append("（暂无书签或批注）")
    else:
        for i, bm in enumerate(bookmarks, 1):
            ch_title = bm.get("chTitle") or f"第 {int(bm.get('ch', 0)) + 1} 章"
            preview = bm.get("preview") or ""
            note = (bm.get("note") or "").strip()
            ts = bm.get("createdAt") or ""
            lines.append(f"### {i}. {ch_title}")
            if ts:
                lines.append(f"> 记录时间：{ts}")
            if preview:
                lines.append(f"> 原文摘录：{preview}")
            if note:
                lines.append(f"\n**批注**：{note}")
            lines.append("")

    content = "\n".join(lines)
    out_file.write_text(content, encoding="utf-8")
    return {
        "ok": True,
        "path": str(out_file),
        "filename": out_file.name,
        "count": len(bookmarks),
        "content": content,
    }


class ReaderHandler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, fmt, *args):
        if sys.stdout is None:
            return
        try:
            ts = time.strftime("%H:%M:%S")
            sys.stdout.write(f"[{ts}] [ocr-dev] {args[0]}\n")
            sys.stdout.flush()
        except Exception:
            pass

    def _send_json(self, obj, status=HTTPStatus.OK):
        body = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def _send_bytes(self, data: bytes, content_type: str, status=HTTPStatus.OK):
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-cache")
        self.end_headers()
        self.wfile.write(data)

    def _read_json_body(self):
        length = int(self.headers.get("Content-Length") or "0")
        raw = self.rfile.read(length) if length > 0 else b"{}"
        return json.loads(raw.decode("utf-8"))

    def do_GET(self):
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path
        qs = urllib.parse.parse_qs(parsed.query)

        try:
            if path == "/api/health":
                st = load_state()
                files = scan_novel_files()
                ver = compute_library_version(files, get_filter_signature(st))
                self._send_json({
                    "ok": True,
                    "app": "ocr-reader",
                    "pid": os.getpid(),
                    "version": ver,
                    "bookCount": len(files),
                })
                return

            if path == "/api/state":
                self._send_json(load_state())
                return

            if path == "/api/books":
                st = load_state()
                files = scan_novel_files()
                ver = compute_library_version(files, get_filter_signature(st))
                progress_map = st.get("progress") or {}
                book_secs = (st.get("stats") or {}).get("bookSeconds") or {}
                out = []
                for f in files:
                    pinfo = progress_map.get(f["name"]) or {}
                    out.append({
                        "name": f["name"],
                        "ext": f["ext"],
                        "size": f["size"],
                        "mtime": int(f["mtime_ns"] // 1_000_000),
                        "percent": pinfo.get("percent", 0),
                        "ch": pinfo.get("ch", 0),
                        "readSeconds": book_secs.get(f["name"], 0),
                    })
                self._send_json({
                    "version": ver,
                    "books": out,
                    "lastBook": st.get("lastBook", ""),
                })
                return

            if path == "/api/book/toc":
                name = (qs.get("name") or [""])[0]
                book = get_parsed_book(name)
                self._send_json({
                    "name": book["name"],
                    "ext": book["ext"],
                    "totalChars": book["totalChars"],
                    "chapterCount": book["chapterCount"],
                    "toc": book["toc"],
                })
                return

            if path == "/api/book/chapter":
                name = (qs.get("name") or [""])[0]
                ch_idx = int((qs.get("ch") or ["0"])[0])
                book = get_parsed_book(name)
                if ch_idx < 0 or ch_idx >= book["chapterCount"]:
                    ch_idx = 0
                ch = book["chapters"][ch_idx]
                toc_item = book["toc"][ch_idx]
                self._send_json({
                    "name": book["name"],
                    "ch": ch_idx,
                    "chapterCount": book["chapterCount"],
                    "totalChars": book["totalChars"],
                    "title": ch["title"],
                    "chars": toc_item["chars"],
                    "startChar": toc_item["startChar"],
                    "paras": ch["paras"],
                })
                return

            if path == "/api/search":
                name = (qs.get("name") or [""])[0]
                q = (qs.get("q") or [""])[0].strip()
                mode = (qs.get("mode") or ["content"])[0]
                scope = (qs.get("scope") or ["book"])[0]
                if not q:
                    self._send_json({"results": []})
                    return

                st = load_state()
                q_low = q.lower()
                results = []
                max_hits = 120

                target_names = [name] if (scope == "book" and name) else [f["name"] for f in scan_novel_files()]
                for bname in target_names:
                    try:
                        book = get_parsed_book(bname, st)
                    except Exception:
                        continue
                    for c_idx, ch in enumerate(book["chapters"]):
                        if mode == "chapters":
                            if q_low in ch["title"].lower():
                                results.append({
                                    "book": bname,
                                    "ch": c_idx,
                                    "chTitle": ch["title"],
                                    "paraIdx": -1,
                                    "snippet": ch["title"],
                                })
                                if len(results) >= max_hits:
                                    break
                        else:
                            for p_idx, p in enumerate(ch["paras"]):
                                pos = p.lower().find(q_low)
                                if pos >= 0:
                                    start = max(0, pos - 18)
                                    end = min(len(p), pos + len(q) + 28)
                                    snip = ("…" if start > 0 else "") + p[start:end] + ("…" if end < len(p) else "")
                                    results.append({
                                        "book": bname,
                                        "ch": c_idx,
                                        "chTitle": ch["title"],
                                        "paraIdx": p_idx,
                                        "snippet": snip,
                                    })
                                    if len(results) >= max_hits:
                                        break
                        if len(results) >= max_hits:
                            break
                    if len(results) >= max_hits:
                        break

                self._send_json({"results": results})
                return

            # 静态前端文件服务（仅允许根目录静态资产）
            if path in ("/", "/index.html"):
                target = ROOT_DIR / "index.html"
            else:
                rel = path.lstrip("/")
                if rel in ("style.css", "app.js", "snippets.js", "novels.js", "favicon.svg", "favicon.png", "favicon.ico"):
                    target = ROOT_DIR / rel
                else:
                    self._send_json({"error": "Not found"}, HTTPStatus.NOT_FOUND)
                    return

            if not target.exists():
                if target.name == "novels.js":
                    self._send_bytes(b"window.NOVELS_PACKED = [];", "application/javascript; charset=utf-8")
                    return
                self._send_json({"error": "File not found"}, HTTPStatus.NOT_FOUND)
                return

            ctype, _ = mimetypes.guess_type(str(target))
            if target.suffix == ".js":
                ctype = "application/javascript; charset=utf-8"
            elif target.suffix == ".css":
                ctype = "text/css; charset=utf-8"
            elif target.suffix == ".html":
                ctype = "text/html; charset=utf-8"
            elif target.suffix == ".svg":
                ctype = "image/svg+xml"
            elif target.suffix == ".png":
                ctype = "image/png"
            elif target.suffix == ".ico":
                ctype = "image/x-icon"
            self._send_bytes(target.read_bytes(), ctype or "application/octet-stream")

        except FileNotFoundError as e:
            self._send_json({"error": f"File not found: {e}"}, HTTPStatus.NOT_FOUND)
        except ValueError as e:
            self._send_json({"error": str(e)}, HTTPStatus.BAD_REQUEST)
        except Exception as e:
            self._send_json({"error": f"Internal error: {e}"}, HTTPStatus.INTERNAL_SERVER_ERROR)

    def do_POST(self):
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path

        try:
            if path == "/api/state":
                body = self._read_json_body()
                with STATE_LOCK:
                    st = load_state()
                    for k in ("settings", "lastBook", "bookmarks", "cleanEnabled", "customFilterWords"):
                        if k in body:
                            st[k] = body[k]
                    if isinstance(body.get("progress"), dict):
                        st["progress"].update(body["progress"])
                    save_state(st)
                self._send_json({"ok": True})
                return

            if path == "/api/progress":
                body = self._read_json_body()
                book_name = body.get("book")
                if not book_name:
                    raise ValueError("Missing book name")
                with STATE_LOCK:
                    st = load_state()
                    st["lastBook"] = book_name
                    st["progress"][book_name] = {
                        "ch": int(body.get("ch", 0)),
                        "line": int(body.get("line", 0)),
                        "percent": round(float(body.get("percent", 0.0)), 2),
                        "updatedAt": int(time.time()),
                    }
                    save_state(st)
                self._send_json({"ok": True})
                return

            if path == "/api/stats/tick":
                body = self._read_json_body()
                secs = max(0, min(120, int(body.get("seconds", 0))))
                chars = max(0, min(50000, int(body.get("chars", 0))))
                book_name = body.get("book") or ""
                today = time.strftime("%Y-%m-%d")
                with STATE_LOCK:
                    st = load_state()
                    stats = st["stats"]
                    if secs > 0:
                        stats["dailySeconds"][today] = int(stats["dailySeconds"].get(today, 0)) + secs
                        if book_name:
                            stats["bookSeconds"][book_name] = int(stats["bookSeconds"].get(book_name, 0)) + secs
                    if chars > 0:
                        stats["totalCharsRead"] = int(stats.get("totalCharsRead", 0)) + chars
                        if secs >= 5:
                            instant_cpm = chars / (secs / 60.0)
                            if 80 <= instant_cpm <= 2500:
                                old_cpm = float(stats.get("readingSpeedCpm", 450))
                                stats["readingSpeedCpm"] = round(old_cpm * 0.8 + instant_cpm * 0.2)
                    save_state(st)
                    res_stats = dict(stats)
                self._send_json({"ok": True, "stats": res_stats, "today": today})
                return

            if path == "/api/upload":
                raw_name = urllib.parse.unquote(self.headers.get("X-Filename") or "")
                fname = sanitize_upload_name(raw_name)
                length = int(self.headers.get("Content-Length") or "0")
                if length <= 0 or length > 100 * 1024 * 1024:
                    raise ValueError("Invalid file size (0 - 100MB)")
                data = self.rfile.read(length)
                target = safe_novel_path(fname)
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(data)
                with CACHE_LOCK:
                    BOOK_CACHE.pop(fname, None)
                book = get_parsed_book(fname)
                self._send_json({
                    "ok": True,
                    "name": book["name"],
                    "chapterCount": book["chapterCount"],
                    "totalChars": book["totalChars"],
                })
                return

            if path == "/api/book/rename":
                body = self._read_json_body()
                old_name = body.get("oldName") or ""
                new_base = sanitize_upload_name(body.get("newName") or "")
                old_path = safe_novel_path(old_name)
                if not old_path.exists():
                    raise FileNotFoundError(old_name)
                new_rel = (old_path.parent.relative_to(NOVELS_DIR.resolve()) / new_base).as_posix()
                if new_rel.startswith("./"):
                    new_rel = new_rel[2:]
                new_path = safe_novel_path(new_rel)
                if new_path.exists() and new_path != old_path:
                    raise ValueError("Target filename already exists")
                old_path.rename(new_path)
                with CACHE_LOCK:
                    BOOK_CACHE.pop(old_name, None)
                    BOOK_CACHE.pop(new_rel, None)
                with STATE_LOCK:
                    st = load_state()
                    if old_name in st["progress"]:
                        st["progress"][new_rel] = st["progress"].pop(old_name)
                    if st.get("lastBook") == old_name:
                        st["lastBook"] = new_rel
                    for bm in st.get("bookmarks") or []:
                        if bm.get("book") == old_name:
                            bm["book"] = new_rel
                    bs = st["stats"].get("bookSeconds") or {}
                    if old_name in bs:
                        bs[new_rel] = bs.pop(old_name)
                    save_state(st)
                self._send_json({"ok": True, "newName": new_rel})
                return

            if path == "/api/book/delete":
                body = self._read_json_body()
                name = body.get("name") or ""
                target = safe_novel_path(name)
                if not target.exists():
                    raise FileNotFoundError(name)
                target.unlink()
                with CACHE_LOCK:
                    BOOK_CACHE.pop(name, None)
                self._send_json({"ok": True})
                return

            if path == "/api/notes/export":
                body = self._read_json_body()
                book_name = body.get("book") or ""
                if not book_name:
                    raise ValueError("Missing book name")
                st = load_state()
                self._send_json(export_book_notes(book_name, st))
                return

            if path == "/api/shutdown":
                self._send_json({"ok": True})
                threading.Thread(target=self.server.shutdown, daemon=True).start()
                return

            self._send_json({"error": "Unknown endpoint"}, HTTPStatus.NOT_FOUND)
        except FileNotFoundError as e:
            self._send_json({"error": f"File not found: {e}"}, HTTPStatus.NOT_FOUND)
        except ValueError as e:
            self._send_json({"error": str(e)}, HTTPStatus.BAD_REQUEST)
        except Exception as e:
            self._send_json({"error": f"Internal error: {e}"}, HTTPStatus.INTERNAL_SERVER_ERROR)


def check_existing_instance(port: int) -> bool:
    url = f"http://127.0.0.1:{port}/api/health"
    try:
        with urllib.request.urlopen(url, timeout=0.6) as resp:
            data = json.loads(resp.read().decode("utf-8"))
            return bool(data.get("ok") and data.get("app") == "ocr-reader")
    except Exception:
        return False


def pick_free_port(preferred: int) -> int:
    for p in range(preferred, preferred + 30):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            try:
                s.bind(("127.0.0.1", p))
                return p
            except OSError:
                continue
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


def find_chromium_exe():
    candidates = [
        r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
        r"C:\Program Files\Microsoft\Edge\Application\msedge.exe",
        r"C:\Program Files\Google\Chrome\Application\chrome.exe",
        r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
    ]
    for c in candidates:
        if os.path.exists(c):
            return c
    for name in ("msedge", "chrome", "chromium"):
        found = shutil.which(name)
        if found:
            return found
    return None


def launch_client(url: str, mode: str):
    if mode == "app":
        exe = find_chromium_exe()
        if exe:
            try:
                subprocess.Popen(
                    [exe, f"--app={url}", "--window-size=1520,880"],
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                )
                return
            except Exception:
                pass
    webbrowser.open(url)


def read_saved_port():
    try:
        if PORT_FILE.exists():
            return int(PORT_FILE.read_text(encoding="utf-8").strip())
    except Exception:
        pass
    return None


def write_saved_port(port: int):
    try:
        ensure_dirs()
        PORT_FILE.write_text(str(port), encoding="utf-8")
    except Exception:
        pass


def clear_saved_port(port: int):
    try:
        if read_saved_port() == port and PORT_FILE.exists():
            PORT_FILE.unlink()
    except Exception:
        pass


def stop_running_instances(base_port: int) -> int:
    candidates = []
    saved = read_saved_port()
    if saved:
        candidates.append(saved)
    if base_port not in candidates:
        candidates.append(base_port)

    stopped = 0
    for p in candidates:
        if check_existing_instance(p):
            try:
                req = urllib.request.Request(
                    f"http://127.0.0.1:{p}/api/shutdown",
                    data=b"{}",
                    headers={"Content-Type": "application/json"},
                    method="POST",
                )
                with urllib.request.urlopen(req, timeout=1.0):
                    stopped += 1
                clear_saved_port(p)
            except Exception:
                pass
    return stopped


def main():
    # 适配 pythonw.exe 无控制台模式（避免 stdout/stderr 为 None 导致写入报错）
    if sys.stdout is None:
        sys.stdout = open(os.devnull, "w", encoding="utf-8")
    if sys.stderr is None:
        sys.stderr = open(os.devnull, "w", encoding="utf-8")

    parser = argparse.ArgumentParser(description="OCR Dataset Dev Server (Local Reader)")
    parser.add_argument("--port", type=int, default=DEFAULT_PORT)
    parser.add_argument("--mode", choices=["app", "browser", "none"], default="app")
    parser.add_argument("--stop", action="store_true", help="Stop running local server instances")
    args = parser.parse_args()

    if args.stop:
        n = stop_running_instances(args.port)
        print(f"[ocr-dev] Stopped {n} active instance(s).")
        return

    ensure_dirs()

    # 若已有本服务在运行（优先查记录端口或默认端口），直接打开新窗口复用实例
    for existing_p in [read_saved_port(), args.port]:
        if existing_p and check_existing_instance(existing_p):
            url = f"http://127.0.0.1:{existing_p}/"
            print(f"[ocr-dev] Active workspace server detected at {url}, opening client...")
            if args.mode != "none":
                launch_client(url, args.mode)
            return

    port = pick_free_port(args.port)
    server = ThreadingHTTPServer(("127.0.0.1", port), ReaderHandler)
    write_saved_port(port)
    url = f"http://127.0.0.1:{port}/"
    print(f"[ocr-dev] Starting PyCharm OCR Dataset Service on {url} (127.0.0.1 only)")
    print(f"[ocr-dev] Watching datasets directory: {NOVELS_DIR}")
    print("[ocr-dev] Press Ctrl+C to stop service.")

    if args.mode != "none":
        threading.Timer(0.35, launch_client, args=(url, args.mode)).start()

    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\n[ocr-dev] Shutting down server cleanly.")
    finally:
        server.server_close()
        clear_saved_port(port)


if __name__ == "__main__":
    main()
