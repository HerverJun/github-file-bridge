(function () {
  "use strict";

  const DEFAULT_SETTINGS = {
    linesPerPage: 15,
    fontSize: 14,
    maxCols: 100,
    style: "#",
    italic: false,
    brightness: 100,
    paraGap: true,
    wheelMode: "step", // "step" | "page" | "off"
    typingMode: false,
    autoBossOnBlur: false,
    leftWidth: 260,
    bottomHeight: 168
  };

  // JetBrains Darcula 风格内联矢量图标
  const ICONS = {
    folder: `<svg viewBox="0 0 16 16" width="14" height="14"><path d="M1.5 3.5h4.2l1.3 1.5h7.5v8h-13z" fill="#8C9BA5" fill-opacity="0.85"/></svg>`,
    folderOpen: `<svg viewBox="0 0 16 16" width="14" height="14"><path d="M1.5 3.5h4.2l1.3 1.5h7.5v2H2.5L1.5 13z" fill="#8C9BA5"/><path d="M2.6 6.8h12.2l-1.3 6.2H1.5z" fill="#9AA7B0" fill-opacity="0.9"/></svg>`,
    py: `<svg viewBox="0 0 16 16" width="14" height="14"><path d="M7.9 1.8c-2.5 0-2.3 1.1-2.3 1.1v1.3h2.4v.4H4.6S2.8 4.4 2.8 7s1.5 2.5 1.5 2.5h.9V8.3s-.1-1.5 1.5-1.5h2.5s1.4 0 1.4-1.4V3.2s.2-1.4-2.7-1.4zM6.5 2.7a.5.5 0 1 1 0 1 .5.5 0 0 1 0-1z" fill="#3C87C6"/><path d="M8.1 14.2c2.5 0 2.3-1.1 2.3-1.1v-1.3H8v-.4h3.4s1.8.2 1.8-2.4-1.5-2.5-1.5-2.5h-.9v1.2s.1 1.5-1.5 1.5H6.8s-1.4 0-1.4 1.4v2.2s-.2 1.4 2.7 1.4zm1.4-.9a.5.5 0 1 1 0-1 .5.5 0 0 1 0 1z" fill="#E6C24C"/></svg>`,
    yml: `<svg viewBox="0 0 16 16" width="14" height="14"><rect x="2.5" y="2" width="11" height="12" rx="1" fill="none" stroke="#CB772F" stroke-width="1.2"/><path d="M5 5.5h6M5 8h4.5M5 10.5h5.5" stroke="#CB772F" stroke-width="1.2" stroke-linecap="round"/></svg>`,
    txt: `<svg viewBox="0 0 16 16" width="14" height="14"><path d="M3.5 2h6l3 3v9h-9z" fill="none" stroke="#9AA7B0" stroke-width="1.2"/><path d="M5.5 7h5M5.5 9.5h5M5.5 12h3.5" stroke="#8C9BA5" stroke-width="1.1"/></svg>`,
    md: `<svg viewBox="0 0 16 16" width="14" height="14"><rect x="2" y="3" width="12" height="10" rx="1.2" fill="none" stroke="#548AF7" stroke-width="1.2"/><path d="M4.2 10.5v-5l2 2.5 2-2.5v5M10.2 8.2l1.6 2 1.6-2M11.8 5.5v4.5" fill="none" stroke="#548AF7" stroke-width="1.1" stroke-linecap="round" stroke-linejoin="round"/></svg>`,
    lib: `<svg viewBox="0 0 16 16" width="14" height="14"><rect x="2.5" y="2.5" width="3" height="11" fill="#A97744"/><rect x="6.5" y="3.5" width="3" height="10" fill="#8C6843"/><path d="M10.5 3l2.8.5-1.2 10-2.8-.5z" fill="#B58958"/></svg>`,
    cls: `<svg viewBox="0 0 16 16" width="14" height="14"><circle cx="8" cy="8" r="6" fill="#4B7B99"/><text x="8" y="11" text-anchor="middle" fill="#EAEAEA" font-size="8.5" font-family="sans-serif" font-weight="700">C</text></svg>`,
    method: `<svg viewBox="0 0 16 16" width="14" height="14"><circle cx="8" cy="8" r="5.6" fill="#8C5FA8"/><text x="8" y="10.8" text-anchor="middle" fill="#F0F0F0" font-size="8" font-family="sans-serif" font-weight="700">m</text></svg>`
  };

  const SNIPPETS = Array.isArray(window.SNIPPETS) ? window.SNIPPETS : [];
  const SNIPPET_BY_FILE = new Map(SNIPPETS.map((s, i) => [s.file, i]));

  const state = {
    serverMode: false,
    libraryVersion: "",
    books: [], // 统一书目数组
    dirBooks: [],
    importedBooks: [],
    progressMap: loadLocalJson("moyu.progress", {}),
    lastBook: loadLocalStr("moyu.lastBook", ""),
    cur: { book: 0, ch: 0, line: 0 },
    activeChapter: null, // { title, paras, chars, startChar }
    wrappedLines: [],
    boss: false,
    settings: Object.assign({}, DEFAULT_SETTINGS, loadLocalJson("moyu.settings", {})),
    cleanEnabled: true,
    customFilterWords: [],
    stats: loadLocalJson("moyu.stats", {
      dailySeconds: {},
      bookSeconds: {},
      totalCharsRead: 0,
      readingSpeedCpm: 450
    }),
    lastActiveTs: Date.now(),
    pendingChars: 0,
    snippetOverride: null,
    pendingAuthHint: false,
    leftView: "project",
    bottomPane: "run",
    find: { open: false, mode: "chapters", scope: "book", query: "", results: [], idx: -1 },
    bookmarks: loadLocalJson("moyu.bookmarks", []),
    termHistory: [],
    termHistIdx: -1,
    logEpoch: 12,
    logIter: 340
  };

  const el = {
    menuFile: document.getElementById("menu-file"),
    fileDropdown: document.getElementById("file-dropdown"),
    actOpenFolder: document.getElementById("act-open-folder"),
    actImportFiles: document.getElementById("act-import-files"),
    actReloadFolder: document.getElementById("act-reload-folder"),
    actAddBookmark: document.getElementById("act-add-bookmark"),
    actExportNotes: document.getElementById("act-export-notes"),
    actOpenLibrary: document.getElementById("act-open-library"),
    actOpenSettings: document.getElementById("act-open-settings"),
    actExit: document.getElementById("act-exit"),
    menuEdit: document.getElementById("menu-edit"),
    menuNavigate: document.getElementById("menu-navigate"),
    menuTools: document.getElementById("menu-tools"),
    menuHelp: document.getElementById("menu-help"),
    titlePath: document.getElementById("title-path"),
    breadcrumbs: document.getElementById("breadcrumbs"),
    btnRunSim: document.getElementById("btn-run-sim"),
    btnFind: document.getElementById("btn-find"),
    btnSettings: document.getElementById("btn-settings"),
    tabLeftProject: document.getElementById("tab-left-project"),
    tabLeftStructure: document.getElementById("tab-left-structure"),
    tabRightSciview: document.getElementById("tab-right-sciview"),
    leftPanelTitle: document.getElementById("left-panel-title"),
    projectPanel: document.getElementById("project-panel"),
    projectTree: document.getElementById("project-tree"),
    structurePane: document.getElementById("structure-pane"),
    structureBookSelect: document.getElementById("structure-book-select"),
    structureTree: document.getElementById("structure-tree"),
    resizerLeft: document.getElementById("resizer-left"),
    resizerBottom: document.getElementById("resizer-bottom"),
    editorTabs: document.getElementById("editor-tabs"),
    findWrap: document.getElementById("find-wrap"),
    findInput: document.getElementById("find-input"),
    findModeCh: document.getElementById("find-mode-ch"),
    findModeText: document.getElementById("find-mode-text"),
    findScopeAll: document.getElementById("find-scope-all"),
    findCount: document.getElementById("find-count"),
    findPrev: document.getElementById("find-prev"),
    findNext: document.getElementById("find-next"),
    findClose: document.getElementById("find-close"),
    findResultsPanel: document.getElementById("find-results-panel"),
    codeViewport: document.getElementById("code-viewport"),
    inspNovelMark: document.getElementById("insp-novel-mark"),
    runPanel: document.getElementById("run-panel"),
    bottomPanelTitle: document.getElementById("bottom-panel-title"),
    paneRun: document.getElementById("pane-run"),
    paneTodo: document.getElementById("pane-todo"),
    paneTerminal: document.getElementById("pane-terminal"),
    paneConsole: document.getElementById("pane-console"),
    runLogs: document.getElementById("run-logs"),
    todoList: document.getElementById("todo-list"),
    btnTodoAdd: document.getElementById("btn-todo-add"),
    btnTodoExport: document.getElementById("btn-todo-export"),
    terminalWrap: document.getElementById("terminal-wrap"),
    terminalOutput: document.getElementById("terminal-output"),
    terminalInput: document.getElementById("terminal-input"),
    bottomTabs: Array.from(document.querySelectorAll(".bottom-tab")),
    statusLeft: document.getElementById("status-left"),
    statusSrvBadge: document.getElementById("status-srv-badge"),
    statusTypingBadge: document.getElementById("status-typing-badge"),
    statusPos: document.getElementById("status-pos"),
    statusMem: document.getElementById("status-mem"),
    dropOverlay: document.getElementById("drop-overlay"),
    fallbackInput: document.getElementById("fallback-dir-input"),
    importFilesInput: document.getElementById("import-files-input"),
    gotoModal: document.getElementById("goto-modal"),
    gotoInput: document.getElementById("goto-input"),
    gotoMax: document.getElementById("goto-max"),
    gotoOk: document.getElementById("goto-ok"),
    gotoCancel: document.getElementById("goto-cancel"),
    bookmarkModal: document.getElementById("bookmark-modal"),
    bmPreviewText: document.getElementById("bm-preview-text"),
    bmNoteInput: document.getElementById("bm-note-input"),
    bmOk: document.getElementById("bm-ok"),
    bmCancel: document.getElementById("bm-cancel"),
    settingsModal: document.getElementById("settings-modal"),
    sTabs: Array.from(document.querySelectorAll(".s-tab")),
    stabAppearance: document.getElementById("stab-appearance"),
    stabReading: document.getElementById("stab-reading"),
    stabLibrary: document.getElementById("stab-library"),
    stabStats: document.getElementById("stab-stats"),
    setLines: document.getElementById("set-lines"),
    setFontsize: document.getElementById("set-fontsize"),
    setMaxcols: document.getElementById("set-maxcols"),
    setStyle: document.getElementById("set-style"),
    setBrightness: document.getElementById("set-brightness"),
    setBrightnessVal: document.getElementById("set-brightness-val"),
    setParagap: document.getElementById("set-paragap"),
    setItalic: document.getElementById("set-italic"),
    setWheel: document.getElementById("set-wheel"),
    setTyping: document.getElementById("set-typing"),
    setAutoblur: document.getElementById("set-autoblur"),
    setCleanEnabled: document.getElementById("set-clean-enabled"),
    setFilterWords: document.getElementById("set-filter-words"),
    statsCards: document.getElementById("stats-cards"),
    statsBars: document.getElementById("stats-bars"),
    libImportBtn: document.getElementById("lib-import-btn"),
    libFolderBtn: document.getElementById("lib-folder-btn"),
    libList: document.getElementById("lib-list"),
    setReset: document.getElementById("set-reset"),
    setOk: document.getElementById("set-ok"),
    setCancel: document.getElementById("set-cancel")
  };

  // ---------------- 基础存取与后端 API ----------------
  function loadLocalJson(key, fallback) {
    try {
      const raw = localStorage.getItem(key);
      return raw ? JSON.parse(raw) : fallback;
    } catch (_) {
      return fallback;
    }
  }

  function loadLocalStr(key, fallback) {
    try {
      const v = localStorage.getItem(key);
      return v !== null ? v : fallback;
    } catch (_) {
      return fallback;
    }
  }

  function saveLocal(key, val) {
    try {
      localStorage.setItem(key, typeof val === "string" ? val : JSON.stringify(val));
    } catch (_) {}
  }

  async function apiGet(url) {
    const resp = await fetch(url, { cache: "no-store" });
    const data = await resp.json();
    if (!resp.ok) throw new Error(data.error || "API error");
    return data;
  }

  async function apiPost(url, payload) {
    const resp = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json; charset=utf-8" },
      body: JSON.stringify(payload || {})
    });
    const data = await resp.json();
    if (!resp.ok) throw new Error(data.error || "API error");
    return data;
  }

  function persistStatePatch(patch) {
    if (patch.settings) saveLocal("moyu.settings", patch.settings);
    if (patch.bookmarks) saveLocal("moyu.bookmarks", patch.bookmarks);
    if (patch.lastBook !== undefined) saveLocal("moyu.lastBook", patch.lastBook);
    if (state.serverMode) {
      apiPost("/api/state", patch).catch(() => {});
    }
  }

  let progressSyncTimer = null;
  function saveCurrentProgress() {
    const book = state.books[state.cur.book];
    if (!book) return;
    const pct = computeBookPercent();
    const rec = {
      ch: state.cur.ch,
      line: state.cur.line,
      percent: pct,
      updatedAt: Math.floor(Date.now() / 1000)
    };
    state.progressMap[book.name] = rec;
    state.lastBook = book.name;
    book.percent = pct;
    book.ch = state.cur.ch;
    saveLocal("moyu.progress", state.progressMap);
    saveLocal("moyu.lastBook", book.name);

    if (state.serverMode) {
      clearTimeout(progressSyncTimer);
      progressSyncTimer = setTimeout(() => {
        apiPost("/api/progress", {
          book: book.name,
          ch: rec.ch,
          line: rec.line,
          percent: rec.percent
        }).catch(() => {});
      }, 220);
    }
  }

  function applyVisualSettings() {
    document.documentElement.style.setProperty("--editor-font-size", state.settings.fontSize + "px");
    const factor = (state.settings.brightness || 100) / 100;
    const clampByte = (v) => Math.max(45, Math.min(220, Math.round(v)));
    const g = clampByte(128 * factor);
    document.documentElement.style.setProperty("--novel-cmt-color", `rgb(${g}, ${g}, ${g})`);
    document.documentElement.style.setProperty(
      "--novel-doc-color",
      `rgb(${clampByte(98 * factor)}, ${clampByte(151 * factor)}, ${clampByte(85 * factor)})`
    );
    if (state.settings.leftWidth) el.projectPanel.style.width = state.settings.leftWidth + "px";
    if (state.settings.bottomHeight) el.runPanel.style.height = state.settings.bottomHeight + "px";
    el.statusTypingBadge.classList.toggle("hidden", !state.settings.typingMode);
    el.statusSrvBadge.classList.toggle("hidden", !state.serverMode);
    el.findScopeAll.classList.toggle("hidden", !state.serverMode);
  }

  // ---------------- 阅读进度与时间估算 ----------------
  function computeBookPercent() {
    const book = state.books[state.cur.book];
    if (!book) return 0;
    const totalChars = book.totalChars || 0;
    const chObj = state.activeChapter;
    if (totalChars > 0 && chObj) {
      const lineRatio = state.wrappedLines.length > 0
        ? Math.min(1, (state.cur.line + state.settings.linesPerPage) / state.wrappedLines.length)
        : 0;
      const readChars = (chObj.startChar || 0) + Math.round((chObj.chars || 0) * lineRatio);
      return Math.min(100, Math.round((readChars / totalChars) * 1000) / 10);
    }
    const chCount = book.chapterCount || (book.toc ? book.toc.length : 1);
    return Math.min(100, Math.round(((state.cur.ch + 1) / Math.max(1, chCount)) * 1000) / 10);
  }

  function estimateChapterRemainMinutes() {
    const chObj = state.activeChapter;
    if (!chObj || !chObj.chars) return 0;
    const totalLines = Math.max(1, state.wrappedLines.length);
    const remainRatio = Math.max(0, 1 - (state.cur.line + state.settings.linesPerPage) / totalLines);
    const remainChars = Math.round(chObj.chars * remainRatio);
    const cpm = Math.max(120, Number(state.stats.readingSpeedCpm) || 450);
    return Math.max(remainChars > 60 ? 1 : 0, Math.round(remainChars / cpm));
  }

  function getTodayKey() {
    const d = new Date();
    const pad = (n) => String(n).padStart(2, "0");
    return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
  }

  function formatDuration(sec) {
    const s = Math.max(0, Math.floor(sec || 0));
    const h = Math.floor(s / 3600);
    const m = Math.floor((s % 3600) / 60);
    if (h > 0) return `${h}h ${m}m`;
    if (m > 0) return `${m} 分钟`;
    return `${s} 秒`;
  }

  // ---------------- 离线解码与解析（兼容 file:// 降级） ----------------
  function decodeBuffer(buf) {
    const u8 = new Uint8Array(buf);
    let view = u8;
    if (u8.length >= 3 && u8[0] === 0xef && u8[1] === 0xbb && u8[2] === 0xbf) view = u8.subarray(3);
    try {
      return new TextDecoder("utf-8", { fatal: true }).decode(view);
    } catch (_) {
      return new TextDecoder("gb18030").decode(view);
    }
  }

  function cleanMarkdownLine(line) {
    return line
      .replace(/!\[[^\]]*\]\([^)]*\)/g, "")
      .replace(/\[([^\]]+)\]\([^)]*\)/g, "$1")
      .replace(/(\*\*|__|~~|`)/g, "")
      .replace(/^\s*>\s?/, "")
      .replace(/^\s*[-*+]\s+/, "");
  }

  function trimFull(str) {
    return str.replace(/^[\s\u3000]+|[\s\u3000]+$/g, "");
  }

  function parseBookClient(name, rawText, source) {
    const isMd = /\.md$/i.test(name);
    const lines = String(rawText || "").replace(/\r\n?/g, "\n").split("\n");
    const mdHeadingRe = /^\s*#{1,6}\s+.+$/;
    const hasMdHeadings = isMd && lines.slice(0, 200).some((l) => mdHeadingRe.test(l));
    const chapterRe = /^\s*(第[0-9０-９零一二三四五六七八九十百千万两〇]+[章节回卷集部篇幕].{0,36}|(?:楔子|序章|序言|引子|尾声|番外).{0,24}|Chapter\s+\d+.{0,36}|#{1,6}\s+.+)\s*$/i;
    const chapters = [];
    let current = null;

    for (let i = 0; i < lines.length; i++) {
      let rawLine = lines[i];
      const trimmed = trimFull(rawLine);
      if (!trimmed) continue;

      const isHeading = hasMdHeadings
        ? trimmed.length <= 120 && mdHeadingRe.test(trimmed)
        : (trimmed.length <= 120 && mdHeadingRe.test(trimmed)) || (trimmed.length <= 44 && chapterRe.test(trimmed));

      if (isHeading) {
        let title = trimmed.replace(/^#{1,6}\s+/, "");
        if (isMd) title = trimFull(cleanMarkdownLine(title));
        current = { title: title || "章节", paras: [] };
        chapters.push(current);
        continue;
      }
      if (isMd) rawLine = cleanMarkdownLine(rawLine);
      const para = trimFull(rawLine);
      if (!para) continue;
      if (!current) {
        current = { title: "前言", paras: [] };
        chapters.push(current);
      }
      current.paras.push(para);
    }

    if (chapters.length === 1 && chapters[0].title === "前言") {
      const allParas = chapters[0].paras;
      const chunks = [];
      let bufParas = [];
      let charCount = 0;
      for (const p of allParas) {
        bufParas.push(p);
        charCount += p.length;
        if (charCount >= 3000) {
          chunks.push({ title: "Part " + (chunks.length + 1), paras: bufParas });
          bufParas = [];
          charCount = 0;
        }
      }
      if (bufParas.length > 0 || chunks.length === 0) {
        chunks.push({ title: "Part " + (chunks.length + 1), paras: bufParas });
      }
      return finalizeClientBook(name, chunks, source);
    }

    if (chapters.length === 0) {
      chapters.push({ title: "空文件", paras: ["（文件内容为空）"] });
    }
    return finalizeClientBook(name, chapters, source);
  }

  function finalizeClientBook(name, chapters, source) {
    let totalChars = 0;
    const toc = chapters.map((ch, idx) => {
      const chars = ch.paras.reduce((a, p) => a + p.length, 0);
      const item = { idx, title: ch.title, chars, startChar: totalChars };
      totalChars += chars;
      return item;
    });
    const m = name.match(/\.[a-z0-9]+$/i);
    return {
      name,
      ext: m ? m[0].toLowerCase() : ".txt",
      source: source || "packed",
      totalChars,
      chapterCount: chapters.length,
      toc,
      chapters,
      chapterCache: null
    };
  }

  // ---------------- 统一书目章节按需加载（支持服务端懒加载 + 离线按书懒解析） ----------------
  function loadScriptOnce(src) {
    return new Promise((resolve) => {
      if (Array.isArray(window.NOVELS_PACKED)) return resolve();
      const s = document.createElement("script");
      s.src = src;
      s.charset = "utf-8";
      s.onload = () => resolve();
      s.onerror = () => resolve();
      document.head.appendChild(s);
    });
  }

  function makeLazyClientBook(name, rawText, source) {
    const m = name.match(/\.[a-z0-9]+$/i);
    return {
      name,
      ext: m ? m[0].toLowerCase() : ".txt",
      source: source || "packed",
      totalChars: 0,
      chapterCount: 0,
      toc: [],
      chapters: null,
      chapterCache: null,
      _rawText: rawText || ""
    };
  }

  async function ensureBookToc(book) {
    if (!book) return;
    if (!state.serverMode) {
      if (!book.chapters && typeof book._rawText === "string") {
        const parsed = parseBookClient(book.name, book._rawText, book.source);
        book.toc = parsed.toc;
        book.chapters = parsed.chapters;
        book.totalChars = parsed.totalChars;
        book.chapterCount = parsed.chapterCount;
        book._rawText = null;
      }
      return;
    }
    if (book.toc && book.toc.length > 0) return;
    const data = await apiGet(`/api/book/toc?name=${encodeURIComponent(book.name)}`);
    book.toc = data.toc || [];
    book.totalChars = data.totalChars || 0;
    book.chapterCount = data.chapterCount || book.toc.length;
  }

  async function fetchServerChapter(book, chIdx) {
    if (!book.chapterCache) book.chapterCache = {};
    if (book.chapterCache[chIdx]) return book.chapterCache[chIdx];
    const data = await apiGet(`/api/book/chapter?name=${encodeURIComponent(book.name)}&ch=${chIdx}`);
    const chObj = {
      title: data.title,
      paras: data.paras || [],
      chars: data.chars || 0,
      startChar: data.startChar || 0
    };
    book.chapterCache[chIdx] = chObj;
    book.chapterCount = data.chapterCount || book.chapterCount;
    book.totalChars = data.totalChars || book.totalChars;
    return chObj;
  }

  async function loadAndRenderChapter(bookIdx, chIdx, targetLine, resetToEnd) {
    const book = state.books[bookIdx];
    if (!book) {
      state.activeChapter = null;
      state.wrappedLines = [];
      renderAllViews();
      return;
    }

    await ensureBookToc(book);
    const maxCh = Math.max(0, (book.chapterCount || 1) - 1);
    const safeCh = Math.max(0, Math.min(maxCh, chIdx));
    state.cur.book = bookIdx;
    state.cur.ch = safeCh;

    let chObj = null;
    if (state.serverMode) {
      chObj = await fetchServerChapter(book, safeCh);
      // 后台静默预取下一章，翻章零等待
      if (safeCh + 1 <= maxCh && !book.chapterCache[safeCh + 1]) {
        fetchServerChapter(book, safeCh + 1).catch(() => {});
      }
    } else {
      const rawCh = book.chapters[safeCh] || book.chapters[0];
      const tocItem = book.toc[safeCh] || { chars: 0, startChar: 0 };
      chObj = {
        title: rawCh.title,
        paras: rawCh.paras,
        chars: tocItem.chars,
        startChar: tocItem.startChar
      };
    }

    state.activeChapter = chObj;
    computeWrappedLines();
    if (resetToEnd) {
      state.cur.line = Math.max(0, state.wrappedLines.length - state.settings.linesPerPage);
    } else if (typeof targetLine === "number") {
      state.cur.line = Math.max(0, Math.min(targetLine, Math.max(0, state.wrappedLines.length - 1)));
    }
    state.lastActiveTs = Date.now();
    saveCurrentProgress();
    renderAllViews();
  }

  async function selectBook(bookIdx) {
    const book = state.books[bookIdx];
    if (!book) return;
    const saved = state.progressMap[book.name];
    const ch = saved && typeof saved.ch === "number" ? saved.ch : 0;
    const line = saved && typeof saved.line === "number" ? saved.line : 0;
    await loadAndRenderChapter(bookIdx, ch, line, false);
  }

  // ---------------- 像素折行 ----------------
  const measureCanvas = document.createElement("canvas");
  const measureCtx = measureCanvas.getContext("2d");
  const widthCache = new Map();
  let cachedFontKey = "";

  function syncFontMeasure() {
    const fontStr = `${state.settings.fontSize}px "JetBrains Mono", Consolas, "Microsoft YaHei", monospace`;
    if (cachedFontKey !== fontStr) {
      cachedFontKey = fontStr;
      widthCache.clear();
      measureCtx.font = fontStr;
    }
  }

  function charWidth(ch) {
    let w = widthCache.get(ch);
    if (w === undefined) {
      w = measureCtx.measureText(ch).width;
      widthCache.set(ch, w);
    }
    return w;
  }

  function stringWidth(str) {
    let sum = 0;
    for (const ch of str) sum += charWidth(ch);
    return sum;
  }

  function getActiveSnippet() {
    if (SNIPPETS.length === 0) {
      return {
        file: "db_postprocess.py",
        crumbs: ["det", "db_postprocess.py"],
        lang: "py",
        startLine: 1,
        bossComments: ["OCR post-processing pipeline."],
        code: "def run():\n    # @@NOVEL@@\n    pass"
      };
    }
    if (state.snippetOverride !== null && SNIPPETS[state.snippetOverride]) {
      return SNIPPETS[state.snippetOverride];
    }
    const pySnippets = SNIPPETS.filter((s) => s.lang !== "yml");
    const pool = pySnippets.length > 0 ? pySnippets : SNIPPETS;
    return pool[state.cur.ch % pool.length];
  }

  function getMarkerIndent(snippet) {
    const m = snippet.code.match(/^([ \t]*)# @@NOVEL@@/m);
    return m ? m[1] : "";
  }

  function getMaxLinePx(snippet) {
    syncFontMeasure();
    const indent = getMarkerIndent(snippet);
    const useDoc = state.settings.style === "docstring" && snippet.lang !== "yml";
    const prefix = useDoc ? indent : indent + "# ";
    const prefixW = stringWidth(prefix);
    const viewportW = el.codeViewport.clientWidth || 900;
    const availByView = viewportW - 54 - prefixW - 30;
    const availByCols = state.settings.maxCols * charWidth("0");
    return Math.max(180, Math.min(availByView, availByCols));
  }

  function wrapParagraph(text, maxPx) {
    const out = [];
    let line = "";
    let curW = 0;
    for (const ch of text) {
      const w = charWidth(ch);
      if (line.length > 0 && curW + w > maxPx) {
        // 英文单词尽量按空格回退折行，避免截断单词
        if (/[A-Za-z0-9'-]/.test(ch) && /[A-Za-z0-9'-]$/.test(line)) {
          const spIdx = line.lastIndexOf(" ");
          if (spIdx > 0 && line.length - spIdx <= 20) {
            const head = line.slice(0, spIdx);
            const carry = line.slice(spIdx + 1) + ch;
            out.push(head);
            line = carry;
            curW = stringWidth(carry);
            continue;
          }
        }
        out.push(line);
        line = ch === " " ? "" : ch;
        curW = ch === " " ? 0 : w;
      } else {
        line += ch;
        curW += w;
      }
    }
    if (line.length > 0) out.push(line);
    return out;
  }

  function isZhEnPair(curPara, nextPara) {
    if (!curPara || !nextPara) return false;
    return /[\u4e00-\u9fff]/.test(curPara) && !/[\u4e00-\u9fff]/.test(nextPara) && /[A-Za-z]/.test(nextPara);
  }

  function computeWrappedLines() {
    const chObj = state.activeChapter;
    if (!chObj) {
      state.wrappedLines = [];
      return;
    }
    const maxPx = getMaxLinePx(getActiveSnippet());
    const result = [];
    result.push(...wrapParagraph(chObj.title || "", maxPx));
    result.push("");
    for (let i = 0; i < chObj.paras.length; i++) {
      result.push(...wrapParagraph(chObj.paras[i], maxPx));
      if (state.settings.paraGap && i < chObj.paras.length - 1) {
        // 双语对照时：中文句与紧随的英文句紧贴成组，每组结束后再插空行
        if (!isZhEnPair(chObj.paras[i], chObj.paras[i + 1])) {
          result.push("");
        }
      }
    }
    state.wrappedLines = result;
    if (state.cur.line >= result.length) {
      state.cur.line = Math.max(0, result.length - state.settings.linesPerPage);
    }
  }

  // ---------------- 语法高亮（Python + YAML + 缩进参考线） ----------------
  function escHtml(s) {
    return String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
  }

  function renderIndentGuides(rawLine) {
    const m = rawLine.match(/^( +)/);
    if (!m) return { prefixHtml: "", rest: rawLine };
    const spaces = m[1];
    const groups = Math.floor(spaces.length / 4);
    const rem = spaces.length % 4;
    let html = "";
    for (let i = 0; i < groups; i++) html += `<span class="indent-guide">    </span>`;
    if (rem > 0) html += " ".repeat(rem);
    return { prefixHtml: html, rest: rawLine.slice(spaces.length) };
  }

  const PY_TOKEN_RE = /("""|'''|#.*$|f?"(?:\\.|[^"\\])*"|f?'(?:\\.|[^'\\])*'|@[A-Za-z_][A-Za-z0-9_.]*|\b(?:def|class)\b(?=\s+[A-Za-z_])|\b(?:import|from|as|return|if|elif|else|for|while|in|not|and|or|is|None|True|False|with|try|except|finally|raise|pass|break|continue|lambda|yield|async|await)\b|\bself\b|\b(?:print|len|range|int|str|float|list|dict|tuple|set|isinstance|super|open|enumerate|zip|min|max|round|abs|sorted)\b|\b\d+(?:\.\d+)?\b)/g;

  function highlightDefIdentifier(str) {
    const dm = str.match(/^(\s+)([A-Za-z_][A-Za-z0-9_]*)(.*)$/);
    if (!dm) return escHtml(str);
    return escHtml(dm[1]) + `<span class="tok-def">${escHtml(dm[2])}</span>` + escHtml(dm[3]);
  }

  function highlightPythonSegment(segment, hlState) {
    let out = "";
    let lastIndex = 0;
    let expectDefName = false;
    PY_TOKEN_RE.lastIndex = 0;

    while (lastIndex < segment.length) {
      if (hlState.inTriple) {
        const q = hlState.inTriple;
        const endIdx = segment.indexOf(q, lastIndex);
        if (endIdx === -1) {
          out += `<span class="tok-doc">${escHtml(segment.slice(lastIndex))}</span>`;
          break;
        } else {
          const endPos = endIdx + 3;
          out += `<span class="tok-doc">${escHtml(segment.slice(lastIndex, endPos))}</span>`;
          hlState.inTriple = null;
          lastIndex = endPos;
          PY_TOKEN_RE.lastIndex = lastIndex;
          continue;
        }
      }

      const m = PY_TOKEN_RE.exec(segment);
      if (!m) {
        const rest = segment.slice(lastIndex);
        out += expectDefName ? highlightDefIdentifier(rest) : escHtml(rest);
        break;
      }

      if (m.index > lastIndex) {
        const gap = segment.slice(lastIndex, m.index);
        if (expectDefName) {
          const dm = gap.match(/^(\s+)([A-Za-z_][A-Za-z0-9_]*)(.*)$/);
          if (dm) {
            out += escHtml(dm[1]) + `<span class="tok-def">${escHtml(dm[2])}</span>` + escHtml(dm[3]);
            expectDefName = false;
          } else {
            out += escHtml(gap);
          }
        } else {
          out += escHtml(gap);
        }
      }

      const tok = m[0];
      lastIndex = m.index + tok.length;

      if (tok === '"""' || tok === "'''") {
        const closeIdx = segment.indexOf(tok, lastIndex);
        if (closeIdx === -1) {
          hlState.inTriple = tok;
          out += `<span class="tok-doc">${escHtml(segment.slice(m.index))}</span>`;
          break;
        } else {
          const endPos = closeIdx + 3;
          out += `<span class="tok-doc">${escHtml(segment.slice(m.index, endPos))}</span>`;
          lastIndex = endPos;
          PY_TOKEN_RE.lastIndex = lastIndex;
          continue;
        }
      }

      if (tok.startsWith("#")) {
        out += `<span class="${state.settings.italic ? "tok-cmt italic" : "tok-cmt"}">${escHtml(tok)}</span>`;
      } else if (tok.startsWith('"') || tok.startsWith("'") || tok.startsWith('f"') || tok.startsWith("f'")) {
        out += `<span class="tok-str">${escHtml(tok)}</span>`;
      } else if (tok.startsWith("@")) {
        out += `<span class="tok-dec">${escHtml(tok)}</span>`;
      } else if (tok === "def" || tok === "class") {
        out += `<span class="tok-kw">${tok}</span>`;
        expectDefName = true;
      } else if (tok === "self") {
        out += `<span class="tok-self">${tok}</span>`;
      } else if (/^\d/.test(tok)) {
        out += `<span class="tok-num">${tok}</span>`;
      } else if (/^(?:print|len|range|int|str|float|list|dict|tuple|set|isinstance|super|open|enumerate|zip|min|max|round|abs|sorted)$/.test(tok)) {
        out += `<span class="tok-bi">${tok}</span>`;
      } else {
        out += `<span class="tok-kw">${tok}</span>`;
      }
    }
    return out;
  }

  function highlightYamlSegment(segment) {
    if (segment.startsWith("#")) return `<span class="tok-cmt">${escHtml(segment)}</span>`;
    const m = segment.match(/^([A-Za-z0-9_.-]+)(:)(\s*)(.*)$/);
    if (!m) return escHtml(segment);
    const key = `<span class="tok-yml-key">${escHtml(m[1])}</span>`;
    const val = m[4];
    let valHtml = escHtml(val);
    if (/^(?:true|false|null|True|False)$/.test(val)) {
      valHtml = `<span class="tok-kw">${escHtml(val)}</span>`;
    } else if (/^-?\d+(?:\.\d+)?$/.test(val)) {
      valHtml = `<span class="tok-num">${escHtml(val)}</span>`;
    } else if (val.startsWith("[")) {
      valHtml = escHtml(val)
        .replace(/\b(True|False|true|false)\b/g, '<span class="tok-kw">$1</span>')
        .replace(/\b\d+(?:\.\d+)?\b/g, '<span class="tok-num">$&</span>');
    } else if (val.length > 0) {
      valHtml = `<span class="tok-str">${escHtml(val)}</span>`;
    }
    return key + ":" + escHtml(m[3]) + valHtml;
  }

  function highlightCodeLine(rawLine, lang, hlState) {
    const { prefixHtml, rest } = renderIndentGuides(rawLine);
    if (!rest) return prefixHtml || " ";
    return lang === "yml" ? prefixHtml + highlightYamlSegment(rest) : prefixHtml + highlightPythonSegment(rest, hlState);
  }

  function escapeRegExp(s) {
    return s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  }

  function formatNovelTextHtml(text, query) {
    if (!query || state.boss || !state.find.open || state.find.mode !== "content") {
      return escHtml(text);
    }
    const re = new RegExp(escapeRegExp(query), "gi");
    let out = "";
    let last = 0;
    let m;
    while ((m = re.exec(text)) !== null) {
      if (m.index > last) out += escHtml(text.slice(last, m.index));
      out += `<mark class="find-hl">${escHtml(m[0])}</mark>`;
      last = m.index + m[0].length;
      if (m[0].length === 0) break;
    }
    if (last < text.length) out += escHtml(text.slice(last));
    return out;
  }

  // ---------------- 编辑器与周边渲染 ----------------
  function getCommentBlockItems(snippet, indent) {
    const N = state.settings.linesPerPage;
    const useDoc = state.settings.style === "docstring" && snippet.lang !== "yml";
    let slice = [];

    if (state.boss) {
      const pool = Array.isArray(snippet.bossComments) && snippet.bossComments.length > 0
        ? snippet.bossComments
        : ["OCR pipeline execution notes and memory constraints."];
      for (let i = 0; i < N; i++) slice.push(pool[i % pool.length]);
    } else if (state.books.length === 0) {
      const guide = state.serverMode
        ? [
            "novels/ 目录当前暂无可读文件。",
            "直接把 .epub / .txt / .md 拖进窗口，或放入本地 novels/ 文件夹即可自动加载！",
            "",
            "快捷操作：滚轮/→/空格翻页 · Ctrl+F 全文搜索 · Ctrl+B 书签批注 · Esc 老板键。"
          ]
        : [
            "当前运行于纯离线静态模式（推荐双击 start.bat 启动智能阅读服务，支持 EPUB 与自动目录监控）。",
            "1. 直接把 .txt / .md 拖拽到窗口（自动缓存，刷新免重选）；",
            "2. 或按 Ctrl + O 选择本地 novels/ 目录；",
            "3. 翻页：滚轮 / → / 空格，搜索：Ctrl+F，老板键：Esc。"
          ];
      slice = guide.slice(0, N);
    } else {
      slice = state.wrappedLines.slice(state.cur.line, state.cur.line + N);
    }

    while (slice.length < N) slice.push("");

    const items = [];
    if (useDoc) {
      items.push({ indent, prefix: '"""', body: "" });
      for (const l of slice) items.push({ indent, prefix: "", body: l });
      items.push({ indent, prefix: '"""', body: "" });
    } else {
      for (const l of slice) items.push({ indent, prefix: l ? "# " : "#", body: l });
    }
    return items;
  }

  function renderEditor() {
    applyVisualSettings();

    const snippet = getActiveSnippet();
    const rawLines = snippet.code.split("\n");
    const markerIdx = rawLines.findIndex((l) => /^\s*# @@NOVEL@@\s*$/.test(l));
    const beforeLines = markerIdx >= 0 ? rawLines.slice(0, markerIdx) : rawLines;
    const afterLines = markerIdx >= 0 ? rawLines.slice(markerIdx + 1) : [];
    const indent = getMarkerIndent(snippet);
    const useDoc = state.settings.style === "docstring" && snippet.lang !== "yml";

    const hlState = { inTriple: null };
    const frag = document.createDocumentFragment();
    let lineNo = snippet.startLine || 1;
    let firstNovelRow = null;
    let novelRowCount = 0;
    const novelStartLineNo = lineNo + beforeLines.length;

    const appendCodeRow = (rawLine) => {
      const row = document.createElement("div");
      row.className = "row";
      const num = document.createElement("span");
      num.className = "num";
      num.textContent = String(lineNo++);
      const code = document.createElement("span");
      code.className = "code";
      code.innerHTML = highlightCodeLine(rawLine, snippet.lang, hlState);
      row.appendChild(num);
      row.appendChild(code);
      frag.appendChild(row);
    };

    beforeLines.forEach(appendCodeRow);

    const blockItems = getCommentBlockItems(snippet, indent);
    const cls = state.boss
      ? useDoc
        ? "tok-doc"
        : state.settings.italic
        ? "tok-cmt italic"
        : "tok-cmt"
      : useDoc
      ? "tok-novel-doc"
      : state.settings.italic
      ? "tok-novel-cmt italic"
      : "tok-novel-cmt";

    const query = state.find.query.trim();
    blockItems.forEach((item, idx) => {
      const row = document.createElement("div");
      const isCaretLine = useDoc ? idx === 1 : idx === 0;
      row.className = isCaretLine ? "row novel-row current-caret" : "row novel-row";
      const num = document.createElement("span");
      num.className = "num";
      num.textContent = String(lineNo++);
      const code = document.createElement("span");
      code.className = "code";

      const { prefixHtml } = renderIndentGuides(item.indent);
      const bodyHtml = formatNovelTextHtml(item.body, query);
      const caretHtml = isCaretLine ? `<span class="ide-caret"></span>` : "";
      code.innerHTML = `${prefixHtml}<span class="${cls}">${escHtml(item.prefix)}${bodyHtml}</span>${caretHtml}`;

      row.appendChild(num);
      row.appendChild(code);
      frag.appendChild(row);
      if (idx === 0) firstNovelRow = row;
      novelRowCount++;
    });

    afterLines.forEach(appendCodeRow);

    el.codeViewport.innerHTML = "";
    el.codeViewport.appendChild(frag);

    if (firstNovelRow) {
      const rowH = firstNovelRow.offsetHeight || state.settings.fontSize * 1.5;
      const blockH = rowH * novelRowCount;
      const targetTop = firstNovelRow.offsetTop - el.codeViewport.clientHeight / 2 + blockH / 2;
      el.codeViewport.scrollTop = Math.max(0, targetTop);

      const totalRows = beforeLines.length + novelRowCount + afterLines.length;
      const topPct = Math.round((beforeLines.length / Math.max(totalRows, 1)) * 100);
      const hPct = Math.max(8, Math.round((novelRowCount / Math.max(totalRows, 1)) * 100));
      el.inspNovelMark.style.top = topPct + "%";
      el.inspNovelMark.style.height = hPct + "%";
    }

    updateChrome(snippet, novelStartLineNo);
  }

  function updateChrome(snippet, novelStartLineNo) {
    document.title = `ocr-detector – ${snippet.file}`;
    const relWin = snippet.crumbs.join("\\");
    el.titlePath.textContent = `ocr-detector [D:\\work\\ocr-detector] - ...\\${relWin}`;

    el.breadcrumbs.innerHTML = "";
    const parts = ["ocr-detector", ...snippet.crumbs];
    parts.forEach((p, idx) => {
      if (idx > 0) {
        const sep = document.createElement("span");
        sep.className = "crumb-sep";
        sep.textContent = "›";
        el.breadcrumbs.appendChild(sep);
      }
      const sp = document.createElement("span");
      sp.className = idx === parts.length - 1 ? "crumb active" : "crumb";
      sp.textContent = p;
      el.breadcrumbs.appendChild(sp);
    });

    const extraCandidates = ["db_postprocess.py", "dbnet.py", "infer.py", "train_det.py", "ctc_decoder.py"].filter(
      (f) => f !== snippet.file
    );
    const tabs = [snippet.file, extraCandidates[0], extraCandidates[1], extraCandidates[2]];
    el.editorTabs.innerHTML = "";
    tabs.forEach((fname, idx) => {
      const tab = document.createElement("div");
      tab.className = idx === 0 ? "editor-tab active" : "editor-tab";
      const iconSvg = fname.endsWith(".yml") ? ICONS.yml : ICONS.py;
      tab.innerHTML = `<span class="tree-svg">${iconSvg}</span><span>${escHtml(fname)}</span><span class="tab-close">×</span>`;
      tab.addEventListener("click", () => selectSnippetFile(fname));
      el.editorTabs.appendChild(tab);
    });

    el.statusPos.textContent = `${novelStartLineNo}:1`;
    const book = state.books[state.cur.book];
    if (book && (book.chapterCount || (book.toc && book.toc.length))) {
      const totalCh = book.chapterCount || book.toc.length;
      const pct = computeBookPercent();
      const remMin = estimateChapterRemainMinutes();
      const todayMin = Math.round(((state.stats.dailySeconds || {})[getTodayKey()] || 0) / 60);
      el.statusMem.textContent = `${state.cur.ch + 1} of ${totalCh}M`;
      el.statusMem.title = state.boss
        ? "Memory Usage: 512M / 2048M"
        : `${book.name} · 全书 ${pct}% · 本章剩余约 ${remMin} 分钟 · 今日已读 ${todayMin} 分钟`;
    } else {
      el.statusMem.textContent = "0 of 0M";
      el.statusMem.title = "Memory Usage";
    }
  }

  // ---------------- Project 树 & Structure 大纲 ----------------
  function addTreeNode(parent, depth, opts) {
    const div = document.createElement("div");
    div.className = "tree-node" + (opts.selected ? " selected" : "");
    div.style.paddingLeft = depth * 14 + 4 + "px";
    if (opts.title) div.title = opts.title;

    const arrow = document.createElement("span");
    arrow.className = "tree-arrow";
    arrow.textContent = opts.arrow || "";
    div.appendChild(arrow);

    const icon = document.createElement("span");
    icon.className = "tree-svg";
    icon.innerHTML = opts.svg || ICONS.txt;
    div.appendChild(icon);

    const label = document.createElement("span");
    label.className = "tree-label";
    label.textContent = opts.label;
    div.appendChild(label);

    if (opts.sub) {
      const sub = document.createElement("span");
      sub.className = "tree-sub";
      sub.textContent = opts.sub;
      div.appendChild(sub);
    }

    if (opts.onClick) div.addEventListener("click", opts.onClick);
    parent.appendChild(div);
    return div;
  }

  function renderProjectTree() {
    const frag = document.createDocumentFragment();
    const activeFile = getActiveSnippet().file;

    addTreeNode(frag, 0, { arrow: "▾", svg: ICONS.folderOpen, label: "ocr-detector", sub: "D:\\work\\ocr-detector" });
    addTreeNode(frag, 1, { arrow: "▸", svg: ICONS.folder, label: ".idea" });
    addTreeNode(frag, 1, { arrow: "▾", svg: ICONS.folderOpen, label: "configs" });
    ["det_db_r50.yml", "rec_crnn.yml"].forEach((yml) => {
      addTreeNode(frag, 2, { svg: ICONS.yml, label: yml, selected: yml === activeFile, onClick: () => selectSnippetFile(yml) });
    });

    addTreeNode(frag, 1, {
      arrow: "▾",
      svg: ICONS.folderOpen,
      label: "datasets",
      title: state.serverMode ? "novels/ 实时监控中" : "本地小说目录"
    });

    let selectedChapterNode = null;
    if (state.books.length === 0) {
      addTreeNode(frag, 2, {
        svg: ICONS.txt,
        label: "train_list.txt",
        title: "拖入 .epub/.txt/.md 文件即可阅读",
        onClick: () => triggerImportFiles()
      });
    } else {
      state.books.forEach((book, bIdx) => {
        const isCurBook = bIdx === state.cur.book;
        addTreeNode(frag, 2, {
          arrow: isCurBook ? "▾" : "▸",
          svg: isCurBook ? ICONS.folderOpen : ICONS.folder,
          label: `icdar_part${bIdx + 1}`,
          title: state.boss ? `icdar_part${bIdx + 1}` : `${book.name} (${book.percent || 0}%)`,
          onClick: () => {
            if (state.cur.book !== bIdx) selectBook(bIdx);
          }
        });

        if (isCurBook && book.toc && book.toc.length > 0) {
          // 若超长篇有上千章，仍控制单次渲染在流畅范围内（窗口展示当前章附近或全部 <=600 章）
          const total = book.toc.length;
          const startIdx = total > 600 ? Math.max(0, state.cur.ch - 150) : 0;
          const endIdx = total > 600 ? Math.min(total, startIdx + 300) : total;
          for (let cIdx = startIdx; cIdx < endIdx; cIdx++) {
            const ch = book.toc[cIdx];
            const isSel = cIdx === state.cur.ch;
            const padNum = String(cIdx + 1).padStart(4, "0");
            const node = addTreeNode(frag, 3, {
              svg: ICONS.txt,
              label: `gt_img_${padNum}.txt`,
              title: state.boss ? `gt_img_${padNum}.txt` : ch.title,
              selected: isSel,
              onClick: () => loadAndRenderChapter(bIdx, cIdx, 0, false)
            });
            if (isSel) selectedChapterNode = node;
          }
        }
      });
    }

    const codeFolders = [
      { dir: "det", files: ["__init__.py", "dbnet.py", "db_postprocess.py", "augment.py"] },
      { dir: "rec", files: ["__init__.py", "crnn.py", "ctc_decoder.py"] },
      { dir: "tools", files: ["train_det.py", "infer.py", "eval_metrics.py"] }
    ];
    codeFolders.forEach((grp) => {
      addTreeNode(frag, 1, { arrow: "▾", svg: ICONS.folderOpen, label: grp.dir });
      grp.files.forEach((f) => {
        addTreeNode(frag, 2, { svg: ICONS.py, label: f, selected: f === activeFile, onClick: () => selectSnippetFile(f) });
      });
    });

    addTreeNode(frag, 1, { svg: ICONS.txt, label: "requirements.txt" });
    addTreeNode(frag, 1, { svg: ICONS.md, label: "README.md" });
    addTreeNode(frag, 0, { arrow: "▸", svg: ICONS.lib, label: "External Libraries" });
    addTreeNode(frag, 0, { arrow: "▸", svg: ICONS.folder, label: "Scratches and Consoles" });

    el.projectTree.innerHTML = "";
    el.projectTree.appendChild(frag);
    if (selectedChapterNode) selectedChapterNode.scrollIntoView({ block: "nearest" });
  }

  function renderStructureTree() {
    const frag = document.createDocumentFragment();
    const book = state.books[state.cur.book];

    // 同步顶部切书下拉框
    el.structureBookSelect.innerHTML = "";
    state.books.forEach((b, idx) => {
      const opt = document.createElement("option");
      opt.value = String(idx);
      const shortName = b.name.split("/").pop().replace(/\.(txt|md|epub)$/i, "");
      opt.textContent = `${shortName} (${b.percent || 0}%)`;
      if (idx === state.cur.book) opt.selected = true;
      el.structureBookSelect.appendChild(opt);
    });

    if (!book || state.boss || !book.toc) {
      const snippet = getActiveSnippet();
      addTreeNode(frag, 0, { arrow: "▾", svg: ICONS.cls, label: snippet.file.replace(/\.\w+$/, "") });
      addTreeNode(frag, 1, { svg: ICONS.method, label: "__init__(self, ...)" });
      addTreeNode(frag, 1, { svg: ICONS.method, label: "forward(self, inputs)" });
      addTreeNode(frag, 1, { svg: ICONS.method, label: "postprocess(self, preds)" });
      el.structureTree.innerHTML = "";
      el.structureTree.appendChild(frag);
      return;
    }

    addTreeNode(frag, 0, {
      arrow: "▾",
      svg: ICONS.cls,
      label: book.name.replace(/\.(txt|md|epub)$/i, ""),
      sub: `${book.toc.length}`
    });

    let selNode = null;
    book.toc.forEach((ch, idx) => {
      const isSel = idx === state.cur.ch;
      const node = addTreeNode(frag, 1, {
        svg: ICONS.method,
        label: ch.title,
        sub: `${ch.chars}c`,
        selected: isSel,
        title: `${idx + 1}. ${ch.title}`,
        onClick: () => loadAndRenderChapter(state.cur.book, idx, 0, false)
      });
      if (isSel) selNode = node;
    });

    el.structureTree.innerHTML = "";
    el.structureTree.appendChild(frag);
    if (selNode) selNode.scrollIntoView({ block: "nearest" });
  }

  function switchLeftView(view) {
    if (state.leftView === view && !el.projectPanel.classList.contains("collapsed")) {
      el.projectPanel.classList.add("collapsed");
      el.resizerLeft.classList.add("hidden");
      el.tabLeftProject.classList.remove("active");
      el.tabLeftStructure.classList.remove("active");
      computeWrappedLines();
      renderEditor();
      return;
    }
    state.leftView = view;
    el.projectPanel.classList.remove("collapsed");
    el.resizerLeft.classList.remove("hidden");
    el.tabLeftProject.classList.toggle("active", view === "project");
    el.tabLeftStructure.classList.toggle("active", view === "structure");
    el.leftPanelTitle.textContent = view === "project" ? "Project" : "Structure";
    el.projectTree.classList.toggle("hidden", view !== "project");
    el.structurePane.classList.toggle("hidden", view !== "structure");
    if (view === "structure") renderStructureTree();
    else renderProjectTree();
    computeWrappedLines();
    renderEditor();
  }

  function selectSnippetFile(fname) {
    state.snippetOverride = SNIPPET_BY_FILE.has(fname) ? SNIPPET_BY_FILE.get(fname) : null;
    computeWrappedLines();
    renderEditor();
    renderProjectTree();
  }

  // ---------------- 翻页 / 步进 / 跳章 / 老板键 ----------------
  async function advanceLines(delta) {
    const book = state.books[state.cur.book];
    if (!book || !state.activeChapter) return;
    state.lastActiveTs = Date.now();
    const totalCh = book.chapterCount || (book.toc ? book.toc.length : 1);

    if (delta > 0) {
      // 累计翻阅字数用于自动估算阅读速度
      const passed = state.wrappedLines.slice(state.cur.line, state.cur.line + delta);
      state.pendingChars += passed.reduce((a, l) => a + l.length, 0);

      if (state.cur.line + delta < state.wrappedLines.length) {
        state.cur.line += delta;
        saveCurrentProgress();
        renderAllViews();
      } else if (state.cur.ch + 1 < totalCh) {
        await loadAndRenderChapter(state.cur.book, state.cur.ch + 1, 0, false);
      }
    } else if (delta < 0) {
      if (state.cur.line + delta >= 0) {
        state.cur.line += delta;
        saveCurrentProgress();
        renderAllViews();
      } else if (state.cur.line > 0) {
        state.cur.line = 0;
        saveCurrentProgress();
        renderAllViews();
      } else if (state.cur.ch > 0) {
        await loadAndRenderChapter(state.cur.book, state.cur.ch - 1, 0, true);
      }
    }
  }

  async function jumpChapter(delta) {
    const book = state.books[state.cur.book];
    if (!book) return;
    const totalCh = book.chapterCount || (book.toc ? book.toc.length : 1);
    const nextCh = state.cur.ch + delta;
    if (nextCh < 0 || nextCh >= totalCh) return;
    await loadAndRenderChapter(state.cur.book, nextCh, 0, false);
  }

  function toggleBossMode(forceBoss) {
    const next = typeof forceBoss === "boolean" ? forceBoss : !state.boss;
    if (next === state.boss) return;
    state.boss = next;
    if (state.boss) {
      closeFindBar(false);
      closeOpenModals();
      closeFileMenu();
      if (state.leftView === "structure") {
        state.leftView = "project";
        el.leftPanelTitle.textContent = "Project";
        el.tabLeftProject.classList.add("active");
        el.tabLeftStructure.classList.remove("active");
        el.projectTree.classList.remove("hidden");
        el.structurePane.classList.add("hidden");
      }
    }
    renderAllViews();
  }

  function renderAllViews() {
    renderEditor();
    renderProjectTree();
    if (state.leftView === "structure") renderStructureTree();
    renderTodoList();
  }

  // ---------------- Ctrl+F 服务端/本地智能搜索 + 预览浮层 ----------------
  function openFindBar() {
    if (state.boss) return;
    state.find.open = true;
    el.findWrap.classList.remove("hidden");
    el.findInput.focus();
    el.findInput.select();
    runFindQuery(false);
  }

  function closeFindBar(rerender) {
    state.find.open = false;
    el.findWrap.classList.add("hidden");
    el.findResultsPanel.classList.add("hidden");
    if (rerender !== false) renderEditor();
  }

  async function runFindQuery(jumpToFirst) {
    const book = state.books[state.cur.book];
    const q = el.findInput.value.trim();
    state.find.query = q;
    state.find.results = [];
    state.find.idx = -1;

    if (!q || (state.books.length === 0)) {
      el.findCount.textContent = "0/0";
      el.findResultsPanel.classList.add("hidden");
      renderEditor();
      return;
    }

    if (state.serverMode) {
      try {
        const bname = book ? book.name : "";
        const data = await apiGet(
          `/api/search?name=${encodeURIComponent(bname)}&q=${encodeURIComponent(q)}&mode=${state.find.mode}&scope=${state.find.scope}`
        );
        state.find.results = data.results || [];
      } catch (_) {
        state.find.results = [];
      }
    } else if (book) {
      const qLow = q.toLowerCase();
      await ensureBookToc(book);
    if (state.find.mode === "chapters") {
      await ensureBookToc(book);
      (book.toc || []).forEach((ch, cIdx) => {
        if (ch.title.toLowerCase().includes(qLow)) {
          state.find.results.push({ book: book.name, ch: cIdx, chTitle: ch.title, paraIdx: -1, snippet: ch.title });
        }
      });
    } else {
      await ensureBookToc(book);
      outer: for (let cIdx = 0; cIdx < (book.chapters || []).length; cIdx++) {
          const ch = book.chapters[cIdx];
          for (let pIdx = 0; pIdx < ch.paras.length; pIdx++) {
            const p = ch.paras[pIdx];
            const pos = p.toLowerCase().indexOf(qLow);
            if (pos >= 0) {
              const s = Math.max(0, pos - 16);
              const e = Math.min(p.length, pos + q.length + 26);
              state.find.results.push({
                book: book.name,
                ch: cIdx,
                chTitle: ch.title,
                paraIdx: pIdx,
                snippet: (s > 0 ? "…" : "") + p.slice(s, e) + (e < p.length ? "…" : "")
              });
              if (state.find.results.length >= 120) break outer;
            }
          }
        }
      }
    }

    renderFindResultsPanel();
    if (state.find.results.length > 0) {
      state.find.idx = 0;
      if (jumpToFirst) await jumpToFindResult(0);
      else updateFindCounter();
    } else {
      el.findCount.textContent = "0/0";
      renderEditor();
    }
  }

  function renderFindResultsPanel() {
    const hits = state.find.results;
    if (!state.find.open || hits.length === 0) {
      el.findResultsPanel.classList.add("hidden");
      return;
    }
    const frag = document.createDocumentFragment();
    hits.slice(0, 60).forEach((h, i) => {
      const item = document.createElement("div");
      item.className = i === state.find.idx ? "find-res-item active" : "find-res-item";
      item.innerHTML = `
        <div class="find-res-meta">
          <span>${escHtml(h.chTitle || ("Ch." + (h.ch + 1)))}</span>
          <span>${state.find.scope === "all" ? escHtml(h.book) : `#${h.ch + 1}`}</span>
        </div>
        <div class="find-res-snip">${escHtml(h.snippet || "")}</div>
      `;
      item.addEventListener("click", () => {
        jumpToFindResult(i);
        el.findResultsPanel.classList.add("hidden");
      });
      frag.appendChild(item);
    });
    el.findResultsPanel.innerHTML = "";
    el.findResultsPanel.appendChild(frag);
    el.findResultsPanel.classList.remove("hidden");
  }

  function updateFindCounter() {
    const total = state.find.results.length;
    el.findCount.textContent = total > 0 ? `${state.find.idx + 1}/${total}` : "0/0";
  }

  async function jumpToFindResult(idx) {
    if (state.find.results.length === 0) return;
    const total = state.find.results.length;
    state.find.idx = ((idx % total) + total) % total;
    const hit = state.find.results[state.find.idx];

    const bIdx = state.books.findIndex((b) => b.name === hit.book);
    if (bIdx < 0) return;
    await loadAndRenderChapter(bIdx, hit.ch, 0, false);

    if (hit.paraIdx >= 0 && state.find.query) {
      const qLow = state.find.query.toLowerCase();
      const lineIdx = state.wrappedLines.findIndex((l) => l.toLowerCase().includes(qLow));
      if (lineIdx >= 0) {
        state.cur.line = Math.max(0, lineIdx - 2);
        saveCurrentProgress();
        renderEditor();
      }
    }
    updateFindCounter();
    renderFindResultsPanel();
  }

  // ---------------- 书签 + 批注 + 导出 Markdown ----------------
  function openBookmarkModal() {
    const book = state.books[state.cur.book];
    if (!book || state.boss) return;
    const previewRaw = state.wrappedLines.slice(state.cur.line, state.cur.line + 3).join(" ").trim();
    el.bmPreviewText.textContent = previewRaw || (state.activeChapter ? state.activeChapter.title : "");
    el.bmNoteInput.value = "";
    el.bookmarkModal.classList.remove("hidden");
    el.bmNoteInput.focus();
  }

  function commitBookmark() {
    const book = state.books[state.cur.book];
    if (!book) {
      el.bookmarkModal.classList.add("hidden");
      return;
    }
    const snippet = getActiveSnippet();
    const previewRaw = state.wrappedLines.slice(state.cur.line, state.cur.line + 2).join(" ").trim();
    const chTitle = (state.activeChapter && state.activeChapter.title) || "";
    const note = el.bmNoteInput.value.trim();
    const nowStr = new Date().toLocaleString("zh-CN", { hour12: false });

    state.bookmarks.unshift({
      id: Date.now() + Math.random(),
      book: book.name,
      ch: state.cur.ch,
      line: state.cur.line,
      chTitle,
      preview: (previewRaw || chTitle || "...").slice(0, 60),
      note,
      createdAt: nowStr,
      snippetFile: snippet.file,
      lineNo: (snippet.startLine || 60) + 22
    });
    if (state.bookmarks.length > 100) state.bookmarks.length = 100;
    persistStatePatch({ bookmarks: state.bookmarks });
    renderTodoList();
    el.bookmarkModal.classList.add("hidden");
    el.statusLeft.textContent = `TODO marker saved at ${snippet.file}:${(snippet.startLine || 60) + 22}`;
  }

  async function exportCurrentNotes() {
    const book = state.books[state.cur.book];
    if (!book) return;
    if (state.serverMode) {
      try {
        await apiPost("/api/state", { bookmarks: state.bookmarks });
        const res = await apiPost("/api/notes/export", { book: book.name });
        el.statusLeft.textContent = `Notes exported (${res.count}) -> data/notes/${res.filename}`;
        return;
      } catch (e) {
        el.statusLeft.textContent = `Export failed: ${e.message}`;
        return;
      }
    }
    // 离线降级：直接触发 .md 下载
    const list = state.bookmarks.filter((b) => b.book === book.name);
    const md = [
      `# 《${book.name}》阅读笔记`,
      "",
      ...list.map((b, i) => `### ${i + 1}. ${b.chTitle}\n> ${b.preview}\n${b.note ? `\n**批注**：${b.note}\n` : ""}`)
    ].join("\n");
    const blob = new Blob([md], { type: "text/markdown;charset=utf-8" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = `${book.name.replace(/\.\w+$/, "")}_notes.md`;
    a.click();
    URL.revokeObjectURL(a.href);
    el.statusLeft.textContent = `Downloaded ${a.download}`;
  }

  function renderTodoList() {
    el.todoList.innerHTML = "";
    const frag = document.createDocumentFragment();

    if (state.boss) {
      const fakeTodos = [
        { loc: "det/db_postprocess.py:94", text: "# TODO(det): evaluate polygon mode vs quad mode for curved receipt lines" },
        { loc: "tools/train_det.py:168", text: "# TODO(amp): verify SyncBN memory overhead across 4x RTX 4090 nodes" }
      ];
      fakeTodos.forEach((ft) => {
        const row = document.createElement("div");
        row.className = "todo-item";
        row.innerHTML = `<div class="todo-left"><span class="todo-loc">${escHtml(ft.loc)}</span><span class="todo-tag">${escHtml(ft.text)}</span></div>`;
        frag.appendChild(row);
      });
      el.todoList.appendChild(frag);
      return;
    }

    const curBook = state.books[state.cur.book];
    const list = curBook ? state.bookmarks.filter((b) => b.book === curBook.name) : state.bookmarks;
    if (list.length === 0) {
      const empty = document.createElement("div");
      empty.className = "todo-item";
      empty.innerHTML = `<div class="todo-left"><span class="todo-text">No TODO items. Press Ctrl+B to add a bookmark / reading note (↓ exports Markdown).</span></div>`;
      frag.appendChild(empty);
      el.todoList.appendChild(frag);
      return;
    }

    list.forEach((bm) => {
      const row = document.createElement("div");
      row.className = "todo-item";
      const noteHtml = bm.note ? `<span class="todo-note">// ${escHtml(bm.note)}</span>` : "";
      row.innerHTML = `
        <div class="todo-left" title="${escHtml((bm.chTitle || "") + (bm.note ? " | 批注: " + bm.note : ""))}">
          <span class="todo-loc">${escHtml(bm.snippetFile || "db_postprocess.py")}:${bm.lineNo || 100}</span>
          <span class="todo-tag"># TODO [ch.${bm.ch + 1}]</span>
          <span class="todo-text">${escHtml(bm.preview)}</span>${noteHtml}
        </div>
        <button class="todo-del" type="button" title="移除书签">×</button>
      `;
      row.querySelector(".todo-left").addEventListener("click", () => {
        const bIdx = state.books.findIndex((b) => b.name === bm.book);
        if (bIdx >= 0) loadAndRenderChapter(bIdx, bm.ch, bm.line, false);
      });
      row.querySelector(".todo-del").addEventListener("click", (e) => {
        e.stopPropagation();
        state.bookmarks = state.bookmarks.filter((x) => x.id !== bm.id);
        persistStatePatch({ bookmarks: state.bookmarks });
        renderTodoList();
      });
      frag.appendChild(row);
    });
    el.todoList.appendChild(frag);
  }

  // ---------------- 阅读统计看板 & 智能心跳 ----------------
  function startStatsHeartbeat() {
    setInterval(() => {
      if (document.hidden || state.boss || state.books.length === 0) return;
      if (Date.now() - state.lastActiveTs > 90000) return;

      const secs = 15;
      const chars = state.pendingChars;
      state.pendingChars = 0;
      const book = state.books[state.cur.book];
      const today = getTodayKey();

      state.stats.dailySeconds = state.stats.dailySeconds || {};
      state.stats.bookSeconds = state.stats.bookSeconds || {};
      state.stats.dailySeconds[today] = (state.stats.dailySeconds[today] || 0) + secs;
      if (book) {
        state.stats.bookSeconds[book.name] = (state.stats.bookSeconds[book.name] || 0) + secs;
        book.readSeconds = state.stats.bookSeconds[book.name];
      }
      state.stats.totalCharsRead = (state.stats.totalCharsRead || 0) + chars;
      if (chars > 0) {
        const instantCpm = chars / (secs / 60);
        if (instantCpm >= 80 && instantCpm <= 2500) {
          state.stats.readingSpeedCpm = Math.round((state.stats.readingSpeedCpm || 450) * 0.8 + instantCpm * 0.2);
        }
      }
      saveLocal("moyu.stats", state.stats);

      if (state.serverMode) {
        apiPost("/api/stats/tick", {
          seconds: secs,
          chars,
          book: book ? book.name : ""
        })
          .then((res) => {
            if (res && res.stats) {
              state.stats = res.stats;
              saveLocal("moyu.stats", state.stats);
            }
          })
          .catch(() => {});
      }
      updateChrome(getActiveSnippet(), (getActiveSnippet().startLine || 1) + 22);
    }, 15000);
  }

  function renderStatsPanel() {
    const today = getTodayKey();
    const todaySec = (state.stats.dailySeconds || {})[today] || 0;
    const totalChars = state.stats.totalCharsRead || 0;
    const cpm = state.stats.readingSpeedCpm || 450;
    const book = state.books[state.cur.book];
    const pct = computeBookPercent();
    const remMin = estimateChapterRemainMinutes();

    el.statsCards.innerHTML = `
      <div class="stat-card"><div class="stat-val">${formatDuration(todaySec)}</div><div class="stat-lbl">今日已读</div></div>
      <div class="stat-card"><div class="stat-val">${pct}%</div><div class="stat-lbl">当前全书进度</div></div>
      <div class="stat-card"><div class="stat-val">~${remMin} min</div><div class="stat-lbl">本章预计剩余</div></div>
      <div class="stat-card"><div class="stat-val">${cpm} 字/分</div><div class="stat-lbl">阅读速度 · 累计 ${(totalChars / 10000).toFixed(1)}w 字</div></div>
    `;

    // 近 7 日趋势柱状图
    const days = [];
    const now = new Date();
    for (let i = 6; i >= 0; i--) {
      const d = new Date(now.getTime() - i * 86400000);
      const pad = (n) => String(n).padStart(2, "0");
      const key = `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
      const mins = Math.round(((state.stats.dailySeconds || {})[key] || 0) / 60);
      days.push({ label: `${d.getMonth() + 1}/${d.getDate()}`, mins });
    }
    const maxMin = Math.max(10, ...days.map((d) => d.mins));
    el.statsBars.innerHTML = days
      .map((d) => {
        const hPct = Math.max(4, Math.round((d.mins / maxMin) * 100));
        return `<div class="bar-col" title="${d.label}: ${d.mins} 分钟"><div class="bar-fill" style="height:${hPct}%"></div><div class="bar-day">${d.label}</div></div>`;
      })
      .join("");

    el.setCleanEnabled.checked = Boolean(state.cleanEnabled);
    el.setFilterWords.value = (state.customFilterWords || []).join("\n");
    if (book) {
      el.statsCards.title = `当前书籍：${book.name}`;
    }
  }

  // ---------------- 底部活面板 & 假 Terminal ----------------
  function switchBottomPane(pane) {
    if (state.bottomPane === pane && !el.runPanel.classList.contains("collapsed")) {
      el.runPanel.classList.add("collapsed");
      el.resizerBottom.classList.add("hidden");
      el.bottomTabs.forEach((b) => b.classList.remove("active"));
      computeWrappedLines();
      renderEditor();
      return;
    }
    state.bottomPane = pane;
    el.runPanel.classList.remove("collapsed");
    el.resizerBottom.classList.remove("hidden");
    el.bottomTabs.forEach((b) => b.classList.toggle("active", b.dataset.pane === pane));

    const titles = {
      run: "Run: train_det",
      todo: "TODO: Current Project",
      terminal: "Terminal: Local (ocr-env)",
      console: "Python Console (ocr-env)"
    };
    el.bottomPanelTitle.textContent = titles[pane] || "Run";
    el.paneRun.classList.toggle("hidden", pane !== "run");
    el.paneTodo.classList.toggle("hidden", pane !== "todo");
    el.paneTerminal.classList.toggle("hidden", pane !== "terminal");
    el.paneConsole.classList.toggle("hidden", pane !== "console");

    if (pane === "todo") renderTodoList();
    if (pane === "terminal") el.terminalInput.focus();
    computeWrappedLines();
    renderEditor();
  }

  function initFakeTerminal() {
    appendTermLine("Windows PowerShell — Conda environment activated: ocr-env (Python 3.10.14)");
    appendTermLine("Type 'nvidia-smi', 'git status', 'ls', 'python --version', 'clear' or 'help'.\n");

    el.terminalWrap.addEventListener("click", () => el.terminalInput.focus());
    el.terminalInput.addEventListener("keydown", (e) => {
      if (e.key === "Enter") {
        e.preventDefault();
        const cmd = el.terminalInput.value.trim();
        el.terminalInput.value = "";
        appendTermLine(`(ocr-env) PS D:\\work\\ocr-detector> ${cmd}`);
        if (cmd) {
          state.termHistory.unshift(cmd);
          state.termHistIdx = -1;
          handleTermCommand(cmd);
        }
        el.terminalWrap.scrollTop = el.terminalWrap.scrollHeight;
      } else if (e.key === "ArrowUp") {
        if (state.termHistory.length > 0) {
          e.preventDefault();
          state.termHistIdx = Math.min(state.termHistory.length - 1, state.termHistIdx + 1);
          el.terminalInput.value = state.termHistory[state.termHistIdx];
        }
      } else if (e.key === "ArrowDown") {
        if (state.termHistIdx >= 0) {
          e.preventDefault();
          state.termHistIdx -= 1;
          el.terminalInput.value = state.termHistIdx >= 0 ? state.termHistory[state.termHistIdx] : "";
        }
      }
    });
  }

  function appendTermLine(text) {
    el.terminalOutput.textContent += text + "\n";
  }

  function handleTermCommand(raw) {
    const cmd = raw.toLowerCase();
    if (cmd === "clear" || cmd === "cls") {
      el.terminalOutput.textContent = "";
      return;
    }
    if (cmd === "nvidia-smi") {
      appendTermLine(
        "+-----------------------------------------------------------------------------+\n" +
        "| NVIDIA-SMI 551.86    Driver Version: 551.86       CUDA Version: 12.4        |\n" +
        "|-------------------------------+----------------------+----------------------+\n" +
        "|   0  NVIDIA GeForce RTX 4090  | 00000000:01:00.0 Off |                  Off |\n" +
        "| 42%   64C    P2   298W / 450W |  11420MiB / 24564MiB |     94%      Default |\n" +
        "+-------------------------------+----------------------+----------------------+"
      );
    } else if (cmd === "git status") {
      appendTermLine(
        "On branch main\nYour branch is up to date with 'origin/main'.\n\n" +
        "Changes not staged for commit:\n" +
        "  modified:   det/db_postprocess.py\n" +
        "  modified:   configs/det_db_r50.yml"
      );
    } else if (cmd === "ls" || cmd === "dir") {
      appendTermLine("configs/   datasets/   det/   rec/   tools/   README.md   requirements.txt");
    } else if (cmd === "pwd") {
      appendTermLine("D:\\work\\ocr-detector");
    } else if (cmd.startsWith("python")) {
      appendTermLine("Python 3.10.14");
    } else if (cmd === "pip list") {
      appendTermLine("torch 2.2.2+cu121\nopencv-python 4.9.0.80\npyclipper 1.3.0.post5\nshapely 2.0.3\nnumpy 1.26.4");
    } else if (cmd === "stats" && !state.boss) {
      const book = state.books[state.cur.book];
      const todaySec = (state.stats.dailySeconds || {})[getTodayKey()] || 0;
      appendTermLine(
        `[reader] mode=${state.serverMode ? "server" : "offline"} | books=${state.books.length} | ` +
        `today=${formatDuration(todaySec)} | speed=${state.stats.readingSpeedCpm || 450} cpm | ` +
        `current=${book ? book.name : "none"} (${computeBookPercent()}%)`
      );
    } else if (cmd === "help") {
      appendTermLine("Available commands: nvidia-smi, git status, ls, pwd, python --version, pip list, clear");
    } else {
      appendTermLine(`'${raw.split(/\s+/)[0]}' completed with exit code 0.`);
    }
  }

  // ---------------- 服务端书库同步与热监控 ----------------
  async function syncServerLibrary(preferredBookName, silent) {
    const data = await apiGet("/api/books");
    const prevName = preferredBookName || (state.books[state.cur.book] ? state.books[state.cur.book].name : state.lastBook);
    state.libraryVersion = data.version || "";
    const oldMap = new Map(state.books.map((b) => [b.name, b]));

    state.books = (data.books || []).map((item) => {
      const old = oldMap.get(item.name);
      // 文件修改时间未变则复用已缓存的 toc 与 chapterCache
      if (old && old.mtime === item.mtime && old.size === item.size) {
        old.percent = item.percent;
        old.readSeconds = item.readSeconds;
        return old;
      }
      return {
        name: item.name,
        ext: item.ext,
        size: item.size,
        mtime: item.mtime,
        percent: item.percent || 0,
        ch: item.ch || 0,
        readSeconds: item.readSeconds || 0,
        source: "server",
        totalChars: 0,
        chapterCount: 0,
        toc: [],
        chapterCache: {}
      };
    });

    if (state.books.length === 0) {
      state.activeChapter = null;
      state.wrappedLines = [];
      renderAllViews();
      renderLibraryList();
      return;
    }

    let idx = state.books.findIndex((b) => b.name === prevName);
    if (idx < 0) idx = 0;

    // 如果是热更新且正在看同一本书未变更，只需刷新书架树无需跳行
    const curBook = state.books[idx];
    if (silent && state.activeChapter && oldMap.has(curBook.name) && oldMap.get(curBook.name) === curBook) {
      state.cur.book = idx;
      renderProjectTree();
      renderLibraryList();
      el.statusLeft.textContent = `Workspace synced — ${state.books.length} dataset(s) watched`;
      return;
    }

    await selectBook(idx);
    renderLibraryList();
    if (!silent) {
      el.statusLeft.textContent = `Indexing finished — ${state.books.length} dataset(s) ready`;
    }
  }

  function startHotWatchLoop() {
    setInterval(async () => {
      if (!state.serverMode || document.hidden) return;
      try {
        const h = await apiGet("/api/health");
        if (h && h.version && h.version !== state.libraryVersion) {
          await syncServerLibrary(null, true);
        }
      } catch (_) {}
    }, 4000);
  }

  // ---------------- 离线模式 IndexedDB + localStorage 兼容 ----------------
  function openIdb() {
    return new Promise((resolve, reject) => {
      if (!("indexedDB" in window)) return reject(new Error("no indexedDB"));
      const timer = setTimeout(() => reject(new Error("indexedDB timeout")), 600);
      const req = indexedDB.open("moyu", 2);
      req.onupgradeneeded = () => {
        const db = req.result;
        if (!db.objectStoreNames.contains("kv")) db.createObjectStore("kv");
        if (!db.objectStoreNames.contains("books")) db.createObjectStore("books", { keyPath: "name" });
      };
      req.onsuccess = () => { clearTimeout(timer); resolve(req.result); };
      req.onerror = () => { clearTimeout(timer); reject(req.error); };
      req.onblocked = () => { clearTimeout(timer); reject(new Error("indexedDB blocked")); };
    });
  }

  async function idbGet(store, key) {
    const db = await openIdb();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(store, "readonly");
      const req = tx.objectStore(store).get(key);
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
  }

  async function idbPut(store, val, key) {
    const db = await openIdb();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(store, "readwrite");
      const req = key !== undefined ? tx.objectStore(store).put(val, key) : tx.objectStore(store).put(val);
      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    });
  }

  async function idbGetAllBooks() {
    try {
      const db = await openIdb();
      return await new Promise((resolve, reject) => {
        const tx = db.transaction("books", "readonly");
        const req = tx.objectStore("books").getAll();
        req.onsuccess = () => resolve(req.result || []);
        req.onerror = () => reject(req.error);
      });
    } catch (_) {
      return loadLocalJson("moyu.importedBooks", []);
    }
  }

  async function persistImportedBookOffline(name, text) {
    const rec = { name, text, updatedAt: Date.now() };
    try {
      await idbPut("books", rec);
    } catch (_) {
      const list = loadLocalJson("moyu.importedBooks", []).filter((x) => x.name !== name);
      list.push(rec);
      saveLocal("moyu.importedBooks", list);
    }
  }

  async function removeOfflineBook(name) {
    state.importedBooks = state.importedBooks.filter((b) => b.name !== name);
    try {
      const db = await openIdb();
      await new Promise((resolve, reject) => {
        const tx = db.transaction("books", "readwrite");
        const req = tx.objectStore("books").delete(name);
        req.onsuccess = () => resolve();
        req.onerror = () => reject(req.error);
      });
    } catch (_) {}
    saveLocal("moyu.importedBooks", loadLocalJson("moyu.importedBooks", []).filter((x) => x.name !== name));
    await rebuildOfflineBooks();
    renderLibraryList();
  }

  async function readBooksFromDirHandle(dirHandle) {
    const loaded = [];
    for await (const [name, handle] of dirHandle.entries()) {
      if (handle.kind === "file" && /\.(txt|md)$/i.test(name)) {
        const file = await handle.getFile();
        loaded.push(parseBookClient(name, decodeBuffer(await file.arrayBuffer()), "folder"));
      }
    }
    return loaded;
  }

  async function rebuildOfflineBooks(selectBookName) {
    const byName = new Map();
    if (Array.isArray(window.NOVELS_PACKED)) {
      for (const item of window.NOVELS_PACKED) {
        if (item && item.name) byName.set(item.name, makeLazyClientBook(item.name, item.text || "", "packed"));
      }
    }
    for (const item of state.importedBooks) {
      if (item && item.name) byName.set(item.name, makeLazyClientBook(item.name, item.text || "", "imported"));
    }
    for (const b of state.dirBooks) byName.set(b.name, b);

    state.books = Array.from(byName.values()).sort((a, b) => a.name.localeCompare(b.name, "zh-CN"));
    if (state.books.length === 0) {
      state.activeChapter = null;
      state.wrappedLines = [];
      renderAllViews();
      return;
    }
    const targetName = selectBookName || state.lastBook || "石黑一雄中英双语作品集/01_长日将尽_The Remains of the Day.md";
    let idx = state.books.findIndex((b) => b.name === targetName);
    if (idx < 0) idx = 0;
    await selectBook(idx);
  }

  // ---------------- 文件上传 / 拖拽落盘 ----------------
  function triggerImportFiles() {
    el.importFilesInput.value = "";
    el.importFilesInput.click();
  }

  async function importFileList(fileList) {
    const allowed = state.serverMode ? /\.(txt|md|epub)$/i : /\.(txt|md)$/i;
    const files = Array.from(fileList || []).filter((f) => allowed.test(f.name));
    if (files.length === 0) {
      if (!state.serverMode && Array.from(fileList || []).some((f) => /\.epub$/i.test(f.name))) {
        el.statusLeft.textContent = "EPUB 需要通过 start.bat 启动本地智能阅读服务后导入";
      }
      return;
    }

    if (state.serverMode) {
      let lastName = null;
      for (const f of files) {
        const buf = await f.arrayBuffer();
        const resp = await fetch("/api/upload", {
          method: "POST",
          headers: { "X-Filename": encodeURIComponent(f.name) },
          body: buf
        });
        const data = await resp.json();
        if (resp.ok && data.name) lastName = data.name;
      }
      await syncServerLibrary(lastName, false);
      el.statusLeft.textContent = `Uploaded ${files.length} file(s) to novels/`;
      return;
    }

    let lastName = null;
    for (const f of files) {
      const text = decodeBuffer(await f.arrayBuffer());
      await persistImportedBookOffline(f.name, text);
      state.importedBooks = state.importedBooks.filter((b) => b.name !== f.name);
      state.importedBooks.push({ name: f.name, text });
      lastName = f.name;
    }
    await rebuildOfflineBooks(lastName);
    renderLibraryList();
    el.statusLeft.textContent = `Imported ${files.length} file(s) into local cache`;
  }

  async function openFolder(forcePick) {
    if (state.serverMode) {
      await syncServerLibrary(null, false);
      el.statusLeft.textContent = `Synced novels/ directory (${state.books.length} books)`;
      return;
    }
    if (typeof window.showDirectoryPicker === "function") {
      try {
        let dirHandle = forcePick ? null : await idbGet("kv", "dir").catch(() => null);
        if (dirHandle && typeof dirHandle.requestPermission === "function") {
          const perm = await dirHandle.requestPermission({ mode: "read" });
          if (perm === "granted") {
            state.pendingAuthHint = false;
            state.dirBooks = await readBooksFromDirHandle(dirHandle);
            await rebuildOfflineBooks();
            return;
          }
        }
        const picked = await window.showDirectoryPicker({ id: "moyu-novels", mode: "read" });
        await idbPut("kv", picked, "dir").catch(() => {});
        state.pendingAuthHint = false;
        state.dirBooks = await readBooksFromDirHandle(picked);
        await rebuildOfflineBooks();
        return;
      } catch (err) {
        if (err && err.name === "AbortError") return;
      }
    }
    el.fallbackInput.value = "";
    el.fallbackInput.click();
  }

  // ---------------- 启动流程（智能探测 Server / 离线兜底） ----------------
  async function bootLoad() {
    if (window.location.protocol.startsWith("http")) {
      try {
        const health = await apiGet("/api/health");
        if (health && health.ok && health.app === "ocr-reader") {
          state.serverMode = true;
          const srvState = await apiGet("/api/state");
          if (srvState) {
            if (srvState.settings && Object.keys(srvState.settings).length > 0) {
              state.settings = Object.assign({}, DEFAULT_SETTINGS, srvState.settings);
            }
            if (srvState.progress) state.progressMap = srvState.progress;
            if (srvState.lastBook) state.lastBook = srvState.lastBook;
            if (Array.isArray(srvState.bookmarks)) state.bookmarks = srvState.bookmarks;
            if (srvState.stats) state.stats = Object.assign(state.stats, srvState.stats);
            state.cleanEnabled = srvState.cleanEnabled !== false;
            state.customFilterWords = Array.isArray(srvState.customFilterWords) ? srvState.customFilterWords : [];
          }
          applyVisualSettings();
          await syncServerLibrary(state.lastBook, false);
          startHotWatchLoop();
          startStatsHeartbeat();
          return;
        }
      } catch (_) {}
    }

    // 离线静态模式：仅在此模式下按需动态加载离线书包 novels.js
    await loadScriptOnce("novels.js");
    await rebuildOfflineBooks();
    let dirty = false;
    try {
      const savedBooks = await idbGetAllBooks();
      if (savedBooks.length > 0) {
        state.importedBooks = savedBooks;
        dirty = true;
      }
    } catch (_) {}
    try {
      const savedHandle = await idbGet("kv", "dir");
      if (savedHandle && typeof savedHandle.queryPermission === "function") {
        const perm = await savedHandle.queryPermission({ mode: "read" });
        if (perm === "granted") {
          state.dirBooks = await readBooksFromDirHandle(savedHandle);
          dirty = true;
        } else {
          state.pendingAuthHint = true;
        }
      }
    } catch (_) {}
    if (dirty) await rebuildOfflineBooks();
    startStatsHeartbeat();
  }

  // ---------------- Go to / Settings / Library 对话框 ----------------
  function openGotoModal() {
    const book = state.books[state.cur.book];
    if (!book) return;
    const totalCh = book.chapterCount || (book.toc ? book.toc.length : 1);
    el.gotoMax.textContent = String(totalCh);
    el.gotoInput.value = String(state.cur.ch + 1);
    el.gotoModal.classList.remove("hidden");
    el.gotoInput.focus();
    el.gotoInput.select();
  }

  async function applyGoto() {
    const book = state.books[state.cur.book];
    if (!book) {
      el.gotoModal.classList.add("hidden");
      return;
    }
    const totalCh = book.chapterCount || (book.toc ? book.toc.length : 1);
    const raw = el.gotoInput.value.trim();
    if (raw.endsWith("%")) {
      const pct = parseFloat(raw.slice(0, -1));
      if (!Number.isNaN(pct) && pct >= 0 && pct <= 100) {
        const targetChar = (book.totalChars || 0) * (pct / 100);
        let targetCh = Math.min(totalCh - 1, Math.floor((pct / 100) * totalCh));
        if (book.totalChars > 0 && book.toc && book.toc.length > 0) {
          for (let i = book.toc.length - 1; i >= 0; i--) {
            if (book.toc[i].startChar <= targetChar) {
              targetCh = i;
              break;
            }
          }
        }
        await loadAndRenderChapter(state.cur.book, Math.max(0, targetCh), 0, false);
      }
    } else {
      const val = parseInt(raw, 10);
      if (!Number.isNaN(val) && val >= 1 && val <= totalCh) {
        await loadAndRenderChapter(state.cur.book, val - 1, 0, false);
      }
    }
    el.gotoModal.classList.add("hidden");
  }

  function renderLibraryList() {
    el.libList.innerHTML = "";
    if (state.books.length === 0) {
      el.libList.innerHTML = `<div class="lib-row"><span style="color:#888">暂无书籍，点击上方上传或将 .epub/.txt/.md 拖入窗口</span></div>`;
      return;
    }
    const sourceLabel = { server: "novels/", folder: "目录", imported: "本地缓存", packed: "离线打包" };
    state.books.forEach((b, idx) => {
      const row = document.createElement("div");
      row.className = "lib-row";
      const isCur = idx === state.cur.book;
      const extBadge = (b.ext || ".txt").replace(".", "").toUpperCase();
      const canManageServer = state.serverMode;
      const canDelOffline = !state.serverMode && state.importedBooks.some((x) => x.name === b.name);
      const mins = Math.round((b.readSeconds || 0) / 60);

      row.innerHTML = `
        <span class="lib-name" title="点击切换到本书">${isCur ? "● " : ""}${escHtml(b.name)}</span>
        <span class="lib-meta">
          <span class="lib-tag">${extBadge}</span>
          <span class="lib-tag">${b.percent || 0}%</span>
          ${mins > 0 ? `<span class="lib-tag">${mins}m</span>` : ""}
          <span class="lib-tag">${sourceLabel[b.source] || b.source}</span>
          ${canManageServer ? `<button class="lib-act-btn btn-ren" type="button" title="重命名文件">✎</button>` : ""}
          ${canManageServer || canDelOffline ? `<button class="todo-del btn-del" type="button" title="移除书籍">×</button>` : ""}
        </span>
      `;
      row.querySelector(".lib-name").addEventListener("click", async () => {
        await selectBook(idx);
        renderLibraryList();
      });

      const renBtn = row.querySelector(".btn-ren");
      if (renBtn) {
        renBtn.addEventListener("click", async () => {
          const nextName = window.prompt("输入新文件名（需保留扩展名 .epub / .txt / .md）：", b.name.split("/").pop());
          if (!nextName || nextName.trim() === b.name.split("/").pop()) return;
          try {
            const res = await apiPost("/api/book/rename", { oldName: b.name, newName: nextName.trim() });
            await syncServerLibrary(res.newName, false);
          } catch (err) {
            el.statusLeft.textContent = `Rename failed: ${err.message}`;
          }
        });
      }

      const delBtn = row.querySelector(".btn-del");
      if (delBtn) {
        delBtn.addEventListener("click", async () => {
          if (state.serverMode) {
            if (!window.confirm(`确认从 novels/ 目录永久删除 "${b.name}" 吗？`)) return;
            try {
              await apiPost("/api/book/delete", { name: b.name });
              await syncServerLibrary(null, false);
            } catch (err) {
              el.statusLeft.textContent = `Delete failed: ${err.message}`;
            }
          } else {
            await removeOfflineBook(b.name);
          }
        });
      }
      el.libList.appendChild(row);
    });
  }

  function switchSettingsTab(tabName) {
    el.sTabs.forEach((t) => t.classList.toggle("active", t.dataset.stab === tabName));
    el.stabAppearance.classList.toggle("hidden", tabName !== "appearance");
    el.stabReading.classList.toggle("hidden", tabName !== "reading");
    el.stabLibrary.classList.toggle("hidden", tabName !== "library");
    el.stabStats.classList.toggle("hidden", tabName !== "stats");
    if (tabName === "library") renderLibraryList();
    if (tabName === "stats") renderStatsPanel();
  }

  function openSettingsModal(initialTab) {
    el.setLines.value = String(state.settings.linesPerPage);
    el.setFontsize.value = String(state.settings.fontSize);
    el.setMaxcols.value = String(state.settings.maxCols);
    el.setStyle.value = state.settings.style;
    el.setBrightness.value = String(state.settings.brightness || 100);
    el.setBrightnessVal.textContent = (state.settings.brightness || 100) + "%";
    el.setParagap.checked = Boolean(state.settings.paraGap);
    el.setItalic.checked = Boolean(state.settings.italic);
    el.setWheel.value = state.settings.wheelMode || "step";
    el.setTyping.checked = Boolean(state.settings.typingMode);
    el.setAutoblur.checked = Boolean(state.settings.autoBossOnBlur);
    el.setCleanEnabled.checked = Boolean(state.cleanEnabled);
    el.setFilterWords.value = (state.customFilterWords || []).join("\n");
    switchSettingsTab(initialTab || "appearance");
    el.settingsModal.classList.remove("hidden");
  }

  async function applySettings() {
    const clamp = (v, min, max, fallback) => {
      const n = parseInt(v, 10);
      return Number.isNaN(n) ? fallback : Math.min(max, Math.max(min, n));
    };
    state.settings.linesPerPage = clamp(el.setLines.value, 10, 25, 15);
    state.settings.fontSize = clamp(el.setFontsize.value, 11, 22, 14);
    state.settings.maxCols = clamp(el.setMaxcols.value, 40, 160, 100);
    state.settings.style = el.setStyle.value === "docstring" ? "docstring" : "#";
    state.settings.brightness = clamp(el.setBrightness.value, 65, 135, 100);
    state.settings.paraGap = Boolean(el.setParagap.checked);
    state.settings.italic = Boolean(el.setItalic.checked);
    state.settings.wheelMode = el.setWheel.value;
    state.settings.typingMode = Boolean(el.setTyping.checked);
    state.settings.autoBossOnBlur = Boolean(el.setAutoblur.checked);

    const prevClean = JSON.stringify([state.cleanEnabled, state.customFilterWords]);
    state.cleanEnabled = Boolean(el.setCleanEnabled.checked);
    state.customFilterWords = el.setFilterWords.value
      .split(/\r?\n/)
      .map((s) => s.trim())
      .filter(Boolean);
    const cleanChanged = JSON.stringify([state.cleanEnabled, state.customFilterWords]) !== prevClean;

    persistStatePatch({
      settings: state.settings,
      cleanEnabled: state.cleanEnabled,
      customFilterWords: state.customFilterWords
    });

    el.settingsModal.classList.add("hidden");
    if (cleanChanged && state.serverMode && state.books[state.cur.book]) {
      // 清空当前书缓存并按新清洗规则重载当前章
      state.books.forEach((b) => { b.toc = []; b.chapterCache = {}; });
      await loadAndRenderChapter(state.cur.book, state.cur.ch, state.cur.line, false);
      el.statusLeft.textContent = "Text cleaning rules applied & chapter refreshed";
    } else {
      computeWrappedLines();
      renderEditor();
    }
  }

  function closeOpenModals() {
    let closed = false;
    [el.gotoModal, el.bookmarkModal, el.settingsModal].forEach((m) => {
      if (!m.classList.contains("hidden")) {
        m.classList.add("hidden");
        closed = true;
      }
    });
    return closed;
  }

  function closeFileMenu() {
    el.fileDropdown.classList.add("hidden");
    el.menuFile.classList.remove("open");
  }

  // ---------------- 拖拽分割条 & 全局文件拖拽 ----------------
  function initResizers() {
    el.resizerLeft.addEventListener("mousedown", (e) => {
      e.preventDefault();
      el.resizerLeft.classList.add("dragging");
      const startX = e.clientX;
      const startW = el.projectPanel.offsetWidth;
      const onMove = (ev) => {
        const w = Math.max(160, Math.min(480, startW + (ev.clientX - startX)));
        el.projectPanel.style.width = w + "px";
        state.settings.leftWidth = w;
      };
      const onUp = () => {
        el.resizerLeft.classList.remove("dragging");
        window.removeEventListener("mousemove", onMove);
        window.removeEventListener("mouseup", onUp);
        persistStatePatch({ settings: state.settings });
        computeWrappedLines();
        renderEditor();
      };
      window.addEventListener("mousemove", onMove);
      window.addEventListener("mouseup", onUp);
    });

    el.resizerBottom.addEventListener("mousedown", (e) => {
      e.preventDefault();
      el.resizerBottom.classList.add("dragging");
      const startY = e.clientY;
      const startH = el.runPanel.offsetHeight;
      const onMove = (ev) => {
        const h = Math.max(90, Math.min(380, startH - (ev.clientY - startY)));
        el.runPanel.style.height = h + "px";
        state.settings.bottomHeight = h;
      };
      const onUp = () => {
        el.resizerBottom.classList.remove("dragging");
        window.removeEventListener("mousemove", onMove);
        window.removeEventListener("mouseup", onUp);
        persistStatePatch({ settings: state.settings });
        renderEditor();
      };
      window.addEventListener("mousemove", onMove);
      window.addEventListener("mouseup", onUp);
    });
  }

  function initDragDrop() {
    let dragDepth = 0;
    window.addEventListener("dragenter", (e) => {
      if (e.dataTransfer && Array.from(e.dataTransfer.types || []).includes("Files")) {
        e.preventDefault();
        dragDepth++;
        el.dropOverlay.classList.remove("hidden");
      }
    });
    window.addEventListener("dragover", (e) => { if (dragDepth > 0) e.preventDefault(); });
    window.addEventListener("dragleave", () => {
      if (dragDepth > 0) {
        dragDepth--;
        if (dragDepth === 0) el.dropOverlay.classList.add("hidden");
      }
    });
    window.addEventListener("drop", (e) => {
      e.preventDefault();
      dragDepth = 0;
      el.dropOverlay.classList.add("hidden");
      if (e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files.length > 0) {
        importFileList(e.dataTransfer.files);
      }
    });
  }

  // ---------------- 假训练日志 ----------------
  function formatLogTime(d) {
    const pad = (n) => String(n).padStart(2, "0");
    return `${d.getFullYear()}/${pad(d.getMonth() + 1)}/${pad(d.getDate())} ${pad(d.getHours())}:${pad(
      d.getMinutes()
    )}:${pad(d.getSeconds())}`;
  }

  function makeLogLine(isEval) {
    const ts = formatLogTime(new Date());
    if (isEval) {
      const p = (0.83 + Math.random() * 0.04).toFixed(4);
      const r = (0.78 + Math.random() * 0.04).toFixed(4);
      const h = (0.805 + Math.random() * 0.03).toFixed(4);
      return `[${ts}] ppocr INFO: eval metric | precision: ${p}, recall: ${r}, hmean: ${h}, fps: ${(28 + Math.random() * 5).toFixed(2)}`;
    }
    state.logIter += 20;
    if (state.logIter > 1000) { state.logIter = 20; state.logEpoch += 1; }
    const lr = (0.00095 * Math.pow(0.998, state.logIter / 20)).toFixed(6);
    const shrink = (0.38 + Math.random() * 0.08).toFixed(4);
    const thresh = (0.24 + Math.random() * 0.06).toFixed(4);
    const bce = (0.15 + Math.random() * 0.05).toFixed(4);
    const loss = (parseFloat(shrink) + parseFloat(thresh) + parseFloat(bce)).toFixed(4);
    const hmean = (0.808 + Math.random() * 0.015).toFixed(4);
    return `[${ts}] epoch: [${state.logEpoch}/500], iter: ${state.logIter}, lr: ${lr}, loss: ${loss}, loss_shrink_maps: ${shrink}, loss_threshold_maps: ${thresh}, loss_binary_maps: ${bce}, hmean: ${hmean}`;
  }

  function appendRunLog(text, cls) {
    const div = document.createElement("div");
    if (cls) div.className = cls;
    div.textContent = text;
    el.runLogs.appendChild(div);
    while (el.runLogs.childElementCount > 200) el.runLogs.removeChild(el.runLogs.firstElementChild);
    el.runLogs.scrollTop = el.runLogs.scrollHeight;
  }

  function initFakeLogs() {
    appendRunLog("D:\\envs\\ocr-env\\Scripts\\python.exe D:\\work\\ocr-detector\\tools\\train_det.py -c configs\\det_db_r50.yml");
    appendRunLog("[2026/11/26 10:11:52] ppocr INFO: Loading pretrained backbone ResNet50_vd_ssld...", "log-line-ok");
    for (let i = 0; i < 14; i++) appendRunLog(makeLogLine(i === 13));
    function scheduleNext() {
      setTimeout(() => {
        const isEval = state.logIter % 200 === 0;
        appendRunLog(makeLogLine(isEval), isEval ? "log-line-ok" : "");
        scheduleNext();
      }, 3000 + Math.floor(Math.random() * 5000));
    }
    scheduleNext();
  }

  // ---------------- 事件绑定 ----------------
  el.menuFile.addEventListener("click", (e) => {
    e.stopPropagation();
    const hidden = el.fileDropdown.classList.toggle("hidden");
    el.menuFile.classList.toggle("open", !hidden);
  });
  document.addEventListener("click", (e) => {
    if (!el.fileDropdown.contains(e.target) && e.target !== el.menuFile) closeFileMenu();
    if (!el.findWrap.contains(e.target)) el.findResultsPanel.classList.add("hidden");
  });

  el.actOpenFolder.addEventListener("click", () => { closeFileMenu(); openFolder(true); });
  el.actImportFiles.addEventListener("click", () => { closeFileMenu(); triggerImportFiles(); });
  el.actReloadFolder.addEventListener("click", () => { closeFileMenu(); openFolder(false); });
  el.actAddBookmark.addEventListener("click", () => { closeFileMenu(); openBookmarkModal(); });
  el.actExportNotes.addEventListener("click", () => { closeFileMenu(); exportCurrentNotes(); });
  if (el.actOpenLibrary) {
    el.actOpenLibrary.addEventListener("click", () => { closeFileMenu(); openSettingsModal("library"); });
  }
  el.actOpenSettings.addEventListener("click", () => { closeFileMenu(); openSettingsModal("appearance"); });
  el.structureBookSelect.addEventListener("change", () => {
    const idx = parseInt(el.structureBookSelect.value, 10);
    if (!Number.isNaN(idx) && idx >= 0 && idx < state.books.length) {
      selectBook(idx);
      el.structureBookSelect.blur();
    }
  });
  if (el.actExit) {
    el.actExit.addEventListener("click", async () => {
      closeFileMenu();
      if (state.serverMode) {
        try { await apiPost("/api/shutdown", {}); } catch (_) {}
      }
      el.statusLeft.textContent = "Service stopped — you may close this window";
      window.close();
    });
  }

  el.menuEdit.addEventListener("click", openFindBar);
  el.menuNavigate.addEventListener("click", openGotoModal);
  el.menuTools.addEventListener("click", () => openSettingsModal("stats"));
  el.menuHelp.addEventListener("click", () => openSettingsModal("reading"));
  el.btnFind.addEventListener("click", openFindBar);
  el.btnSettings.addEventListener("click", () => openSettingsModal("appearance"));
  el.tabRightSciview.addEventListener("click", () => { if (!state.boss) openSettingsModal("stats"); });
  el.btnRunSim.addEventListener("click", () => {
    appendRunLog(makeLogLine(false));
    if (state.bottomPane !== "run") switchBottomPane("run");
  });

  el.tabLeftProject.addEventListener("click", () => switchLeftView("project"));
  el.tabLeftStructure.addEventListener("click", () => { if (!state.boss) switchLeftView("structure"); });
  el.bottomTabs.forEach((btn) => btn.addEventListener("click", () => switchBottomPane(btn.dataset.pane)));
  el.btnTodoAdd.addEventListener("click", openBookmarkModal);
  el.btnTodoExport.addEventListener("click", exportCurrentNotes);

  // 搜索栏事件
  let findTimer = null;
  el.findInput.addEventListener("input", () => {
    clearTimeout(findTimer);
    findTimer = setTimeout(() => runFindQuery(false), 140);
  });
  el.findInput.addEventListener("focus", () => {
    if (state.find.results.length > 0) el.findResultsPanel.classList.remove("hidden");
  });
  el.findInput.addEventListener("keydown", (e) => {
    if (e.key === "Enter") {
      e.preventDefault();
      if (state.find.results.length === 0) runFindQuery(true);
      else jumpToFindResult(state.find.idx + (e.shiftKey ? -1 : 1));
    }
  });
  el.findModeCh.addEventListener("click", () => {
    state.find.mode = "chapters";
    el.findModeCh.classList.add("active");
    el.findModeText.classList.remove("active");
    runFindQuery(false);
  });
  el.findModeText.addEventListener("click", () => {
    state.find.mode = "content";
    el.findModeText.classList.add("active");
    el.findModeCh.classList.remove("active");
    runFindQuery(false);
  });
  el.findScopeAll.addEventListener("click", () => {
    state.find.scope = state.find.scope === "book" ? "all" : "book";
    el.findScopeAll.classList.toggle("active", state.find.scope === "all");
    runFindQuery(false);
  });
  el.findPrev.addEventListener("click", () => jumpToFindResult(state.find.idx - 1));
  el.findNext.addEventListener("click", () => jumpToFindResult(state.find.idx + 1));
  el.findClose.addEventListener("click", () => closeFindBar(true));

  // 文件选择器回调
  el.fallbackInput.addEventListener("change", async (e) => {
    const files = Array.from(e.target.files || []).filter((f) => /\.(txt|md)$/i.test(f.name));
    if (files.length === 0) return;
    const loaded = [];
    for (const f of files) loaded.push(parseBookClient(f.name, decodeBuffer(await f.arrayBuffer()), "folder"));
    state.dirBooks = loaded;
    await rebuildOfflineBooks();
  });
  el.importFilesInput.addEventListener("change", (e) => importFileList(e.target.files));

  // Go to & Bookmark 弹窗
  el.gotoOk.addEventListener("click", applyGoto);
  el.gotoCancel.addEventListener("click", () => el.gotoModal.classList.add("hidden"));
  el.gotoInput.addEventListener("keydown", (e) => { if (e.key === "Enter") { e.preventDefault(); applyGoto(); } });

  el.bmOk.addEventListener("click", commitBookmark);
  el.bmCancel.addEventListener("click", () => el.bookmarkModal.classList.add("hidden"));
  el.bmNoteInput.addEventListener("keydown", (e) => { if (e.key === "Enter") { e.preventDefault(); commitBookmark(); } });

  // Settings 弹窗
  el.sTabs.forEach((t) => t.addEventListener("click", () => switchSettingsTab(t.dataset.stab)));
  el.setBrightness.addEventListener("input", () => { el.setBrightnessVal.textContent = el.setBrightness.value + "%"; });
  el.setOk.addEventListener("click", applySettings);
  el.setCancel.addEventListener("click", () => el.settingsModal.classList.add("hidden"));
  el.setReset.addEventListener("click", () => {
    state.settings = Object.assign({}, DEFAULT_SETTINGS);
    persistStatePatch({ settings: state.settings });
    openSettingsModal("appearance");
    computeWrappedLines();
    renderEditor();
  });
  el.libImportBtn.addEventListener("click", triggerImportFiles);
  el.libFolderBtn.addEventListener("click", () => { el.settingsModal.classList.add("hidden"); openFolder(true); });

  // 鼠标滚轮翻页
  let lastWheelTs = 0;
  el.codeViewport.addEventListener(
    "wheel",
    (e) => {
      if (state.boss || state.settings.wheelMode === "off" || e.shiftKey || e.ctrlKey) return;
      if (state.books.length === 0) return;
      e.preventDefault();
      const now = Date.now();
      const cooldown = state.settings.wheelMode === "page" ? 180 : 60;
      if (now - lastWheelTs < cooldown) return;
      lastWheelTs = now;
      const dir = e.deltaY > 0 ? 1 : -1;
      const step = state.settings.wheelMode === "page" ? state.settings.linesPerPage : 3;
      advanceLines(dir * step);
    },
    { passive: false }
  );

  // 失焦自动老板键
  window.addEventListener("blur", () => {
    if (state.settings.autoBossOnBlur && !state.boss) toggleBossMode(true);
  });

  // 全局快捷键
  window.addEventListener("keydown", (e) => {
    if (e.key === "Escape") {
      e.preventDefault();
      closeFileMenu();
      if (closeOpenModals()) return;
      if (state.find.open) { closeFindBar(true); return; }
      toggleBossMode();
      return;
    }

    const activeTag = document.activeElement ? document.activeElement.tagName : "";
    if (activeTag === "INPUT" || activeTag === "SELECT" || activeTag === "TEXTAREA") return;

    if ((e.ctrlKey && !e.altKey && e.key === ",") || (e.ctrlKey && e.altKey && (e.key === "s" || e.key === "S"))) { e.preventDefault(); openSettingsModal("appearance"); return; }
    if (e.altKey && !e.ctrlKey && (e.key === "l" || e.key === "L")) { e.preventDefault(); if (!state.boss) openSettingsModal("library"); return; }
    if (e.ctrlKey && e.altKey && (e.key === "y" || e.key === "Y")) { e.preventDefault(); openFolder(false); return; }
    if (e.ctrlKey && !e.altKey && (e.key === "o" || e.key === "O")) { e.preventDefault(); openFolder(false); return; }
    if (e.ctrlKey && !e.altKey && (e.key === "i" || e.key === "I")) { e.preventDefault(); triggerImportFiles(); return; }
    if (e.ctrlKey && !e.altKey && (e.key === "f" || e.key === "F")) { e.preventDefault(); openFindBar(); return; }
    if (e.ctrlKey && !e.altKey && (e.key === "g" || e.key === "G")) { e.preventDefault(); openGotoModal(); return; }
    if (e.ctrlKey && !e.altKey && (e.key === "b" || e.key === "B")) { e.preventDefault(); openBookmarkModal(); return; }
    if (e.altKey && !e.ctrlKey && e.key === "1") { e.preventDefault(); switchLeftView("project"); return; }
    if (e.altKey && !e.ctrlKey && e.key === "7") { e.preventDefault(); if (!state.boss) switchLeftView("structure"); return; }
    if (e.ctrlKey && e.key === "ArrowDown") { e.preventDefault(); jumpChapter(1); return; }
    if (e.ctrlKey && e.key === "ArrowUp") { e.preventDefault(); jumpChapter(-1); return; }

    if (e.key === "ArrowRight" || e.key === "PageDown" || e.key === " ") {
      e.preventDefault();
      advanceLines(state.settings.linesPerPage);
      return;
    }
    if (e.key === "ArrowLeft" || e.key === "PageUp") {
      e.preventDefault();
      advanceLines(-state.settings.linesPerPage);
      return;
    }

    if (state.settings.typingMode && !state.boss && !e.ctrlKey && !e.altKey && !e.metaKey) {
      if (e.key === "Backspace") {
        e.preventDefault();
        advanceLines(-1);
      } else if (e.key.length === 1 || e.key === "Enter") {
        e.preventDefault();
        advanceLines(1);
      }
    }
  });

  let resizeTimer = null;
  window.addEventListener("resize", () => {
    clearTimeout(resizeTimer);
    resizeTimer = setTimeout(() => {
      computeWrappedLines();
      renderEditor();
    }, 150);
  });

  // ---------------- 启动 ----------------
  applyVisualSettings();
  initResizers();
  initDragDrop();
  initFakeLogs();
  initFakeTerminal();
  bootLoad();
})();
