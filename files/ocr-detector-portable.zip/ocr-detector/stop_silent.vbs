Option Explicit
Dim fso, sh, dir, scriptPath, pyCmd

Set fso = CreateObject("Scripting.FileSystemObject")
Set sh = CreateObject("WScript.Shell")
dir = fso.GetParentFolderName(WScript.ScriptFullName)
scriptPath = fso.BuildPath(dir, "server.py")

Function CmdExists(cmdLine)
    On Error Resume Next
    Dim rc
    rc = sh.Run("cmd /c " & cmdLine & " >nul 2>nul", 0, True)
    CmdExists = (Err.Number = 0 And rc = 0)
    On Error GoTo 0
End Function

pyCmd = ""
If CmdExists("pythonw --version") Then
    pyCmd = "pythonw"
ElseIf CmdExists("pyw -3 --version") Then
    pyCmd = "pyw -3"
ElseIf CmdExists("python --version") Then
    pyCmd = "python"
ElseIf CmdExists("py -3 --version") Then
    pyCmd = "py -3"
End If

If pyCmd <> "" Then
    sh.CurrentDirectory = dir
    sh.Run pyCmd & " """ & scriptPath & """ --stop", 0, True
End If
