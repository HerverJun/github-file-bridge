@echo off
title PyCharm OCR Dataset Service (127.0.0.1)
cd /d "%~dp0"
set "PY_CMD="
python --version >nul 2>nul && set "PY_CMD=python"
if not defined PY_CMD (py -3 --version >nul 2>nul && set "PY_CMD=py -3")
if not defined PY_CMD (
    echo [INFO] Python 3 not found. Opening standalone offline reader...
    start "" "%~dp0index.html"
    exit /b 0
)
%PY_CMD% "%~dp0server.py" --mode app
if %errorlevel% neq 0 pause
