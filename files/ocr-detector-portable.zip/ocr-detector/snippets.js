window.SNIPPETS = [
  {
    file: "db_postprocess.py",
    crumbs: ["det", "db_postprocess.py"],
    lang: "py",
    startLine: 78,
    bossComments: [
      "DBNet differentiable binarization post-processing pipeline:",
      "1. Threshold probability map using self.thresh to extract foreground mask.",
      "2. Trace external contours with cv2.CHAIN_APPROX_SIMPLE to reduce vertices.",
      "3. Compute minimum-area oriented bounding box and reject tiny noise regions.",
      "4. Estimate polygon confidence via fast axis-aligned crop mean over pred map.",
      "5. Expand shrunken text kernels back using Vatti clipping (pyclipper).",
      "   Offset distance D = Area * unclip_ratio / Perimeter (default ratio=1.5).",
      "6. Re-fit minimum bounding rectangle after expansion and clamp to dest dims.",
      "Note: polygons with fewer than 4 vertices after unclipping are discarded.",
      "Benchmark (ICDAR2015 val, 1280x736): avg postprocess latency ~3.4ms/img.",
      "Ref: Liao et al., Real-time Scene Text Detection with Differentiable",
      "Binarization, AAAI 2020. Keep float32 precision prior to contour casting.",
      "Warning: changing min_size below 3 increases false positives on blurred",
      "background textures and watermark edges in scanned invoice datasets.",
      "TODO(det): evaluate polygon mode vs quad mode for curved receipt lines.",
      "Memory guard: cap candidate count to max_candidates before unclipping.",
      "Coordinate order follows clockwise top-left convention for perspective crop.",
      "Verified compatible with OpenCV 4.8+ and pyclipper 1.3.0.post5."
    ],
    code: String.raw`import cv2
import numpy as np
import pyclipper
from shapely.geometry import Polygon


class DBPostProcess:
    """Decode probability map from DBNet head into oriented text polygons."""

    def __init__(self, thresh=0.3, box_thresh=0.6, max_candidates=1000, unclip_ratio=1.5):
        self.thresh = thresh
        self.box_thresh = box_thresh
        self.max_candidates = max_candidates
        self.unclip_ratio = unclip_ratio
        self.min_size = 3

    def boxes_from_bitmap(self, pred, bitmap, dest_width, dest_height):
        height, width = bitmap.shape
        contours, _ = cv2.findContours(
            (bitmap * 255).astype(np.uint8),
            cv2.RETR_LIST,
            cv2.CHAIN_APPROX_SIMPLE
        )
        boxes, scores = [], []
        # @@NOVEL@@
        for idx in range(min(len(contours), self.max_candidates)):
            contour = contours[idx]
            points, sside = self.get_mini_boxes(contour)
            if sside < self.min_size:
                continue
            score = self.box_score_fast(pred, points.reshape(-1, 2))
            if self.box_thresh > score:
                continue
            box = self.unclip(points, self.unclip_ratio).reshape(-1, 1, 2)
            box, sside = self.get_mini_boxes(box)
            if sside < self.min_size + 2:
                continue
            box = np.array(box)
            box[:, 0] = np.clip(np.round(box[:, 0] / width * dest_width), 0, dest_width)
            box[:, 1] = np.clip(np.round(box[:, 1] / height * dest_height), 0, dest_height)
            boxes.append(box.astype(np.int16))
            scores.append(score)
        return np.array(boxes, dtype=np.int16), scores`
  },
  {
    file: "dbnet.py",
    crumbs: ["det", "dbnet.py"],
    lang: "py",
    startLine: 104,
    bossComments: [
      "Differentiable Binarization (DB) Head forward formulation:",
      "Given fused multi-scale FPN feature tensor F of shape (B, C, H/4, W/4):",
      "- Probability branch predicts shrink text region map P in [0, 1].",
      "- Threshold branch predicts adaptive local threshold map T in [0, 1].",
      "- Approximate step function: B_hat = 1 / (1 + exp(-k * (P - T))).",
      "Amplification factor k=50 yields sharp gradients near the decision boundary",
      "while preventing gradient vanishing during early training epochs.",
      "During inference, only probability map P is needed, cutting head FLOPs by",
      "nearly 45% without degrading ICDAR2015 or Total-Text Hmean.",
      "Transposed convolutions use kernel_size=2, stride=2 to avoid checkerboard",
      "artifacts when upsampling back to full input resolution.",
      "All Conv-BN-ReLU blocks initialize weights with Kaiming normal (fan_out).",
      "Ensure batch_size >= 4 when using standard BatchNorm2d; switch to SyncBN",
      "for multi-GPU distributed training across 4+ nodes.",
      "Output dictionary keys match DBLoss expectations: maps, thresh_maps, binary.",
      "FP16 note: clamp (P - T) to [-15, 15] inside sigmoid to avoid inf under AMP.",
      "TensorRT export: dynamic shapes verified for 320 <= H, W <= 1920.",
      "Feature pyramid channel width fixed at inner_channels=256."
    ],
    code: String.raw`import torch
import torch.nn as nn
import torch.nn.functional as F


class DBHead(nn.Module):
    """Differentiable Binarization head predicting probability and threshold maps."""

    def __init__(self, in_channels, k=50, adaptive=True):
        super().__init__()
        self.k = k
        self.adaptive = adaptive
        self.binarize = nn.Sequential(
            nn.Conv2d(in_channels, in_channels // 4, 3, padding=1, bias=False),
            nn.BatchNorm2d(in_channels // 4),
            nn.ReLU(inplace=True),
            nn.ConvTranspose2d(in_channels // 4, in_channels // 4, 2, 2),
            nn.BatchNorm2d(in_channels // 4),
            nn.ReLU(inplace=True),
            nn.ConvTranspose2d(in_channels // 4, 1, 2, 2),
            nn.Sigmoid()
        )
        self.thresh = self._init_thresh(in_channels)

    def step_function(self, x, y):
        # @@NOVEL@@
        return torch.reciprocal(1.0 + torch.exp(-self.k * (x - y)))

    def forward(self, fuse_feat):
        shrink_maps = self.binarize(fuse_feat)
        if not self.training or not self.adaptive:
            return {"maps": shrink_maps}
        threshold_maps = self.thresh(fuse_feat)
        binary_maps = self.step_function(shrink_maps, threshold_maps)
        return {
            "maps": shrink_maps,
            "shrink_maps": shrink_maps,
            "threshold_maps": threshold_maps,
            "binary_maps": binary_maps
        }`
  },
  {
    file: "ctc_decoder.py",
    crumbs: ["rec", "ctc_decoder.py"],
    lang: "py",
    startLine: 64,
    bossComments: [
      "CTC greedy and prefix beam decoding utilities for sequence recognition.",
      "Index 0 is strictly reserved for the CTC blank token across all checkpoints.",
      "Adjacent duplicate labels are collapsed prior to removing blank indices so",
      "repeated characters separated by a blank (e.g., 'l', blank, 'l') survive.",
      "Confidence score aggregates per-timestep softmax maxima over retained tokens.",
      "For Chinese + alphanumeric 6623-char dictionaries, greedy decoding runs in",
      "<0.3ms per batch of 32 crops on CPU; beam_width=5 improves rare char recall",
      "by +0.4% at ~3x CPU cost.",
      "Ensure dictionary file uses LF or CRLF without trailing blank lines.",
      "When use_space_char=True, whitespace is appended at the tail of vocabulary.",
      "Out-of-range indices are defensively ignored in case of head/dict mismatch.",
      "Empty decoded sequences return ('', 0.0) and are filtered downstream.",
      "Prefix beam search stores log-probabilities as (p_blank, p_non_blank).",
      "Log-sum-exp stabilization prevents numerical underflow on long text lines.",
      "Note: half-width / full-width punctuation normalization runs post-decode.",
      "Thread-safe: decoder keeps read-only lookup table after __init__.",
      "Tested against PP-OCRv4 ch_dict_v1.txt (6625 symbols including space).",
      "See rec_crnn.yml for max_text_length and character_dict_path settings."
    ],
    code: String.raw`import math
import numpy as np


class CTCLabelDecoder:
    """Convert raw CTC logits into normalized UTF-8 text strings."""

    def __init__(self, dict_path, use_space_char=True):
        self.character = ["blank"]
        with open(dict_path, "r", encoding="utf-8") as fp:
            for line in fp:
                char = line.strip("\r\n")
                self.character.append(char)
        if use_space_char:
            self.character.append(" ")
        self.ignored_tokens = [0]

    def decode_greedy(self, text_index, text_prob=None, remove_duplicate=True):
        results = []
        batch_size = len(text_index)
        for batch_idx in range(batch_size):
            selection = np.ones(len(text_index[batch_idx]), dtype=bool)
            # @@NOVEL@@
            if remove_duplicate:
                selection[1:] = text_index[batch_idx][1:] != text_index[batch_idx][:-1]
            for ignored in self.ignored_tokens:
                selection &= text_index[batch_idx] != ignored
            char_list = [
                self.character[idx]
                for idx in text_index[batch_idx][selection]
                if idx < len(self.character)
            ]
            if text_prob is not None:
                conf_list = text_prob[batch_idx][selection]
                avg_conf = float(np.mean(conf_list)) if len(conf_list) else 0.0
            else:
                avg_conf = 1.0
            results.append(("".join(char_list), round(avg_conf, 4)))
        return results

    def beam_search_step(self, probs, beam_width=5):
        beams = {(): (0.0, -math.inf)}
        return sorted(beams.items(), key=lambda x: x[1][0], reverse=True)[:beam_width]`
  },
  {
    file: "crnn.py",
    crumbs: ["rec", "crnn.py"],
    lang: "py",
    startLine: 88,
    bossComments: [
      "CRNN sequence encoder + CTC projection head for cropped text line images.",
      "Input shape: (B, 3, 48, W_max) where aspect ratio is preserved via right-pad.",
      "Backbone downsamples height by 16x/48x and width by 4x to keep dense steps",
      "for narrow characters such as '1', 'i', 'l', and vertical punctuation.",
      "Two-layer bidirectional LSTM models left/right contextual dependencies with",
      "hidden_size=256 per direction (concatenated output dim = 512).",
      "Linear head maps sequence features (B, T, 512) to (B, T, num_classes).",
      "During ONNX / TensorRT export, flatten_parameters() is skipped on dynamic W.",
      "Dropout=0.1 between BiLSTM layers mitigates overfitting on synthetic corpora.",
      "Use CTCLoss(blank=0, zero_infinity=True) to guard against short-crop NaNs.",
      "Weight decay is disabled on bias and LayerNorm/BatchNorm affine parameters.",
      "Inference latency: 2.1ms for batch=16 (48x320) on FP16 TensorRT engine.",
      "Compatible with both MobileNetV3-large and SVTR-Tiny visual backbones.",
      "AdaptiveAvgPool2d collapses vertical axis cleanly to height=1 before RNN.",
      "Note: transpose to (T, B, C) only if passing directly into torch.nn.CTCLoss.",
      "Checkpoint keys follow 'backbone.*', 'neck.encoder.*', and 'head.fc.*'.",
      "Verify input normalization matches mean=[0.5,0.5,0.5], std=[0.5,0.5,0.5].",
      "Dynamic width padding aligned to multiples of 32 for GPU warp efficiency."
    ],
    code: String.raw`import torch
import torch.nn as nn


class SequenceEncoder(nn.Module):
    """Bidirectional LSTM sequence modeling neck for OCR recognition."""

    def __init__(self, in_channels, hidden_size=256, num_layers=2, dropout=0.1):
        super().__init__()
        self.pool = nn.AdaptiveAvgPool2d((1, None))
        self.rnn = nn.LSTM(
            input_size=in_channels,
            hidden_size=hidden_size,
            num_layers=num_layers,
            bidirectional=True,
            batch_first=True,
            dropout=dropout if num_layers > 1 else 0.0
        )
        self.out_channels = hidden_size * 2

    def forward(self, feat):
        pooled = self.pool(feat).squeeze(2).permute(0, 2, 1)
        # @@NOVEL@@
        seq_out, _ = self.rnn(pooled)
        return seq_out


class CRNNHead(nn.Module):
    def __init__(self, in_channels, num_classes):
        super().__init__()
        self.fc = nn.Linear(in_channels, num_classes)

    def forward(self, seq_feat):
        logits = self.fc(seq_feat)
        if not self.training:
            return torch.softmax(logits, dim=-1)
        return logits`
  },
  {
    file: "augment.py",
    crumbs: ["det", "augment.py"],
    lang: "py",
    startLine: 112,
    bossComments: [
      "Synchronized geometric augmentation for scene text detection datasets.",
      "Affine matrix rotates both RGB image and N-point ground-truth polygons",
      "around the image center, then translates origin so rotated bounds remain",
      "non-negative without clipping corner text lines.",
      "Border fill uses neutral gray (128, 128, 128) to avoid introducing sharp",
      "black edge gradients that DBNet could misclassify as vertical strokes.",
      "Polygons marked with ignore_tags=True ('###') are preserved unchanged to",
      "maintain consistent loss masking in MakeShrinkMap and MakeBorderMap.",
      "Keep max_angle <= 15 deg for document/receipt OCR; widen to 30 deg for",
      "natural street-view scenes (ICDAR2015 / RCTW / MLT).",
      "Homogeneous coordinate multiplication runs in float32 for sub-pixel accuracy.",
      "Random crop stage ensures sampled crops avoid slicing through active text",
      "boxes whenever a valid split axis exists within 50 trials.",
      "After warping, polygons falling >75% outside the viewport are flagged ignored.",
      "Color jitter and Gaussian blur should run after geometric transforms.",
      "Determinism: worker seeds initialized via torch.initial_seed() modulo 2**32.",
      "Measured overhead: ~1.8ms per 1024x1024 sample in 8-worker DataLoader.",
      "Compatible with arbitrary N-vertex curved text annotations (Total-Text)."
    ],
    code: String.raw`import random
import cv2
import numpy as np


class RandomRotateAndCrop:
    """Apply affine rotation and synchronized polygon warping for text detection."""

    def __init__(self, max_angle=15.0, crop_size=(640, 640), keep_ratio=0.75):
        self.max_angle = max_angle
        self.crop_size = crop_size
        self.keep_ratio = keep_ratio

    def __call__(self, data):
        img = data["image"]
        polys = data["polys"]
        ignore_tags = data["ignore_tags"]
        h, w = img.shape[:2]
        angle = random.uniform(-self.max_angle, self.max_angle)
        center = (w * 0.5, h * 0.5)
        rot_mat = cv2.getRotationMatrix2D(center, angle, 1.0)
        # @@NOVEL@@
        cos_v = abs(rot_mat[0, 0])
        sin_v = abs(rot_mat[0, 1])
        new_w = int(h * sin_v + w * cos_v)
        new_h = int(h * cos_v + w * sin_v)
        rot_mat[0, 2] += (new_w * 0.5) - center[0]
        rot_mat[1, 2] += (new_h * 0.5) - center[1]
        warped = cv2.warpAffine(
            img, rot_mat, (new_w, new_h), flags=cv2.INTER_LINEAR, borderValue=(128, 128, 128)
        )
        transformed_polys = []
        for poly, ignored in zip(polys, ignore_tags):
            if ignored:
                transformed_polys.append(poly)
                continue
            ones = np.ones((poly.shape[0], 1), dtype=np.float32)
            pts = np.hstack([poly, ones])
            transformed_polys.append(pts.dot(rot_mat.T))
        data["image"] = warped
        data["polys"] = transformed_polys
        return data`
  },
  {
    file: "train_det.py",
    crumbs: ["tools", "train_det.py"],
    lang: "py",
    startLine: 145,
    bossComments: [
      "Mixed-precision (AMP) training loop for DBNet++ text detection model.",
      "Loss combines three weighted terms: L = L_shrink + alpha*L_thresh + beta*L_bin",
      "with alpha=10.0, beta=1.0 and OHEM negative-to-positive ratio of 3:1.",
      "GradScaler dynamically adjusts loss scale to prevent FP16 underflow in",
      "small threshold-map gradients; clip_grad_norm_(5.0) stabilizes early epochs.",
      "Cosine annealing scheduler with 2-epoch linear warmup updates per iteration.",
      "Pinned host memory + non_blocking=True overlaps H2D copy with GPU compute.",
      "EMA weights (decay=0.9995) are evaluated every 5 epochs on ICDAR2015 val.",
      "Checkpoints save best_hmean.pth along with optimizer and scaler states.",
      "If loss becomes NaN on corrupted labels, scaler automatically skips step().",
      "Recommended batch_size=16 on single 24GB GPU (640x640 input crop).",
      "Log metrics emitted every 20 iterations to stdout and TensorBoard writer.",
      "Ensure cudnn.benchmark=True only when input spatial sizes remain fixed.",
      "Gradient accumulation can be toggled via cfg.Train.grad_accum_steps.",
      "Peak VRAM footprint: ~11.4 GB with ResNet50_vd backbone and AMP enabled.",
      "Zeroing gradients with set_to_none=True reduces memory bandwidth overhead.",
      "Resume training via --resume output/db_r50/latest.pth.",
      "All distributed ranks synchronize eval Hmean via all_reduce before logging."
    ],
    code: String.raw`import time
import torch
from torch.cuda.amp import GradScaler, autocast


def train_one_epoch(model, train_loader, criterion, optimizer, scheduler, epoch, logger):
    model.train()
    scaler = GradScaler(enabled=True)
    meter = {"loss": 0.0, "shrink": 0.0, "thresh": 0.0, "bce": 0.0}
    t_start = time.time()

    for step, batch in enumerate(train_loader):
        images = batch["image"].cuda(non_blocking=True)
        targets = {k: v.cuda(non_blocking=True) for k, v in batch.items() if k != "image"}
        optimizer.zero_grad(set_to_none=True)

        with autocast():
            preds = model(images)
            loss_dict = criterion(preds, targets)
            total_loss = loss_dict["loss"]
        # @@NOVEL@@

        scaler.scale(total_loss).backward()
        scaler.unscale_(optimizer)
        torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=5.0)
        scaler.step(optimizer)
        scaler.update()
        scheduler.step()

        meter["loss"] += float(total_loss.detach())
        meter["shrink"] += float(loss_dict["loss_shrink_maps"].detach())
        meter["thresh"] += float(loss_dict["loss_threshold_maps"].detach())

        if (step + 1) % 20 == 0:
            elapsed = time.time() - t_start
            avg_loss = meter["loss"] / (step + 1)
            lr = optimizer.param_groups[0]["lr"]
            logger.info("epoch=%d iter=%d lr=%.6f loss=%.4f time=%.2fs", epoch, step + 1, lr, avg_loss, elapsed)
    return meter["loss"] / max(len(train_loader), 1)`
  },
  {
    file: "infer.py",
    crumbs: ["tools", "infer.py"],
    lang: "py",
    startLine: 92,
    bossComments: [
      "End-to-end two-stage OCR inference pipeline (Detection -> Crop -> Recognition).",
      "Perspective transform rectifies arbitrary quadrilaterals into axis-aligned",
      "horizontal crops using bicubic interpolation and replicate border padding.",
      "Vertical text heuristic: when cropped height/width >= 1.5, rotate 90 deg CCW",
      "before passing to the horizontal recognition model.",
      "Recognition crops are sorted by width aspect ratio to minimize right-padding",
      "waste inside mini-batches (rec_batch_num=6 by default).",
      "Detections with recognition confidence below drop_score (0.5) are discarded.",
      "Boxes are pre-sorted in natural reading order (top-to-bottom, left-to-right)",
      "using a 10px vertical line tolerance for multi-column invoice layouts.",
      "Optional angle classifier (cls_predictor) handles upside-down 180-deg crops.",
      "Warmup pass recommended on first 3 calls when running ONNXRuntime / TRT.",
      "Return payload includes pixel quad coordinates, UTF-8 string, and float conf.",
      "Memory note: copy crop arrays if caller mutates input image buffer in-place.",
      "Handles empty detection frames gracefully without invoking rec_predictor.",
      "End-to-end throughput on 1080p document scans: ~31 FPS on RTX 4090.",
      "Supports BGR uint8 numpy images directly from cv2.imread or video streams.",
      "Thread safety depends on underlying predictor session execution provider."
    ],
    code: String.raw`import cv2
import numpy as np


class TextSystemPipeline:
    """End-to-end OCR pipeline: detection -> perspective crop -> recognition."""

    def __init__(self, det_predictor, rec_predictor, drop_score=0.5):
        self.det_predictor = det_predictor
        self.rec_predictor = rec_predictor
        self.drop_score = drop_score

    @staticmethod
    def get_rotate_crop_image(img, points):
        width = int(max(np.linalg.norm(points[0] - points[1]), np.linalg.norm(points[2] - points[3])))
        height = int(max(np.linalg.norm(points[0] - points[3]), np.linalg.norm(points[1] - points[2])))
        dst_pts = np.float32([[0, 0], [width, 0], [width, height], [0, height]])
        mat = cv2.getPerspectiveTransform(points.astype(np.float32), dst_pts)
        dst_img = cv2.warpPerspective(
            img, mat, (width, height), borderMode=cv2.BORDER_REPLICATE, flags=cv2.INTER_CUBIC
        )
        # @@NOVEL@@
        if dst_img.shape[0] * 1.0 / max(dst_img.shape[1], 1) >= 1.5:
            dst_img = np.rot90(dst_img)
        return dst_img

    def __call__(self, image):
        dt_boxes, det_time = self.det_predictor(image)
        if dt_boxes is None or len(dt_boxes) == 0:
            return [], {"det_ms": det_time, "rec_ms": 0.0}
        crops = [self.get_rotate_crop_image(image, box) for box in dt_boxes]
        rec_res, rec_time = self.rec_predictor(crops)
        outputs = []
        for box, (text, score) in zip(dt_boxes, rec_res):
            if score >= self.drop_score:
                outputs.append({"box": box.tolist(), "text": text, "score": float(score)})
        return outputs, {"det_ms": det_time, "rec_ms": rec_time}`
  },
  {
    file: "eval_metrics.py",
    crumbs: ["tools", "eval_metrics.py"],
    lang: "py",
    startLine: 56,
    bossComments: [
      "ICDAR2015 polygon IoU evaluation protocol (Precision, Recall, Hmean).",
      "1. Filter predictions overlapping 'don't care' (###) GT regions with area",
      "   precision > area_precision_constraint (0.5) before matching.",
      "2. Construct pairwise IoU matrix between remaining GT and detected polygons.",
      "3. Apply greedy one-to-one matching for pairs exceeding iou_constraint (0.5).",
      "4. Accumulate matched_sum, num_gt_care, and num_det_care across dataset.",
      "Self-intersecting polygons are repaired via buffer(0) to prevent Shapely",
      "TopologicalError exceptions during intersection area calculation.",
      "Degenerate zero-area boxes return IoU=0.0 safely without ZeroDivisionError.",
      "Hmean = 2 * P * R / (P + R), returning 0.0 when both P and R are zero.",
      "Matches official ICDAR 2015 Task 4.1 script within 1e-5 floating tolerance.",
      "Multi-threaded dataset evaluation scales linearly across CPU cores.",
      "Use iou_constraint=0.5 for standard detection, 0.7 for tight-box audits.",
      "All input polygons expected as shape (N, 2) float coordinates.",
      "Avoid modifying global Shapely precision context in worker processes.",
      "Report dictionary also includes per-image false positive counts for debugging.",
      "Validation set typically completes 500 images in ~2.4 seconds on 8 cores.",
      "Reference baseline (DBNet-R50): P=0.864, R=0.791, Hmean=0.826."
    ],
    code: String.raw`import numpy as np
from shapely.geometry import Polygon


class DetectionIoUEvaluator:
    """Compute ICDAR-style Precision, Recall, and Hmean for text polygons."""

    def __init__(self, iou_constraint=0.5, area_precision_constraint=0.5):
        self.iou_constraint = iou_constraint
        self.area_precision_constraint = area_precision_constraint

    @staticmethod
    def polygon_iou(poly_a, poly_b):
        pa = Polygon(poly_a).buffer(0)
        pb = Polygon(poly_b).buffer(0)
        if not pa.is_valid or not pb.is_valid:
            return 0.0
        inter = pa.intersection(pb).area
        union = pa.area + pb.area - inter
        return float(inter / union) if union > 0.0 else 0.0

    def evaluate_image(self, gt_polys, det_polys):
        matched = 0
        used_det = set()
        # @@NOVEL@@
        for gt in gt_polys:
            best_iou = 0.0
            best_idx = -1
            for idx, det in enumerate(det_polys):
                if idx in used_det:
                    continue
                iou = self.polygon_iou(gt, det)
                if iou > best_iou:
                    best_iou = iou
                    best_idx = idx
            if best_iou >= self.iou_constraint and best_idx >= 0:
                used_det.add(best_idx)
                matched += 1
        precision = matched / max(len(det_polys), 1)
        recall = matched / max(len(gt_polys), 1)
        hmean = 2 * precision * recall / max(precision + recall, 1e-6)
        return {"precision": precision, "recall": recall, "hmean": hmean}`
  },
  {
    file: "det_db_r50.yml",
    crumbs: ["configs", "det_db_r50.yml"],
    lang: "yml",
    startLine: 18,
    bossComments: [
      "Training configuration for ResNet50_vd + FPN + DBHead text detector.",
      "Pretrained ImageNet SSLD weights accelerate convergence by ~40 epochs.",
      "Adjust batch_size_per_card based on available GPU VRAM (16 for 24GB).",
      "Input crop size 640x640 balances small-text recall and training speed.",
      "Shrink ratio 0.4 keeps adjacent text lines separated during binarization.",
      "Border map thresholds clipped to [0.3, 0.7] for stable L1 regression.",
      "Validation runs full-resolution resize (limit_side_len=1280, type=max).",
      "PostProcess unclip_ratio=1.5 tuned on ICDAR2015 + private invoice val.",
      "Learning rate uses AdamW with cosine decay and 2-epoch linear warmup.",
      "Enable use_amp=true on Ampere/Ada GPUs for ~1.7x step throughput.",
      "Checkpoint frequency: save every 10 epochs + overwrite best_accuracy.",
      "DataLoader num_workers=8 with persistent_workers=true on NVMe SSD.",
      "Augmentation pipeline order: Flip -> Rotate -> Crop -> ColorJitter.",
      "Ignore unreadable '###' annotations via ignore_tags mask in DBLoss.",
      "OHEM ratio 3.0 focuses BCE loss on hard background false positives.",
      "Seed fixed to 2026 for reproducible ablation runs across branches.",
      "Export target: ONNX opset 14 -> TensorRT FP16 dynamic profile.",
      "Do not modify architecture.head.k without retraining threshold branch."
    ],
    code: String.raw`Global:
  use_gpu: true
  epoch_num: 500
  log_smooth_window: 20
  print_batch_step: 20
  save_model_dir: ./output/det_db_r50/
  save_epoch_step: 10
  eval_batch_step: [0, 400]
  pretrained_model: ./pretrain/ResNet50_vd_ssld.pth
  use_amp: true

Architecture:
  model_type: det
  algorithm: DB
  Backbone:
    name: ResNet_vd
    layers: 50
    dcn_stage: [False, True, True, True]
  Neck:
    name: DBFPN
    out_channels: 256
  Head:
    name: DBHead
    k: 50
    # @@NOVEL@@

Loss:
  name: DBLoss
  balance_loss: true
  main_loss_type: DiceLoss
  alpha: 5.0
  beta: 10.0
  ohem_ratio: 3.0

Optimizer:
  name: AdamW
  beta1: 0.9
  beta2: 0.999
  lr:
    name: Cosine
    learning_rate: 0.001
    warmup_epoch: 2`
  },
  {
    file: "rec_crnn.yml",
    crumbs: ["configs", "rec_crnn.yml"],
    lang: "yml",
    startLine: 12,
    bossComments: [
      "Recognition model configuration: MobileNetV3_large + BiLSTM + CTC.",
      "Target image height fixed to 48px; max width 320px during training.",
      "Character dictionary covers 6623 common Chinese + ASCII symbols.",
      "Space character enabled to preserve multi-word English fields.",
      "Synthetic + real document crops mixed at 40:60 sampling ratio.",
      "Batch size 128 per GPU yields smooth CTC gradient estimates.",
      "Gradient clipping norm=5.0 prevents LSTM exploding steps on noisy labels.",
      "Use cosine schedule starting at 1e-3 decaying to 1e-5 over 200 epochs.",
      "Evaluation computes exact full-string accuracy and normalized edit distance.",
      "Right-padding uses zero fill after [-1, 1] pixel normalization.",
      "Data augmentation includes mild perspective warp, blur, and contrast jitter.",
      "Beam search optional during offline evaluation; greedy used in production.",
      "Ensure dictionary path matches deployment bundle before exporting ONNX.",
      "Expected validation accuracy on internal receipt benchmark: 96.8%.",
      "Model footprint: 8.9 MB FP32, 4.6 MB FP16 TensorRT engine.",
      "Freeze backbone for first 3 epochs when fine-tuning on new fonts.",
      "Max text length 40 covers 99.7% of cropped lines after splitting.",
      "Verify UTF-8 encoding of label list files before starting training."
    ],
    code: String.raw`Global:
  use_gpu: true
  epoch_num: 200
  log_smooth_window: 20
  save_model_dir: ./output/rec_crnn_mv3/
  character_dict_path: ./configs/ppocr_keys_v1.txt
  max_text_length: 40
  use_space_char: true

Architecture:
  model_type: rec
  algorithm: CRNN
  Backbone:
    name: MobileNetV3
    scale: 0.5
    model_name: large
  Neck:
    name: SequenceEncoder
    encoder_type: rnn
    hidden_size: 256
  Head:
    name: CTCHead
    # @@NOVEL@@

Loss:
  name: CTCLoss
  zero_infinity: true

PostProcess:
  name: CTCLabelDecode

Optimizer:
  name: Adam
  lr:
    name: Cosine
    learning_rate: 0.001
    warmup_epoch: 5`
  }
];
