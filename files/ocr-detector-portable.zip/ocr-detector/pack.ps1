$ErrorActionPreference = "Stop"

$novelsDir = Join-Path $PSScriptRoot "novels"
$outFile = Join-Path $PSScriptRoot "novels.js"

if (-not (Test-Path $novelsDir)) {
    New-Item -ItemType Directory -Path $novelsDir | Out-Null
}

# Fast path using Python 3 when available (handles 15MB+ books in <0.3s)
$pyCmd = $null
if (Get-Command python -ErrorAction SilentlyContinue) { $pyCmd = "python" }
elseif (Get-Command py -ErrorAction SilentlyContinue) { $pyCmd = "py" }

if ($pyCmd) {
    $pyCode = @'
import json, sys
from pathlib import Path

root = Path(sys.argv[1]).resolve()
out = Path(sys.argv[2]).resolve()

def decode_bytes(raw: bytes) -> str:
    if raw.startswith(b"\xef\xbb\xbf"):
        return raw[3:].decode("utf-8", errors="replace")
    try:
        return raw.decode("utf-8")
    except UnicodeDecodeError:
        return raw.decode("gb18030", errors="replace")

items = []
for p in sorted(root.rglob("*")):
    if p.is_file() and p.suffix.lower() in (".txt", ".md"):
        rel = p.relative_to(root).as_posix()
        items.append({"name": rel, "text": decode_bytes(p.read_bytes())})

payload = "window.NOVELS_PACKED = " + json.dumps(items, ensure_ascii=False, separators=(",", ":")) + ";"
out.write_text(payload, encoding="utf-8")
print(f"Packed {len(items)} file(s) into novels.js ({out.stat().st_size / 1024 / 1024:.2f} MB):")
for it in items:
    print(f"  - {it['name']}")
'@
    if ($pyCmd -eq "py") {
        $pyCode | & py -3 - $novelsDir $outFile
    } else {
        $pyCode | & python - $novelsDir $outFile
    }
    exit $LASTEXITCODE
}

# Pure PowerShell fallback (no Python required)
$utf8Strict = New-Object System.Text.UTF8Encoding($false, $true)
$utf8Out = New-Object System.Text.UTF8Encoding($false)
$gbk = [System.Text.Encoding]::GetEncoding("gb18030")
$baseUri = [Uri]((Resolve-Path $novelsDir).Path + "\")

$files = Get-ChildItem -Path $novelsDir -Recurse -File | Where-Object {
    $_.Extension -in @(".txt", ".md")
} | Sort-Object FullName

$sb = New-Object System.Text.StringBuilder
[void]$sb.Append("window.NOVELS_PACKED = [")
$idx = 0
foreach ($f in $files) {
    $bytes = [System.IO.File]::ReadAllBytes($f.FullName)
    if ($bytes.Length -ge 3 -and $bytes[0] -eq 0xEF -and $bytes[1] -eq 0xBB -and $bytes[2] -eq 0xBF) {
        $slice = New-Object byte[] ($bytes.Length - 3)
        [Array]::Copy($bytes, 3, $slice, 0, $slice.Length)
        $bytes = $slice
    }
    try { $text = $utf8Strict.GetString($bytes) } catch { $text = $gbk.GetString($bytes) }
    $rel = [Uri]::UnescapeDataString($baseUri.MakeRelativeUri([Uri]$f.FullName).ToString())
    if ($idx -gt 0) { [void]$sb.Append(",") }
    $entry = ConvertTo-Json -InputObject ([pscustomobject]@{ name = $rel; text = $text }) -Compress
    [void]$sb.Append($entry)
    $idx++
}
[void]$sb.Append("];")
[System.IO.File]::WriteAllText($outFile, $sb.ToString(), $utf8Out)
Write-Host ("Packed {0} file(s) into novels.js." -f $idx)
