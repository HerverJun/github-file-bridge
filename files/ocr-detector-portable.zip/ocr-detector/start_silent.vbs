Option Explicit
Dim fso, sh, dir, scriptPath, pyCmd, htmlPath, url, browserExe

Set fso = CreateObject("Scripting.FileSystemObject")
Set sh = CreateObject("WScript.Shell")
dir = fso.GetParentFolderName(WScript.ScriptFullName)
scriptPath = fso.BuildPath(dir, "server.py")
htmlPath = fso.BuildPath(dir, "index.html")

Function CmdExists(cmdLine)
    On Error Resume Next
    Dim rc
    rc = sh.Run("cmd /c " & cmdLine & " >nul 2>nul", 0, True)
    CmdExists = (Err.Number = 0 And rc = 0)
    On Error GoTo 0
End Function

pyCmd = ""
If CmdExists("pythonw --version") Then
    pyCmd = "pythonw"
ElseIf CmdExists("pyw -3 --version") Then
    pyCmd = "pyw -3"
ElseIf CmdExists("python --version") Then
    pyCmd = "python"
ElseIf CmdExists("py -3 --version") Then
    pyCmd = "py -3"
End If

sh.CurrentDirectory = dir

If pyCmd <> "" Then
    sh.Run pyCmd & " """ & scriptPath & """ --mode app", 0, False
Else
    ' Target machine has no Python 3: gracefully open standalone offline reader window
    Dim candidates, c
    candidates = Array( _
        "C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe", _
        "C:\Program Files\Microsoft\Edge\Application\msedge.exe", _
        "C:\Program Files\Google\Chrome\Application\chrome.exe", _
        "C:\Program Files (x86)\Google\Chrome\Application\chrome.exe" _
    )
    browserExe = ""
    For Each c In candidates
        If fso.FileExists(c) Then
            browserExe = c
            Exit For
        End If
    Next
    url = "file:///" & Replace(htmlPath, "\", "/")
    If browserExe <> "" Then
        sh.Run """" & browserExe & """ --app=""" & url & """ --window-size=1520,880", 1, False
    Else
        sh.Run """" & htmlPath & """", 1, False
    End If
End If
